"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [79898], {
        38405: function(a, r, e) {
            e.d(r, {
                Kw: function() {
                    return i
                },
                fD: function() {
                    return c
                },
                j7: function() {
                    return o
                },
                w: function() {
                    return s
                }
            });
            var t = e(76871),
                l = t.autoNeufMoteurUrl,
                n = l.replace("/fr/", "/ar/"),
                o = [{
                    label: {
                        fr: "byd",
                        ar: "\u0628\u064a \u0648\u0627\u064a \u062f\u064a"
                    },
                    link: {
                        fr: "".concat(l, "byd/"),
                        ar: "".concat(n, "byd/")
                    }
                }, {
                    label: {
                        fr: "opel corsa",
                        ar: "\u0623\u0648\u0628\u0644 \u0643\u0648\u0631\u0633\u0627"
                    },
                    link: {
                        fr: "".concat(l, "opel/corsa/"),
                        ar: "".concat(n, "opel/corsa/")
                    }
                }, {
                    label: {
                        fr: "nissan magnite",
                        ar: "\u0646\u064a\u0633\u0627\u0646 \u0645\u0627\u062c\u0646\u0627\u064a\u062a"
                    },
                    link: {
                        fr: "".concat(l, "nissan/magnite/"),
                        ar: "".concat(n, "nissan/magnite/")
                    }
                }, {
                    label: {
                        fr: "ford raptor",
                        ar: "\u0641\u0648\u0631\u062f \u0631\u0627\u0628\u062a\u0648\u0631"
                    },
                    link: {
                        fr: "".concat(l, "ford/ranger/ford-ranger-4x4-raptor-bva-4051.html"),
                        ar: "".concat(n, "ford/ranger/ford-ranger-4x4-raptor-bva-4051.html")
                    }
                }, {
                    label: {
                        fr: "baic maroc",
                        ar: "\u0628\u0627\u064a\u0643 \u0627\u0644\u0645\u063a\u0631\u0628"
                    },
                    link: {
                        fr: "".concat(l, "baic/"),
                        ar: "".concat(n, "baic/")
                    }
                }, {
                    label: {
                        fr: "cupra",
                        ar: "\u0643\u0648\u0628\u0631\u0627"
                    },
                    link: {
                        fr: "".concat(l, "cupra/"),
                        ar: "".concat(n, "cupra/")
                    }
                }, {
                    label: {
                        fr: "africa twin",
                        ar: "\u0623\u0641\u0631\u064a\u0643\u0627 \u062a\u0648\u064a\u0646"
                    },
                    link: {
                        fr: "https://www.moteur.ma/fr/neuf/moto/honda/crf-africa-twin/",
                        ar: "https://www.moteur.ma/ar/neuf/moto/honda/crf-africa-twin/"
                    }
                }, {
                    label: {
                        fr: "clio 5",
                        ar: "\u0643\u0644\u064a\u0648 5"
                    },
                    link: {
                        fr: "".concat(l, "renault/clio/"),
                        ar: "".concat(n, "renault/clio/")
                    }
                }, {
                    label: {
                        fr: "fiat fiorino",
                        ar: "\u0641\u064a\u0627\u062a \u0641\u064a\u0648\u0631\u064a\u0646\u0648"
                    },
                    link: {
                        fr: "".concat(l, "fiat/fiorino/"),
                        ar: "".concat(n, "fiat/fiorino/")
                    }
                }, {
                    label: {
                        fr: "tiguan",
                        ar: "\u062a\u064a\u062c\u0648\u0627\u0646"
                    },
                    link: {
                        fr: "https://www.moteur.ma/fr/voiture/achat-voiture-occasion/marque/volkswagen/modele/tiguan/",
                        ar: "https://www.moteur.ma/ar/voiture/achat-voiture-occasion/marque/volkswagen/modele/tiguan/"
                    }
                }, {
                    label: {
                        fr: "dacia bigster",
                        ar: "\u062f\u0627\u0633\u064a\u0627 \u0628\u064a\u062c\u0633\u062a\u0631"
                    },
                    link: {
                        fr: "".concat(l, "dacia/bigster/"),
                        ar: "".concat(n, "dacia/bigster/")
                    }
                }, {
                    label: {
                        fr: "renault kardian",
                        ar: "\u0631\u064a\u0646\u0648 \u0643\u0627\u0631\u062f\u064a\u0627\u0646"
                    },
                    link: {
                        fr: "".concat(l, "renault/kardian/"),
                        ar: "".concat(n, "renault/kardian/")
                    }
                }, {
                    label: {
                        fr: "fiat 500",
                        ar: "\u0641\u064a\u0627\u062a 500"
                    },
                    link: {
                        fr: "".concat(l, "fiat/500/"),
                        ar: "".concat(n, "fiat/500/")
                    }
                }, {
                    label: {
                        fr: "peugeot 2008",
                        ar: "\u0628\u064a\u062c\u0648 2008"
                    },
                    link: {
                        fr: "".concat(l, "peugeot/2008/"),
                        ar: "".concat(n, "peugeot/2008/")
                    }
                }, {
                    label: {
                        fr: "hyundai tucson",
                        ar: "\u0647\u064a\u0648\u0646\u062f\u0627\u064a \u062a\u0648\u0643\u0633\u0648\u0646"
                    },
                    link: {
                        fr: "".concat(l, "hyundai/tucson/"),
                        ar: "".concat(n, "hyundai/tucson/")
                    }
                }, {
                    label: {
                        fr: "seat ateca",
                        ar: "\u0633\u064a\u0627\u062a \u0623\u062a\u064a\u0643\u0627"
                    },
                    link: {
                        fr: "".concat(l, "seat/ateca/"),
                        ar: "".concat(n, "seat/ateca/")
                    }
                }, {
                    label: {
                        fr: "bmw gs 1250",
                        ar: "\u0628\u064a \u0625\u0645 \u062f\u0628\u0644\u064a\u0648 \u062c\u064a \u0625\u0633 1250"
                    },
                    link: {
                        fr: "https://www.moteur.ma/fr/neuf/moto/bmw/r1250-gs/",
                        ar: "https://www.moteur.ma/ar/neuf/moto/bmw/r1250-gs/"
                    }
                }, {
                    label: {
                        fr: "golf 8",
                        ar: "\u062c\u0648\u0644\u0641 8"
                    },
                    link: {
                        fr: "https://www.moteur.ma/fr/voiture/achat-voiture-occasion/marque/volkswagen/modele/golf-8/",
                        ar: "https://www.moteur.ma/ar/voiture/achat-voiture-occasion/marque/volkswagen/modele/golf-8/"
                    }
                }, {
                    label: {
                        fr: "t-roc",
                        ar: "\u062a\u064a-\u0631\u0648\u0643"
                    },
                    link: {
                        fr: "".concat(l, "volkswagen/t-roc/"),
                        ar: "".concat(n, "volkswagen/t-roc/")
                    }
                }, {
                    label: {
                        fr: "suzuki jimny",
                        ar: "\u0633\u0648\u0632\u0648\u0643\u064a \u062c\u064a\u0645\u0646\u064a"
                    },
                    link: {
                        fr: "".concat(l, "suzuki/jimny/"),
                        ar: "".concat(n, "suzuki/jimny/")
                    }
                }, {
                    label: {
                        fr: "skoda",
                        ar: "\u0634\u0643\u0648\u062f\u0627"
                    },
                    link: {
                        fr: "".concat(l, "skoda/"),
                        ar: "".concat(n, "skoda/")
                    }
                }, {
                    label: {
                        fr: "audi q8",
                        ar: "\u0623\u0648\u062f\u064a \u0643\u064a\u06488"
                    },
                    link: {
                        fr: "".concat(l, "audi/q8/"),
                        ar: "".concat(n, "audi/q8/")
                    }
                }, {
                    label: {
                        fr: "opel mokka",
                        ar: "\u0623\u0648\u0628\u0644 \u0645\u0648\u0643\u0627"
                    },
                    link: {
                        fr: "".concat(l, "opel/mokka/"),
                        ar: "".concat(n, "opel/mokka/")
                    }
                }, {
                    label: {
                        fr: "kia seltos",
                        ar: "\u0643\u064a\u0627 \u0633\u064a\u0644\u062a\u0648\u0633"
                    },
                    link: {
                        fr: "".concat(l, "kia/seltos/"),
                        ar: "".concat(n, "kia/seltos/")
                    }
                }, {
                    label: {
                        fr: "changan",
                        ar: "\u062a\u0634\u0627\u0646\u062c\u0627\u0646"
                    },
                    link: {
                        fr: "".concat(l, "changan/"),
                        ar: "".concat(n, "changan/")
                    }
                }, {
                    label: {
                        fr: "kymco maroc",
                        ar: "\u0643\u064a\u0645\u0643\u0648 \u0627\u0644\u0645\u063a\u0631\u0628"
                    },
                    link: {
                        fr: "https://www.moteur.ma/fr/neuf/moto/kymco/",
                        ar: "https://www.moteur.ma/ar/neuf/moto/kymco/"
                    }
                }, {
                    label: {
                        fr: "peugeot 208",
                        ar: "\u0628\u064a\u062c\u0648 208"
                    },
                    link: {
                        fr: "".concat(l, "peugeot/208/"),
                        ar: "".concat(n, "peugeot/208/")
                    }
                }, {
                    label: {
                        fr: "audi q3",
                        ar: "\u0623\u0648\u062f\u064a \u0643\u064a\u06483"
                    },
                    link: {
                        fr: "".concat(l, "audi/q3/"),
                        ar: "".concat(n, "audi/q3/")
                    }
                }, {
                    label: {
                        fr: "hyundai accent",
                        ar: "\u0647\u064a\u0648\u0646\u062f\u0627\u064a \u0623\u0643\u0633\u0646\u062a"
                    },
                    link: {
                        fr: "".concat(l, "hyundai/accent/"),
                        ar: "".concat(n, "hyundai/accent/")
                    }
                }, {
                    label: {
                        fr: "peugeot 3008",
                        ar: "\u0628\u064a\u062c\u0648 3008"
                    },
                    link: {
                        fr: "".concat(l, "peugeot/3008/"),
                        ar: "".concat(n, "peugeot/3008/")
                    }
                }, {
                    label: {
                        fr: "lamborghini urus",
                        ar: "\u0644\u0627\u0645\u0628\u0648\u0631\u062c\u064a\u0646\u064a \u0623\u0648\u0631\u0648\u0633"
                    },
                    link: {
                        fr: "https://www.moteur.ma/fr/voiture/achat-voiture-occasion/marque/lamborghini/modele/urus/",
                        ar: "https://www.moteur.ma/ar/voiture/achat-voiture-occasion/marque/lamborghini/modele/urus/"
                    }
                }, {
                    label: {
                        fr: "fiat tipo",
                        ar: "\u0641\u064a\u0627\u062a \u062a\u064a\u0628\u0648"
                    },
                    link: {
                        fr: "".concat(l, "fiat/tipo/"),
                        ar: "".concat(n, "fiat/tipo/")
                    }
                }, {
                    label: {
                        fr: "nissan qashqai",
                        ar: "\u0646\u064a\u0633\u0627\u0646 \u0642\u0627\u0634\u0642\u0627\u064a"
                    },
                    link: {
                        fr: "".concat(l, "nissan/qashqai/"),
                        ar: "".concat(n, "nissan/qashqai/")
                    }
                }, {
                    label: {
                        fr: "skoda kodiaq",
                        ar: "\u0634\u0643\u0648\u062f\u0627 \u0643\u0648\u062f\u064a\u0627\u0643"
                    },
                    link: {
                        fr: "".concat(l, "skoda/kodiaq/"),
                        ar: "".concat(n, "skoda/kodiaq/")
                    }
                }, {
                    label: {
                        fr: "hyundai creta",
                        ar: "\u0647\u064a\u0648\u0646\u062f\u0627\u064a \u0643\u0631\u064a\u062a\u0627"
                    },
                    link: {
                        fr: "".concat(l, "hyundai/creta/"),
                        ar: "".concat(n, "hyundai/creta/")
                    }
                }, {
                    label: {
                        fr: "kia sportage",
                        ar: "\u0643\u064a\u0627 \u0633\u0628\u0648\u0631\u062a\u0627\u062c"
                    },
                    link: {
                        fr: "".concat(l, "kia/sportage/"),
                        ar: "".concat(n, "kia/sportage/")
                    }
                }, {
                    label: {
                        fr: "dacia logan",
                        ar: "\u062f\u0627\u0633\u064a\u0627 \u0644\u0648\u062c\u0627\u0646"
                    },
                    link: {
                        fr: "".concat(l, "dacia/logan/"),
                        ar: "".concat(n, "dacia/logan/")
                    }
                }, {
                    label: {
                        fr: "touareg",
                        ar: "\u0637\u0648\u0627\u0631\u0642"
                    },
                    link: {
                        fr: "".concat(l, "volkswagen/touareg/"),
                        ar: "".concat(n, "volkswagen/touareg/")
                    }
                }, {
                    label: {
                        fr: "toyota yaris",
                        ar: "\u062a\u0648\u064a\u0648\u062a\u0627 \u064a\u0627\u0631\u064a\u0633"
                    },
                    link: {
                        fr: "".concat(l, "toyota/yaris/"),
                        ar: "".concat(n, "toyota/yaris/")
                    }
                }, {
                    label: {
                        fr: "toyota",
                        ar: "\u062a\u0648\u064a\u0648\u062a\u0627"
                    },
                    link: {
                        fr: "".concat(l, "toyota/"),
                        ar: "".concat(n, "toyota/")
                    }
                }, {
                    label: {
                        fr: "mercedes vito",
                        ar: "\u0645\u0631\u0633\u064a\u062f\u0633 \u0641\u064a\u062a\u0648"
                    },
                    link: {
                        fr: "".concat(l, "mercedes-benz/vito/"),
                        ar: "".concat(n, "mercedes-benz/vito/")
                    }
                }, {
                    label: {
                        fr: "qj motor maroc",
                        ar: "\u0643\u064a\u0648 \u062c\u064a \u0645\u0648\u062a\u0648\u0631 \u0627\u0644\u0645\u063a\u0631\u0628"
                    },
                    link: {
                        fr: "https://www.moteur.ma/fr/neuf/moto/qjmotor/",
                        ar: "https://www.moteur.ma/ar/neuf/moto/qjmotor/"
                    }
                }, {
                    label: {
                        fr: "ford focus",
                        ar: "\u0641\u0648\u0631\u062f \u0641\u0648\u0643\u0633"
                    },
                    link: {
                        fr: "".concat(l, "ford/focus/"),
                        ar: "".concat(n, "ford/focus/")
                    }
                }, {
                    label: {
                        fr: "seat ibiza",
                        ar: "\u0633\u064a\u0627\u062a \u0625\u064a\u0628\u064a\u0632\u0627"
                    },
                    link: {
                        fr: "".concat(l, "seat/ibiza/"),
                        ar: "".concat(n, "seat/ibiza/")
                    }
                }, {
                    label: {
                        fr: "skoda kamiq",
                        ar: "\u0634\u0643\u0648\u062f\u0627 \u0643\u0627\u0645\u064a\u0643"
                    },
                    link: {
                        fr: "".concat(l, "skoda/kamiq/"),
                        ar: "".concat(n, "skoda/kamiq/")
                    }
                }, {
                    label: {
                        fr: "geely",
                        ar: "\u062c\u064a\u0644\u064a"
                    },
                    link: {
                        fr: "".concat(l, "geely/"),
                        ar: "".concat(n, "geely/")
                    }
                }, {
                    label: {
                        fr: "caddy",
                        ar: "\u0643\u0627\u062f\u064a"
                    },
                    link: {
                        fr: "".concat(l, "volkswagen/caddy/"),
                        ar: "".concat(n, "volkswagen/caddy/")
                    }
                }, {
                    label: {
                        fr: "ford transit",
                        ar: "\u0641\u0648\u0631\u062f \u062a\u0631\u0627\u0646\u0632\u064a\u062a"
                    },
                    link: {
                        fr: "".concat(l, "ford/transit/"),
                        ar: "".concat(n, "ford/transit/")
                    }
                }, {
                    label: {
                        fr: "skoda octavia",
                        ar: "\u0634\u0643\u0648\u062f\u0627 \u0623\u0648\u0643\u062a\u0627\u0641\u064a\u0627"
                    },
                    link: {
                        fr: "".concat(l, "skoda/octavia/"),
                        ar: "".concat(n, "skoda/octavia/")
                    }
                }],
                i = [{
                    label: {
                        ar: "\u0627\u0644\u062f\u0627\u0631 \u0627\u0644\u0628\u064a\u0636\u0627\u0621",
                        fr: "Casablanca"
                    },
                    slug: "casablanca"
                }, {
                    label: {
                        ar: "\u0623\u0643\u0627\u062f\u064a\u0631",
                        fr: "Agadir"
                    },
                    slug: "agadir"
                }, {
                    label: {
                        ar: "\u0627\u0644\u0631\u0628\u0627\u0637",
                        fr: "Rabat"
                    },
                    slug: "rabat"
                }, {
                    label: {
                        ar: "\u0627\u0644\u062d\u0633\u064a\u0645\u0629",
                        fr: "Al Hoce\xefma"
                    },
                    slug: "al_hoceima"
                }, {
                    label: {
                        ar: "\u0645\u0631\u0627\u0643\u0634",
                        fr: "Marrakech"
                    },
                    slug: "marrakech"
                }, {
                    label: {
                        ar: "\u0645\u0643\u0646\u0627\u0633",
                        fr: "Mekn\xe8s"
                    },
                    slug: "meknes"
                }, {
                    label: {
                        ar: "\u0627\u0644\u0646\u0627\u0638\u0648\u0631",
                        fr: "Nador"
                    },
                    slug: "nador"
                }, {
                    label: {
                        ar: "\u0637\u0646\u062c\u0629",
                        fr: "Tanger"
                    },
                    slug: "tanger"
                }, {
                    label: {
                        ar: "\u0628\u0646\u0649 \u0645\u0644\u0627\u0644",
                        fr: "B\xe9ni Mellal"
                    },
                    slug: "beni_mellal"
                }, {
                    label: {
                        ar: "\u0627\u0644\u062c\u062f\u064a\u062f\u0629",
                        fr: "El Jadida"
                    },
                    slug: "el_jadida"
                }, {
                    label: {
                        ar: "\u0627\u0644\u0631\u0634\u064a\u062f\u064a\u0629",
                        fr: "Errachidia"
                    },
                    slug: "errachidia"
                }, {
                    label: {
                        ar: "\u0641\u0627\u0633",
                        fr: "F\xe8s"
                    },
                    slug: "fes"
                }, {
                    label: {
                        ar: "\u0627\u0644\u0642\u0646\u064a\u0637\u0631\u0629",
                        fr: "K\xe9nitra"
                    },
                    slug: "kenitra"
                }, {
                    label: {
                        ar: "\u0648\u062c\u062f\u0629",
                        fr: "Oujda"
                    },
                    slug: "oujda"
                }, {
                    label: {
                        ar: "\u062e\u0646\u064a\u0641\u0631\u0629",
                        fr: "kh\xe9nifra"
                    },
                    slug: "khenifra"
                }, {
                    label: {
                        ar: "\u062e\u0631\u064a\u0628\u0643\u0629",
                        fr: "Khouribga"
                    },
                    slug: "khouribga"
                }, {
                    label: {
                        ar: "\u0627\u0644\u0639\u0631\u0627\u0626\u0634",
                        fr: "Larache"
                    },
                    slug: "larache"
                }, {
                    label: {
                        ar: "\u0648\u0631\u0632\u0627\u0632\u0627\u062a",
                        fr: "Ouarzazate"
                    },
                    slug: "ouarzazate"
                }, {
                    label: {
                        ar: "\u0627\u0633\u0641\u064a",
                        fr: "Safi"
                    },
                    slug: "safi"
                }, {
                    label: {
                        ar: "\u062a\u0627\u0632\u0629",
                        fr: "Taza"
                    },
                    slug: "taza"
                }, {
                    label: {
                        ar: "\u062a\u0637\u0648\u0627\u0646",
                        fr: "T\xe9touan"
                    },
                    slug: "tetouan"
                }, {
                    label: {
                        ar: "\u0633\u0637\u0627\u062a",
                        fr: "Settat"
                    },
                    slug: "settat"
                }, {
                    label: {
                        ar: "\u0633\u0644\u0627",
                        fr: "Sal\xe9"
                    },
                    slug: "sale"
                }],
                c = [{
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u062f\u0627\u0631 \u0627\u0644\u0628\u064a\u0636\u0627\u0621",
                        fr: "Immobilier \xe0 Casablanca"
                    },
                    slug: "casablanca/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u0631\u0628\u0627\u0637",
                        fr: "Immobilier \xe0 Rabat"
                    },
                    slug: "rabat/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0645\u0631\u0627\u0643\u0634",
                        fr: "Immobilier \xe0 Marrakech"
                    },
                    slug: "marrakech/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0623\u0643\u0627\u062f\u064a\u0631",
                        fr: "Immobilier \xe0 Agadir"
                    },
                    slug: "agadir/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0641\u0627\u0633",
                        fr: "Immobilier \xe0 F\xe8s"
                    },
                    slug: "fes/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0633\u0644\u0627",
                        fr: "Immobilier \xe0 Sal\xe9"
                    },
                    slug: "sale/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0637\u0646\u062c\u0629",
                        fr: "Immobilier \xe0 Tanger"
                    },
                    slug: "tanger/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u0642\u0646\u064a\u0637\u0631\u0629",
                        fr: "Immobilier \xe0 K\xe9nitra"
                    },
                    slug: "kenitra/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0645\u0643\u0646\u0627\u0633",
                        fr: "Immobilier \xe0 Mekn\xe8s"
                    },
                    slug: "meknes/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u062c\u062f\u064a\u062f\u0629",
                        fr: "Immobilier \xe0 El Jadida"
                    },
                    slug: "el_jadida/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u062a\u0637\u0648\u0627\u0646",
                        fr: "Immobilier \xe0 T\xe9touan"
                    },
                    slug: "tetouan/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0633\u0637\u0627\u062a",
                        fr: "Immobilier \xe0 Settat"
                    },
                    slug: "settat/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u0646\u0627\u0638\u0648\u0631",
                        fr: "Immobilier \xe0 Nador"
                    },
                    slug: "nador/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0628\u0646\u064a \u0645\u0644\u0627\u0644",
                        fr: "Immobilier \xe0 B\xe9ni Mellal"
                    },
                    slug: "beni_mellal/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u0631\u0634\u064a\u062f\u064a\u0629",
                        fr: "Immobilier \xe0 Errachidia"
                    },
                    slug: "errachidia/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0648\u062c\u062f\u0629",
                        fr: "Immobilier \xe0 Oujda"
                    },
                    slug: "oujda/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u062e\u0646\u064a\u0641\u0631\u0629",
                        fr: "Immobilier \xe0 Kh\xe9nifra"
                    },
                    slug: "khenifra/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u062e\u0631\u064a\u0628\u0643\u0629",
                        fr: "Immobilier \xe0 Khouribga"
                    },
                    slug: "khouribga/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u0639\u0631\u0627\u0626\u0634",
                        fr: "Immobilier \xe0 Larache"
                    },
                    slug: "larache/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0648\u0631\u0632\u0627\u0632\u0627\u062a",
                        fr: "Immobilier \xe0 Ouarzazate"
                    },
                    slug: "ouarzazate/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0622\u0633\u0641\u064a",
                        fr: "Immobilier \xe0 Safi"
                    },
                    slug: "safi/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u062a\u0627\u0632\u0629",
                        fr: "Immobilier \xe0 Taza"
                    },
                    slug: "taza/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u0645\u062d\u0645\u062f\u064a\u0629",
                        fr: "Immobilier \xe0 Mohammedia"
                    },
                    slug: "mohammedia/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u0635\u0648\u064a\u0631\u0629",
                        fr: "Immobilier \xe0 Essaouira"
                    },
                    slug: "essaouira/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0627\u0644\u062f\u0627\u062e\u0644\u0629",
                        fr: "Immobilier \xe0 Dakhla"
                    },
                    slug: "dakhla/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0625\u0641\u0631\u0627\u0646",
                        fr: "Immobilier \xe0 Ifrane"
                    },
                    slug: "ifrane/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0628\u0646\u0633\u0644\u064a\u0645\u0627\u0646",
                        fr: "Immobilier \xe0 Benslimane"
                    },
                    slug: "benslimane/immobilier"
                }, {
                    label: {
                        ar: "\u0639\u0642\u0627\u0631\u0627\u062a \u0641\u064a \u0628\u0648\u0632\u0646\u064a\u0642\u0629",
                        fr: "Immobilier \xe0 Bouznika"
                    },
                    slug: "bouznika/immobilier"
                }],
                s = [{
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u0645\u0631\u0627\u0643\u0634",
                        fr: "Appartement \xe0 louer Marrakech"
                    },
                    slug: "marrakech/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u0627\u0644\u0631\u0628\u0627\u0637",
                        fr: "Appartement \xe0 louer Rabat"
                    },
                    slug: "rabat/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0645\u0631\u0627\u0643\u0634",
                        fr: "Appartement \xe0 vendre Marrakech"
                    },
                    slug: "marrakech/appartements-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u0627\u0644\u062f\u0627\u0631 \u0627\u0644\u0628\u064a\u0636\u0627\u0621",
                        fr: "Appartement \xe0 louer Casablanca"
                    },
                    slug: "casablanca/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u062a\u0645\u0627\u0631\u0629",
                        fr: "Appartement \xe0 louer Temara"
                    },
                    slug: "temara/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0637\u0646\u062c\u0629",
                        fr: "Appartement \xe0 vendre Tanger"
                    },
                    slug: "tanger/appartements-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0627\u0644\u0631\u0628\u0627\u0637",
                        fr: "Appartement \xe0 vendre Rabat"
                    },
                    slug: "rabat/appartements-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u0627\u0644\u0642\u0646\u064a\u0637\u0631\u0629",
                        fr: "Appartement \xe0 louer K\xe9nitra"
                    },
                    slug: "kenitra/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u062a\u0645\u0627\u0631\u0629",
                        fr: "Appartement \xe0 vendre Temara"
                    },
                    slug: "temara/appartements-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u0627\u0644\u0645\u062d\u0645\u062f\u064a\u0629",
                        fr: "Appartement \xe0 louer Mohammedia"
                    },
                    slug: "mohammedia/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0623\u0643\u0627\u062f\u064a\u0631",
                        fr: "Appartement \xe0 vendre Agadir"
                    },
                    slug: "agadir/appartements-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u062a\u0637\u0648\u0627\u0646",
                        fr: "Appartement \xe0 louer T\xe9touan"
                    },
                    slug: "tetouan/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0627\u0644\u0642\u0646\u064a\u0637\u0631\u0629",
                        fr: "Appartement \xe0 vendre K\xe9nitra"
                    },
                    slug: "kenitra/appartements-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u0645\u0643\u0646\u0627\u0633",
                        fr: "Appartement \xe0 louer Mekn\xe8s"
                    },
                    slug: "meknes/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u0641\u0627\u0633",
                        fr: "Appartement \xe0 louer F\xe8s"
                    },
                    slug: "fes/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0628\u0648\u0632\u0646\u064a\u0642\u0629",
                        fr: "Appartement \xe0 vendre Bouznika"
                    },
                    slug: "bouznika/appartements-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0625\u064a\u062c\u0627\u0631 \u0641\u064a \u0628\u0648\u0633\u0643\u0648\u0631\u0629",
                        fr: "Appartement \xe0 louer Bouskoura"
                    },
                    slug: "bouskoura/appartements-%C3%A0_louer"
                }, {
                    label: {
                        ar: "\u0634\u0642\u0629 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0645\u0631\u062a\u064a\u0644",
                        fr: "Appartement \xe0 vendre Martil"
                    },
                    slug: "martil/appartements-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0641\u064a\u0644\u0627 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0627\u0644\u062c\u062f\u064a\u062f\u0629",
                        fr: "Villa \xe0 vendre El Jadida"
                    },
                    slug: "el_jadida/villas_riad-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0641\u064a\u0644\u0627 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0645\u0631\u0627\u0643\u0634",
                        fr: "Villa \xe0 vendre Marrakech"
                    },
                    slug: "marrakech/villas_riad-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0641\u064a\u0644\u0627 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0627\u0644\u062f\u0627\u0631 \u0627\u0644\u0628\u064a\u0636\u0627\u0621",
                        fr: "Villa \xe0 vendre Casablanca"
                    },
                    slug: "casablanca/villas_riad-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0641\u064a\u0644\u0627 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0627\u0644\u0631\u0628\u0627\u0637",
                        fr: "Villa \xe0 vendre Rabat"
                    },
                    slug: "rabat/villas_riad-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0645\u0646\u0632\u0644 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0648\u062c\u062f\u0629",
                        fr: "Maison \xe0 vendre Oujda"
                    },
                    slug: "oujda/maisons-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0645\u0646\u0632\u0644 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0623\u0643\u0627\u062f\u064a\u0631",
                        fr: "Maison \xe0 vendre Agadir"
                    },
                    slug: "agadir/maisons-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0645\u0646\u0632\u0644 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0645\u0631\u0627\u0643\u0634",
                        fr: "Maison \xe0 vendre Marrakech"
                    },
                    slug: "marrakech/maisons-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0645\u0646\u0632\u0644 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0637\u0646\u062c\u0629",
                        fr: "Maison \xe0 vendre Tanger"
                    },
                    slug: "tanger/maisons-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0645\u0646\u0632\u0644 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0627\u0644\u0642\u0646\u064a\u0637\u0631\u0629",
                        fr: "Maison \xe0 vendre K\xe9nitra"
                    },
                    slug: "kenitra/maisons-%C3%A0_vendre"
                }, {
                    label: {
                        ar: "\u0641\u064a\u0644\u0627 \u0644\u0644\u0628\u064a\u0639 \u0641\u064a \u0641\u0627\u0633",
                        fr: "Villa \xe0 vendre F\xe8s"
                    },
                    slug: "fes/villas_riad-%C3%A0_vendre"
                }]
        },
        31512: function(a, r, e) {
            var t = e(67294),
                l = e(2185),
                n = e(76871),
                o = e(70232),
                i = e(38405),
                c = e(92398),
                s = e(96977),
                u = e(85893);

            function m(a) {
                var r = a.cities,
                    e = (0, l.v9)(o.P6),
                    i = (0, t.useContext)(s.Q).__t,
                    m = (0, t.useMemo)((function() {
                        return r.map((function(a) {
                            return {
                                label: a.label[e],
                                url: "".concat(n.baseUrl, "/").concat(e, "/").concat(a.slug)
                            }
                        }))
                    }), [r, e]);
                return (0, u.jsx)(c.Z, {
                    list: m,
                    title: i("av.listing.seoLinks.popular.cities.heading")
                })
            }
            m.defaultProps = {
                cities: i.Kw
            }, r.Z = (0, t.memo)(m)
        },
        64554: function(a, r, e) {
            e.d(r, {
                Z: function() {
                    return I
                }
            });
            var t = e(59499),
                l = e(17674),
                n = e(67294),
                o = e(11399),
                i = e(51338),
                c = e(50029),
                s = e(87794),
                u = e.n(s),
                m = e(88767),
                f = e(2185),
                b = e(90762),
                d = e(93550),
                g = e(96977),
                p = e(73315),
                k = e(20511),
                v = e(76871),
                h = e(16700),
                w = e(51121),
                _ = e(5526),
                y = e(85893),
                A = function(a) {
                    var r = new URL(v.avitoMagEndpoint);
                    return r.searchParams.set("_fields", "id,title,link,featured_media,featured_media_src_url"), a && r.searchParams.set("categories", a), r.toString()
                },
                C = function() {
                    var a = (0, c.Z)(u().mark((function a() {
                        var r, e, t, l, n, o, i, c, s, m = arguments;
                        return u().wrap((function(a) {
                            for (;;) switch (a.prev = a.next) {
                                case 0:
                                    return r = m.length > 0 && void 0 !== m[0] ? m[0] : {}, e = r.categories, t = r.signal, l = A(e), a.prev = 2, a.next = 5, fetch(l, {
                                        method: "GET",
                                        headers: {
                                            Accept: "application/json",
                                            "Content-Type": "text/plain"
                                        },
                                        signal: t
                                    });
                                case 5:
                                    if ((n = a.sent).ok) {
                                        a.next = 15;
                                        break
                                    }
                                    return a.next = 9, n.text().catch((function() {
                                        return ""
                                    }));
                                case 9:
                                    throw o = a.sent, (i = new Error("Failed to fetch magazine posts (".concat(n.status, ")"))).status = n.status, i.responseBody = o, i.url = l, i;
                                case 15:
                                    return a.next = 17, n.json();
                                case 17:
                                    if (c = a.sent, Array.isArray(c)) {
                                        a.next = 23;
                                        break
                                    }
                                    throw (s = new Error("Unexpected magazine posts payload shape")).url = l, s.payload = c, s;
                                case 23:
                                    return a.abrupt("return", c.sort((function(a, r) {
                                        return r.id - a.id
                                    })));
                                case 26:
                                    if (a.prev = 26, a.t0 = a.catch(2), "AbortError" !== (null === a.t0 || void 0 === a.t0 ? void 0 : a.t0.name)) {
                                        a.next = 30;
                                        break
                                    }
                                    throw a.t0;
                                case 30:
                                    throw h.Z.error("Error fetching magazine posts", {
                                        message: null === a.t0 || void 0 === a.t0 ? void 0 : a.t0.message,
                                        status: null === a.t0 || void 0 === a.t0 ? void 0 : a.t0.status,
                                        url: (null === a.t0 || void 0 === a.t0 ? void 0 : a.t0.url) || l
                                    }), a.t0;
                                case 32:
                                case "end":
                                    return a.stop()
                            }
                        }), a, null, [
                            [2, 26]
                        ])
                    })));
                    return function() {
                        return a.apply(this, arguments)
                    }
                }();

            function j(a) {
                var r = a.category,
                    e = a.subCategory,
                    t = a.avitoMagCategories,
                    l = a.utmTags,
                    o = (0, n.useContext)(g.Q).__t,
                    i = (0, f.v9)((function(a) {
                        return a.page
                    })).page_type,
                    c = (0, m.useQuery)(["magazinePosts", t], (function(a) {
                        var r = a.signal;
                        return C({
                            categories: t,
                            signal: r
                        })
                    }), {
                        staleTime: 6e5,
                        retry: function(a, r) {
                            return "AbortError" !== (null === r || void 0 === r ? void 0 : r.name) && (!(null !== r && void 0 !== r && r.status && r.status >= 400 && r.status < 500) && a < 1)
                        },
                        enabled: !0,
                        onError: function(a) {
                            "AbortError" !== (null === a || void 0 === a ? void 0 : a.name) && h.Z.error("React Query error fetching magazine posts", {
                                message: null === a || void 0 === a ? void 0 : a.message,
                                status: null === a || void 0 === a ? void 0 : a.status,
                                url: null === a || void 0 === a ? void 0 : a.url
                            })
                        }
                    }),
                    s = c.data,
                    u = void 0 === s ? [] : s,
                    A = c.isLoading,
                    j = c.isError,
                    x = c.error,
                    M = (0, n.useMemo)((function() {
                        return {
                            slidesToShow: 3.1,
                            slidesToScroll: 2,
                            responsive: [{
                                breakpoint: 320,
                                settings: {
                                    slidesToShow: 1.1,
                                    slidesToScroll: 1
                                }
                            }, {
                                breakpoint: b.AV.sm,
                                settings: {
                                    slidesToShow: 1.2,
                                    slidesToScroll: 1
                                }
                            }, {
                                breakpoint: b.AV.md,
                                settings: {
                                    slidesToShow: 1.5,
                                    slidesToScroll: 2
                                }
                            }, {
                                breakpoint: b.AV.xxl,
                                settings: {
                                    slidesToShow: 3.1,
                                    slidesToScroll: 2
                                }
                            }]
                        }
                    }), []),
                    z = function() {
                        (0, p.ut)(k.D.COMMON__ELEMENT_CLICKED, {
                            element_name: "magazine_articles",
                            page_name: i,
                            category_id: r,
                            subcategory_id: e,
                            value: "",
                            seller_type: ""
                        })
                    };
                return A || j || 0 === u.length ? (j && "AbortError" !== (null === x || void 0 === x ? void 0 : x.name) && h.Z.error("Magazine posts failed to load page_name: ".concat(i, ", category_id: ").concat(r, ", subcategory_id: ").concat(e), {
                    message: null === x || void 0 === x ? void 0 : x.message,
                    status: null === x || void 0 === x ? void 0 : x.status,
                    url: null === x || void 0 === x ? void 0 : x.url,
                    categories: t
                }), null) : (0, y.jsx)(_.Z, {
                    heading: (0, y.jsx)(w.R, {
                        headingText: o("av.common.magazine.title")
                    }),
                    cards: function(a) {
                        return a.map((function(a) {
                            var r;
                            return (0, y.jsx)(d.Z, {
                                title: null === (r = a.title) || void 0 === r ? void 0 : r.rendered,
                                src: a.featured_media_src_url || v.IMAGE_PLACEHOLDER,
                                to: "".concat(a.link).concat(l),
                                onCardClick: z
                            }, a.id)
                        }))
                    }(u),
                    carouselSliderSettings: M
                })
            }
            j.defaultProps = {
                avitoMagCategories: "",
                utmTags: "",
                category: 0,
                subCategory: 0
            };
            var x = j;

            function M(a, r) {
                var e = Object.keys(a);
                if (Object.getOwnPropertySymbols) {
                    var t = Object.getOwnPropertySymbols(a);
                    r && (t = t.filter((function(r) {
                        return Object.getOwnPropertyDescriptor(a, r).enumerable
                    }))), e.push.apply(e, t)
                }
                return e
            }

            function z(a) {
                for (var r = 1; r < arguments.length; r++) {
                    var e = null != arguments[r] ? arguments[r] : {};
                    r % 2 ? M(Object(e), !0).forEach((function(r) {
                        (0, t.Z)(a, r, e[r])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(a, Object.getOwnPropertyDescriptors(e)) : M(Object(e)).forEach((function(r) {
                        Object.defineProperty(a, r, Object.getOwnPropertyDescriptor(e, r))
                    }))
                }
                return a
            }

            function E(a) {
                var r = (0, n.useRef)(null),
                    e = (0, i.Z)({
                        ref: r,
                        offset: "400px"
                    }),
                    t = (0, l.Z)(e, 1)[0];
                return (0, y.jsx)("div", {
                    ref: r,
                    children: (0, y.jsx)(o.k, {
                        condition: t,
                        children: (0, y.jsx)(x, z({}, a))
                    })
                })
            }
            var I = (0, n.memo)(E)
        },
        34883: function(a, r, e) {
            e.d(r, {
                IF: function() {
                    return l
                },
                Kq: function() {
                    return n
                },
                QL: function() {
                    return i
                },
                u6: function() {
                    return o
                }
            });
            var t = e(74324),
                l = {
                    1e3: {
                        ar: "181,191",
                        fr: "66,76"
                    },
                    2e3: {
                        ar: "193,183",
                        fr: "78,68"
                    },
                    5e3: {
                        ar: "70",
                        fr: "70"
                    },
                    0: {
                        ar: "179",
                        fr: "64"
                    }
                },
                n = function(a) {
                    var r, e, t = a.category,
                        n = a.lang;
                    return (null === (r = l[t]) || void 0 === r ? void 0 : r[n]) || (null === (e = l[0]) || void 0 === e ? void 0 : e[n])
                },
                o = function(a) {
                    return "0" === String(a) || (0, t.EM)(a) || (0, t.tT)(a) || (0, t.$X)(a)
                },
                i = function(a) {
                    var r = a.category,
                        e = a.page;
                    return (0, t.EM)(r) ? "?utm_source=avito&utm_medium=".concat(e, "&utm_campaign=RE") : (0, t.tT)(r) ? "?utm_source=avito&utm_medium=".concat(e, "&utm_campaign=AUTO") : (0, t.$X)(r) ? "?utm_source=avito&utm_medium=".concat(e, "&utm_campaign=MULTIMEDIA") : "?utm_source=avito&utm_medium=".concat(e, "&utm_campaign=GENERAL")
                }
        },
        92398: function(a, r, e) {
            e.d(r, {
                Z: function() {
                    return y
                }
            });
            var t, l, n, o, i = e(67294),
                c = e(99689),
                s = e(41686),
                u = e(25849),
                m = e(31155),
                f = e(71383),
                b = e(48538),
                d = e(22329),
                g = e(19235),
                p = e(19521).default,
                k = (p.div(t || (t = (0, f.Z)([""]))), p.span(l || (l = (0, f.Z)(["\n  font-size: ", ";\n  color: ", ";\n  font-weight: 200;\n"])), (0, b.px)(d.Z[2]), g.ZP.midnight_lighter), p.span(n || (n = (0, f.Z)(["\n  margin-right: ", ";\n"])), (0, m.W)(3))),
                v = p.a(o || (o = (0, f.Z)(["\n  font-size: ", ";\n  color: ", ";\n  margin-right: ", ";\n  cursor: default;\n  &:hover {\n    color: ", ";\n    text-decoration: none;\n    cursor: pointer;\n  }\n"])), (0, b.px)(d.Z[2]), g.ZP.midnight_lighter, (0, m.W)(3), g.ZP.sea_normal),
                h = e(92003),
                w = e(85893),
                _ = function(a) {
                    var r = a.list,
                        e = a.title;
                    return r.length ? (0, w.jsxs)(c.X, {
                        children: [(0, w.jsx)(s.xv, {
                            variant: "h6",
                            fontWeight: 400,
                            children: e
                        }), (0, w.jsx)(u.J, {
                            children: (0, w.jsx)(h.A0, {
                                wrap: "true",
                                margin: "0 0 ".concat((0, m.W)(5), " 0"),
                                children: r.map((function(a, e) {
                                    var t = a.label,
                                        l = a.url;
                                    return (0, w.jsx)("div", {
                                        children: (0, w.jsxs)(s.xv, {
                                            variant: "body2",
                                            fontWeight: 200,
                                            color: "midnight_lighter",
                                            noMargin: !0,
                                            children: [(0, w.jsx)(v, {
                                                href: l,
                                                children: t
                                            }), e !== r.length - 1 && (0, w.jsx)(k, {
                                                children: "|"
                                            })]
                                        }, t)
                                    }, t)
                                }))
                            })
                        })]
                    }) : null
                },
                y = (0, i.memo)(_)
        }
    }
]);