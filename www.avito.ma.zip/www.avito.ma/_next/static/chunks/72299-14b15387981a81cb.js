(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [72299], {
        96607: function(e, t, a) {
            var n = {
                "./": [49679, 49679],
                "./Abs": [41509, 41509],
                "./Abs.js": [41509, 41509],
                "./AccessoiresInformatique": [51226, 51226],
                "./AccessoiresInformatique.js": [51226, 51226],
                "./AccountCircle": [29208, 29208],
                "./AccountCircle.js": [29208, 29208],
                "./AccountCircleLine": [59175, 59175],
                "./AccountCircleLine.js": [59175, 59175],
                "./Add": [31011, 31011],
                "./Add.js": [31011, 31011],
                "./AddCircle": [80682, 80682],
                "./AddCircle.js": [80682, 80682],
                "./AddNote": [54031, 54031],
                "./AddNote.js": [54031, 54031],
                "./AirConditioning": [78902, 78902],
                "./AirConditioning.js": [78902, 78902],
                "./Airbags": [21856, 21856],
                "./Airbags.js": [21856, 21856],
                "./AlertLine": [76358, 76358],
                "./AlertLine.js": [76358, 76358],
                "./AllCategories": [10908, 10908],
                "./AllCategories.js": [10908, 10908],
                "./Amenage": [8793, 8793],
                "./Amenage.js": [8793, 8793],
                "./Animeaux": [76388, 76388],
                "./Animeaux.js": [76388, 76388],
                "./AnneeModele": [96200, 96200],
                "./AnneeModele.js": [96200, 96200],
                "./Antivol": [88757, 88757],
                "./Antivol.js": [88757, 88757],
                "./AppareilsPhoto": [83275, 83275],
                "./AppareilsPhoto.js": [83275, 83275],
                "./Appartements": [90778, 90778],
                "./Appartements.js": [90778, 90778],
                "./ArrowLeft": [87184, 87184],
                "./ArrowLeft.js": [87184, 87184],
                "./ArrowRight": [41706, 41706],
                "./ArrowRight.js": [41706, 41706],
                "./ArrowRightS": [29315, 29315],
                "./ArrowRightS.js": [29315, 29315],
                "./Arrows": [85993, 85993],
                "./Arrows.js": [85993, 85993],
                "./ArtEtCollections": [39052, 39052],
                "./ArtEtCollections.js": [39052, 39052],
                "./ArticlesToilettage": [50870, 50870],
                "./ArticlesToilettage.js": [50870, 50870],
                "./Ascenseur": [57970, 57970],
                "./Ascenseur.js": [57970, 57970],
                "./AttachmentFill": [41201, 41201],
                "./AttachmentFill.js": [41201, 41201],
                "./AttachmentLine": [26603, 26603],
                "./AttachmentLine.js": [26603, 26603],
                "./Attic": [88019, 88019],
                "./Attic.js": [88019, 88019],
                "./Auction": [60742, 60742],
                "./Auction.js": [60742, 60742],
                "./AuctionLine": [62746, 62746],
                "./AuctionLine.js": [62746, 62746],
                "./AutoNeuf": [41120, 41120],
                "./AutoNeuf.js": [41120, 41120],
                "./Autre": [24851, 24851],
                "./Autre.js": [24851, 24851],
                "./AutreImmobilier": [57048, 57048],
                "./AutreImmobilier.js": [57048, 57048],
                "./AvitoIcon": [70354, 70354],
                "./AvitoIcon.js": [70354, 70354],
                "./Balcon": [90555, 90555],
                "./Balcon.js": [90555, 90555],
                "./Balcony": [35298, 35298],
                "./Balcony.js": [35298, 35298],
                "./BankCard": [82286, 82286],
                "./BankCard.js": [82286, 82286],
                "./BankLine": [26513, 26513],
                "./BankLine.js": [26513, 26513],
                "./BarGraph": [13474, 13474],
                "./BarGraph.js": [13474, 13474],
                "./Bars": [50370, 50370],
                "./Bars.js": [50370, 50370],
                "./BaselineDrag": [57668, 57668],
                "./BaselineDrag.js": [57668, 57668],
                "./BasketballLine": [69716, 69716],
                "./BasketballLine.js": [69716, 69716],
                "./Bateaux": [28871, 28871],
                "./Bateaux.js": [28871, 28871],
                "./Bathrooms": [65007, 65007],
                "./Bathrooms.js": [65007, 65007],
                "./Bike": [53161, 53161],
                "./Bike.js": [53161, 53161],
                "./BoiteAVitesse": [71573, 71573],
                "./BoiteAVitesse.js": [71573, 71573],
                "./Brand": [42818, 42818],
                "./Brand.js": [42818, 42818],
                "./Briefcase": [1574, 1574],
                "./Briefcase.js": [1574, 1574],
                "./Briefcase2Line": [11271, 11271],
                "./Briefcase2Line.js": [11271, 11271],
                "./BuildStatus": [84304, 84304],
                "./BuildStatus.js": [84304, 84304],
                "./Building4Line": [32842, 32842],
                "./Building4Line.js": [32842, 32842],
                "./BuildingLine": [71930, 71930],
                "./BuildingLine.js": [71930, 71930],
                "./Bulb": [69293, 69293],
                "./Bulb.js": [69293, 69293],
                "./BulleBasse": [80928, 80928],
                "./BulleBasse.js": [80928, 80928],
                "./BureauxEtPlateaux": [77397, 77397],
                "./BureauxEtPlateaux.js": [77397, 77397],
                "./BusinessEtAffairesCommerciales": [41988, 41988],
                "./BusinessEtAffairesCommerciales.js": [41988, 41988],
                "./CablageTelephonique": [76009, 76009],
                "./CablageTelephonique.js": [76009, 76009],
                "./Cadres": [62392, 62392],
                "./Cadres.js": [62392, 62392],
                "./Calendar": [88581, 88581],
                "./Calendar.js": [88581, 88581],
                "./CalendarChecked": [63663, 63663],
                "./CalendarChecked.js": [63663, 63663],
                "./Camera": [4573, 4573],
                "./Camera.js": [4573, 4573],
                "./CameraDeRecul": [65720, 65720],
                "./CameraDeRecul.js": [65720, 65720],
                "./Camions": [22694, 22694],
                "./Camions.js": [22694, 22694],
                "./Capacite": [16756, 16756],
                "./Capacite.js": [16756, 16756],
                "./Car": [33895, 33895],
                "./Car.js": [33895, 33895],
                "./CarCheck": [79521, 79521],
                "./CarCheck.js": [79521, 79521],
                "./CarFill2": [97889, 97889],
                "./CarFill2.js": [97889, 97889],
                "./CarFill3": [44866, 44866],
                "./CarFill3.js": [44866, 44866],
                "./Carburant": [37360, 37360],
                "./Carburant.js": [37360, 37360],
                "./CardTextOutline": [39338, 39338],
                "./CardTextOutline.js": [39338, 39338],
                "./CaretLeft": [49048, 49048],
                "./CaretLeft.js": [49048, 49048],
                "./Carousserie": [12091, 12091],
                "./Carousserie.js": [12091, 12091],
                "./CartFill": [71146, 71146],
                "./CartFill.js": [71146, 71146],
                "./CartLine": [53270, 53270],
                "./CartLine.js": [53270, 53270],
                "./Cash": [32555, 32555],
                "./Cash.js": [32555, 32555],
                "./Cbs": [40396, 40396],
                "./Cbs.js": [40396, 40396],
                "./CdMp3Bluetooth": [31620, 31620],
                "./CdMp3Bluetooth.js": [31620, 31620],
                "./CentreDAppels": [10491, 10491],
                "./CentreDAppels.js": [10491, 10491],
                "./Chair": [44817, 44817],
                "./Chair.js": [44817, 44817],
                "./Chambres": [40251, 40251],
                "./Chambres.js": [40251, 40251],
                "./Chart": [85188, 85188],
                "./Chart.js": [85188, 85188],
                "./Chat": [14813, 14813],
                "./Chat.js": [14813, 14813],
                "./ChatBubbleOutline": [66990, 66990],
                "./ChatBubbleOutline.js": [66990, 66990],
                "./ChatBubblesOutline": [70751, 70751],
                "./ChatBubblesOutline.js": [70751, 70751],
                "./ChatOutline": [18752, 18752],
                "./ChatOutline.js": [18752, 18752],
                "./Chauffage": [48805, 48805],
                "./Chauffage.js": [48805, 48805],
                "./Chaussures": [41943, 41943],
                "./Chaussures.js": [41943, 41943],
                "./CheckLine": [99830, 99830],
                "./CheckLine.js": [99830, 99830],
                "./ChevronDown": [88372, 88372],
                "./ChevronDown.js": [88372, 88372],
                "./ChevronLeft": [41479, 41479],
                "./ChevronLeft.js": [41479, 41479],
                "./ChevronRight": [14222, 14222],
                "./ChevronRight.js": [14222, 14222],
                "./ChevronUp": [37485, 37485],
                "./ChevronUp.js": [37485, 37485],
                "./ChildrensArea": [18802, 18802],
                "./ChildrensArea.js": [18802, 18802],
                "./CircleChecked": [29786, 29786],
                "./CircleChecked.js": [29786, 29786],
                "./CircleCheckedOutline": [80557, 80557],
                "./CircleCheckedOutline.js": [80557, 80557],
                "./Climatisation": [7670, 7670],
                "./Climatisation.js": [7670, 7670],
                "./ClockHour": [75400, 75400],
                "./ClockHour.js": [75400, 75400],
                "./ClockOutline": [11287, 11287],
                "./ClockOutline.js": [11287, 11287],
                "./Close": [47217, 47217],
                "./Close.js": [47217, 47217],
                "./CloseCircle": [39032, 39032],
                "./CloseCircle.js": [39032, 39032],
                "./CloseOutline": [75382, 75382],
                "./CloseOutline.js": [75382, 75382],
                "./CloseWhite": [4512, 4512],
                "./CloseWhite.js": [4512, 4512],
                "./Collocations": [90518, 90518],
                "./Collocations.js": [90518, 90518],
                "./CommunalGarden": [71204, 71204],
                "./CommunalGarden.js": [71204, 71204],
                "./CommunalPool": [46097, 46097],
                "./CommunalPool.js": [46097, 46097],
                "./Concierge": [89666, 89666],
                "./Concierge.js": [89666, 89666],
                "./Consommation": [13231, 13231],
                "./Consommation.js": [13231, 13231],
                "./ConstructionCone": [71947, 71947],
                "./ConstructionCone.js": [71947, 71947],
                "./ConsumerLending": [27033, 27033],
                "./ConsumerLending.js": [27033, 27033],
                "./CouchLine": [37730, 37730],
                "./CouchLine.js": [37730, 37730],
                "./CoursEtFormations": [80918, 18358],
                "./CoursEtFormations.js": [80918, 18358],
                "./CreditCard": [65377, 65377],
                "./CreditCard.js": [65377, 65377],
                "./CrownFill": [45017, 45017],
                "./CrownFill.js": [45017, 45017],
                "./CuisineEquipee": [10154, 10154],
                "./CuisineEquipee.js": [10154, 10154],
                "./CursorClick": [20907, 20907],
                "./CursorClick.js": [20907, 20907],
                "./CustomerService": [33106, 33106],
                "./CustomerService.js": [33106, 33106],
                "./Cylindree": [88109, 88109],
                "./Cylindree.js": [88109, 88109],
                "./Date": [55896, 55896],
                "./Date.js": [55896, 55896],
                "./DateEvent": [20957, 20957],
                "./DateEvent.js": [20957, 20957],
                "./DateRange": [70762, 70762],
                "./DateRange.js": [70762, 70762],
                "./Delete": [94260, 94260],
                "./Delete.js": [94260, 94260],
                "./Delete2Line": [91921, 91921],
                "./Delete2Line.js": [91921, 91921],
                "./Delivery2": [60859, 60859],
                "./Delivery2.js": [60859, 60859],
                "./DeliveryCar": [11189, 11189],
                "./DeliveryCar.js": [11189, 11189],
                "./DemandesDEmploi": [60866, 60866],
                "./DemandesDEmploi.js": [60866, 60866],
                "./Details": [81980, 81980],
                "./Details.js": [81980, 81980],
                "./Discount": [82175, 82175],
                "./Discount.js": [82175, 82175],
                "./Distance": [16567, 16567],
                "./Distance.js": [16567, 16567],
                "./DollarOnHand": [12284, 12284],
                "./DollarOnHand.js": [12284, 12284],
                "./Donations": [58375, 58375],
                "./Donations.js": [58375, 58375],
                "./DotsVertical": [79266, 79266],
                "./DotsVertical.js": [79266, 79266],
                "./DownloadLine": [41673, 41673],
                "./DownloadLine.js": [41673, 41673],
                "./DownwardArrow": [11536, 11536],
                "./DownwardArrow.js": [11536, 11536],
                "./Duplex": [78365, 78365],
                "./Duplex.js": [78365, 78365],
                "./EBike": [66908, 66908],
                "./EBike.js": [66908, 66908],
                "./EBikeLine": [79318, 79318],
                "./EBikeLine.js": [79318, 79318],
                "./Edit": [11526, 11526],
                "./Edit.js": [11526, 11526],
                "./EditLine": [95863, 95863],
                "./EditLine.js": [95863, 95863],
                "./ElectromenagerEtVaisselles": [26717, 26717],
                "./ElectromenagerEtVaisselles.js": [26717, 26717],
                "./Electronic": [70831, 70831],
                "./Electronic.js": [70831, 70831],
                "./Elevator": [30572, 30572],
                "./Elevator.js": [30572, 30572],
                "./Email": [46026, 46026],
                "./Email.js": [46026, 46026],
                "./EnginsAgricole": [83973, 83973],
                "./EnginsAgricole.js": [83973, 83973],
                "./EnginsBtp": [99876, 99876],
                "./EnginsBtp.js": [99876, 99876],
                "./EnsuiteBathrooms": [98710, 98710],
                "./EnsuiteBathrooms.js": [98710, 98710],
                "./EqualizerLine": [20238, 20238],
                "./EqualizerLine.js": [20238, 20238],
                "./EquipementsEnfants": [36920, 36920],
                "./EquipementsEnfants.js": [36920, 36920],
                "./EquipementsPourEnfantEtBebe": [48193, 48193],
                "./EquipementsPourEnfantEtBebe.js": [48193, 48193],
                "./EquippedKitchen": [92875, 92875],
                "./EquippedKitchen.js": [92875, 92875],
                "./ErrorOutline": [50966, 50966],
                "./ErrorOutline.js": [50966, 50966],
                "./Esp": [91355, 91355],
                "./Esp.js": [91355, 91355],
                "./EtatLine": [35642, 35642],
                "./EtatLine.js": [35642, 35642],
                "./Excel": [72063, 72063],
                "./Excel.js": [72063, 72063],
                "./ExternalLink": [76161, 76161],
                "./ExternalLink.js": [76161, 76161],
                "./Facebook": [83095, 83095],
                "./Facebook.js": [83095, 83095],
                "./Facebook2": [84298, 84298],
                "./Facebook2.js": [84298, 84298],
                "./FemmesDeMenagesNounousEtChauffeurs": [15794, 15794],
                "./FemmesDeMenagesNounousEtChauffeurs.js": [15794, 15794],
                "./FerRepasser": [49039, 49039],
                "./FerRepasser.js": [49039, 49039],
                "./FileCheck": [18980, 18980],
                "./FileCheck.js": [18980, 18980],
                "./FileCopyLine": [36904, 36904],
                "./FileCopyLine.js": [36904, 36904],
                "./FileFind": [94059, 94059],
                "./FileFind.js": [94059, 94059],
                "./FilmsLivresEtMagazines": [84758, 84758],
                "./FilmsLivresEtMagazines.js": [84758, 84758],
                "./Filter": [70693, 70693],
                "./Filter.js": [70693, 70693],
                "./FilterFill": [84171, 84171],
                "./FilterFill.js": [84171, 84171],
                "./Fireplace": [97594, 97594],
                "./Fireplace.js": [97594, 97594],
                "./FittedWardrobes": [53363, 53363],
                "./FittedWardrobes.js": [53363, 53363],
                "./Flag": [25628, 25628],
                "./Flag.js": [25628, 25628],
                "./Flashlight": [8570, 8570],
                "./Flashlight.js": [8570, 8570],
                "./Floor": [28525, 52890],
                "./Floor.js": [28525, 52890],
                "./FloorNumber": [66674, 66674],
                "./FloorNumber.js": [66674, 66674],
                "./Floors": [39581, 39581],
                "./Floors.js": [39581, 39581],
                "./Football": [4029, 4029],
                "./Football.js": [4029, 4029],
                "./Form": [49635, 49635],
                "./Form.js": [49635, 49635],
                "./Fuel": [6566, 6566],
                "./Fuel.js": [6566, 6566],
                "./Furnished": [9236, 9236],
                "./Furnished.js": [9236, 9236],
                "./Gadgets": [56478, 56478],
                "./Gadgets.js": [56478, 56478],
                "./Gallery": [39425, 39425],
                "./Gallery.js": [39425, 39425],
                "./Garage": [8560, 8560],
                "./Garage.js": [8560, 8560],
                "./Gear": [38410, 38410],
                "./Gear.js": [38410, 38410],
                "./GiftLine": [7614, 7614],
                "./GiftLine.js": [7614, 7614],
                "./Google": [48569, 48569],
                "./Google.js": [48569, 48569],
                "./Gps": [76368, 76368],
                "./Gps.js": [76368, 76368],
                "./Hand": [77253, 77253],
                "./Hand.js": [77253, 77253],
                "./Hang": [25301, 25301],
                "./Hang.js": [25301, 25301],
                "./HeartFill": [67972, 67972],
                "./HeartFill.js": [67972, 67972],
                "./HeartOutline": [62861, 62861],
                "./HeartOutline.js": [62861, 62861],
                "./Heating": [44568, 44568],
                "./Heating.js": [44568, 44568],
                "./Highlight": [49057, 49057],
                "./Highlight.js": [49057, 49057],
                "./Home": [65981, 65981],
                "./Home.js": [65981, 65981],
                "./Home3Fill": [65649, 65649],
                "./Home3Fill.js": [65649, 65649],
                "./HotelBedFill": [71723, 71723],
                "./HotelBedFill.js": [71723, 71723],
                "./House": [91221, 91221],
                "./House.js": [91221, 91221],
                "./HouseCollocation": [80452, 80452],
                "./HouseCollocation.js": [80452, 80452],
                "./HouseOnHand": [34011, 34011],
                "./HouseOnHand.js": [34011, 34011],
                "./HouseOutline": [86533, 86533],
                "./HouseOutline.js": [86533, 86533],
                "./HouseShakeHands": [91074, 91074],
                "./HouseShakeHands.js": [91074, 91074],
                "./ImageEtSon": [65307, 65307],
                "./ImageEtSon.js": [65307, 65307],
                "./Images": [23161, 23161],
                "./Images.js": [23161, 23161],
                "./Immo": [23125, 23125],
                "./Immo.js": [23125, 23125],
                "./ImmoNeuf": [31795, 31795],
                "./ImmoNeuf.js": [31795, 31795],
                "./Info": [4578, 4578],
                "./Info.js": [4578, 4578],
                "./InfoLine": [19815, 19815],
                "./InfoLine.js": [19815, 19815],
                "./InformationLine": [45077, 45077],
                "./InformationLine.js": [45077, 45077],
                "./InformatiqueEtMultimedia": [91565, 91565],
                "./InformatiqueEtMultimedia.js": [91565, 91565],
                "./InstagramLine": [28546, 28546],
                "./InstagramLine.js": [28546, 28546],
                "./InstrumentsDeMusique": [53156, 53156],
                "./InstrumentsDeMusique.js": [53156, 53156],
                "./JantesAluminium": [82819, 82819],
                "./JantesAluminium.js": [82819, 82819],
                "./Jardin": [11936, 11936],
                "./Jardin.js": [11936, 11936],
                "./JardinEtOutilsDeBricolage": [47022, 47022],
                "./JardinEtOutilsDeBricolage.js": [47022, 47022],
                "./JeuxVideoEtConsoles": [55760, 55760],
                "./JeuxVideoEtConsoles.js": [55760, 55760],
                "./Jobs": [9747, 10874],
                "./Jobs.js": [9747, 10874],
                "./Key": [59117, 59117],
                "./Key.js": [59117, 59117],
                "./Label": [68178, 68178],
                "./Label.js": [68178, 68178],
                "./Language": [28520, 28520],
                "./Language.js": [28520, 28520],
                "./LaundryRoom": [17971, 17971],
                "./LaundryRoom.js": [17971, 17971],
                "./LayoutGridLine": [17219, 17219],
                "./LayoutGridLine.js": [17219, 17219],
                "./LayoutRowLine": [66840, 66840],
                "./LayoutRowLine.js": [66840, 66840],
                "./LimiteurDeVitesse": [68341, 68341],
                "./LimiteurDeVitesse.js": [68341, 68341],
                "./Linkedin": [94384, 94384],
                "./Linkedin.js": [94384, 94384],
                "./ListCheck2": [76323, 76323],
                "./ListCheck2.js": [76323, 76323],
                "./LiveableArea": [43744, 43744],
                "./LiveableArea.js": [43744, 43744],
                "./Loading": [81518, 81518],
                "./Loading.js": [81518, 81518],
                "./Loan": [56234, 56234],
                "./Loan.js": [56234, 56234],
                "./Location": [82906, 82906],
                "./Location.js": [82906, 82906],
                "./LocationDeVacances": [75792, 75792],
                "./LocationDeVacances.js": [75792, 75792],
                "./LocationOn": [37926, 37926],
                "./LocationOn.js": [37926, 37926],
                "./Lock": [53753, 53753],
                "./Lock.js": [53753, 53753],
                "./LockLine": [66756, 66756],
                "./LockLine.js": [66756, 66756],
                "./Login": [41325, 41325],
                "./Login.js": [41325, 41325],
                "./LogoutCircleRLine": [69211, 69211],
                "./LogoutCircleRLine.js": [69211, 69211],
                "./LoopWithCar": [63404, 63404],
                "./LoopWithCar.js": [63404, 63404],
                "./Loti": [26162, 26162],
                "./Loti.js": [26162, 26162],
                "./Loudspeaker": [79787, 79787],
                "./Loudspeaker.js": [79787, 79787],
                "./MagasinsCommercesEtLocauxIndustriels": [62858, 62858],
                "./MagasinsCommercesEtLocauxIndustriels.js": [62858, 62858],
                "./Magazine": [58987, 58987],
                "./Magazine.js": [58987, 58987],
                "./Magnify": [81514, 81514],
                "./Magnify.js": [81514, 81514],
                "./MaisonsEtVillas": [14256, 14256],
                "./MaisonsEtVillas.js": [14256, 14256],
                "./Map2Fill": [94030, 94030],
                "./Map2Fill.js": [94030, 94030],
                "./MapLocation": [14963, 14963],
                "./MapLocation.js": [14963, 14963],
                "./MapMarker": [95710, 95710],
                "./MapMarker.js": [95710, 95710],
                "./MapPinFill": [19795, 19795],
                "./MapPinFill.js": [19795, 19795],
                "./MapPinLine": [45467, 45467],
                "./MapPinLine.js": [45467, 45467],
                "./MaterielsProfessionnels": [79854, 79854],
                "./MaterielsProfessionnels.js": [79854, 79854],
                "./MenuDown": [48873, 48873],
                "./MenuDown.js": [48873, 48873],
                "./MessageLine": [14474, 14474],
                "./MessageLine.js": [14474, 14474],
                "./Messenger": [12934, 12934],
                "./Messenger.js": [12934, 12934],
                "./MetiersIt": [16620, 16620],
                "./MetiersIt.js": [16620, 16620],
                "./Meuble": [14578, 14578],
                "./Meuble.js": [14578, 14578],
                "./MeublesEtDecoration": [81877, 81877],
                "./MeublesEtDecoration.js": [81877, 81877],
                "./Mezzanine": [38245, 38245],
                "./Mezzanine.js": [38245, 38245],
                "./Mileage": [81428, 81428],
                "./Mileage.js": [81428, 81428],
                "./MinusCircleFill": [78829, 78829],
                "./MinusCircleFill.js": [78829, 78829],
                "./MoneyCalculator": [97756, 97756],
                "./MoneyCalculator.js": [97756, 97756],
                "./MontresEtBijoux": [89843, 89843],
                "./MontresEtBijoux.js": [89843, 89843],
                "./Mosque": [91015, 91015],
                "./Mosque.js": [91015, 91015],
                "./Motos": [64025, 64025],
                "./Motos.js": [64025, 64025],
                "./Myads": [3353, 3353],
                "./Myads.js": [3353, 3353],
                "./Myorders": [31999, 31999],
                "./Myorders.js": [31999, 31999],
                "./MyordersLine": [59818, 59818],
                "./MyordersLine.js": [59818, 59818],
                "./Myproducts": [14791, 14791],
                "./Myproducts.js": [14791, 14791],
                "./MyproductsLine": [6137, 6137],
                "./MyproductsLine.js": [6137, 6137],
                "./NoImage": [68651, 68651],
                "./NoImage.js": [68651, 68651],
                "./NombreDePortes": [58750, 58750],
                "./NombreDePortes.js": [58750, 58750],
                "./Nursury": [10557, 10557],
                "./Nursury.js": [10557, 10557],
                "./Office": [34658, 34658],
                "./Office.js": [34658, 34658],
                "./OffresDEmploi": [79815, 79815],
                "./OffresDEmploi.js": [79815, 79815],
                "./OffresDeStages": [39681, 39681],
                "./OffresDeStages.js": [39681, 39681],
                "./OpenPlanKitchen": [73985, 73985],
                "./OpenPlanKitchen.js": [73985, 73985],
                "./OrdinateurDeBord": [40738, 40738],
                "./OrdinateurDeBord.js": [40738, 40738],
                "./OrdinateurDeBureau": [30294, 30294],
                "./OrdinateurDeBureau.js": [30294, 30294],
                "./Orientation": [71551, 71551],
                "./Orientation.js": [71551, 71551],
                "./Origin": [39907, 39907],
                "./Origin.js": [39907, 39907],
                "./Origine": [44960, 44960],
                "./Origine.js": [44960, 44960],
                "./PaperPlane": [65914, 65914],
                "./PaperPlane.js": [65914, 65914],
                "./Parking": [36713, 36713],
                "./Parking.js": [36713, 36713],
                "./ParkingIndoor": [42469, 42469],
                "./ParkingIndoor.js": [42469, 42469],
                "./ParkingOutdoor": [82986, 82986],
                "./ParkingOutdoor.js": [82986, 82986],
                "./PcPortable": [53031, 53031],
                "./PcPortable.js": [53031, 53031],
                "./Pdf": [94874, 94874],
                "./Pdf.js": [94874, 94874],
                "./PdfDownload": [13415, 13415],
                "./PdfDownload.js": [13415, 13415],
                "./Pen": [7822, 7822],
                "./Pen.js": [7822, 7822],
                "./Phone": [51917, 51917],
                "./Phone.js": [51917, 51917],
                "./PhoneLine": [40669, 40669],
                "./PhoneLine.js": [40669, 40669],
                "./PhoneStorage": [2688, 2688],
                "./PhoneStorage.js": [2688, 2688],
                "./Pieces": [4958, 4958],
                "./Pieces.js": [4958, 4958],
                "./PiecesAccessoires": [97450, 97450],
                "./PiecesAccessoires.js": [97450, 97450],
                "./Piscine": [9835, 9835],
                "./Piscine.js": [9835, 9835],
                "./Plan": [57219, 57219],
                "./Plan.js": [57219, 57219],
                "./Play": [76483, 76483],
                "./Play.js": [76483, 76483],
                "./PourLaMaisonEtJardin": [58112, 58112],
                "./PourLaMaisonEtJardin.js": [58112, 58112],
                "./PremiereMain": [11804, 11804],
                "./PremiereMain.js": [11804, 11804],
                "./PriceTag3Fill": [59286, 59286],
                "./PriceTag3Fill.js": [59286, 59286],
                "./PriceTag3Line": [3485, 3485],
                "./PriceTag3Line.js": [3485, 3485],
                "./PrivateGarage": [93652, 93652],
                "./PrivateGarage.js": [93652, 93652],
                "./PrivateGarden": [77628, 80918],
                "./PrivateGarden.js": [77628, 80918],
                "./PrivateJacuzzi": [68367, 68367],
                "./PrivateJacuzzi.js": [68367, 68367],
                "./PrivatePool": [20853, 20853],
                "./PrivatePool.js": [20853, 20853],
                "./ProduitsDeBeaute": [24635, 24635],
                "./ProduitsDeBeaute.js": [24635, 24635],
                "./Profile": [69815, 69815],
                "./Profile.js": [69815, 69815],
                "./PropertyAge": [4267, 4267],
                "./PropertyAge.js": [4267, 4267],
                "./Prospects": [88459, 88459],
                "./Prospects.js": [88459, 88459],
                "./Protected": [65839, 65839],
                "./Protected.js": [65839, 65839],
                "./PuissanceFiscale": [52253, 52253],
                "./PuissanceFiscale.js": [52253, 52253],
                "./RadarDeRecul": [64311, 64311],
                "./RadarDeRecul.js": [64311, 64311],
                "./Radio2Line": [64806, 64806],
                "./Radio2Line.js": [64806, 64806],
                "./RealEstateLoan": [9556, 9556],
                "./RealEstateLoan.js": [9556, 9556],
                "./Redirect": [23336, 23336],
                "./Redirect.js": [23336, 23336],
                "./RedirectFill": [94784, 94784],
                "./RedirectFill.js": [94784, 94784],
                "./RefreshArrow": [26879, 26879],
                "./RefreshArrow.js": [26879, 26879],
                "./RegulateurDeVitesse": [7576, 7576],
                "./RegulateurDeVitesse.js": [7576, 7576],
                "./RemorquesEtCaravanes": [3630, 3630],
                "./RemorquesEtCaravanes.js": [3630, 3630],
                "./Restart": [85869, 85869],
                "./Restart.js": [85869, 85869],
                "./Restaurants": [69833, 69833],
                "./Restaurants.js": [69833, 69833],
                "./Rocket": [80238, 80238],
                "./Rocket.js": [80238, 80238],
                "./RocketLine": [86122, 86122],
                "./RocketLine.js": [86122, 86122],
                "./SacDeReservoir": [18267, 18267],
                "./SacDeReservoir.js": [18267, 18267],
                "./SacsEtAccessoires": [48215, 48215],
                "./SacsEtAccessoires.js": [48215, 48215],
                "./SalleDeBain": [27343, 27343],
                "./SalleDeBain.js": [27343, 27343],
                "./Sauna": [12377, 12377],
                "./Sauna.js": [12377, 12377],
                "./Search2Line": [99508, 99508],
                "./Search2Line.js": [99508, 99508],
                "./SearchLine": [37571, 37571],
                "./SearchLine.js": [37571, 37571],
                "./SecurePaymentLine": [16205, 16205],
                "./SecurePaymentLine.js": [16205, 16205],
                "./Securite": [42441, 42441],
                "./Securite.js": [42441, 42441],
                "./SeeMore": [49204, 49204],
                "./SeeMore.js": [49204, 49204],
                "./Services": [19804, 19804],
                "./Services.js": [19804, 19804],
                "./Serviettes": [74414, 74414],
                "./Serviettes.js": [74414, 74414],
                "./Settings": [98237, 98237],
                "./Settings.js": [98237, 98237],
                "./Settings3Line": [46115, 46115],
                "./Settings3Line.js": [46115, 46115],
                "./ShareLine": [65105, 65105],
                "./ShareLine.js": [65105, 65105],
                "./ShareUpFill": [48584, 48584],
                "./ShareUpFill.js": [48584, 48584],
                "./Shield": [94733, 94733],
                "./Shield.js": [94733, 94733],
                "./ShopBadge": [59149, 59149],
                "./ShopBadge.js": [59149, 59149],
                "./SiegesCuir": [95475, 95475],
                "./SiegesCuir.js": [95475, 95475],
                "./SmartphoneLine": [44412, 44412],
                "./SmartphoneLine.js": [44412, 44412],
                "./SolarEnergy": [23300, 23300],
                "./SolarEnergy.js": [23300, 23300],
                "./SpamLine": [51193, 51193],
                "./SpamLine.js": [51193, 51193],
                "./SpareRoom": [11806, 11806],
                "./SpareRoom.js": [11806, 11806],
                "./SportEtLoisirs": [18354, 18354],
                "./SportEtLoisirs.js": [18354, 18354],
                "./SquareChecked": [49388, 49388],
                "./SquareChecked.js": [49388, 49388],
                "./SquareCheckedLine": [52958, 52958],
                "./SquareCheckedLine.js": [52958, 52958],
                "./SquareUnchecked": [70737, 70737],
                "./SquareUnchecked.js": [70737, 70737],
                "./StaffQuarters": [87981, 87981],
                "./StaffQuarters.js": [87981, 87981],
                "./Star": [17751, 17751],
                "./Star.js": [17751, 17751],
                "./StarFill": [29570, 29570],
                "./StarFill.js": [29570, 29570],
                "./Steering2Line": [77481, 77481],
                "./Steering2Line.js": [77481, 77481],
                "./StocksEtVenteEnGros": [38180, 38180],
                "./StocksEtVenteEnGros.js": [38180, 38180],
                "./StopSign": [71462, 71462],
                "./StopSign.js": [71462, 71462],
                "./StorageRoom": [49140, 49140],
                "./StorageRoom.js": [49140, 49140],
                "./Store": [29735, 29735],
                "./Store.js": [29735, 29735],
                "./Store2Fill": [57405, 57405],
                "./Store2Fill.js": [57405, 57405],
                "./Store2Line": [67615, 67615],
                "./Store2Line.js": [67615, 67615],
                "./Store3Line": [77972, 77972],
                "./Store3Line.js": [77972, 77972],
                "./Subtract": [33154, 33154],
                "./Subtract.js": [33154, 33154],
                "./SurfaceTotale": [857, 857],
                "./SurfaceTotale.js": [857, 857],
                "./SwapBoxLine": [8799, 8799],
                "./SwapBoxLine.js": [8799, 8799],
                "./TShirtLine": [35783, 35783],
                "./TShirtLine.js": [35783, 35783],
                "./Tablettes": [94883, 94883],
                "./Tablettes.js": [94883, 94883],
                "./TagFill2": [63015, 63015],
                "./TagFill2.js": [63015, 63015],
                "./Telephones": [44828, 44828],
                "./Telephones.js": [44828, 44828],
                "./Television": [32996, 32996],
                "./Television.js": [32996, 32996],
                "./Terrace": [95803, 95803],
                "./Terrace.js": [95803, 95803],
                "./TerrainsEtFermes": [39419, 39419],
                "./TerrainsEtFermes.js": [39419, 39419],
                "./Terrasse": [52035, 52035],
                "./Terrasse.js": [52035, 52035],
                "./ThumbsUp": [35079, 35079],
                "./ThumbsUp.js": [35079, 35079],
                "./TimeFill": [81029, 81029],
                "./TimeFill.js": [81029, 81029],
                "./TimeLine": [19844, 19844],
                "./TimeLine.js": [19844, 19844],
                "./Titre": [64897, 64897],
                "./Titre.js": [64897, 64897],
                "./ToitOuvrant": [30489, 30489],
                "./ToitOuvrant.js": [30489, 30489],
                "./TouteLaCategorie": [77978, 77978],
                "./TouteLaCategorie.js": [77978, 77978],
                "./Translate": [64999, 64999],
                "./Translate.js": [64999, 64999],
                "./TrashEmpty": [24086, 24086],
                "./TrashEmpty.js": [24086, 24086],
                "./TravauxDeMaison": [23018, 23018],
                "./TravauxDeMaison.js": [23018, 23018],
                "./TrendingUp": [30594, 30594],
                "./TrendingUp.js": [30594, 30594],
                "./Tshirt": [25978, 25978],
                "./Tshirt.js": [25978, 25978],
                "./Twitter": [53885, 53885],
                "./Twitter.js": [53885, 53885],
                "./Unlock": [11650, 47184],
                "./Unlock.js": [11650, 47184],
                "./UnlockLine": [28143, 28143],
                "./UnlockLine.js": [28143, 28143],
                "./UpwardArrow": [18750, 18750],
                "./UpwardArrow.js": [18750, 18750],
                "./Urgent": [94318, 94318],
                "./Urgent.js": [94318, 94318],
                "./UserProfileFocus": [67570, 67570],
                "./UserProfileFocus.js": [67570, 67570],
                "./UserVoiceLine": [32154, 32154],
                "./UserVoiceLine.js": [32154, 32154],
                "./Vehicules": [96590, 96590],
                "./Vehicules.js": [96590, 96590],
                "./Velos": [37782, 37782],
                "./Velos.js": [37782, 37782],
                "./VerifiedCheck": [33291, 33291],
                "./VerifiedCheck.js": [33291, 33291],
                "./VerifiedShopBadge": [93609, 93609],
                "./VerifiedShopBadge.js": [93609, 93609],
                "./VerrouillageCentraliseADistance": [31595, 31595],
                "./VerrouillageCentraliseADistance.js": [31595, 31595],
                "./Vetements": [64239, 64239],
                "./Vetements.js": [64239, 64239],
                "./VetementsPourEnfantEtBebe": [7531, 7531],
                "./VetementsPourEnfantEtBebe.js": [7531, 7531],
                "./Video": [11775, 11775],
                "./Video.js": [11775, 11775],
                "./Videos": [41711, 41711],
                "./Videos.js": [41711, 41711],
                "./View": [14752, 14752],
                "./View.js": [14752, 14752],
                "./Views": [48493, 48493],
                "./Views.js": [48493, 48493],
                "./ViewsCity": [65979, 65979],
                "./ViewsCity.js": [65979, 65979],
                "./ViewsGolf": [72998, 72998],
                "./ViewsGolf.js": [72998, 72998],
                "./ViewsLake": [20425, 20425],
                "./ViewsLake.js": [20425, 20425],
                "./ViewsMountain": [79106, 79106],
                "./ViewsMountain.js": [79106, 79106],
                "./ViewsSea": [658, 658],
                "./ViewsSea.js": [658, 658],
                "./Visibility": [6397, 6397],
                "./Visibility.js": [6397, 6397],
                "./VisibilityOff": [605, 605],
                "./VisibilityOff.js": [605, 605],
                "./VitresElectriques": [56509, 95265],
                "./VitresElectriques.js": [56509, 95265],
                "./Voitures": [74161, 74161],
                "./Voitures.js": [74161, 74161],
                "./VoituresDeLocation": [74822, 74822],
                "./VoituresDeLocation.js": [74822, 74822],
                "./VoyagesEtBilletterie": [12265, 12265],
                "./VoyagesEtBilletterie.js": [12265, 12265],
                "./Wash": [67004, 67004],
                "./Wash.js": [67004, 67004],
                "./WashOutline": [3311, 3311],
                "./WashOutline.js": [3311, 3311],
                "./Wc": [43451, 43451],
                "./Wc.js": [43451, 43451],
                "./WhatsappLine": [41076, 41076],
                "./WhatsappLine.js": [41076, 41076],
                "./Wifi": [9160, 9160],
                "./Wifi.js": [9160, 9160],
                "./Youtube": [10750, 10750],
                "./Youtube.js": [10750, 10750],
                "./Zoning": [68090, 68090],
                "./Zoning.js": [68090, 68090],
                "./index": [49679, 49679],
                "./index.js": [49679, 49679]
            };

            function o(e) {
                if (!a.o(n, e)) return Promise.resolve().then((function() {
                    var t = new Error("Cannot find module '" + e + "'");
                    throw t.code = "MODULE_NOT_FOUND", t
                }));
                var t = n[e],
                    o = t[0];
                return a.e(t[1]).then((function() {
                    return a(o)
                }))
            }
            o.keys = function() {
                return Object.keys(n)
            }, o.id = 96607, e.exports = o
        },
        96054: function(e, t, a) {
            "use strict";
            a.d(t, {
                $: function() {
                    return r
                }
            });
            var n, o = a(71383),
                r = (0, a(68806).Ps)(n || (n = (0, o.Z)(["\n  query {\n    getCategories(withMissingCats: true) {\n      categories {\n        value: id\n        parent: parentId\n        children: childrenIds\n        order\n        label {\n          fr\n          ar\n        }\n        slug {\n          ar\n          fr\n        }\n        adTypes {\n          value: key\n          order\n          label {\n            fr\n            ar\n          }\n        }\n      }\n      count\n    }\n  }\n"])))
        },
        52890: function(e, t, a) {
            "use strict";
            a.d(t, {
                QA: function() {
                    return l
                },
                mz: function() {
                    return u
                },
                v_: function() {
                    return c
                }
            });
            var n, o, r, i = a(71383),
                s = a(68806),
                c = (0, s.ZP)(n || (n = (0, i.Z)(["\n  query ($startIndex: Int, $stopIndex: Int, $keyword: String) {\n    getCitiesFormattedNext(\n      startIndex: $startIndex\n      stopIndex: $stopIndex\n      keyword: $keyword\n    ) {\n      cities {\n        label\n        value\n        type\n      }\n      count\n    }\n  }\n"]))),
                u = (0, s.ZP)(o || (o = (0, i.Z)(["\n  query ($isMobile: Boolean) {\n    getPopularCitiesFormattedNext(isMobile: $isMobile) {\n      cities {\n        label\n        value\n        type\n      }\n      count\n    }\n  }\n"]))),
                l = (0, s.ZP)(r || (r = (0, i.Z)(["\n  query ($cityId: Int!) {\n    getAreas(cityId: $cityId) {\n      areas {\n        value: id\n        label {\n          fr\n          ar\n        }\n        slug {\n          fr\n          ar\n        }\n      }\n      count\n    }\n  }\n"])))
        },
        82268: function(e, t, a) {
            "use strict";
            a.d(t, {
                H: function() {
                    return r
                }
            });
            var n, o = a(71383),
                r = (0, a(68806).Ps)(n || (n = (0, o.Z)(["\n  mutation collectPerformanceEvent($event: PerformanceEventInput!) {\n    collectPerformanceEvent(event: $event) {\n      name\n    }\n  }\n"])))
        },
        73794: function(e, t, a) {
            "use strict";
            a.d(t, {
                SO: function() {
                    return l
                },
                bS: function() {
                    return c
                },
                dP: function() {
                    return u
                }
            });
            var n, o, r, i = a(71383),
                s = a(68806),
                c = (0, s.Ps)(n || (n = (0, i.Z)(["\n  mutation saveAd($input: SaveAdInput!) {\n    saveAd(input: $input)\n  }\n"]))),
                u = (0, s.Ps)(o || (o = (0, i.Z)(["\n  mutation unsaveAd($input: UnsaveAdInput!) {\n    unsaveAd(input: $input)\n  }\n"]))),
                l = (0, s.Ps)(r || (r = (0, i.Z)(["\n  query getMySavedAds($page: Page!) {\n    getMySavedAds(page: $page) {\n      ads {\n        listId\n        media {\n          defaultImage {\n            paths {\n              smallThumbnail\n            }\n          }\n        }\n        price {\n          withoutCurrency\n        }\n        title\n      }\n      count {\n        total\n      }\n    }\n  }\n"])))
        },
        15153: function(e, t, a) {
            "use strict";
            a.d(t, {
                Ov: function() {
                    return l
                },
                Uc: function() {
                    return v
                },
                jL: function() {
                    return u
                },
                uQ: function() {
                    return d
                }
            });
            var n, o, r, i, s = a(71383),
                c = a(68806),
                u = (0, c.Ps)(n || (n = (0, s.Z)(["\n  query getMyAds($filters: MyAdsFilterInput!, $pagination: Page!) {\n    getMyAds(filters: $filters, pagination: $pagination) {\n      ads {\n        adId\n        listId\n        discount\n        labels\n        editAdStatus\n        type {\n          key\n          name\n        }\n        image {\n          paths {\n            smallThumbnail\n          }\n        }\n        mediaCount\n        price {\n          withCurrency\n          withoutCurrency\n        }\n        title\n        publishedAt\n        lastStateTime\n        modifiedAt\n        location {\n          city {\n            id\n            name\n          }\n        }\n        performance {\n          conversations\n          phoneViews\n          views\n        }\n        lastAppliedVasPack {\n          name\n          startDate\n          endDate\n        }\n        vasPackages {\n          count\n        }\n        refusalReason\n        status\n        category {\n          id\n        }\n      }\n      count {\n        total\n      }\n    }\n  }\n"]))),
                l = (0, c.Ps)(o || (o = (0, s.Z)(["\n  query getMyAd($adId: ID!) {\n    getMyAd(adId: $adId) {\n      adId\n      listId\n      discount\n      labels\n      media {\n        images {\n          paths {\n            smallThumbnail\n            standard\n          }\n        }\n      }\n      price {\n        withoutCurrency\n      }\n      title\n      location {\n        city {\n          id\n          name\n        }\n        area {\n          id\n          name\n        }\n      }\n      publishedAt\n      description\n      performance {\n        conversations\n        phoneViews\n        views\n      }\n      category {\n        id\n        name\n      }\n      status\n      type {\n        key\n      }\n      vasPacks {\n        name\n        startDate\n        endDate\n        category\n      }\n      phone\n      params {\n        secondary {\n          ... on TextAdParam {\n            id\n            name\n            textValue\n          }\n          ... on NumericAdParam {\n            id\n            name\n            numericValue\n            unit\n          }\n          ... on BooleanAdParam {\n            id\n            name\n            booleanValue\n          }\n        }\n      }\n    }\n  }\n"]))),
                d = (0, c.Ps)(r || (r = (0, s.Z)(["\n  query getMyAdsCount {\n    getMyAdsCount {\n      countByStatus {\n        status\n        count\n      }\n    }\n  }\n"]))),
                v = (0, c.Ps)(i || (i = (0, s.Z)(["\n  mutation PatchAd($ad: PatchAdInput!) {\n    patchAd(ad: $ad) {\n      adId\n    }\n  }\n"])))
        },
        20495: function(e, t, a) {
            "use strict";
            a.d(t, {
                C: function() {
                    return r
                }
            });
            var n, o = a(71383),
                r = (0, a(68806).Ps)(n || (n = (0, o.Z)(["\n  query getMyStoreInfo($storeId: ID!) {\n    getMyStoreInfo(storeId: $storeId) {\n      name\n      email\n      category {\n        id\n        name\n      }\n      website\n      description {\n        long\n        short\n      }\n      phones {\n        number\n      }\n      locations {\n        address\n        city {\n          id\n          name\n          trackingValue\n        }\n      }\n      logo {\n        defaultPath\n      }\n      startDate\n      expiryDate\n      points {\n        count\n        expiryDate\n      }\n      offersDelivery\n      membership {\n        id\n        name\n      }\n      isVerifiedSeller\n    }\n  }\n"])))
        },
        51432: function(e, t, a) {
            "use strict";
            a.d(t, {
                AK: function() {
                    return Y
                },
                E8: function() {
                    return j
                },
                In: function() {
                    return H
                },
                Nb: function() {
                    return F
                },
                Nv: function() {
                    return ee
                },
                Nw: function() {
                    return q
                },
                Q0: function() {
                    return k
                },
                T6: function() {
                    return N
                },
                Wm: function() {
                    return Z
                },
                Wn: function() {
                    return M
                },
                Y: function() {
                    return X
                },
                Yh: function() {
                    return ae
                },
                _c: function() {
                    return J
                },
                bi: function() {
                    return ne
                },
                h0: function() {
                    return Q
                },
                lP: function() {
                    return z
                },
                q5: function() {
                    return U
                },
                rq: function() {
                    return G
                },
                s2: function() {
                    return B
                },
                sx: function() {
                    return $
                },
                vV: function() {
                    return K
                },
                vr: function() {
                    return V
                },
                yz: function() {
                    return W
                },
                z3: function() {
                    return te
                },
                zc: function() {
                    return x
                }
            });
            var n, o, r, i, s, c, u, l, d, v, p, m, g, f, h, y, b, _, A, E, S, R, C, D, T, P, O, I, w = a(71383),
                L = a(68806),
                M = ((0, L.Ps)(n || (n = (0, w.Z)(["\n  mutation logoutUser($token: String!) {\n    logoutUser(token: $token)\n  }\n"]))), (0, L.Ps)(o || (o = (0, w.Z)(["\n  mutation submitReportAd(\n    $listId: Int!\n    $from: String!\n    $type: String!\n    $body: String!\n  ) {\n    submitReportAd(listId: $listId, from: $from, type: $type, body: $body)\n  }\n"])))),
                x = (0, L.Ps)(r || (r = (0, w.Z)(["\n  mutation deactivateAd($adId: Int!, $accountId: Int!, $token: String!) {\n    deactivateAd(adId: $adId, accountId: $accountId, token: $token)\n  }\n"]))),
                N = (0, L.Ps)(i || (i = (0, w.Z)(["\n  mutation activateAd($adId: Int!, $accountId: Int!, $token: String!) {\n    activateAd(adId: $adId, accountId: $accountId, token: $token)\n  }\n"]))),
                q = (0, L.Ps)(s || (s = (0, w.Z)(["\n  mutation deleteAd($listId: Int!, $accountId: Int!, $token: String!) {\n    deleteAd(listId: $listId, accountId: $accountId, token: $token)\n  }\n"]))),
                k = (0, L.Ps)(c || (c = (0, w.Z)(["\n  mutation registerAccount($input: RegisterAccountInput!) {\n    registerAccount(input: $input) {\n      login {\n        accessToken\n      }\n\n      info {\n        id\n        name\n        email\n        phone {\n          number\n          isHidden\n        }\n        registeredAt\n      }\n    }\n  }\n"]))),
                j = ((0, L.Ps)(u || (u = (0, w.Z)(["\n  mutation login($email: String!, $password: String!) {\n    login(email: $email, password: $password) {\n      token\n      tokenType\n      expiresIn\n      accountId\n      uuId\n    }\n  }\n"]))), (0, L.Ps)(l || (l = (0, w.Z)(["\n  query getMyAccountInfo {\n    getMyAccountInfo {\n      id\n      name\n      email\n      phone {\n        number\n        isHidden\n      }\n      location {\n        city {\n          id\n          name\n          trackingValue\n        }\n        address\n      }\n      registeredAt\n    }\n  }\n"])))),
                U = (0, L.Ps)(d || (d = (0, w.Z)(["\n  mutation updateMyAccountInfo($input: UpdateMyAccountInfoInput!) {\n    updateMyAccountInfo(input: $input) {\n      id\n      name\n      email\n      phone {\n        number\n        isHidden\n      }\n      location {\n        city {\n          id\n          name\n          trackingValue\n        }\n        address\n      }\n      registeredAt\n    }\n  }\n"]))),
                V = (0, L.Ps)(v || (v = (0, w.Z)(["\n  mutation editUserPassword(\n    $userId: String!\n    $currentPassword: String!\n    $password: String!\n    $accountType: String\n  ) {\n    editUserPassword(\n      userId: $userId\n      currentPassword: $currentPassword\n      password: $password\n      accountType: $accountType\n    )\n  }\n"]))),
                z = (0, L.Ps)(p || (p = (0, w.Z)(["\n  query ($storeId: String!) {\n    getShopProfile(storeId: $storeId) {\n      storeId\n      email\n      name\n      desc\n      shortDesc\n      category\n      imageLogo\n      address\n      offersDelivery\n      phone1\n      phone2\n      phone3\n      storeUrl\n      storePoints\n      storePointsExpiry\n      storeStartDate\n      storeEndDate\n    }\n  }\n"]))),
                B = (0, L.Ps)(m || (m = (0, w.Z)(["\n  mutation editShopProfile(\n    $userId: String!\n    $address: String!\n    $shopCategory: Int!\n    $shopDescription: String!\n    $shopName: String!\n    $phone1: String!\n    $phone2: String!\n    $phone3: String!\n    $shortDescription: String!\n    $shopUrl: String!\n  ) {\n    editShopProfile(\n      userId: $userId\n      address: $address\n      shopCategory: $shopCategory\n      shopDescription: $shopDescription\n      shopName: $shopName\n      phone1: $phone1\n      phone2: $phone2\n      phone3: $phone3\n      shortDescription: $shortDescription\n      shopUrl: $shopUrl\n    )\n  }\n"]))),
                F = (0, L.Ps)(g || (g = (0, w.Z)(["\n  mutation requestAccountRecovery($input: RequestAccountRecoveryInput!) {\n    requestAccountRecovery(input: $input) {\n      email\n    }\n  }\n"]))),
                G = (0, L.Ps)(f || (f = (0, w.Z)(["\n  query checkActivationCode($input: CheckActivationCodeInput!) {\n    checkActivationCode(input: $input) {\n      isValid\n    }\n  }\n"]))),
                Z = (0, L.Ps)(h || (h = (0, w.Z)(["\n  mutation resetMyPassword($input: ResetMyPasswordInput!) {\n    resetMyPassword(input: $input) {\n      code\n    }\n  }\n"]))),
                H = (0, L.Ps)(y || (y = (0, w.Z)(["\n  query getUserNotificationPreferences {\n    getUserNotificationPreferences {\n      settings {\n        adNotificationsEnabled\n        vasNotificationsEnabled\n        paymentNotificationsEnabled\n        newsletterNotificationsEnabled\n        chatNotificationsEnabled\n      }\n    }\n  }\n"]))),
                $ = (0, L.Ps)(b || (b = (0, w.Z)(["\n  mutation updateUserNotificationPreferences(\n    $preferences: NotificationPreferencesSettingsInput!\n  ) {\n    updateUserNotificationPreferences(preferences: $preferences) {\n      adNotificationsEnabled\n      vasNotificationsEnabled\n      paymentNotificationsEnabled\n      newsletterNotificationsEnabled\n      chatNotificationsEnabled\n    }\n  }\n"]))),
                K = (0, L.Ps)(_ || (_ = (0, w.Z)(["\n  query getUserNotificationChannel($channelName: String!) {\n    getUserNotificationChannel(channelName: $channelName) {\n      name\n      status\n    }\n  }\n"]))),
                Y = (0, L.Ps)(A || (A = (0, w.Z)(["\n  mutation sendEmailVerification($lang: NotificationLang) {\n    sendEmailVerification(lang: $lang)\n  }\n"]))),
                W = (0, L.Ps)(E || (E = (0, w.Z)(["\n  mutation verifyEmail($input: VerifyEmailInput!) {\n    verifyEmail(input: $input) {\n      code\n    }\n  }\n"]))),
                X = (0, L.Ps)(S || (S = (0, w.Z)(["\n  mutation loginByEmail($email: String!, $password: String!) {\n    loginByEmail(email: $email, password: $password) {\n      accessToken\n    }\n  }\n"]))),
                J = (0, L.Ps)(R || (R = (0, w.Z)(["\n  mutation loginByIdentifier($identifier: String!, $password: String!) {\n    loginByIdentifier(identifier: $identifier, password: $password) {\n      accessToken\n      refreshToken\n    }\n  }\n"]))),
                Q = (0, L.Ps)(C || (C = (0, w.Z)(["\n  query checkAccountExistance($phone: String!) {\n    checkAccountExistance(input: { phone: $phone }) {\n      doesAccountExist\n    }\n  }\n"]))),
                ee = (0, L.Ps)(D || (D = (0, w.Z)(["\n  mutation logout {\n    logout\n  }\n"]))),
                te = ((0, L.Ps)(T || (T = (0, w.Z)(["\n  mutation loginByFacebook($token: String!) {\n    loginByFacebook(token: $token) {\n      accessToken\n    }\n  }\n"]))), (0, L.Ps)(P || (P = (0, w.Z)(["\n  mutation loginWithGoogle($token: String!) {\n    loginWithGoogle(token: $token) {\n      accessToken\n    }\n  }\n"])))),
                ae = (0, L.Ps)(O || (O = (0, w.Z)(["\n  mutation requestAccountRecoveryByPhone(\n    $input: RequestAccountRecoveryByPhoneInput!\n  ) {\n    requestAccountRecoveryByPhone(input: $input) {\n      phone\n    }\n  }\n"]))),
                ne = (0, L.Ps)(I || (I = (0, w.Z)(["\n  mutation requestPhoneVerification(\n    $input: RequestPhoneVerificationCodeInput!\n  ) {\n    requestPhoneVerification(input: $input) {\n      phone\n    }\n  }\n"])))
        },
        2849: function(e, t, a) {
            "use strict";
            a.d(t, {
                n: function() {
                    return o
                }
            });
            var n = a(40782),
                o = function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : n.Am.POSITION.BOTTOM_LEFT;
                    n.Am.error(e, {
                        autoClose: t,
                        position: a
                    })
                }
        },
        56159: function(e, t, a) {
            "use strict";
            a.d(t, {
                b: function() {
                    return r
                }
            });
            var n = a(19521),
                o = a(85893),
                r = n.default.div.withConfig({
                    componentId: "sc-13n0hte-0"
                })(["max-width:100px;width:fit-content;margin-right:auto;margin-left:auto;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;"]);
            t.Z = function(e) {
                var t = e.value;
                return (0, o.jsx)(r, {
                    children: t ? "".concat(t) : "-"
                })
            }
        },
        46615: function(e, t, a) {
            "use strict";
            var n, o, r = a(71383),
                i = a(67294),
                s = a(19521),
                c = a(98e3),
                u = a(6055),
                l = a(31155),
                d = a(70269),
                v = a(96977),
                p = a(85893),
                m = (0, s.default)(u.C).withConfig({
                    componentId: "sc-1cv0y0l-0"
                })(["position:relative;", " font-weight:", ";line-height:14px;color:", ";background-color:", ";&:before{position:absolute;content:'';width:6px;height:6px;top:50%;", " border-radius:50%;margin-top:-3px;background-color:", ";}"], (0, c.Z)(n || (n = (0, r.Z)(["padding-left: ", ";"])), (0, l.W)(4)), d.Z.normal, (function(e) {
                    return e.color.text
                }), (function(e) {
                    return e.color.bg
                }), (0, c.Z)(o || (o = (0, r.Z)(["left: 6px;"]))), (function(e) {
                    return e.color.text
                }));
            t.Z = function(e) {
                var t, a = e.status,
                    n = e.value,
                    o = (0, i.useContext)(v.Q).__t,
                    r = null !== (t = a[n]) && void 0 !== t ? t : {},
                    s = r.label,
                    c = r.textColor,
                    u = r.bgColor;
                return (0, p.jsx)(m, {
                    color: {
                        text: c,
                        bg: u
                    },
                    textColor: "currentColor",
                    bgColor: "currentColor",
                    rounded: !0,
                    children: o(s)
                })
            }
        },
        47250: function(e, t, a) {
            "use strict";
            a.d(t, {
                $2: function() {
                    return v
                },
                G8: function() {
                    return u
                },
                dO: function() {
                    return s
                },
                ii: function() {
                    return c
                },
                pO: function() {
                    return p
                },
                qv: function() {
                    return d
                }
            });
            var n = a(52493),
                o = a(46615),
                r = a(56159),
                i = a(19235),
                s = {
                    PENDING: {
                        label: "av.seller.center.order.status.pending.short",
                        text: "av.seller.center.my-orders.empty-state.text.status.pending",
                        value: "PENDING",
                        taggingValue: "pending",
                        textColor: "#F48B29",
                        bgColor: "#FEEFE1",
                        operations: ["PREPARE", "CANCEL", "DELETE", "VIEW_ON_AVITO"],
                        ctas: []
                    },
                    READY: {
                        label: "av.seller.center.order.status.readyForDelivery.short",
                        text: "av.seller.center.my-orders.empty-state.text.status.readyForDelivery",
                        value: "READY",
                        taggingValue: "ready_to_ship",
                        textColor: i.ZP.vehicules_normal,
                        bgColor: "#FEE1E3",
                        operations: ["VIEW_ON_AVITO"],
                        ctas: []
                    },
                    DELIVERING: {
                        label: "av.seller.center.order.status.delivering.short",
                        text: "av.seller.center.my-orders.empty-state.text.status.delivering",
                        value: "DELIVERING",
                        taggingValue: "on_delivery",
                        textColor: "#1A58F4",
                        bgColor: "#E1EAFE",
                        operations: ["VIEW_ON_AVITO"],
                        ctas: []
                    },
                    DELIVERED: {
                        label: "av.seller.center.order.status.delivred.short",
                        text: "av.seller.center.my-orders.empty-state.text.status.delivered",
                        value: "DELIVERED",
                        taggingValue: "delivered",
                        textColor: i.ZP.market_normal,
                        bgColor: "#E1FEEC",
                        operations: ["VIEW_ON_AVITO"],
                        ctas: []
                    },
                    CANCELLED: {
                        label: "av.seller.center.order.status.cancelled.short",
                        text: "av.seller.center.my-orders.empty-state.text.status.cancelled",
                        value: "CANCELLED",
                        taggingValue: "declined",
                        textColor: "#575758",
                        bgColor: i.ZP.smoke_light_grey,
                        operations: ["VIEW_ON_AVITO"],
                        ctas: []
                    },
                    RETURNED: {
                        label: "av.seller.center.order.status.returned.short",
                        value: "RETURNED",
                        textColor: "#575758",
                        bgColor: i.ZP.smoke_light_grey
                    }
                },
                c = [{
                    label: "av.seller.center.order.status.pending.short",
                    value: s.PENDING.value
                }, {
                    label: "av.seller.center.order.status.readyForDelivery",
                    value: s.READY.value
                }, {
                    label: "av.seller.center.order.status.delivering",
                    value: s.DELIVERING.value
                }, {
                    label: "av.seller.center.order.status.delivred",
                    value: s.DELIVERED.value
                }, {
                    label: "av.seller.center.order.status.cancelled",
                    value: s.CANCELLED.value
                }],
                u = {
                    PREPARE: {
                        color: "primary",
                        leftIcon: "CircleCheckedOutline",
                        label: "av.seller.center.order.operations.prepare",
                        isIconBtnOnMobile: !0
                    },
                    CANCEL: {
                        color: "mars",
                        leftIcon: "Close",
                        label: "av.common.cancel",
                        isIconBtnOnMobile: !0
                    },
                    DELETE: {
                        color: "wine",
                        leftIcon: "Delete2Line",
                        label: "av.account.card.menu.delete",
                        isIconBtnOnMobile: !0
                    }
                },
                l = function(e) {
                    return (0, n.L0)({
                        date: e,
                        format: "dd MMM yyyy",
                        source: "yyyy-MM-dd'T'HH:mm:ss'Z'"
                    })
                },
                d = {
                    id: {
                        header: "av.seller.center.order.id",
                        icon: "Arrows"
                    },
                    name: {
                        header: "av.seller.center.product.short",
                        icon: "Arrows"
                    },
                    unitsSold: {
                        header: "av.seller.center.order.units",
                        icon: "Arrows",
                        customCell: {
                            Component: r.Z
                        }
                    },
                    total: {
                        header: "av.common.price",
                        icon: "Arrows"
                    },
                    status: {
                        header: "av.seller.center.product.status",
                        icon: "Arrows",
                        customCell: {
                            Component: o.Z,
                            props: {
                                status: s
                            }
                        }
                    },
                    date: {
                        header: "av.seller.center.order.date",
                        icon: "Arrows",
                        formatCell: l
                    },
                    paymentMethod: {
                        header: "av.seller.center.order.paymentMethod"
                    }
                },
                v = {
                    id: {
                        label: "av.seller.center.order.id"
                    },
                    name: {
                        label: "av.seller.center.product.short"
                    },
                    unitsSold: {
                        label: "av.seller.center.order.units"
                    },
                    total: {
                        label: "av.common.price"
                    },
                    status: {
                        label: "av.seller.center.product.status",
                        customValue: {
                            Component: o.Z,
                            props: {
                                status: s
                            }
                        }
                    },
                    date: {
                        label: "av.seller.center.order.date",
                        formatValue: l
                    },
                    paymentMethod: {
                        label: "av.seller.center.order.paymentMethod"
                    }
                },
                p = {
                    PREPARE: {
                        icon: "CircleCheckedOutline",
                        label: "av.seller.center.order.operations.prepare"
                    },
                    CANCEL: {
                        icon: "Close",
                        label: "av.common.cancel"
                    },
                    DELETE: {
                        icon: "Delete2Line",
                        label: "av.account.card.menu.delete"
                    },
                    VIEW_ON_AVITO: {
                        icon: "RedirectFill",
                        label: "av.account.card.menu.view-on-avito"
                    }
                }
        },
        62107: function(e, t, a) {
            "use strict";
            a.d(t, {
                DW: function() {
                    return i
                }
            });
            var n = a(76871),
                o = {
                    "home-page": "/",
                    "login-page": "/account/signin",
                    "shop-login-page": "/account/shop/signin",
                    "signup-page": "/account/signup",
                    "account.my-ads": "/account/v2/my-ads",
                    "account.my-orders": "/account/v2/my-orders",
                    "account.my-favorites": "/account/v2/my-favorites",
                    "account.stats": "/account/v2/stats",
                    "account.settings": "/account/v2/settings/profile",
                    "account.settings.contact": "/account/v2/settings/contact",
                    "account.settings.password": "/account/v2/settings/password",
                    "account.settings.notification": "/account/v2/settings/notification",
                    "account.ad-operations.deactivate": "/account/ad-operations?action=deactivate",
                    "account.bulk.deactivate": "/account/bulk?action=deactivate",
                    "messaging.messages": "/messages",
                    "messaging.chat": "/messages/chat",
                    "seller.my-products": "/account/seller/my-products",
                    "seller.my-orders": "/account/seller/my-orders",
                    "seller.my-payments": "/account/seller/my-payments",
                    "seller.product-insert": "/product/insert",
                    "seller.product-edit": "/product/edit",
                    "payment-page": "/checkout",
                    "checkout-page": "/ecom/checkout",
                    "ad.insert": "/ad/insert",
                    "ad.edit": "/ad/edit"
                },
                r = function(e) {
                    return "baseUrl" === e ? n.baseUrl : ""
                },
                i = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = e.key,
                        a = e.baseUrlName,
                        n = void 0 === a ? "" : a,
                        i = e.lang;
                    return o[t] ? "".concat(r(n)).concat(i ? "/".concat(i) : "").concat(o[t]) : r(n)
                }
        },
        16700: function(e, t, a) {
            "use strict";
            var n = a(571),
                o = a(44317),
                r = (0, n.Z)(o.KZ);
            t.Z = r
        },
        44317: function(e, t, a) {
            "use strict";
            a.d(t, {
                KZ: function() {
                    return o
                },
                ae: function() {
                    return r
                },
                jd: function() {
                    return n
                },
                yK: function() {
                    return i
                }
            });
            var n = "log",
                o = "AV LOGGER",
                r = {
                    log: {
                        function: "log",
                        level: "log"
                    },
                    warn: {
                        function: "warn",
                        level: "warn"
                    },
                    error: {
                        function: "error",
                        level: "error"
                    },
                    info: {
                        function: "info",
                        level: "info"
                    }
                },
                i = {
                    LOG: "log",
                    WARN: "warn",
                    ERROR: "error",
                    INFO: "info"
                }
        },
        571: function(e, t, a) {
            "use strict";
            var n = a(59499),
                o = a(17674),
                r = a(50029),
                i = a(87794),
                s = a.n(i),
                c = a(33728),
                u = a(82361),
                l = a(44317),
                d = a(76871);

            function v(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function p(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? v(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : v(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var m = function() {
                    var e = (0, r.Z)(s().mark((function e(t) {
                        var a;
                        return s().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return a = d.sendLogApiEndpoint, e.prev = 1, e.next = 4, fetch(a, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        body: JSON.stringify({
                                            logMessage: t
                                        })
                                    });
                                case 4:
                                    e.next = 9;
                                    break;
                                case 6:
                                    e.prev = 6, e.t0 = e.catch(1), console.log("[CLIENT ERROR] Encountered an error while sending client log", (null === e.t0 || void 0 === e.t0 ? void 0 : e.t0.message) || e.t0);
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [1, 6]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                g = function() {
                    if (!c.C5) return null;
                    try {
                        var e = (0, u.l)(),
                            t = e.type,
                            a = e.userAgent,
                            n = (a = void 0 === a ? {} : a).browser,
                            r = void 0 === n ? {} : n,
                            i = a.os,
                            s = void 0 === i ? {} : i,
                            l = a.device,
                            d = void 0 === l ? {} : l,
                            v = {
                                type: t || d.type,
                                browserName: r.name,
                                browserVersion: r.version,
                                osName: s.name,
                                osVersion: s.version,
                                deviceVendor: d.vendor,
                                deviceModel: d.model
                            };
                        return Object.fromEntries(Object.entries(v).map((function(e) {
                            var t, a = (0, o.Z)(e, 2),
                                n = a[0],
                                r = a[1];
                            return [n, (t = r, null === t || void 0 === t ? null : "string" === typeof t ? t.trim() || null : t || null)]
                        })).filter((function(e) {
                            return null !== (0, o.Z)(e, 2)[1]
                        })))
                    } catch (p) {
                        return null
                    }
                },
                f = function(e, t) {
                    return t ? e ? !("object" === typeof e && !Array.isArray(e)) || "clientDevice" in e ? e : p(p({}, e), {}, {
                        clientDevice: t
                    }) : {
                        clientDevice: t
                    } : e
                };
            t.Z = function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : l.KZ,
                    t = function() {
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                            a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : l.jd,
                            n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "",
                            o = console[l.ae[a].function];
                        Object.keys(l.ae).some((function(e) {
                            return e === a
                        })) || (console.warn("[WARNING] ".concat(e, " - Unrecognized logging level ").concat(a, ", Using level: ").concat(l.jd)), o = console.log);
                        var r = (new Date).toISOString(),
                            i = g(),
                            s = f(n, i),
                            d = s ? JSON.stringify(s) : "",
                            v = String(l.ae[a].level).toUpperCase(),
                            p = c.C5 ? "[CLIENT]" : "[SERVER]",
                            h = "".concat(p, "[").concat(v, "]\t").concat(e, " - ").concat(r, " - ").concat(t, " ").concat(d);
                        if (o(h), c.C5 && a === l.yK.ERROR) {
                            var y = (0, u.l)(),
                                b = y.type,
                                _ = y.userAgent,
                                A = _.browser,
                                E = void 0 === A ? {} : A,
                                S = _.os,
                                R = void 0 === S ? {} : S,
                                C = _.device,
                                D = void 0 === C ? {} : C,
                                T = [b || D.type || "unknown", "".concat(E.name || "unknown", "/").concat(E.version || "unknown"), "".concat(R.name || "unknown", "/").concat(R.version || "unknown"), "".concat(D.vendor || "unknown", "/").concat(D.model || "unknown")],
                                P = T.join(", ");
                            m("".concat(h, ", ").concat(P))
                        }
                    },
                    a = function(e, a) {
                        t(e, l.yK.LOG, a)
                    },
                    n = function(e, a) {
                        t(e, l.yK.WARN, a)
                    },
                    o = function(e, a) {
                        t(e, l.yK.ERROR, a)
                    },
                    r = function(e, a) {
                        t(e, l.yK.INFO, a)
                    };
                return {
                    log: a,
                    warn: n,
                    error: o,
                    info: r
                }
            }
        },
        69449: function(e, t, a) {
            "use strict";
            a.d(t, {
                u: function() {
                    return p
                },
                y: function() {
                    return d
                }
            });
            var n = a(50029),
                o = a(87794),
                r = a.n(o),
                i = a(67294),
                s = a(11163),
                c = a(88767),
                u = a(16700),
                l = (a(76871), a(78703)),
                d = function() {
                    var e = (0, n.Z)(r().mark((function e(t) {
                        var a, n, o, i, s, c, l, d, v, p, m, g, f;
                        return r().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return n = t.queryKey, o = n[0], i = n[1] || {}, s = null !== (a = i.pathname) && void 0 !== a ? a : "", c = "string" === typeof s ? s : String(s || ""), l = i.query, d = "/web/api/parse-url", e.prev = 7, v = {
                                        pathname: c
                                    }, l && "object" === typeof l && Object.keys(l).length && (v.query = l), e.next = 12, fetch(d, {
                                        method: "POST",
                                        headers: {
                                            "Content-Type": "application/json"
                                        },
                                        credentials: "include",
                                        body: JSON.stringify(v)
                                    });
                                case 12:
                                    if ((p = e.sent).ok) {
                                        e.next = 20;
                                        break
                                    }
                                    return e.next = 16, p.text().catch((function() {
                                        return ""
                                    }));
                                case 16:
                                    throw m = e.sent, g = m.length > 300 ? m.substring(0, 300) + "\u2026[truncated]" : m, u.Z.error("Encountered an error while parsing listing url", {
                                        errorType: "HTTPError",
                                        error: "Parse URL Request failed with status ".concat(p.status),
                                        status: p.status,
                                        url: d,
                                        requestBody: v,
                                        responseSnippet: g
                                    }), new Error("Parse URL Request failed with status ".concat(p.status));
                                case 20:
                                    return e.next = 22, p.text();
                                case 22:
                                    return f = e.sent, e.abrupt("return", f ? JSON.parse(f) : null);
                                case 26:
                                    e.prev = 26, e.t0 = e.catch(7), u.Z.error("Encountered an error while parsing listing url", {
                                        errorType: null === e.t0 || void 0 === e.t0 ? void 0 : e.t0.name,
                                        error: (null === e.t0 || void 0 === e.t0 ? void 0 : e.t0.message) || e.t0,
                                        queryName: o,
                                        pathname: decodeURIComponent(c),
                                        query: l
                                    });
                                case 29:
                                    return e.abrupt("return", null);
                                case 30:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [7, 26]
                        ])
                    })));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                v = {
                    staleTime: 3e5,
                    cacheTime: 6e5,
                    refetchOnWindowFocus: !1
                };

            function p() {
                var e = (0, s.useRouter)(),
                    t = (0, i.useMemo)((function() {
                        return {
                            pathname: (0, l.jy)(void 0, e)
                        }
                    }), [e.asPath]),
                    a = (0, i.useMemo)((function() {
                        return ["listingUrlParsing", t]
                    }), [t]);
                return (0, c.useQuery)(a, d, v)
            }
        },
        37594: function(e, t, a) {
            "use strict";
            a.d(t, {
                R: function() {
                    return E
                }
            });
            var n = a(59499),
                o = a(99066),
                r = a(48702),
                i = a(35367),
                s = a(42547),
                c = a(77243),
                u = a(36765),
                l = a(51142),
                d = a(88746),
                v = a(95210),
                p = a(62037),
                m = a(33728),
                g = a(76871),
                f = a(16700);

            function h(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function y(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? h(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : h(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var b = 600,
                _ = function(e) {
                    var t, a, n, o = (null === e || void 0 === e || null === (t = e.message) || void 0 === t || null === (a = t.toLowerCase) || void 0 === a ? void 0 : a.call(t)) || "";
                    return o.includes("failed to fetch") || o.includes("network request failed") || (null === e || void 0 === e ? void 0 : e.networkError) && !(null !== e && void 0 !== e && null !== (n = e.networkError) && void 0 !== n && n.statusCode)
                },
                A = null;

            function E(e) {
                return A || (A = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = (0, d.Z)({
                            uri: function(e) {
                                return e.getContext().isNewGateway ? g.newGraphqlEndpoint : g.graphqlEndpoint
                            },
                            credentials: "same-origin",
                            cache: new o.h
                        }),
                        a = new r.i((function(e, t) {
                            var a = e.getContext(),
                                n = a.token,
                                o = a.lang,
                                r = a.visitorId,
                                i = a.isNewGateway,
                                s = a.gaSessionId,
                                c = i ? {
                                    "Accept-Language": o || "fr",
                                    visitorId: r,
                                    "user-session-id": s
                                } : {
                                    token: n,
                                    lang: o || "",
                                    visitorId: r
                                };
                            return i && n && (c.Authorization = "Bearer ".concat(n)), e.setContext({
                                headers: c
                            }), t(e)
                        })),
                        n = [new l.W({
                            attempts: {
                                max: 3,
                                retryIf: function(e, t) {
                                    var a, n, o, r, i, s = t.getContext(),
                                        c = !0 === s.enableRetry;
                                    if (!c) return !1;
                                    var u = null !== (a = s.retryCount) && void 0 !== a ? a : 0,
                                        l = _(e),
                                        d = t.operationName || (null === (n = t.query) || void 0 === n || null === (o = n.definitions) || void 0 === o || null === (r = o[0]) || void 0 === r || null === (i = r.name) || void 0 === i ? void 0 : i.value) || "UnnamedQuery",
                                        v = l && u < 2;
                                    return v && t.setContext((function(e) {
                                        var t = e.fetchOptions;
                                        return {
                                            retryCount: u + 1,
                                            fetchOptions: y(y({}, void 0 === t ? {} : t), {}, {
                                                keepalive: !0
                                            })
                                        }
                                    })), f.Z.error("[RetryLink] -  Attempt ".concat(u, " for ").concat(d, " failed. Preparing retry attempt ").concat(u + 1, " ..."), {
                                        shouldRetry: l,
                                        enableRetry: c,
                                        message: null === e || void 0 === e ? void 0 : e.message,
                                        networkError: null === e || void 0 === e ? void 0 : e.networkError
                                    }), v
                                }
                            },
                            delay: {
                                initial: b,
                                max: 1800,
                                jitter: !0
                            }
                        }), a],
                        h = m.C5 ? new v.g((0, p.eI)({
                            url: g.graphqlWebSocketEndpoint
                        })) : void 0;
                    m.C5 ? n.push((0, i.V)((function(e) {
                        var t = e.query,
                            a = (0, u.p$)(t);
                        return "OperationDefinition" === a.kind && "subscription" === a.operation
                    }), h, t)) : n.push(t);
                    return new s.f({
                        ssrMode: !1,
                        link: (0, c.D)(n),
                        cache: (new o.h).restore(e)
                    })
                }(e)), A
            }
        },
        51151: function(e, t, a) {
            "use strict";
            var n = a(55322),
                o = a(21321),
                r = a(20511),
                i = a(77596),
                s = new n.Z;
            s.add(new o.Z(i.r)), s.register(r.$), t.Z = s
        },
        78703: function(e, t, a) {
            "use strict";
            a.d(t, {
                h5: function() {
                    return c
                },
                jy: function() {
                    return s
                },
                kW: function() {
                    return u
                }
            });
            var n = a(17674),
                o = a(93088),
                r = a(76871),
                i = a(16700);

            function s(e, t) {
                var a, n, o, r, s = t ? null === t || void 0 === t || null === (a = t.asPath) || void 0 === a || null === (n = a.split) || void 0 === n || null === (o = n.call(a, "?")) || void 0 === o ? void 0 : o[0] : null === e || void 0 === e || null === (r = e._parsedUrl) || void 0 === r ? void 0 : r.pathname;
                try {
                    return decodeURIComponent(s || "")
                } catch (c) {
                    return i.Z.warn("Failed to decode URI pathname", {
                        pathname: s,
                        error: null === c || void 0 === c ? void 0 : c.message
                    }), ""
                }
            }

            function c(e) {
                var t = e.req,
                    a = e.res,
                    n = e.generatedUrl;
                try {
                    var s, c = null === t || void 0 === t || null === (s = t._parsedUrl) || void 0 === s ? void 0 : s.path;
                    if (!c || !n) return !1;
                    var u = new URL(decodeURI(c), r.baseUrl);
                    u.searchParams.sort();
                    var l = new URL(decodeURI(n), r.baseUrl);
                    if (l.searchParams.sort(), u.href !== l.href) return i.Z.info("Redirecting to canonical URL", {
                        requestedUrl: u.href,
                        generatedUrl: l.href
                    }), a.status(o.t8.MOVED_PERMANENTLY.CODE).redirect(n), !0
                } catch (d) {
                    i.Z.error("Error during canonical redirect check", (null === d || void 0 === d ? void 0 : d.message) || d)
                }
                return !1
            }

            function u(e) {
                var t = e.res,
                    a = e.asPath;
                if (e.offset > 2147483648) {
                    var r = a.split("?"),
                        i = (0, n.Z)(r, 2),
                        s = i[0],
                        c = i[1],
                        u = new URLSearchParams(c);
                    return u.set("o", 1), t.writeHead(o.dv.BAD_REQUEST.CODE, {
                        Location: "".concat(s, "?").concat(u.toString())
                    }), t.end(), !0
                }
                return !1
            }
        },
        23822: function(e, t, a) {
            var n = a(37018),
                o = a(76871).adTypeString,
                r = a(80925).ALLOWED_VERTICALS_HOME_PAGE,
                i = [1, 2, 3, 4].join("|"),
                s = o && o.map((function(e) {
                    return encodeURI(e)
                })).join("|"),
                c = ":lang(fr|ar)",
                u = null === r || void 0 === r ? void 0 : r.join("|");
            e.exports = n().add({
                pattern: "/".concat(c, "?/checkout"),
                page: "payment",
                name: "payment"
            }).add({
                pattern: "/".concat(c, "/payment/success"),
                page: "payment/success"
            }).add({
                pattern: "/".concat(c, "/payment/failure"),
                page: "payment/failure"
            }).add({
                pattern: "/".concat(c, "?/ecom/checkout"),
                page: "checkout/index",
                name: "checkout"
            }).add({
                pattern: "/vi/:id(\\d+).htm",
                page: "classified/view"
            }).add({
                pattern: "/".concat(c, "/:region/:category/:slug_:id(\\d+).htm"),
                page: "classified/view"
            }).add({
                pattern: "/ad",
                page: "classified/view"
            }).add({
                pattern: "/".concat(c, "/ad/insert/:step(").concat(i, ")?"),
                page: "ad/insert",
                name: "insert"
            }).add({
                pattern: "/".concat(c, "?/ad/edit/:id(\\d+)/:step(").concat(i, ")?"),
                page: "ad/edit",
                name: "edit"
            }).add({
                pattern: "/".concat(c, "/home"),
                page: "home"
            }).add({
                pattern: "/".concat(c, "/v2/search"),
                page: "search/v2"
            }).add({
                pattern: "/".concat(c, "/:vertical(").concat(u, ")"),
                page: "vertical-home"
            }).add({
                pattern: "/".concat(c, "/boutique/:name?/:category?"),
                page: "shop/details"
            }).add({
                pattern: "/".concat(c, "/magasin"),
                page: "shop/details"
            }).add({
                pattern: "/".concat(c, "/boutiques/:location?/:category?/:keyword?:delim(-)?:delim(-)?:type(").concat(s, ")?"),
                page: "shop/listing"
            }).add({
                pattern: "/".concat(c, "/account"),
                page: "account"
            }).add({
                pattern: "/".concat(c, "/account/signin"),
                page: "account/signin"
            }).add({
                pattern: "/".concat(c, "/account/shop/signin"),
                page: "account/shop/signin"
            }).add({
                pattern: "/".concat(c, "/account/signup"),
                page: "account/signup"
            }).add({
                pattern: "/".concat(c, "/account/reset-password"),
                page: "account/reset-password"
            }).add({
                pattern: "/".concat(c, "/account/v2/my-ads"),
                page: "account/v2/my-ads"
            }).add({
                pattern: "/".concat(c, "/account/v2/my-orders"),
                page: "account/v2/my-orders"
            }).add({
                pattern: "/".concat(c, "/account/v2/my-favorites"),
                page: "account/v2/my-favorites"
            }).add({
                pattern: "/".concat(c, "/account/v2/stats"),
                page: "account/v2/stats"
            }).add({
                pattern: "/".concat(c, "/account/v2/settings/profile"),
                page: "account/v2/settings/profile"
            }).add({
                pattern: "/".concat(c, "/account/v2/settings/contact"),
                page: "account/v2/settings/contact"
            }).add({
                pattern: "/".concat(c, "/account/v2/settings/password"),
                page: "account/v2/settings/password"
            }).add({
                pattern: "/".concat(c, "/account/v2/settings/notification"),
                page: "account/v2/settings/notification"
            }).add({
                pattern: "/".concat(c, "/account/ad-operations"),
                page: "account/ad-operations"
            }).add({
                pattern: "/".concat(c, "/account/bulk"),
                page: "account/bulk"
            }).add({
                pattern: "/cotation-voiture/estimation",
                page: "/auto-transaction/cotation"
            }).add({
                pattern: "/cotation-voiture",
                page: "/auto-transaction/landing"
            }).add({
                pattern: "/cotation-voiture/connexion",
                page: "/auto-transaction/login"
            }).add({
                pattern: "/cotation-voiture/mes-estimations/details/:id?",
                page: "/auto-transaction/evaluation-details"
            }).add({
                pattern: "/cotation-voiture/mes-estimations/:o?",
                page: "/auto-transaction/evaluations"
            }).add({
                pattern: "/".concat(c, "/account/seller/my-products"),
                page: "/account/seller/my-products"
            }).add({
                pattern: "/".concat(c, "/account/seller/my-orders"),
                page: "/account/seller/my-orders"
            }).add({
                pattern: "/".concat(c, "/account/seller/my-payments"),
                page: "/account/seller/my-payments"
            }).add({
                pattern: "/".concat(c, "/product/insert"),
                page: "/product/insert"
            }).add({
                pattern: "/".concat(c, "/product/edit"),
                page: "/product/edit"
            }).add({
                pattern: "/".concat(c, "/:location?/:slug1?/:slug2?/:slug3?:delim(-)?:delim(-)?:type(").concat(s, ")?"),
                page: "search"
            }).add({
                pattern: "/:list(list)",
                page: "search"
            }).add({
                pattern: "/:li(li)",
                page: "search"
            }).add({
                pattern: "/deeplink/view/:id?",
                page: "/deeplink/adview"
            })
        },
        93572: function(e, t, a) {
            "use strict";
            a.d(t, {
                L: function() {
                    return r
                },
                b: function() {
                    return o
                }
            });
            var n = a(93088),
                o = function() {
                    return window.__NEXT_REDUX_STORE__
                },
                r = function(e) {
                    var t = e.response,
                        a = void 0 === t ? {} : t;
                    if (a.status === n.dv.BAD_REQUEST.CODE) {
                        var o, r, i = (null === (o = a.data[0]) || void 0 === o ? void 0 : o.wording) || a.wording || a.message,
                            s = (null === (r = a.data[0]) || void 0 === r ? void 0 : r.code) || a.code,
                            c = new Error(i);
                        throw c.code = s, c
                    }
                    return a
                }
        },
        76076: function(e, t, a) {
            "use strict";
            a.d(t, {
                EK: function() {
                    return l
                },
                EO: function() {
                    return n
                },
                GH: function() {
                    return u
                },
                Hn: function() {
                    return d
                },
                LM: function() {
                    return i
                },
                Yq: function() {
                    return m
                },
                il: function() {
                    return g
                },
                jR: function() {
                    return o
                },
                kp: function() {
                    return p
                },
                lg: function() {
                    return v
                },
                wJ: function() {
                    return c
                },
                x5: function() {
                    return r
                },
                ze: function() {
                    return s
                },
                zm: function() {
                    return f
                }
            });
            var n = "LISTING_VIEWED",
                o = "UPDATE_PAGE_NUMBER",
                r = "LOAD_LISTING_ADS_DATA",
                i = "TOGGLE_SAVED_CLASSIFIED",
                s = "DISPLAY_TOAST_MESSAGE",
                c = "userActions/SET_SAVED_ADS",
                u = "userAuthentificationActions/LOAD_SAVED_ADS",
                l = "userAuthentificationActions/ERROR_LOADING_SAVED_ADS",
                d = "SHOW_MODAL",
                v = "PHONE_NUMBER_CALLED",
                p = "TRIGGER_CHAT",
                m = "WHATSAPP_CTA_CLICKED",
                g = "AD_ON_FOCUS",
                f = "TOTAL_LISTING_ADS"
        },
        21098: function(e, t, a) {
            "use strict";
            a.r(t), a.d(t, {
                adOnFocus: function() {
                    return E
                },
                errorLoadingSavedAds: function() {
                    return h
                },
                listingViewed: function() {
                    return d
                },
                loadListingAdsData: function() {
                    return v
                },
                loadSavedAds: function() {
                    return f
                },
                phoneNumberCalled: function() {
                    return b
                },
                setSavedAds: function() {
                    return g
                },
                showModal: function() {
                    return y
                },
                toggleSavedClassified: function() {
                    return p
                },
                triggerChat: function() {
                    return A
                },
                updatePageNumber: function() {
                    return m
                },
                updateTotalListingAds: function() {
                    return S
                },
                whatsappCtaClicked: function() {
                    return _
                }
            });
            var n = a(50029),
                o = a(87794),
                r = a.n(o),
                i = a(27034),
                s = a(93088),
                c = a(76871),
                u = a(68683),
                l = a(76076),
                d = function() {
                    return {
                        type: l.EO
                    }
                },
                v = function(e) {
                    return {
                        type: l.x5,
                        payload: e
                    }
                },
                p = function(e, t, a) {
                    return function() {
                        var o = (0, n.Z)(r().mark((function n(o, d) {
                            var v, p, m, g, f, h, y, b, _, A, E, S;
                            return r().wrap((function(n) {
                                for (;;) switch (n.prev = n.next) {
                                    case 0:
                                        if (v = d(), p = v.authentication, m = p.isLoggedIn, g = p.token, f = v.userProfile.userId, h = {
                                                userId: f,
                                                token: g,
                                                isLoggedIn: m
                                            }, y = [c.endPointBasedUrl, h, Number(t)], m) {
                                            n.next = 5;
                                            break
                                        }
                                        return n.abrupt("return");
                                    case 5:
                                        return b = null, _ = null, A = null, E = null, a ? (A = i.uF, E = "ERROR: Something went wrong while unsaving the Classified") : (A = i.DM, E = "ERROR: Something went wrong while saving the classified"), n.next = 12, (0, u.b)(A, y, E);
                                    case 12:
                                        if (S = n.sent, [s.TD.CREATED.CODE, s.TD.NO_CONTENT.CODE].includes(S) ? (_ = "success", b = a ? "av.unsaveAd.success" : "av.saveAd.success") : (_ = "error", b = a ? "av.unsaveAd.error.internalError" : "av.saveAd.error.internalError"), b || _) {
                                            n.next = 17;
                                            break
                                        }
                                        return n.abrupt("return");
                                    case 17:
                                        "success" === _ && o({
                                            type: l.LM,
                                            payload: {
                                                adId: e,
                                                listId: t
                                            }
                                        }), o({
                                            type: l.ze,
                                            payload: {
                                                type: _,
                                                message: b
                                            }
                                        });
                                    case 19:
                                    case "end":
                                        return n.stop()
                                }
                            }), n)
                        })));
                        return function(e, t) {
                            return o.apply(this, arguments)
                        }
                    }()
                },
                m = function(e) {
                    return {
                        type: l.jR,
                        payload: e
                    }
                },
                g = function(e) {
                    return {
                        type: l.wJ,
                        payload: e
                    }
                },
                f = function(e, t) {
                    return {
                        type: l.GH,
                        payload: {
                            userId: e,
                            token: t
                        }
                    }
                },
                h = function(e) {
                    return {
                        type: l.EK,
                        payload: e
                    }
                },
                y = function(e) {
                    return {
                        type: l.Hn,
                        payload: {
                            modalType: e
                        }
                    }
                },
                b = function(e) {
                    return {
                        type: l.lg,
                        payload: e
                    }
                },
                _ = function(e) {
                    return {
                        type: l.Yq,
                        payload: e
                    }
                },
                A = function(e) {
                    return {
                        type: l.kp,
                        payload: e
                    }
                },
                E = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    return {
                        type: l.il,
                        payload: {
                            adAttributes: e
                        }
                    }
                },
                S = function(e) {
                    return {
                        type: l.zm,
                        payload: e
                    }
                }
        },
        26631: function(e, t, a) {
            "use strict";
            var n = a(35259),
                o = a(7864),
                r = a(74324),
                i = a(80925),
                s = a(76871),
                c = a(21098),
                u = a(76076),
                l = a(27034),
                d = a(58324),
                v = a(93088);
            t.ZP = [function(e) {
                return function(t) {
                    return function(a) {
                        var s = e.getState(),
                            u = (0, o.d)(s);
                        if (a.type === n.Ic.SYNC_USER_DATA) {
                            var l = (null === a || void 0 === a ? void 0 : a.payload) || (0, d.e)("token");
                            if (l) {
                                var v = (0, r.$Q)(l),
                                    p = v.email,
                                    m = v.name,
                                    g = v.accountId,
                                    f = v.storeId,
                                    h = g || f,
                                    y = f ? i.USER_TYPES.SHOP : i.USER_TYPES.PRIVATE,
                                    b = {
                                        name: m,
                                        email: p,
                                        id: h,
                                        type: y,
                                        token: l
                                    };
                                !u && h && e.dispatch(n.oU.updateUserInfos(b)), y === i.USER_TYPES.PRIVATE && e.dispatch((0, c.loadSavedAds)(h, l))
                            }
                        }
                        return t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.payload;
                        return a.type === u.GH && (0, l.$4)(s.endPointBasedUrl, n).then((function(e) {
                            return e.json()
                        })).then((function(t) {
                            var a;
                            null !== t && void 0 !== t && null !== (a = t.ads) && void 0 !== a && a.length || !t.status || t.status === v.TD.OK.CODE ? e.dispatch((0, c.setSavedAds)(t)) : e.dispatch((0, c.errorLoadingSavedAds)(t))
                        })), t(a)
                    }
                }
            }]
        },
        75401: function(e, t, a) {
            "use strict";
            a.d(t, {
                Nv: function() {
                    return o
                },
                Qd: function() {
                    return r
                },
                ZO: function() {
                    return i
                },
                ju: function() {
                    return s
                },
                kS: function() {
                    return u
                },
                tJ: function() {
                    return l
                },
                vw: function() {
                    return d
                },
                x4: function() {
                    return c
                },
                ym: function() {
                    return n
                }
            });
            var n = "authentication/LOGIN",
                o = "authentication/LOGOUT",
                r = "authentication/LOGIN_USER_BY_EMAIL",
                i = "API/LOGIN_USER_BY_EMAIL_SUCCESS",
                s = "API/LOGIN_USER_BY_EMAIL_FAILED",
                c = function(e) {
                    return {
                        type: n,
                        payload: e
                    }
                },
                u = function() {
                    return {
                        type: o
                    }
                },
                l = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                d = function(e, t) {
                    return {
                        type: s,
                        payload: {
                            errorMessage: e,
                            email: null === t || void 0 === t ? void 0 : t.email
                        }
                    }
                }
        },
        60385: function(e, t, a) {
            "use strict";
            var n = a(50029),
                o = a(87794),
                r = a.n(o),
                i = a(75401),
                s = a(35259),
                c = a(10666),
                u = a(36697),
                l = a(51432),
                d = a(35538),
                v = a(74324),
                p = a(80925),
                m = a(20511),
                g = a(73315);
            t.Z = [function(e) {
                return function(t) {
                    return function() {
                        var a = (0, n.Z)(r().mark((function a(n) {
                            var o, f, h, y, b, _, A, E, S, R, C, D, T, P, O, I, w, L, M, x;
                            return r().wrap((function(a) {
                                for (;;) switch (a.prev = a.next) {
                                    case 0:
                                        return o = n.type, f = n.payload, h = e.getState(), o === i.Qd && (e.dispatch((0, c.yh)()), b = null === h || void 0 === h || null === (y = h.page) || void 0 === y ? void 0 : y.lang, _ = f.email, A = f.password, E = f.onAuthSuccess, e.dispatch((0, u.Z)(l.Y, {
                                            successfulResponseAction: i.tJ,
                                            erroredResponseAction: i.vw
                                        }, {
                                            variables: {
                                                email: _,
                                                password: A
                                            },
                                            context: {
                                                isNewGateway: !0,
                                                lang: b
                                            }
                                        }, {
                                            onAuthSuccess: E
                                        }))), o === i.ZO && (null !== f && void 0 !== f && null !== (S = f.data) && void 0 !== S && S.loginByEmail && (R = f.data.loginByEmail.accessToken, C = f.metadata.onAuthSuccess, (D = (0, v.Lt)(R)) && (T = D.sub, P = D.roles, O = D.name, I = D.email, w = D.allowedAccess, (0, d.d8)(p.TOKEN_COOKIE_NAME, R), L = P[0], M = !(null === L || void 0 === L || !L.includes(p.STORE_ROLES.STORE_OWNER)), x = M ? p.USER_TYPES.SHOP : p.USER_TYPES.PRIVATE, e.dispatch((0, i.x4)(R)), e.dispatch((0, s.P1)({
                                            userId: T,
                                            name: O,
                                            email: I,
                                            type: x,
                                            role: L,
                                            allowedAccess: w
                                        })), (0, g.ut)(m.D.USER_ACCOUNT__LOGGED_IN, {
                                            email: I,
                                            status: "Success",
                                            user_id: Number(T),
                                            account_type: x,
                                            element_source: "Avito login"
                                        }), "function" === typeof C && C(R))), e.dispatch((0, c.v3)())), o === i.ju && ((0, g.ut)(m.D.USER_ACCOUNT__LOGGED_IN, {
                                            email: null === f || void 0 === f ? void 0 : f.email,
                                            status: "Error",
                                            element_source: "Avito login"
                                        }), e.dispatch((0, c.TX)({
                                            status: "error",
                                            title: "av.login.error.msg1",
                                            message: "av.login.error.mesg2",
                                            customMessage: null === f || void 0 === f ? void 0 : f.errorMessage
                                        })), e.dispatch((0, c.v3)())), a.abrupt("return", t(n));
                                    case 6:
                                    case "end":
                                        return a.stop()
                                }
                            }), a)
                        })));
                        return function(e) {
                            return a.apply(this, arguments)
                        }
                    }()
                }
            }]
        },
        7864: function(e, t, a) {
            "use strict";
            a.d(t, {
                C: function() {
                    return o
                },
                d: function() {
                    return n
                }
            });
            var n = function(e) {
                    var t;
                    return null === e || void 0 === e || null === (t = e.authentication) || void 0 === t ? void 0 : t.isLoggedIn
                },
                o = function(e) {
                    var t;
                    return null === e || void 0 === e || null === (t = e.authentication) || void 0 === t ? void 0 : t.token
                }
        },
        9401: function(e, t, a) {
            "use strict";
            a.d(t, {
                D: function() {
                    return o
                },
                i: function() {
                    return n
                }
            });
            var n = "tagging/SEND_ELEMENT_CLICKED_EVENT",
                o = "tagging/SEND_CUSTOM_EVENT"
        },
        98459: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return d
                }
            });
            var n = a(17674),
                o = a(20511),
                r = a(50216),
                i = a(16700),
                s = a(9401),
                c = a(68697),
                u = a(80925),
                l = (0, c.P1)((function(e) {
                    return e.page
                }), (function(e) {
                    return e.userProfile
                }), (function(e, t) {
                    return {
                        pageName: e.page_type,
                        sellerType: t.type === u.USER_TYPES.SHOP ? "pro" : "private",
                        sellerId: Number(t.userId),
                        sellerPhone: t.phone
                    }
                })),
                d = [function(e) {
                    return function(t) {
                        return function(a) {
                            var c = e.getState(),
                                u = a.type,
                                d = a.payload,
                                v = null,
                                p = {};
                            switch (u) {
                                case s.i:
                                    v = o.D.COMMON__ELEMENT_CLICKED;
                                    var m = l(c),
                                        g = m.pageName,
                                        f = m.sellerType,
                                        h = m.sellerId,
                                        y = m.sellerPhone,
                                        b = (0, n.Z)(d.props, 4),
                                        _ = b[0],
                                        A = b[1],
                                        E = b[2],
                                        S = b[3];
                                    p.element_name = _, p.page_name = g, p.subcategory_id = A && Number(A), p.seller_id = h, p.seller_type = f, p.seller_phone = y, p.value = String(E), p.element_source = S;
                                    break;
                                case s.D:
                                    v = d.event, d.props && (p = d.props)
                            }
                            if (v) try {
                                (0, r.R)(v, p)
                            } catch (R) {
                                i.Z.error("Encountered an error while event tagging", null === R || void 0 === R ? void 0 : R.toString())
                            }
                            return t(a)
                        }
                    }
                }]
        },
        5050: function(e, t, a) {
            "use strict";
            a.d(t, {
                FM: function() {
                    return s
                },
                Gw: function() {
                    return r
                },
                _B: function() {
                    return n
                },
                bI: function() {
                    return u
                },
                k$: function() {
                    return l
                },
                od: function() {
                    return i
                },
                qN: function() {
                    return c
                },
                xW: function() {
                    return o
                }
            });
            var n = "options/GET_ALL_CATEGORIES_OPTIONS",
                o = "API/GET_ALL_CATEGORIES_SUCCESS",
                r = "API/GET_ALL_CATEGORIES_FAILED",
                i = "options/UPDATE_GET_ALL_CATEGORIES_OPTIONS",
                s = function() {
                    return {
                        type: n
                    }
                },
                c = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                u = function() {
                    return {
                        type: r
                    }
                },
                l = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                }
        },
        10045: function(e, t, a) {
            "use strict";
            a.d(t, {
                BS: function() {
                    return i
                },
                CJ: function() {
                    return s
                },
                HB: function() {
                    return l
                },
                Rl: function() {
                    return o
                },
                UZ: function() {
                    return v
                },
                W: function() {
                    return c
                },
                b: function() {
                    return d
                },
                bJ: function() {
                    return u
                },
                bn: function() {
                    return r
                },
                bp: function() {
                    return m
                },
                n1: function() {
                    return n
                },
                z6: function() {
                    return p
                }
            });
            var n = "options/GET_POPULAR_CITIES_OPTIONS",
                o = "API/GET_POPULAR_CITIES_SUCCESS",
                r = "options/GET_ALL_CITIES_OPTIONS",
                i = "API/GET_ALL_CITIES_SUCCESS",
                s = "options/UPDATE_POPULAR_CITIES_OPTIONS",
                c = "options/UPDATE_ALL_CITIES_OPTIONS",
                u = function() {
                    return {
                        type: n
                    }
                },
                l = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                d = function(e) {
                    return {
                        type: s,
                        payload: e
                    }
                },
                v = function() {
                    return {
                        type: r
                    }
                },
                p = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                m = function(e) {
                    return {
                        type: c,
                        payload: e
                    }
                }
        },
        74516: function(e, t, a) {
            "use strict";
            a.d(t, {
                X: function() {
                    return s
                }
            });
            var n = a(5050),
                o = a(80308),
                r = a(96054),
                i = a(10666),
                s = function(e) {
                    return function(t) {
                        return function(a) {
                            var s, c, u, l, d = a.type,
                                v = a.payload;
                            (d === n._B && e.dispatch((0, o.Z)(r.$, {
                                successfulResponseAction: n.qN,
                                erroredResponseAction: n.bI
                            }, {
                                context: {
                                    isNewGateway: !1
                                }
                            })), d === n.xW) && (null !== v && void 0 !== v && null !== (s = v.data) && void 0 !== s && null !== (c = s.getCategories) && void 0 !== c && c.categories && e.dispatch((0, n.k$)(null === v || void 0 === v || null === (u = v.data) || void 0 === u || null === (l = u.getCategories) || void 0 === l ? void 0 : l.categories)));
                            return d === n.Gw && e.dispatch((0, i.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error"
                            })), t(a)
                        }
                    }
                };
            t.Z = [s]
        },
        41823: function(e, t, a) {
            "use strict";
            var n = a(10045),
                o = a(80308),
                r = a(52890);
            t.ZP = [function(e) {
                return function(t) {
                    return function(a) {
                        var i, s, c, u = a.type,
                            l = a.payload,
                            d = e.getState();
                        u === n.n1 && e.dispatch((0, o.Z)(r.mz, {
                            successfulResponseAction: n.HB
                        }, {
                            context: {
                                lang: null === d || void 0 === d || null === (i = d.page) || void 0 === i ? void 0 : i.lang,
                                isNewGateway: !1
                            }
                        }));
                        if (u === n.Rl && (null !== l && void 0 !== l && null !== (s = l.data) && void 0 !== s && null !== (c = s.getPopularCitiesFormattedNext) && void 0 !== c && c.cities)) {
                            var v = null === l || void 0 === l ? void 0 : l.data.getPopularCitiesFormattedNext.cities.map((function(e) {
                                return {
                                    label: e.label,
                                    value: e.value,
                                    type: e.type
                                }
                            }));
                            e.dispatch((0, n.b)(v))
                        }
                        return t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var i, s, c, u = a.type,
                            l = a.payload,
                            d = e.getState();
                        u === n.bn && e.dispatch((0, o.Z)(r.v_, {
                            successfulResponseAction: n.z6
                        }, {
                            context: {
                                lang: null === d || void 0 === d || null === (i = d.page) || void 0 === i ? void 0 : i.lang,
                                isNewGateway: !1
                            }
                        }));
                        if (u === n.BS && (null !== l && void 0 !== l && null !== (s = l.data) && void 0 !== s && null !== (c = s.getCitiesFormattedNext) && void 0 !== c && c.cities)) {
                            var v = l.data.getCitiesFormattedNext.cities.map((function(e) {
                                return {
                                    label: e.label,
                                    value: e.value
                                }
                            }));
                            e.dispatch((0, n.bp)(v))
                        }
                        return t(a)
                    }
                }
            }]
        },
        34693: function(e, t, a) {
            "use strict";
            var n = a(90116),
                o = a(53894),
                r = a(33728),
                i = a(60385),
                s = a(41823),
                c = a(76466),
                u = a(63194),
                l = a(17653),
                d = a(7303),
                v = a(74516),
                p = a(39277),
                m = a(87383),
                g = a(14916),
                f = a(26997),
                h = a(24123),
                y = a(4906);
            t.Z = [o.Z].concat((0, n.Z)(i.Z), (0, n.Z)(s.ZP), (0, n.Z)(c.ZP), [u.Z], (0, n.Z)(l.ZP), (0, n.Z)(d.ZP), (0, n.Z)(v.Z), (0, n.Z)(g.ZP), (0, n.Z)(f.ZP), (0, n.Z)(h.ZP), (0, n.Z)(y.ZP), (0, n.Z)(p.Z), [r.C5 && m.Z]).filter(Boolean)
        },
        87383: function(e, t, a) {
            "use strict";
            a.d(t, {
                Q: function() {
                    return v
                }
            });
            var n = a(59499),
                o = a(20511),
                r = a(50216),
                i = a(16700),
                s = a(33728),
                c = a(45685),
                u = a(95271);

            function l(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function d(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? l(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : l(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var v = function() {
                return function(e) {
                    return function(t) {
                        var a = t.type,
                            n = t.payload,
                            s = null;
                        if (a === u.iF) s = o.D.COMMON__ELEMENT_CLICKED;
                        if (s) try {
                            (0, r.R)(s, d({}, n))
                        } catch (c) {
                            i.Z.error("Encountered an error while event tagging", null === c || void 0 === c ? void 0 : c.toString())
                        }
                        return e(t)
                    }
                }
            };
            t.Z = function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.type,
                            l = a.payload,
                            v = e.getState(),
                            p = null,
                            m = {};
                        switch (n) {
                            case u.Jt:
                                p = o.D.USER_ACCOUNT__TAB_CLICKED, m = {
                                    tab: null === l || void 0 === l ? void 0 : l.tab,
                                    from: null === l || void 0 === l ? void 0 : l.from
                                };
                                break;
                            case u.IQ:
                                p = o.D.USER_ACCOUNT__FILTER_CLICKED, m = {
                                    filter: l
                                };
                                break;
                            case u.I_:
                                p = o.D.USER_ACCOUNT__PROFILE_INFOS_UPDATED, m = {
                                    status: l
                                };
                                break;
                            case u.Si:
                                p = o.D.USER_ACCOUNT__PASSWORD_UPDATED, m = {
                                    status: l
                                };
                                break;
                            case u.ed:
                                p = o.D.USER_ACCOUNT__AD_DETAILS_DISPLAYED, m = {
                                    ad_id: null === l || void 0 === l ? void 0 : l.adId,
                                    ad_type: null === l || void 0 === l ? void 0 : l.adType,
                                    from: null === l || void 0 === l ? void 0 : l.from
                                };
                                break;
                            case u.Wp:
                                p = null === l || void 0 === l ? void 0 : l.tag, m = {
                                    ad_id: null === l || void 0 === l ? void 0 : l.adId
                                };
                                break;
                            case u.H4:
                                p = o.D.USER_ACCOUNT__ACTIVATE_AD_CLICKED, m = {
                                    ad_id: l
                                };
                                break;
                            case u.fQ:
                                p = o.D.USER_ACCOUNT__DELETED_AD_CLICKED;
                                break;
                            case u.tp:
                                p = o.D.USER_ACCOUNT__INITIATED_AD_DELETION, m = {
                                    ad_ids: null === l || void 0 === l ? void 0 : l.adIds,
                                    number_of_ads: null === l || void 0 === l ? void 0 : l.numberOfAds
                                };
                                break;
                            case u.Oi:
                                p = o.D.USER_ACCOUNT__SUB_TAB_CLICKED, m = {
                                    tab: l
                                };
                                break;
                            case u.hC:
                                p = o.D.USER_ACCOUNT__FILTER_TRIGGRED;
                                break;
                            case u.Mf:
                                p = o.D.USER_ACCOUNT__MULTIPLE_ADS_SELECTED;
                                break;
                            case u.ut:
                                p = o.D.USER_ACCOUNT__MANAGE_AD_CLICKED;
                                break;
                            case u.OH:
                                p = o.D.USER_ACCOUNT__DATE_RANG_SELECTED, m = {
                                    days: l
                                }
                        }
                        if (p) try {
                            (0, r.R)(p, d(d(d({
                                source: (0, s.eF)()
                            }, (0, c.pq)(v)), m), {}, {
                                element_source: "New version"
                            }))
                        } catch (g) {
                            i.Z.error("Encountered an error while event tagging", null === g || void 0 === g ? void 0 : g.toString())
                        }
                        return t(a)
                    }
                }
            }
        },
        27256: function(e, t, a) {
            "use strict";
            var n = a(90116),
                o = a(53894),
                r = a(98459),
                i = a(26631),
                s = a(60385),
                c = a(39277),
                u = a(34693),
                l = a(36331),
                d = [o.Z].concat((0, n.Z)(i.ZP), (0, n.Z)(s.Z), (0, n.Z)(u.Z), (0, n.Z)(c.Z), (0, n.Z)(l.Z), (0, n.Z)(r.Z)).filter(Boolean);
            t.Z = (0, n.Z)(new Set(d))
        },
        36331: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return M
                }
            });
            var n = a(90116),
                o = a(53894),
                r = a(33728),
                i = a(39277),
                s = a(59499),
                c = a(50029),
                u = a(87794),
                l = a.n(u),
                d = a(27034),
                v = a(93088),
                p = a(53326),
                m = a(68683),
                g = a(76871);

            function f(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function h(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(a), !0).forEach((function(t) {
                        (0, s.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : f(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var y = function(e) {
                    var t = e.getState,
                        a = e.dispatch;
                    return function(e) {
                        return function() {
                            var n = (0, c.Z)(l().mark((function n(o) {
                                var r, i, s, c, u, f, y, b, _, A, E, S, R, C, D, T, P, O, I, w, L;
                                return l().wrap((function(n) {
                                    for (;;) switch (n.prev = n.next) {
                                        case 0:
                                            if (r = t(), i = o.type, s = o.payload, i === p.w4 && (c = s, u = r.shopDetails.shopAds, f = u.find((function(e) {
                                                    return e.id === c
                                                })), c && f && (y = u.map((function(e) {
                                                    return e.id === c ? h(h({}, e), {}, {
                                                        isSaved: !e.isSaved
                                                    }) : e
                                                })), a((0, p.ag)(y)))), i !== p.V9) {
                                                n.next = 24;
                                                break
                                            }
                                            if (b = null, _ = null, A = null, E = null, S = s.adId, R = s.listId, C = s.isSaved, D = r.authentication, T = D.isLoggedIn, P = D.token, O = r.userProfile.userId, I = {
                                                    userId: O,
                                                    token: P,
                                                    isLoggedIn: T
                                                }, w = [g.endPointBasedUrl, I, Number(R)], T) {
                                                n.next = 14;
                                                break
                                            }
                                            return n.abrupt("return");
                                        case 14:
                                            return C ? (A = d.uF, E = "ERROR: Something went wrong while unsaving the Classified") : (A = d.DM, E = "ERROR: Something went wrong while saving the classified"), n.next = 17, (0, m.b)(A, w, E);
                                        case 17:
                                            if (L = n.sent, [v.TD.CREATED.CODE, v.TD.NO_CONTENT.CODE].includes(L) ? (_ = "success", b = C ? "av.unsaveAd.success" : "av.saveAd.success") : (_ = "error", b = C ? "av.unsaveAd.error.internalError" : "av.saveAd.error.internalError"), b || _) {
                                                n.next = 22;
                                                break
                                            }
                                            return n.abrupt("return");
                                        case 22:
                                            "success" === _ && a((0, p.CM)(S)), a((0, p.oh)({
                                                type: _,
                                                message: b
                                            }));
                                        case 24:
                                            return n.abrupt("return", e(o));
                                        case 25:
                                        case "end":
                                            return n.stop()
                                    }
                                }), n)
                            })));
                            return function(e) {
                                return n.apply(this, arguments)
                            }
                        }()
                    }
                },
                b = a(60385),
                _ = a(20511),
                A = a(50216),
                E = a(16700),
                S = a(82268),
                R = a(54735),
                C = a(44194),
                D = a(72673),
                T = a(36697),
                P = a(70232),
                O = a(77596);

            function I(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function w(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? I(Object(a), !0).forEach((function(t) {
                        (0, s.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : I(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var L = function(e) {
                    return function(t) {
                        return function(a) {
                            var n = a.type,
                                o = a.payload,
                                i = e.getState(),
                                s = (0, P.EN)(i),
                                c = (0, P.gD)(i),
                                u = _.D.AD_ADVIEW__LEAD,
                                l = {},
                                d = i.shopDetails,
                                v = (d = void 0 === d ? {} : d).filters,
                                m = (v = void 0 === v ? {} : v).storeId,
                                g = {
                                    gaSessionId: s,
                                    token: i.authentication.token,
                                    isNewGateway: !0,
                                    visitorId: c
                                },
                                f = function(e) {
                                    try {
                                        (0, A.R)(u, w(w(w(w(w({}, l), (0, D.MK)(i)), (0, D.Pr)(i)), (0, D.dX)(i)), {}, {
                                            source: (0, r.eF)(),
                                            element_source: "Shop details summary",
                                            page_name: O.a.shopDetails
                                        }))
                                    } catch (t) {
                                        E.Z.error("Encountered an error while firing lead event ".concat(u, " triggered by ").concat(e, " action"), null === t || void 0 === t ? void 0 : t.toString())
                                    }
                                };
                            if (n === p.Hn && "SHOW_NUMBER_MODAL" === o && (l = {
                                    lead_type: "show phone"
                                }, f(n), e.dispatch((0, T.Z)(S.H, {
                                    successfulResponseAction: C.id
                                }, {
                                    variables: {
                                        event: {
                                            name: "STORE_PHONE_NUMBER_SHOWN",
                                            storeId: m
                                        }
                                    },
                                    context: g
                                }, o))), n === p.Y6 && (l = {
                                    lead_type: "call"
                                }, f(n)), n === R.jR) {
                                var h = o.data.collectPerformanceEvent.name;
                                E.Z.info("SUCCESS: Successfully collected perf event ".concat(h))
                            }
                            return t(a)
                        }
                    }
                },
                M = [o.Z, y].concat((0, n.Z)(b.Z), (0, n.Z)(i.Z), [r.C5 && L]).filter(Boolean)
        },
        39277: function(e, t, a) {
            "use strict";
            var n = a(54735),
                o = a(74324),
                r = a(11163),
                i = a.n(r),
                s = a(12622),
                c = a(44194),
                u = a(35538),
                l = a(80925),
                d = [function(e) {
                    return function(t) {
                        return function(a) {
                            var r = a.type,
                                s = e.getState().page.lang;
                            if (r === n.Zd) {
                                var c = a.payload.targetLang;
                                (0, u.d8)(l.LANGUAGE_COOKIE_NAME, c), (0, o.uX)(i().asPath.replace(s, c))
                            }
                            return t(a)
                        }
                    }
                }, function(e) {
                    return function(t) {
                        return function(a) {
                            var o = a.type,
                                r = a.payload;
                            if (o === n.qg) {
                                var i = r.pageName,
                                    u = r.visitorId,
                                    l = r.gaSessionId,
                                    d = r.isMobile,
                                    v = r.isTablet,
                                    p = r.isDesktop,
                                    m = (0, s.Y)(i);
                                e.dispatch((0, c.t0)(m)), e.dispatch((0, c.IA)(u)), e.dispatch((0, c.fZ)(l)), e.dispatch((0, c.Ep)(d)), e.dispatch((0, c.F_)(v)), e.dispatch((0, c.qm)(p))
                            }
                            return t(a)
                        }
                    }
                }];
            t.Z = d
        },
        4264: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return u
                }
            });
            var n = a(59499),
                o = a(54735),
                r = JSON.parse('{"u2":"phoenix","i8":"1.51.0"}');

            function i(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function s(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? i(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : i(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var c = {
                    app: {
                        version: r.i8,
                        name: r.u2
                    },
                    loginWall: {
                        withTabs: !1
                    },
                    env: {
                        visitorId: null,
                        gaSessionId: null
                    },
                    lang: "fr",
                    isMobile: !1,
                    isTablet: !1,
                    isDesktop: !1
                },
                u = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : c,
                        t = arguments.length > 1 ? arguments[1] : void 0,
                        a = t.type,
                        n = t.payload;
                    switch (a) {
                        case o.jK:
                            return s(s({}, e), {}, {
                                breadcrumb: n
                            });
                        case o.ZT:
                            return s(s({}, e), {}, {
                                env: s(s({}, e.env), {}, {
                                    visitorId: n
                                })
                            });
                        case o.eG:
                            return s(s({}, e), {}, {
                                page_type: n
                            });
                        case o.P$:
                            return s(s({}, e), {}, {
                                lang: n
                            });
                        case o._:
                            return s(s({}, e), {}, {
                                isMobile: n
                            });
                        case o.ZE:
                            return s(s({}, e), {}, {
                                isTablet: n
                            });
                        case o.k7:
                            return s(s({}, e), {}, {
                                isDesktop: n
                            });
                        case o.bz:
                            var r;
                            return s(s({}, e), {}, {
                                loginWall: s(s({}, null === e || void 0 === e ? void 0 : e.loginWall), {}, {
                                    isOpen: !(null !== e && void 0 !== e && null !== (r = e.loginWall) && void 0 !== r && r.isOpen)
                                }, n)
                            });
                        case o.m7:
                            return null !== n && void 0 !== n && n.successFunction && "function" === typeof(null === n || void 0 === n ? void 0 : n.successFunction) ? s(s({}, e), {}, {
                                loginWall: s(s({}, null === e || void 0 === e ? void 0 : e.loginWall), {}, {
                                    successFunction: n.successFunction,
                                    funcArgs: null === n || void 0 === n ? void 0 : n.funcArgs
                                })
                            }) : e;
                        case o.Zd:
                            var i = n.lang,
                                u = n.targetLang;
                            return s(s({}, e), {}, {
                                lang: i,
                                targetLang: u
                            });
                        case o.qc:
                            return s(s({}, e), {}, {
                                env: s(s({}, e.env), {}, {
                                    gaSessionId: n
                                })
                            });
                        default:
                            return e
                    }
                }
        },
        71814: function(e, t, a) {
            "use strict";
            a.d(t, {
                BM: function() {
                    return l
                },
                BN: function() {
                    return C
                },
                Cd: function() {
                    return F
                },
                D3: function() {
                    return R
                },
                DY: function() {
                    return L
                },
                EO: function() {
                    return H
                },
                Ev: function() {
                    return I
                },
                Kc: function() {
                    return x
                },
                Lo: function() {
                    return _
                },
                Lw: function() {
                    return Z
                },
                MN: function() {
                    return b
                },
                OV: function() {
                    return y
                },
                Op: function() {
                    return G
                },
                PX: function() {
                    return q
                },
                Qs: function() {
                    return o
                },
                RC: function() {
                    return O
                },
                Rn: function() {
                    return N
                },
                SI: function() {
                    return D
                },
                SJ: function() {
                    return i
                },
                TG: function() {
                    return f
                },
                UK: function() {
                    return m
                },
                UP: function() {
                    return d
                },
                YY: function() {
                    return z
                },
                Z3: function() {
                    return E
                },
                Zx: function() {
                    return u
                },
                a0: function() {
                    return V
                },
                aD: function() {
                    return c
                },
                cB: function() {
                    return M
                },
                fR: function() {
                    return P
                },
                fo: function() {
                    return S
                },
                gN: function() {
                    return r
                },
                hJ: function() {
                    return K
                },
                hX: function() {
                    return w
                },
                hp: function() {
                    return B
                },
                iL: function() {
                    return p
                },
                iW: function() {
                    return v
                },
                oc: function() {
                    return h
                },
                pw: function() {
                    return j
                },
                qr: function() {
                    return k
                },
                rp: function() {
                    return s
                },
                uI: function() {
                    return T
                },
                uR: function() {
                    return g
                },
                v8: function() {
                    return $
                },
                y2: function() {
                    return n
                },
                zW: function() {
                    return A
                },
                zm: function() {
                    return U
                }
            });
            var n = "userOrders/UPDATE_DISPLAY_MODE",
                o = "userOrders/GET_USER_ORDERS",
                r = "API/GET_USER_ORDERS_SUCCESS",
                i = "API/GET_USER_ORDERS_FAILED",
                s = "userOrders/UPDATE_USER_ORDERS",
                c = "userOrders/UPDATE_USER_ORDERS_WITH_COUNT",
                u = "userOrders/GET_USER_ORDERS_COUNTS",
                l = "API/GET_USER_ORDERS_COUNTS_SUCCESS",
                d = "userOrders/UPDATE_USER_ORDERS_COUNTS",
                v = "userOrders/UPDATE_ORDERS_COUNT_BY_STATUS",
                p = "userOrders/ADD_TO_CHECKED_ORDERS_IDS",
                m = "userOrders/REMOVE_FROM_CHECKED_ORDERS_IDS",
                g = "userOrders/ADD_ALL_TO_CHECKED_PRODUCTS_IDS",
                f = "userOrders/REMOVE_ALL_FROM_CHECKED_ORDERS_IDS",
                h = "userOrders/CANCEL_USER_ORDER",
                y = "API/CANCEL_USER_ORDER_SUCCESS",
                b = "API/CANCEL_USER_ORDER_FAILED",
                _ = "userOrders/PREPARE_USER_ORDER",
                A = "API/PREPARE_USER_ORDER_SUCCESS",
                E = "API/PREPARE_USER_ORDER_FAILED",
                S = "userOrders/DELETE_USER_ORDER",
                R = "API/DELETE_USER_ORDER_SUCCESS",
                C = "API/DELETE_USER_ORDER_FAILED",
                D = function(e) {
                    return {
                        type: n,
                        payload: e
                    }
                },
                T = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                P = function(e, t) {
                    return {
                        type: r,
                        payload: {
                            response: e,
                            metadata: t
                        }
                    }
                },
                O = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                I = function(e) {
                    return {
                        type: s,
                        payload: e
                    }
                },
                w = function(e) {
                    return {
                        type: c,
                        payload: e
                    }
                },
                L = function() {
                    return {
                        type: u
                    }
                },
                M = function(e) {
                    return {
                        type: l,
                        payload: e
                    }
                },
                x = function(e) {
                    return {
                        type: d,
                        payload: e
                    }
                },
                N = function(e) {
                    return {
                        type: v,
                        payload: e
                    }
                },
                q = function(e) {
                    return {
                        type: p,
                        payload: e
                    }
                },
                k = function(e) {
                    return {
                        type: m,
                        payload: e
                    }
                },
                j = function(e) {
                    return {
                        type: g,
                        payload: e
                    }
                },
                U = function(e) {
                    return {
                        type: f,
                        payload: e
                    }
                },
                V = function(e) {
                    return {
                        type: h,
                        payload: e
                    }
                },
                z = function(e) {
                    return {
                        type: y,
                        payload: e
                    }
                },
                B = function(e) {
                    return {
                        type: b,
                        payload: e
                    }
                },
                F = function(e) {
                    return {
                        type: _,
                        payload: e
                    }
                },
                G = function(e) {
                    return {
                        type: A,
                        payload: e
                    }
                },
                Z = function(e) {
                    return {
                        type: E,
                        payload: e
                    }
                },
                H = function(e) {
                    return {
                        type: S,
                        payload: e
                    }
                },
                $ = function(e) {
                    return {
                        type: R,
                        payload: e
                    }
                },
                K = function(e) {
                    return {
                        type: C,
                        payload: e
                    }
                }
        },
        4906: function(e, t, a) {
            "use strict";
            a.d(t, {
                ZP: function() {
                    return I
                }
            });
            var n, o, r, i, s, c, u = a(4730),
                l = a(59499),
                d = a(71814),
                v = a(80308),
                p = a(36697),
                m = a(71383),
                g = a(68806),
                f = (0, g.Ps)(n || (n = (0, m.Z)(["\n  query getMyPurchaseOrders($query: MyPurchaseOrdersQuery!) {\n    getMyPurchaseOrders(query: $query) {\n      orders {\n        id\n        product {\n          sku\n          listId\n          name\n          thumbnail\n        }\n        total\n        status\n      }\n      count {\n        total\n      }\n    }\n  }\n"]))),
                h = (0, g.Ps)(o || (o = (0, m.Z)(["\n  query getMySaleOrders($query: MySaleOrdersQuery!) {\n    getMySaleOrders(query: $query) {\n      orders {\n        id\n        product {\n          sku\n          listId\n          name\n          thumbnail\n        }\n        unitsSold\n        total\n        status\n        date\n        paymentMethod\n      }\n      count {\n        total\n      }\n    }\n  }\n"]))),
                y = (0, g.Ps)(r || (r = (0, m.Z)(["\n  query getMySaleOrdersCounts {\n    getMySaleOrdersCounts {\n      countsByStatus {\n        status\n        count\n      }\n    }\n  }\n"]))),
                b = (0, g.Ps)(i || (i = (0, m.Z)(["\n  mutation cancelOrder($id: ID!) {\n    cancelOrder(id: $id)\n  }\n"]))),
                _ = (0, g.Ps)(s || (s = (0, m.Z)(["\n  mutation prepareOrder($id: ID!) {\n    prepareOrder(id: $id)\n  }\n"]))),
                A = (0, g.Ps)(c || (c = (0, m.Z)(["\n  mutation deleteOrder($id: ID!) {\n    deleteOrder(id: $id)\n  }\n"]))),
                E = a(10666),
                S = a(80925),
                R = a(31823),
                C = a(61180),
                D = a(47250),
                T = ["product"];

            function P(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function O(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? P(Object(a), !0).forEach((function(t) {
                        (0, l.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : P(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var I = [function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.type,
                            o = a.payload,
                            r = e.getState();
                        if (n === d.Qs) {
                            e.dispatch((0, E.yh)());
                            var i = r.authentication.token,
                                s = r.userProfile.role,
                                c = r.page.lang,
                                l = o.status,
                                p = o.page,
                                m = !(null === s || void 0 === s || !s.includes(S.STORE_ROLES.ECOM_STORE_OWNER)),
                                g = m ? h : f,
                                y = m ? C.Xm : R.X_;
                            e.dispatch((0, v.Z)(g, {
                                successfulResponseAction: d.fR,
                                erroredResponseAction: d.RC
                            }, {
                                variables: {
                                    query: {
                                        filters: {
                                            status: l
                                        },
                                        page: {
                                            number: p,
                                            size: y
                                        }
                                    }
                                },
                                context: {
                                    token: i,
                                    lang: c,
                                    isNewGateway: !0
                                },
                                fetchPolicy: "no-cache"
                            }, o))
                        }
                        if (n === d.gN) {
                            var b, _, A, D, P = r.userProfile.role,
                                I = r.page.lang,
                                w = !(null === P || void 0 === P || !P.includes(S.STORE_ROLES.ECOM_STORE_OWNER)),
                                L = w ? null === o || void 0 === o || null === (b = o.response) || void 0 === b || null === (_ = b.data) || void 0 === _ ? void 0 : _.getMySaleOrders : null === o || void 0 === o || null === (A = o.response) || void 0 === A || null === (D = A.data) || void 0 === D ? void 0 : D.getMyPurchaseOrders;
                            if (L) {
                                var M = L.orders,
                                    x = L.count.total,
                                    N = {
                                        status: o.metadata.status,
                                        orders: null === M || void 0 === M ? void 0 : M.map((function(e) {
                                            var t, a = O(O(O({}, e), null === e || void 0 === e ? void 0 : e.product), {}, {
                                                paymentMethod: null === (t = S.ECOM_PAYMENT_METHODS[null === e || void 0 === e ? void 0 : e.paymentMethod]) || void 0 === t ? void 0 : t[I]
                                            });
                                            a.product;
                                            return (0, u.Z)(a, T)
                                        }))
                                    };
                                w ? e.dispatch((0, d.Ev)(N)) : e.dispatch((0, d.hX)(O(O({}, N), {}, {
                                    count: x
                                })))
                            }
                            e.dispatch((0, E.v3)())
                        }
                        return n === d.SJ && (e.dispatch((0, E.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: o
                        })), e.dispatch((0, E.v3)())), t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n, o, r = a.type,
                            i = a.payload,
                            s = e.getState();
                        if (r === d.Zx) {
                            var c = s.authentication.token;
                            e.dispatch((0, v.Z)(y, {
                                successfulResponseAction: d.cB
                            }, {
                                context: {
                                    token: c,
                                    isNewGateway: !0
                                },
                                fetchPolicy: "no-cache"
                            }))
                        }
                        if (r === d.BM && (null !== i && void 0 !== i && null !== (n = i.data) && void 0 !== n && null !== (o = n.getMySaleOrdersCounts) && void 0 !== o && o.countsByStatus)) {
                            var u = i.data.getMySaleOrdersCounts.countsByStatus,
                                l = {};
                            u.forEach((function(e) {
                                var t = e.status,
                                    a = e.count;
                                return l[t] = a
                            })), e.dispatch((0, d.Kc)(l))
                        }
                        return t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.type,
                            o = a.payload,
                            r = e.getState();
                        if (n === d.oc) {
                            var i = r.authentication.token,
                                s = r.page.lang,
                                c = o.id;
                            e.dispatch((0, p.Z)(b, {
                                successfulResponseAction: d.YY,
                                erroredResponseAction: d.hp
                            }, {
                                variables: {
                                    id: c
                                },
                                context: {
                                    token: i,
                                    lang: s,
                                    isNewGateway: !0
                                }
                            }, o))
                        }
                        if (n === d.OV) {
                            var u = null !== o && void 0 !== o ? o : {},
                                l = u.data,
                                v = (l = void 0 === l ? {} : l).cancelOrder,
                                m = u.metadata,
                                g = (m = void 0 === m ? {} : m).id,
                                f = m.orderStatus,
                                h = m.page,
                                y = m.pathKey;
                            if (String(v) === String(g)) {
                                var _ = {
                                        from: f,
                                        to: D.dO.CANCELLED.value
                                    },
                                    A = {
                                        stateKey: "userOrders",
                                        itemsKey: "orders",
                                        itemId: v,
                                        page: h,
                                        pathKey: y
                                    },
                                    S = {
                                        updateItems: d.hX,
                                        updateItemsCountByStatus: d.Rn
                                    };
                                (0, C._b)(r, _, A, e.dispatch, S), e.dispatch((0, E.pb)({
                                    icon: "CircleChecked",
                                    message: "av.seller.center.order.operations.cancel.success",
                                    status: "success"
                                }))
                            }
                        }
                        return n === d.MN && e.dispatch((0, E.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: o
                        })), t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.type,
                            o = a.payload,
                            r = e.getState();
                        if (n === d.Lo) {
                            var i = r.authentication.token,
                                s = r.page.lang,
                                c = o.id;
                            e.dispatch((0, p.Z)(_, {
                                successfulResponseAction: d.Op,
                                erroredResponseAction: d.Lw
                            }, {
                                variables: {
                                    id: c
                                },
                                context: {
                                    token: i,
                                    lang: s,
                                    isNewGateway: !0
                                }
                            }, o))
                        }
                        if (n === d.zW) {
                            var u = null !== o && void 0 !== o ? o : {},
                                l = u.data,
                                v = (l = void 0 === l ? {} : l).prepareOrder,
                                m = u.metadata,
                                g = (m = void 0 === m ? {} : m).id,
                                f = m.page;
                            if (String(v) === String(g)) {
                                var h = {
                                        from: D.dO.PENDING.value,
                                        to: D.dO.READY.value
                                    },
                                    y = {
                                        stateKey: "userOrders",
                                        itemsKey: "orders",
                                        itemId: v,
                                        page: f,
                                        pathKey: "seller.my-orders"
                                    },
                                    b = {
                                        updateItems: d.hX,
                                        updateItemsCountByStatus: d.Rn
                                    };
                                (0, C._b)(r, h, y, e.dispatch, b), e.dispatch((0, E.pb)({
                                    icon: "CircleChecked",
                                    message: "av.seller.center.order.operations.prepare.success",
                                    status: "success"
                                }))
                            }
                        }
                        return n === d.Z3 && e.dispatch((0, E.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: o
                        })), t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.type,
                            o = a.payload,
                            r = e.getState();
                        if (n === d.fo) {
                            var i = r.authentication.token,
                                s = r.page.lang,
                                c = o.id;
                            e.dispatch((0, p.Z)(A, {
                                successfulResponseAction: d.v8,
                                erroredResponseAction: d.hJ
                            }, {
                                variables: {
                                    id: c
                                },
                                context: {
                                    token: i,
                                    lang: s,
                                    isNewGateway: !0
                                }
                            }, o))
                        }
                        if (n === d.D3) {
                            var u = null !== o && void 0 !== o ? o : {},
                                l = u.data,
                                v = (l = void 0 === l ? {} : l).deleteOrder,
                                m = u.metadata,
                                g = (m = void 0 === m ? {} : m).id,
                                f = m.page;
                            if (String(v) === String(g)) {
                                var h = {
                                        from: D.dO.PENDING.value
                                    },
                                    y = {
                                        stateKey: "userOrders",
                                        itemsKey: "orders",
                                        itemId: v,
                                        page: f,
                                        pathKey: "seller.my-orders"
                                    },
                                    b = {
                                        updateItems: d.hX
                                    };
                                (0, C._b)(r, h, y, e.dispatch, b), e.dispatch((0, E.pb)({
                                    icon: "CircleChecked",
                                    message: "av.seller.center.order.operations.delete.success",
                                    status: "success"
                                }))
                            }
                        }
                        return n === d.BN && e.dispatch((0, E.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: o
                        })), t(a)
                    }
                }
            }]
        },
        53326: function(e, t, a) {
            "use strict";
            a.d(t, {
                CM: function() {
                    return f
                },
                D2: function() {
                    return n
                },
                Hn: function() {
                    return i
                },
                II: function() {
                    return v
                },
                K4: function() {
                    return g
                },
                V9: function() {
                    return s
                },
                Wk: function() {
                    return u
                },
                Xd: function() {
                    return p
                },
                Y6: function() {
                    return d
                },
                ag: function() {
                    return h
                },
                eD: function() {
                    return r
                },
                jR: function() {
                    return o
                },
                lz: function() {
                    return m
                },
                oh: function() {
                    return y
                },
                w4: function() {
                    return c
                },
                ze: function() {
                    return l
                },
                zp: function() {
                    return b
                }
            });
            var n = "shopDetails/LOAD_SHOP_DETAILS",
                o = "shopDetails/UPDATE_PAGE_NUMBER",
                r = "shopDetails/LOAD_POPULAR_SEARCH",
                i = "shopDetails/SHOW_MODAL",
                s = "shopDetails/PERSIST_SAVED_AD_STATUS",
                c = "shopDetails/UPDATE_SAVED_AD_STATUS",
                u = "shopDetails/UPDATE_ADS",
                l = "shopDetails/DISPLAY_TOAST_MESSAGE",
                d = "shopDetails/CALL_SELLER",
                v = function(e) {
                    return {
                        type: n,
                        payload: e
                    }
                },
                p = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                m = function(e) {
                    return {
                        type: r,
                        payload: e
                    }
                },
                g = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                f = function(e) {
                    return {
                        type: c,
                        payload: e
                    }
                },
                h = function(e) {
                    return {
                        type: u,
                        payload: e
                    }
                },
                y = function(e) {
                    return {
                        type: l,
                        payload: e
                    }
                },
                b = function() {
                    return {
                        type: d
                    }
                }
        },
        72673: function(e, t, a) {
            "use strict";
            a.d(t, {
                MK: function() {
                    return i
                },
                Pr: function() {
                    return s
                },
                cV: function() {
                    return c
                },
                dX: function() {
                    return u
                }
            });
            var n = a(37827),
                o = a(68697),
                r = a(80925),
                i = (0, o.P1)((function(e) {
                    var t, a;
                    return null === e || void 0 === e || null === (t = e.page) || void 0 === t || null === (a = t.app) || void 0 === a ? void 0 : a.name
                }), (function(e) {
                    var t, a;
                    return null === e || void 0 === e || null === (t = e.page) || void 0 === t || null === (a = t.app) || void 0 === a ? void 0 : a.version
                }), (function(e, t) {
                    return {
                        app_name: e,
                        app_version: t
                    }
                })),
                s = (0, o.P1)((function(e) {
                    return e.authentication.isLoggedIn
                }), (function(e) {
                    return e.userProfile.email
                }), (function(e) {
                    return e.userProfile.name
                }), (function(e) {
                    return e.userProfile.type
                }), (function(e) {
                    return e.userProfile.phone
                }), (function(e, t, a, n, o) {
                    return {
                        user_is_authenticated: e,
                        user_email: t,
                        user_name: a,
                        user_type: n,
                        user_phone: o
                    }
                })),
                c = ((0, o.P1)((function(e) {
                    return e.ad.view.adInfo.id
                }), (function(e) {
                    return e.ad.view.adInfo.listId
                }), (function(e) {
                    return e.ad.view.adInfo.type.label
                }), (function(e) {
                    return e.ad.view.adInfo.subject
                }), (function(e, t, a, n) {
                    return {
                        ad_id: e,
                        ad_list_id: t,
                        ad_type: a,
                        ad_name: n
                    }
                })), (0, o.P1)((function(e) {
                    return e.ad.view.adInfo
                }), (function(e) {
                    return e.ad.view.adInfo.seller
                }), (function(e, t) {
                    var a, o, i, s, c, u, l, d, v, p, m, g, f, h, y, b, _, A;
                    return {
                        ad_id: Number(e.id),
                        ad_list_id: Number(e.listId),
                        ad_type: null !== t && void 0 !== t && t.isEcommerce ? "ecommerce" : e.type.key,
                        ad_price: Number(null === (a = e.price) || void 0 === a ? void 0 : a.value),
                        ad_name: e.subject,
                        ad_phone_number: Number(e.phone),
                        category_name: (null === (o = e.category) || void 0 === o || null === (i = o.parent) || void 0 === i ? void 0 : i.name) || "",
                        category_id: Number((null === (s = e.category) || void 0 === s || null === (c = s.parent) || void 0 === c ? void 0 : c.id) || ""),
                        subcategory_name: (null === (u = e.category) || void 0 === u ? void 0 : u.name) || "",
                        subcategory_id: Number((null === (l = e.category) || void 0 === l ? void 0 : l.id) || ""),
                        city: (null === (d = e.location) || void 0 === d || null === (v = d.city) || void 0 === v ? void 0 : v.name) || "",
                        city_id: Number((null === (p = e.location) || void 0 === p || null === (m = p.city) || void 0 === m ? void 0 : m.id) || ""),
                        area: (null === (g = e.location) || void 0 === g || null === (f = g.area) || void 0 === f ? void 0 : f.name) || "",
                        area_id: Number((null === (h = e.location) || void 0 === h || null === (y = h.area) || void 0 === y ? void 0 : y.id) || ""),
                        seller_type: null !== t && void 0 !== t && t.isEcommerce ? r.USER_TYPES.ECOMMERCE : r.USER_TYPES[null === t || void 0 === t || null === (b = t.type) || void 0 === b ? void 0 : b.toUpperCase()],
                        seller_name: null === t || void 0 === t ? void 0 : t.name,
                        seller_id: null === t || void 0 === t ? void 0 : t.id,
                        picture_count: Number((null === (_ = e.images) || void 0 === _ ? void 0 : _.length) || 0),
                        has_phone: Boolean(e.phone),
                        is_phone_verified: Boolean(e.isPhoneVerified),
                        publish_date: (0, n.wZ)(null === (A = e.listTime) || void 0 === A ? void 0 : A.raw)
                    }
                }))),
                u = ((0, o.P1)((function(e) {
                    return e.ad.view.adInfo.seller
                }), (function(e) {
                    return {
                        account_type: null !== e && void 0 !== e && e.isEcommerce ? "ecommerce" : (null === e || void 0 === e ? void 0 : e.type) || "",
                        account_name: (null === e || void 0 === e ? void 0 : e.name) || "",
                        account_id: Number(null === e || void 0 === e ? void 0 : e.id)
                    }
                })), (0, o.P1)((function(e) {
                    return e.page.lang
                }), (function(e) {
                    return {
                        lang: e
                    }
                })))
        },
        10666: function(e, t, a) {
            "use strict";
            a.d(t, {
                AO: function() {
                    return u
                },
                Kz: function() {
                    return T
                },
                Lu: function() {
                    return d
                },
                MR: function() {
                    return v
                },
                QS: function() {
                    return m
                },
                TX: function() {
                    return E
                },
                Ye: function() {
                    return g
                },
                Yg: function() {
                    return A
                },
                _Y: function() {
                    return o
                },
                __: function() {
                    return i
                },
                aj: function() {
                    return l
                },
                cM: function() {
                    return S
                },
                dL: function() {
                    return f
                },
                if: function() {
                    return h
                },
                ig: function() {
                    return p
                },
                ix: function() {
                    return P
                },
                kW: function() {
                    return r
                },
                mC: function() {
                    return c
                },
                o9: function() {
                    return R
                },
                pb: function() {
                    return _
                },
                v3: function() {
                    return b
                },
                v7: function() {
                    return s
                },
                ve: function() {
                    return n
                },
                xM: function() {
                    return C
                },
                yh: function() {
                    return y
                },
                yr: function() {
                    return D
                }
            });
            var n = "UI/SHOW_FORM_LOADER",
                o = "UI/HIDE_FORM_LOADER",
                r = "UI/SHOW_SPINNER",
                i = "UI/HIDE_SPINNER",
                s = "UI/SHOW_TOAST_MESSAGE",
                c = "UI/HIDE_TOAST_MESSAGE",
                u = "UI/SHOW_ALERT_MESSAGE",
                l = "UI/HIDE_ALERT_MESSAGE",
                d = "UI/UPDATE_MODAL_INFO",
                v = "UI/SUCCESS",
                p = "UI/FAILED",
                m = "UI/SHOULD_SCROLL_INTO_VIEW",
                g = "UI/INIT_SHOULD_SCROLL_INTO_VIEW",
                f = function() {
                    return {
                        type: n
                    }
                },
                h = function() {
                    return {
                        type: o
                    }
                },
                y = function() {
                    return {
                        type: r
                    }
                },
                b = function() {
                    return {
                        type: i
                    }
                },
                _ = function(e) {
                    return {
                        type: s,
                        payload: e
                    }
                },
                A = function() {
                    return {
                        type: c
                    }
                },
                E = function(e) {
                    return {
                        type: u,
                        payload: e
                    }
                },
                S = function() {
                    return {
                        type: l
                    }
                },
                R = function(e) {
                    return {
                        type: d,
                        payload: e
                    }
                },
                C = function() {
                    return {
                        type: v
                    }
                },
                D = function() {
                    return {
                        type: p
                    }
                },
                T = function() {
                    return {
                        type: m
                    }
                },
                P = function() {
                    return {
                        type: g
                    }
                }
        },
        11521: function(e, t, a) {
            "use strict";
            a.d(t, {
                Bg: function() {
                    return d
                },
                Cp: function() {
                    return s
                },
                Do: function() {
                    return b
                },
                KD: function() {
                    return l
                },
                Qs: function() {
                    return f
                },
                S2: function() {
                    return o
                },
                YQ: function() {
                    return E
                },
                _9: function() {
                    return h
                },
                a9: function() {
                    return A
                },
                bS: function() {
                    return g
                },
                ec: function() {
                    return y
                },
                gU: function() {
                    return p
                },
                mz: function() {
                    return m
                },
                nZ: function() {
                    return r
                },
                ry: function() {
                    return u
                },
                v8: function() {
                    return c
                },
                wl: function() {
                    return _
                },
                x$: function() {
                    return n
                },
                y0: function() {
                    return v
                },
                zS: function() {
                    return i
                }
            });
            var n = "shopProfile/GET_SHOP_PROFILE_DATA",
                o = "API/GET_SHOP_PROFILE_SUCCESS",
                r = "API/GET_SHOP_PROFILE_FAILED",
                i = "shopProfile/UPDATE_SHOP_PROFILE",
                s = "shopProfile/EDIT_SHOP_PROFILE_DATA",
                c = "API/EDIT_SHOP_PROFILE_SUCCESS",
                u = "API/EDIT_SHOP_PROFILE_FAILED",
                l = "shopProfile/SAVE_EDITED_SHOP_PROFILE",
                d = "shopProfile/EDIT_SHOP_LOGO",
                v = "payment/UPDATE_SHOP_CREDITS",
                p = function() {
                    return {
                        type: n
                    }
                },
                m = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                g = function() {
                    return {
                        type: r
                    }
                },
                f = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                h = function(e) {
                    return {
                        type: s,
                        payload: e
                    }
                },
                y = function(e) {
                    return {
                        type: c,
                        payload: e
                    }
                },
                b = function(e) {
                    return {
                        type: u,
                        payload: e
                    }
                },
                _ = function(e) {
                    return {
                        type: l,
                        payload: e
                    }
                },
                A = function(e) {
                    return {
                        type: d,
                        payload: e
                    }
                },
                E = function(e) {
                    return {
                        type: v,
                        payload: e
                    }
                }
        },
        65062: function(e, t, a) {
            "use strict";
            a.d(t, {
                AC: function() {
                    return n
                },
                KG: function() {
                    return o
                },
                Wy: function() {
                    return i
                },
                X: function() {
                    return l
                },
                X3: function() {
                    return g
                },
                _u: function() {
                    return p
                },
                aB: function() {
                    return m
                },
                dF: function() {
                    return v
                },
                fS: function() {
                    return r
                },
                fo: function() {
                    return f
                },
                mK: function() {
                    return d
                },
                qu: function() {
                    return s
                },
                v8: function() {
                    return u
                },
                zT: function() {
                    return c
                }
            });
            var n = "shopStats/GET_SHOP_PERFORMANCE_METRICS_FIXED_RANGE",
                o = "API/GET_SHOP_PERFORMANCE_METRICS_FIXED_RANGE_SUCCESS",
                r = "API/GET_SHOP_PERFORMANCE_METRICS_FIXED_RANGE_FAILED",
                i = "shopStats/GET_SHOP_PERFORMANCE_METRICS_CUSTOM_RANGE",
                s = "API/GET_SHOP_PERFORMANCE_METRICS_CUSTOM_RANGE_SUCCESS",
                c = "API/GET_SHOP_PERFORMANCE_METRICS_CUSTOM_RANGE_FAILED",
                u = "shopStats/UPDATE_SHOP_STATS_DATA",
                l = function(e) {
                    return {
                        type: n,
                        payload: e
                    }
                },
                d = function(e, t) {
                    return {
                        type: o,
                        payload: {
                            response: e,
                            fixedRange: t
                        }
                    }
                },
                v = function(e) {
                    return {
                        type: r,
                        payload: e
                    }
                },
                p = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                m = function(e, t) {
                    return {
                        type: s,
                        payload: {
                            response: e,
                            customRange: t
                        }
                    }
                },
                g = function(e) {
                    return {
                        type: c,
                        payload: e
                    }
                },
                f = function(e) {
                    return {
                        type: u,
                        payload: e
                    }
                }
        },
        95271: function(e, t, a) {
            "use strict";
            a.d(t, {
                H4: function() {
                    return u
                },
                IQ: function() {
                    return o
                },
                I_: function() {
                    return r
                },
                Jt: function() {
                    return n
                },
                KA: function() {
                    return I
                },
                Mf: function() {
                    return m
                },
                OH: function() {
                    return f
                },
                Oi: function() {
                    return v
                },
                P0: function() {
                    return C
                },
                PH: function() {
                    return O
                },
                Pz: function() {
                    return D
                },
                Si: function() {
                    return i
                },
                Ug: function() {
                    return _
                },
                W$: function() {
                    return P
                },
                WR: function() {
                    return L
                },
                Wp: function() {
                    return c
                },
                X6: function() {
                    return b
                },
                a7: function() {
                    return w
                },
                bI: function() {
                    return y
                },
                cr: function() {
                    return T
                },
                ed: function() {
                    return s
                },
                fQ: function() {
                    return l
                },
                hC: function() {
                    return p
                },
                iF: function() {
                    return h
                },
                tp: function() {
                    return d
                },
                tv: function() {
                    return A
                },
                ut: function() {
                    return g
                },
                vu: function() {
                    return S
                },
                wJ: function() {
                    return E
                },
                y3: function() {
                    return R
                }
            });
            var n = "tagging/SEND_TAB_CLICKED_EVENT",
                o = "tagging/SEND_FILTER_CLICKED_EVENT",
                r = "tagging/SEND_PROFILE_INFOS_UPDATED_EVENT",
                i = "tagging/SEND_PASSWORD_UPDATED_EVENT",
                s = "tagging/SEND_AD_DETAILS_DISPLAYED_EVENT",
                c = "tagging/SEND_AD_CARD_ITEM_CLICKED_EVENT",
                u = "tagging/SEND_ACTIVATE_AD_CLICKED_EVENT",
                l = "tagging/SEND_DELETED_AD_CLICKED_EVENT",
                d = "tagging/SEND_INITIATED_AD_DELETION_EVENT",
                v = "tagging/SEND_SUB_TAB_CLICKED_EVENT",
                p = "tagging/SEND_FILTER_TRIGGRED_EVENT",
                m = "tagging/SEND_MULTIPLE_ADS_SELECTED_EVENT",
                g = "tagging/SEND_MANAGE_AD_CLICKED_EVENT",
                f = "tagging/SEND_DATE_RANGE_SELECTED_EVENT",
                h = "tagging/SEND_ELEMENT_CLICKED_EVENT",
                y = function(e) {
                    return {
                        type: n,
                        payload: e
                    }
                },
                b = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                _ = function(e) {
                    return {
                        type: r,
                        payload: e
                    }
                },
                A = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                E = function(e) {
                    return {
                        type: s,
                        payload: e
                    }
                },
                S = function(e) {
                    return {
                        type: c,
                        payload: e
                    }
                },
                R = function(e) {
                    return {
                        type: u,
                        payload: e
                    }
                },
                C = function() {
                    return {
                        type: l
                    }
                },
                D = function(e) {
                    return {
                        type: d,
                        payload: e
                    }
                },
                T = function(e) {
                    return {
                        type: v,
                        payload: e
                    }
                },
                P = function() {
                    return {
                        type: p
                    }
                },
                O = function() {
                    return {
                        type: m
                    }
                },
                I = function() {
                    return {
                        type: g
                    }
                },
                w = function(e) {
                    return {
                        type: f,
                        payload: e
                    }
                },
                L = function(e) {
                    return {
                        type: h,
                        payload: e
                    }
                }
        },
        92693: function(e, t, a) {
            "use strict";
            a.d(t, {
                $7: function() {
                    return ee
                },
                $H: function() {
                    return R
                },
                BT: function() {
                    return s
                },
                CB: function() {
                    return Y
                },
                Dn: function() {
                    return w
                },
                E6: function() {
                    return z
                },
                EW: function() {
                    return B
                },
                G4: function() {
                    return p
                },
                G7: function() {
                    return f
                },
                Go: function() {
                    return l
                },
                JA: function() {
                    return _
                },
                JZ: function() {
                    return G
                },
                Jy: function() {
                    return n
                },
                Ng: function() {
                    return T
                },
                Nk: function() {
                    return H
                },
                OR: function() {
                    return ae
                },
                Pv: function() {
                    return W
                },
                QS: function() {
                    return M
                },
                RD: function() {
                    return Q
                },
                RF: function() {
                    return k
                },
                RM: function() {
                    return O
                },
                SI: function() {
                    return L
                },
                T6: function() {
                    return C
                },
                UJ: function() {
                    return V
                },
                XQ: function() {
                    return g
                },
                Zb: function() {
                    return y
                },
                Zm: function() {
                    return Z
                },
                _0: function() {
                    return S
                },
                aV: function() {
                    return I
                },
                bK: function() {
                    return te
                },
                c8: function() {
                    return K
                },
                dd: function() {
                    return J
                },
                f$: function() {
                    return q
                },
                gP: function() {
                    return v
                },
                h_: function() {
                    return u
                },
                jC: function() {
                    return r
                },
                k3: function() {
                    return m
                },
                l0: function() {
                    return j
                },
                lU: function() {
                    return U
                },
                mY: function() {
                    return $
                },
                m_: function() {
                    return c
                },
                ms: function() {
                    return x
                },
                p1: function() {
                    return h
                },
                po: function() {
                    return F
                },
                qK: function() {
                    return X
                },
                rQ: function() {
                    return ne
                },
                rj: function() {
                    return b
                },
                tI: function() {
                    return oe
                },
                tn: function() {
                    return N
                },
                u9: function() {
                    return d
                },
                uA: function() {
                    return D
                },
                ut: function() {
                    return P
                },
                v2: function() {
                    return A
                },
                v5: function() {
                    return E
                },
                y2: function() {
                    return o
                },
                z4: function() {
                    return i
                }
            });
            var n = "userAds/TOGGLE_ADS_STATS",
                o = "userAds/UPDATE_DISPLAY_MODE",
                r = "userAds/UPDATE_LISTING_SORT",
                i = "userAds/UPDATE_LISTING_STATUS",
                s = "userAds/GET_USER_ADS_DATA",
                c = "API/GET_USER_ADS_DATA_SUCCESS",
                u = "API/GET_USER_ADS_DATA_FAILED",
                l = "userAds/UPDATE_USER_ADS",
                d = "userAds/GET_USER_AD_DETAILS",
                v = "userAds/GET_USER_AD_DETAILS_SUCCESS",
                p = "userAds/GET_USER_AD_DETAILS_FAILED",
                m = "userAdDetails/UPDATE_USER_AD_DETAILS",
                g = "userAds/ADD_TO_CHECKED_ADS_IDS",
                f = "userAds/REMOVE_FROM_CHECKED_ADS_IDS",
                h = "userAds/ADD_ALL_TO_CHECKED_ADS_IDS",
                y = "userAds/REMOVE_ALL_FROM_CHECKED_ADS_IDS",
                b = "userAds/SET_IS_OPERATION_MODEL_OPEN",
                _ = "userAds/SET_OPERATION_MODAL_PARAMS",
                A = "userAds/DELETE_DEACTIVATED_AD",
                E = "userAds/CONFIRM_DELETE_DEACTIVATED_AD",
                S = "userAds/CONFIRM_DELETE_DEACTIVATED_AD_SUCCESS",
                R = "userAds/CONFIRM_DELETE_DEACTIVATED_AD_FAILED",
                C = "userAds/ACTIVATE_AD",
                D = "userAds/ACTIVATE_AD_SUCCESS",
                T = "userAds/GET_MY_ADS_COUNTS",
                P = "API/GET_MY_ADS_COUNTS_SUCCESS",
                O = "userAds/UPDATE_MY_ADS_COUNTS",
                I = "userAds/UPDATE_ADS_COUNT_BY_STATUS",
                w = function(e) {
                    return {
                        type: n,
                        payload: e
                    }
                },
                L = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                M = function(e) {
                    return {
                        type: r,
                        payload: e
                    }
                },
                x = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                N = function(e) {
                    return {
                        type: s,
                        payload: e
                    }
                },
                q = function(e, t) {
                    return {
                        type: c,
                        payload: {
                            response: e,
                            metadata: t
                        }
                    }
                },
                k = function(e) {
                    return {
                        type: u,
                        payload: e
                    }
                },
                j = function(e) {
                    return {
                        type: l,
                        payload: e
                    }
                },
                U = function(e) {
                    return {
                        type: d,
                        payload: e
                    }
                },
                V = function(e) {
                    return {
                        type: v,
                        payload: e
                    }
                },
                z = function(e) {
                    return {
                        type: p,
                        payload: e
                    }
                },
                B = function(e) {
                    return {
                        type: m,
                        payload: e
                    }
                },
                F = function(e) {
                    return {
                        type: g,
                        payload: e
                    }
                },
                G = function(e) {
                    return {
                        type: f,
                        payload: e
                    }
                },
                Z = function(e) {
                    return {
                        type: h,
                        payload: e
                    }
                },
                H = function() {
                    return {
                        type: y
                    }
                },
                $ = function(e) {
                    return {
                        type: b,
                        payload: e
                    }
                },
                K = function(e) {
                    return {
                        type: _,
                        payload: e
                    }
                },
                Y = function(e) {
                    return {
                        type: A,
                        payload: e
                    }
                },
                W = function() {
                    return {
                        type: E
                    }
                },
                X = function(e) {
                    return {
                        type: S,
                        payload: e
                    }
                },
                J = function() {
                    return {
                        type: R
                    }
                },
                Q = function(e) {
                    return {
                        type: C,
                        payload: e
                    }
                },
                ee = function(e) {
                    return {
                        type: D,
                        payload: e
                    }
                },
                te = function() {
                    return {
                        type: T
                    }
                },
                ae = function(e) {
                    return {
                        type: P,
                        payload: e
                    }
                },
                ne = function(e) {
                    return {
                        type: O,
                        payload: e
                    }
                },
                oe = function(e) {
                    return {
                        type: I,
                        payload: e
                    }
                }
        },
        45831: function(e, t, a) {
            "use strict";
            a.d(t, {
                C2: function() {
                    return l
                },
                FK: function() {
                    return c
                },
                Ft: function() {
                    return s
                },
                Nb: function() {
                    return i
                },
                Pz: function() {
                    return r
                },
                X7: function() {
                    return d
                },
                _s: function() {
                    return n
                },
                ew: function() {
                    return u
                },
                gk: function() {
                    return v
                },
                hk: function() {
                    return o
                }
            });
            var n = "userFavorites/GET_USER_SAVED_ADS",
                o = "userFavorites/GET_MY_SAVED_ADS_SUCESS",
                r = "userFavorites/UPDATE_USER_SAVED_ADS",
                i = "userFavorites/DELETE_USER_SAVED_AD",
                s = "userFavorites/SET_USER_FAVORITE",
                c = function(e) {
                    return {
                        type: n,
                        payload: e
                    }
                },
                u = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                l = function(e) {
                    return {
                        type: r,
                        payload: e
                    }
                },
                d = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                v = function(e) {
                    return {
                        type: s,
                        payload: e
                    }
                }
        },
        372: function(e, t, a) {
            "use strict";
            a.d(t, {
                B5: function() {
                    return E
                },
                BF: function() {
                    return r
                },
                CN: function() {
                    return y
                },
                D: function() {
                    return l
                },
                E$: function() {
                    return P
                },
                FJ: function() {
                    return T
                },
                Fc: function() {
                    return c
                },
                Fu: function() {
                    return S
                },
                HK: function() {
                    return C
                },
                O_: function() {
                    return s
                },
                PW: function() {
                    return p
                },
                Q5: function() {
                    return R
                },
                St: function() {
                    return A
                },
                Wm: function() {
                    return h
                },
                YH: function() {
                    return D
                },
                aU: function() {
                    return f
                },
                b7: function() {
                    return v
                },
                d6: function() {
                    return i
                },
                fz: function() {
                    return g
                },
                lI: function() {
                    return m
                },
                lM: function() {
                    return b
                },
                pJ: function() {
                    return u
                },
                rQ: function() {
                    return n
                },
                t3: function() {
                    return _
                },
                vR: function() {
                    return d
                },
                vv: function() {
                    return o
                }
            });
            var n = "userNotifParams/GET_USER_NOTIF_PARAMS",
                o = "API/GET_USER_NOTIF_PARAMS_SUCCESS",
                r = "API/GET_USER_NOTIF_PARAMS_FAILED",
                i = "userNotifParams/UPDATE_USER_NOTIF_PARAMS",
                s = "userNotifParams/EDIT_USER_NOTIF_PARAMS",
                c = "API/EDIT_USER_NOTIF_PARAMS_SUCCESS",
                u = "API/EDIT_USER_NOTIF_PARAMS_FAILED",
                l = "userNotifParams/GET_USER_NOTIF_CHANNEL",
                d = "API/GET_USER_NOTIF_CHANNEL_SUCCESS",
                v = "userNotifParams/UPDATE_USER_NOTIF_CHANNEL",
                p = "userNotifParams/SEND_USER_EMAIL_VERIFICATION",
                m = "API/SEND_USER_EMAIL_VERIFICATION_SUCCESS",
                g = "API/SEND_USER_EMAIL_VERIFICATION_FAILED",
                f = function() {
                    return {
                        type: n
                    }
                },
                h = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                y = function(e) {
                    return {
                        type: r,
                        payload: e
                    }
                },
                b = function(e) {
                    return {
                        type: i,
                        payload: e
                    }
                },
                _ = function(e) {
                    return {
                        type: s,
                        payload: e
                    }
                },
                A = function(e) {
                    return {
                        type: c,
                        payload: e
                    }
                },
                E = function(e) {
                    return {
                        type: u,
                        payload: e
                    }
                },
                S = function() {
                    return {
                        type: l
                    }
                },
                R = function(e) {
                    return {
                        type: d,
                        payload: e
                    }
                },
                C = function(e) {
                    return {
                        type: v,
                        payload: e
                    }
                },
                D = function() {
                    return {
                        type: p
                    }
                },
                T = function(e) {
                    return {
                        type: m,
                        payload: e
                    }
                },
                P = function() {
                    return {
                        type: g
                    }
                }
        },
        58139: function(e, t, a) {
            "use strict";
            a.d(t, {
                AS: function() {
                    return r
                },
                E: function() {
                    return s
                },
                Rf: function() {
                    return o
                },
                Zy: function() {
                    return i
                },
                pX: function() {
                    return n
                },
                zt: function() {
                    return c
                }
            });
            var n = "userPassword/UPDATE_USER_PASSWORD",
                o = "API/UPDATE_USER_PASSWORD_SUCCESS",
                r = "API/UPDATE_USER_PASSWORD_FAILED",
                i = function(e) {
                    return {
                        type: n,
                        payload: e
                    }
                },
                s = function(e) {
                    return {
                        type: o,
                        payload: e
                    }
                },
                c = function(e) {
                    return {
                        type: r,
                        payload: e
                    }
                }
        },
        35259: function(e, t, a) {
            "use strict";
            a.d(t, {
                q7: function() {
                    return g
                },
                RT: function() {
                    return h
                },
                YY: function() {
                    return f
                },
                O: function() {
                    return _
                },
                Xq: function() {
                    return d
                },
                b1: function() {
                    return p
                },
                gA: function() {
                    return v
                },
                aw: function() {
                    return y
                },
                fR: function() {
                    return b
                },
                R8: function() {
                    return m
                },
                x6: function() {
                    return C
                },
                kh: function() {
                    return T
                },
                gM: function() {
                    return D
                },
                Lt: function() {
                    return A
                },
                WX: function() {
                    return S
                },
                kJ: function() {
                    return E
                },
                P1: function() {
                    return P
                },
                Ic: function() {
                    return I
                },
                cv: function() {
                    return O
                },
                oU: function() {
                    return w
                },
                Lj: function() {
                    return R
                }
            });
            var n = a(50029),
                o = a(87794),
                r = a.n(o),
                i = a(71716),
                s = a(76871),
                c = a(93572),
                u = a(35538),
                l = a(80925),
                d = (function() {
                    var e = (0, n.Z)(r().mark((function e(t) {
                        var a, n, o, d, v, p;
                        return r().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return a = t.userId, n = t.token, o = t.expiresIn, d = t.type, e.prev = 1, e.next = 4, (0, i.PR)(s.endPointBasedUrl, {
                                        userId: a,
                                        token: n,
                                        expiresIn: o
                                    }, d);
                                case 4:
                                    return v = e.sent, e.next = 7, v.json();
                                case 7:
                                    return v = e.sent, p = (0, c.L)({
                                        response: v
                                    }), (0, u.d8)(l.TOKEN_COOKIE_NAME, n), e.abrupt("return", p);
                                case 13:
                                    return e.prev = 13, e.t0 = e.catch(1), e.abrupt("return", {
                                        error: "Failed to retrieve current user"
                                    });
                                case 16:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [1, 13]
                        ])
                    })))
                }(), function() {
                    var e = (0, n.Z)(r().mark((function e(t) {
                        var a, n, o, u, d, v;
                        return r().wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.prev = 0, e.next = 3, (0, i.oP)(s.endPointBasedUrl, encodeURIComponent(t));
                                case 3:
                                    return a = e.sent, e.next = 6, a.json();
                                case 6:
                                    return a = e.sent, n = (0, c.L)({
                                        response: a
                                    }), o = Boolean(n.accountId || n.storeId), u = n.accountStatus === l.USER_ACCOUNT_STATUS.ACCOUNT_STORE_EXISTS ? l.USER_TYPES.SHOP : l.USER_TYPES.PRIVATE, e.abrupt("return", {
                                        isExistingUser: o,
                                        accountType: u,
                                        id: n.accountId || n.storeId
                                    });
                                case 13:
                                    return e.prev = 13, e.t0 = e.catch(0), d = e.t0.code, v = e.t0.message, e.abrupt("return", {
                                        error: {
                                            code: d,
                                            message: v
                                        }
                                    });
                                case 18:
                                case "end":
                                    return e.stop()
                            }
                        }), e, null, [
                            [0, 13]
                        ])
                    })))
                }(), "userProfile/GET_USER_PROFILE_DATA"),
                v = "API/GET_USER_PROFILE_SUCCESS",
                p = "API/GET_USER_PROFILE_FAILED",
                m = "userProfile/UPDATE_USER_PROFILE",
                g = "userProfile/EDIT_USER_PROFILE_DATA",
                f = "API/EDIT_USER_PROFILE_SUCCESS",
                h = "API/EDIT_USER_PROFILE_FAILED",
                y = "userProfile/INIT_USER_PROFILE",
                b = "userProfile/SYNC_USER_PROFILE",
                _ = "API/EMAIL_VALIDATION_SUCCEEDED",
                A = function() {
                    return {
                        type: d
                    }
                },
                E = function(e) {
                    return {
                        type: v,
                        payload: e
                    }
                },
                S = function() {
                    return {
                        type: p
                    }
                },
                R = function(e) {
                    return {
                        type: m,
                        payload: e
                    }
                },
                C = function(e) {
                    return {
                        type: g,
                        payload: e
                    }
                },
                D = function(e) {
                    return {
                        type: f,
                        payload: e
                    }
                },
                T = function(e) {
                    return {
                        type: h,
                        payload: e
                    }
                },
                P = function(e) {
                    return {
                        type: y,
                        payload: e
                    }
                },
                O = function() {
                    return {
                        type: b
                    }
                },
                I = {
                    SYNC_USER_DATA: "userAuthentificationActions/SYNC_USER_DATA",
                    syncUserData: function(e) {
                        return {
                            type: I.SYNC_USER_DATA,
                            payload: e
                        }
                    }
                },
                w = {
                    UPDATE_USER_INFOS: "userAuthentificationActions/UPDATE_USER_INFOS",
                    updateUserInfos: function(e) {
                        return {
                            type: w.UPDATE_USER_INFOS,
                            payload: e
                        }
                    }
                }
        },
        17653: function(e, t, a) {
            "use strict";
            a.d(t, {
                $U: function() {
                    return h
                },
                Il: function() {
                    return y
                },
                mB: function() {
                    return f
                }
            });
            var n = a(93088),
                o = a(71716),
                r = a(11521),
                i = a(10666),
                s = a(80308),
                c = a(36697),
                u = a(20495),
                l = a(51432),
                d = a(80925),
                v = a(76871),
                p = a(95271),
                m = a(74324),
                g = a(31823),
                f = function(e) {
                    return function(t) {
                        return function(a) {
                            var n = a.type,
                                o = a.payload,
                                c = e.getState();
                            if (n === r.x$) {
                                e.dispatch((0, i.dL)());
                                var l = (null === c || void 0 === c ? void 0 : c.userProfile).userId,
                                    d = (null === c || void 0 === c ? void 0 : c.authentication).token;
                                e.dispatch((0, s.Z)(u.C, {
                                    successfulResponseAction: r.mz,
                                    erroredResponseAction: r.bS
                                }, {
                                    variables: {
                                        storeId: String(l)
                                    },
                                    context: {
                                        token: d,
                                        isNewGateway: !0
                                    },
                                    fetchPolicy: "no-cache"
                                }))
                            }
                            if (n === r.S2) {
                                var v, p = (0, m.Cw)(null === o || void 0 === o || null === (v = o.data) || void 0 === v ? void 0 : v.getMyStoreInfo, g.d9);
                                if (p) {
                                    var f = (null === c || void 0 === c ? void 0 : c.userProfile).userId;
                                    p.storeId = f, e.dispatch((0, r.Qs)(p)), e.dispatch((0, i.if)())
                                }
                            }
                            return n === r.nZ && e.dispatch((0, i.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error"
                            })), t(a)
                        }
                    }
                },
                h = function(e) {
                    return function(t) {
                        return function(a) {
                            var o, s = a.type,
                                u = a.payload,
                                d = e.getState();
                            if (s === r.Cp) {
                                var v, m, g;
                                e.dispatch((0, i.yh)());
                                var f = (null === d || void 0 === d ? void 0 : d.userProfile).userId,
                                    h = (null === d || void 0 === d ? void 0 : d.authentication).token,
                                    y = (null === d || void 0 === d ? void 0 : d.page).lang,
                                    b = u.address,
                                    _ = u.shopCategory,
                                    A = u.shopDescription,
                                    E = u.shopName,
                                    S = u.phones,
                                    R = u.shortDescription,
                                    C = u.shopUrl;
                                e.dispatch((0, c.Z)(l.s2, {
                                    successfulResponseAction: r.ec,
                                    erroredResponseAction: r.Do
                                }, {
                                    variables: {
                                        userId: String(f),
                                        address: b,
                                        shopCategory: Number("object" === typeof _ ? _.id : _),
                                        shopDescription: A,
                                        shopName: E,
                                        phone1: null === S || void 0 === S || null === (v = S[0]) || void 0 === v ? void 0 : v.number,
                                        phone2: (null === S || void 0 === S || null === (m = S[1]) || void 0 === m ? void 0 : m.number) || "",
                                        phone3: (null === S || void 0 === S || null === (g = S[2]) || void 0 === g ? void 0 : g.number) || "",
                                        shortDescription: R,
                                        shopUrl: C
                                    },
                                    context: {
                                        token: h,
                                        lang: y,
                                        isNewGateway: !1
                                    }
                                }, u))
                            }
                            if (s === r.v8 && (null === u || void 0 === u || null === (o = u.data) || void 0 === o ? void 0 : o.editShopProfile) === n.TD.CREATED.CODE) {
                                var D = null === u || void 0 === u ? void 0 : u.metadata,
                                    T = D.shopName,
                                    P = D.shopDescription,
                                    O = D.shortDescription,
                                    I = D.shopCategory,
                                    w = D.shopLogo,
                                    L = D.locations,
                                    M = D.address,
                                    x = D.phones,
                                    N = D.shopUrl;
                                e.dispatch((0, r.wl)({
                                    name: T,
                                    desc: P,
                                    shortDesc: O,
                                    category: I,
                                    imageLogo: w,
                                    locations: L,
                                    address: M,
                                    phones: x,
                                    storeUrl: N
                                })), e.dispatch((0, p.Ug)("Success")), e.dispatch((0, i.v3)()), e.dispatch((0, i.pb)({
                                    icon: "CircleChecked",
                                    message: "av.account.setting.alert.account-updated",
                                    status: "success"
                                }))
                            }
                            return s === r.ry && (e.dispatch((0, p.Ug)("Error")), e.dispatch((0, i.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error",
                                customMessage: u
                            })), e.dispatch((0, i.v3)())), t(a)
                        }
                    }
                },
                y = function(e) {
                    return function(t) {
                        return function(a) {
                            var c = a.type,
                                u = a.payload,
                                p = e.getState();
                            if (c === r.Bg) {
                                var m = (null === p || void 0 === p ? void 0 : p.userProfile).userId,
                                    g = (null === p || void 0 === p ? void 0 : p.authentication).token;
                                (0, o.G3)(v.endPointBasedUrl, {
                                    userId: m,
                                    token: g
                                }, u, d.USER_TYPES.SHOP).then((function(t) {
                                    t.status === n.TD.CREATED.CODE ? (e.dispatch((0, i.pb)({
                                        icon: "CircleChecked",
                                        message: "av.account.setting.alert.account-updated",
                                        status: "success"
                                    })), e.dispatch((0, s.Z)(l.lP, {
                                        successfulResponseAction: r.mz,
                                        erroredResponseAction: r.bS
                                    }, {
                                        variables: {
                                            storeId: String(m)
                                        },
                                        context: {
                                            token: g,
                                            isNewGateway: !1
                                        },
                                        fetchPolicy: "no-cache"
                                    }))) : e.dispatch((0, i.pb)({
                                        icon: "InformationLine",
                                        message: "av.account.toaster.activate.error",
                                        status: "error"
                                    }))
                                }))
                            }
                            return t(a)
                        }
                    }
                };
            t.ZP = [f, h, y]
        },
        26997: function(e, t, a) {
            "use strict";
            a.d(t, {
                ZP: function() {
                    return m
                }
            });
            var n, o, r = a(65062),
                i = a(10666),
                s = a(80308),
                c = a(71383),
                u = a(68806),
                l = (0, u.Ps)(n || (n = (0, c.Z)(["\n  query getMyPerformanceMetricsFixedRange(\n    $range: MyPerformanceMetricsFixedRangeFilter!\n  ) {\n    getMyPerformanceMetricsFixedRange(range: $range) {\n      name\n      data {\n        x\n        y\n      }\n      total\n    }\n  }\n"]))),
                d = (0, u.Ps)(o || (o = (0, c.Z)(["\n  query getMyPerformanceMetricsCustomRange($from: String!, $to: String!) {\n    getMyPerformanceMetricsCustomRange(from: $from, to: $to) {\n      name\n      data {\n        x\n        y\n      }\n      total\n    }\n  }\n"]))),
                v = a(60559),
                p = a(94533),
                m = [function(e) {
                    return function(t) {
                        return function(a) {
                            var n, o, c = a.type,
                                u = a.payload,
                                d = e.getState();
                            if (c === r.AC) {
                                var m = (null === d || void 0 === d ? void 0 : d.authentication).token;
                                e.dispatch((0, s.Z)(l, {
                                    successfulResponseAction: r.mK,
                                    erroredResponseAction: r.dF
                                }, {
                                    variables: {
                                        range: u
                                    },
                                    context: {
                                        token: m,
                                        isNewGateway: !0
                                    },
                                    fetchPolicy: "no-cache"
                                }, u))
                            }
                            if (c === r.KG && (null !== u && void 0 !== u && null !== (n = u.response) && void 0 !== n && null !== (o = n.data) && void 0 !== o && o.getMyPerformanceMetricsFixedRange)) {
                                var g = u.response.data.getMyPerformanceMetricsFixedRange,
                                    f = "ALLTIME" === u.fixedRange ? (0, p.Z)(new Date, new Date(2021, 12, 1)) : 0;
                                e.dispatch((0, r.fo)({
                                    statsData: (0, v.KV)(g),
                                    dateFormat: f > 185 ? "MMM yy" : "dd MMM"
                                }))
                            }
                            return c === r.fS && e.dispatch((0, i.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error",
                                customMessage: u
                            })), t(a)
                        }
                    }
                }, function(e) {
                    return function(t) {
                        return function(a) {
                            var n, o, c = a.type,
                                u = a.payload,
                                l = e.getState();
                            if (c === r.Wy) {
                                var p = (null === l || void 0 === l ? void 0 : l.authentication).token,
                                    m = u.from,
                                    g = u.to,
                                    f = u.customRange;
                                e.dispatch((0, s.Z)(d, {
                                    successfulResponseAction: r.aB,
                                    erroredResponseAction: r.X3
                                }, {
                                    variables: {
                                        from: m,
                                        to: g
                                    },
                                    context: {
                                        token: p,
                                        isNewGateway: !0
                                    },
                                    fetchPolicy: "no-cache"
                                }, f))
                            }
                            if (c === r.qu && (null !== u && void 0 !== u && null !== (n = u.response) && void 0 !== n && null !== (o = n.data) && void 0 !== o && o.getMyPerformanceMetricsCustomRange)) {
                                var h = u.response.data.getMyPerformanceMetricsCustomRange,
                                    y = u.customRange;
                                e.dispatch((0, r.fo)({
                                    statsData: (0, v.KV)(h),
                                    dateFormat: y > 185 ? "MMM yy" : "dd MMM"
                                }))
                            }
                            return c === r.zT && e.dispatch((0, i.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error",
                                customMessage: u
                            })), t(a)
                        }
                    }
                }]
        },
        7303: function(e, t, a) {
            "use strict";
            var n = a(59499),
                o = a(94533),
                r = a(93088),
                i = a(92693),
                s = a(80308),
                c = a(36697),
                u = a(15153),
                l = a(51432),
                d = a(10666),
                v = a(31823),
                p = a(80925),
                m = a(23822),
                g = a(62107);

            function f(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function h(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? f(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : f(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            t.ZP = [function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.type,
                            o = a.payload,
                            r = e.getState();
                        if (n === i.BT) {
                            e.dispatch((0, d.yh)());
                            var c = (null === r || void 0 === r ? void 0 : r.authentication).token,
                                l = (null === r || void 0 === r ? void 0 : r.page).lang,
                                p = o.listingStatus,
                                m = o.page,
                                g = o.size,
                                f = o.boosted,
                                h = void 0 === f ? void 0 : f,
                                y = o.sort;
                            e.dispatch((0, s.Z)(u.jL, {
                                successfulResponseAction: i.f$,
                                erroredResponseAction: i.RF
                            }, {
                                variables: {
                                    filters: {
                                        status: null === p || void 0 === p ? void 0 : p.toUpperCase(),
                                        boosted: h
                                    },
                                    pagination: {
                                        number: m,
                                        size: g
                                    }
                                },
                                context: {
                                    token: c,
                                    lang: l,
                                    isNewGateway: !0
                                },
                                fetchPolicy: "no-cache",
                                errorPolicy: "all"
                            }, {
                                listingStatus: p,
                                page: m,
                                size: g,
                                sort: y
                            }))
                        }
                        if (n === i.m_) {
                            var b, _;
                            if (null !== o && void 0 !== o && null !== (b = o.response) && void 0 !== b && null !== (_ = b.data) && void 0 !== _ && _.getMyAds) {
                                var A = o.response.data.getMyAds,
                                    E = A.ads,
                                    S = A.count.total,
                                    R = o.metadata,
                                    C = R.listingStatus,
                                    D = R.page,
                                    T = R.size,
                                    P = R.sort,
                                    O = {
                                        key: C === v.AE.ACTIVE && P !== v.EY.ALL_ADS ? P : C,
                                        ads: E,
                                        metadata: {
                                            page: D,
                                            count: S,
                                            size: T
                                        }
                                    };
                                e.dispatch((0, i.l0)(O))
                            }
                            e.dispatch((0, d.v3)())
                        }
                        return n === i.h_ && (e.dispatch((0, d.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: o
                        })), e.dispatch((0, d.v3)())), t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.type,
                            o = a.payload,
                            r = e.getState();
                        if (n === i.u9) {
                            e.dispatch((0, d.dL)());
                            var c = (null === r || void 0 === r ? void 0 : r.authentication).token,
                                l = (null === r || void 0 === r ? void 0 : r.page).lang;
                            e.dispatch((0, s.Z)(u.Ov, {
                                successfulResponseAction: i.UJ,
                                erroredResponseAction: i.E6
                            }, {
                                variables: {
                                    adId: String(o)
                                },
                                context: {
                                    token: c,
                                    lang: l,
                                    isNewGateway: !0
                                }
                            }))
                        }
                        if (n === i.gP) {
                            var v, p;
                            if (null !== o && void 0 !== o && null !== (v = o.data) && void 0 !== v && v.getMyAd) e.dispatch((0, i.EW)(null === o || void 0 === o || null === (p = o.data) || void 0 === p ? void 0 : p.getMyAd));
                            e.dispatch((0, d.if)())
                        }
                        return n === i.G4 && (e.dispatch((0, d.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: o
                        })), e.dispatch((0, d.if)())), t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n = a.type,
                            r = a.payload;
                        n === i.v2 && ((0, o.Z)(new Date, new Date(null === r || void 0 === r ? void 0 : r.stateTs)) >= p.deactivationDaysToRemoveAd ? e.dispatch((0, i.c8)({
                            type: "CONFIRMATION_AD_DELETE",
                            listId: null === r || void 0 === r ? void 0 : r.listId
                        })) : e.dispatch((0, i.c8)({
                            type: "REFUSE_DELETE_AD",
                            dayBeforeDelete: p.deactivationDaysToRemoveAd - (0, o.Z)(new Date, new Date(null === r || void 0 === r ? void 0 : r.stateTs))
                        })), e.dispatch((0, i.mY)(!0)));
                        return t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n, o = a.type,
                            s = a.payload,
                            u = e.getState();
                        if (o === i.v5) {
                            var p, f = (null === u || void 0 === u ? void 0 : u.userProfile).userId,
                                h = (null === u || void 0 === u ? void 0 : u.authentication).token,
                                y = (null === u || void 0 === u || null === (p = u.userAds) || void 0 === p ? void 0 : p.operationModalParams).listId;
                            e.dispatch((0, c.Z)(l.Nw, {
                                successfulResponseAction: i.qK,
                                erroredResponseAction: i.dd
                            }, {
                                variables: {
                                    accountId: Number(f),
                                    listId: Number(y),
                                    token: h
                                },
                                context: {
                                    isNewGateway: !1
                                }
                            }, y))
                        }
                        if (o === i._0 && (null === s || void 0 === s || null === (n = s.data) || void 0 === n ? void 0 : n.deleteAd) === r.TD.NO_CONTENT.CODE) {
                            var b, _, A, E, S, R, C, D;
                            e.dispatch((0, i.mY)(!1)), e.dispatch((0, d.pb)({
                                icon: "CircleChecked",
                                message: "av.account.toaster.activate.success",
                                status: "success"
                            }));
                            var T = null === s || void 0 === s ? void 0 : s.metadata,
                                P = null === u || void 0 === u || null === (b = u.userAds) || void 0 === b || null === (_ = b.ads) || void 0 === _ || null === (A = _.deactivated) || void 0 === A ? void 0 : A.filter((function(e) {
                                    return e.listId !== T
                                })),
                                O = null === u || void 0 === u || null === (E = u.userAds) || void 0 === E || null === (S = E.pagination) || void 0 === S ? void 0 : S.deactivated;
                            if (0 === (null === P || void 0 === P ? void 0 : P.length) && (null === O || void 0 === O ? void 0 : O.initialPage) > 1) {
                                var I;
                                m.Router.pushRoute("".concat((0, g.DW)({
                                    key: "account.my-ads",
                                    lang: null === u || void 0 === u || null === (I = u.page) || void 0 === I ? void 0 : I.lang
                                }), "?status=").concat(v.AE.DEACTIVATED, "&page=").concat((null === O || void 0 === O ? void 0 : O.initialPage) - 1), {
                                    shallow: !0
                                })
                            } else {
                                var w = {
                                    key: v.AE.DEACTIVATED,
                                    ads: P,
                                    listingStatus: v.AE.DEACTIVATED,
                                    metadata: {
                                        page: null === O || void 0 === O ? void 0 : O.initialPage,
                                        count: (null === O || void 0 === O ? void 0 : O.adsCount) - 1,
                                        size: v.X_
                                    }
                                };
                                e.dispatch((0, i.l0)(w))
                            }
                            e.dispatch((0, i.tI)({
                                status: v.AE.DELETED,
                                count: (null === u || void 0 === u || null === (R = u.userAds) || void 0 === R || null === (C = R.pagination) || void 0 === C || null === (D = C.deleted) || void 0 === D ? void 0 : D.adsCount) + 1
                            }))
                        }
                        return o === i.$H && (e.dispatch((0, i.mY)(!1)), e.dispatch((0, d.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error"
                        }))), t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var n, o, s = a.type,
                            u = a.payload,
                            p = e.getState();
                        if (s === i.T6) {
                            var f = (null === p || void 0 === p ? void 0 : p.userProfile).userId,
                                h = (null === p || void 0 === p ? void 0 : p.authentication).token;
                            e.dispatch((0, c.Z)(l.T6, {
                                successfulResponseAction: i.$7
                            }, {
                                variables: {
                                    accountId: Number(f),
                                    adId: Number(u),
                                    token: h
                                },
                                context: {
                                    isNewGateway: !1
                                }
                            }, u))
                        }
                        if (s === i.uA)
                            if ((null === u || void 0 === u || null === (n = u.data) || void 0 === n ? void 0 : n.activateAd) === r.TD.OK.CODE) {
                                var y, b, _, A, E, S, R, C;
                                e.dispatch((0, i.c8)({
                                    type: "AD_ACTIVATED"
                                })), e.dispatch((0, i.mY)(!0));
                                var D = null === u || void 0 === u ? void 0 : u.metadata,
                                    T = null === p || void 0 === p || null === (y = p.userAds) || void 0 === y || null === (b = y.ads) || void 0 === b || null === (_ = b.deactivated) || void 0 === _ ? void 0 : _.filter((function(e) {
                                        return e.adId !== D
                                    })),
                                    P = null === p || void 0 === p || null === (A = p.userAds) || void 0 === A || null === (E = A.pagination) || void 0 === E ? void 0 : E.deactivated;
                                if (0 === (null === T || void 0 === T ? void 0 : T.length) && (null === P || void 0 === P ? void 0 : P.initialPage) > 1) {
                                    var O;
                                    m.Router.pushRoute("".concat((0, g.DW)({
                                        key: "account.my-ads",
                                        lang: null === p || void 0 === p || null === (O = p.page) || void 0 === O ? void 0 : O.lang
                                    }), "?status=").concat(v.AE.DEACTIVATED, "&page=").concat((null === P || void 0 === P ? void 0 : P.initialPage) - 1), {
                                        shallow: !0
                                    })
                                } else {
                                    var I = {
                                        ads: T,
                                        listingStatus: v.AE.DEACTIVATED,
                                        metadata: {
                                            page: null === P || void 0 === P ? void 0 : P.initialPage,
                                            count: (null === P || void 0 === P ? void 0 : P.adsCount) - 1,
                                            size: v.X_
                                        }
                                    };
                                    e.dispatch((0, i.l0)(I))
                                }
                                e.dispatch((0, i.tI)({
                                    status: v.AE.ACTIVE,
                                    count: (null === p || void 0 === p || null === (S = p.userAds) || void 0 === S || null === (R = S.pagination) || void 0 === R || null === (C = R.active) || void 0 === C ? void 0 : C.adsCount) + 1
                                }))
                            } else(null === u || void 0 === u || null === (o = u.data) || void 0 === o ? void 0 : o.activateAd) === r.dv.PAYMENT_REQUIRED.CODE ? (e.dispatch((0, i.c8)({
                                type: "AD_ACTIVATED_LIMIT",
                                adId: null === u || void 0 === u ? void 0 : u.metadata
                            })), e.dispatch((0, i.mY)(!0))) : e.dispatch((0, d.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error"
                            }));
                        return t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var o, r, c = a.type,
                            l = a.payload,
                            d = e.getState();
                        if (c === i.Ng) {
                            var p = d.authentication.token;
                            e.dispatch((0, s.Z)(u.uQ, {
                                successfulResponseAction: i.OR
                            }, {
                                context: {
                                    token: p,
                                    isNewGateway: !0
                                },
                                fetchPolicy: "no-cache"
                            }))
                        }
                        if (c === i.ut && (null !== l && void 0 !== l && null !== (o = l.data) && void 0 !== o && null !== (r = o.getMyAdsCount) && void 0 !== r && r.countByStatus)) {
                            var m, g, f = l.data.getMyAdsCount.countByStatus,
                                y = d.userAds.pagination,
                                b = null === (m = f.filter((function(e) {
                                    var t = e.status;
                                    return (null === t || void 0 === t ? void 0 : t.toLowerCase()) === v.EY.BOOSTED_ADS
                                }))) || void 0 === m || null === (g = m[0]) || void 0 === g ? void 0 : g.count,
                                _ = f.reduce((function(e, t) {
                                    var a = t.status,
                                        o = t.count,
                                        r = null === a || void 0 === a ? void 0 : a.toLowerCase(),
                                        i = h(h({}, e), {}, (0, n.Z)({}, r, h(h({}, y[r]), {}, {
                                            adsCount: o
                                        })));
                                    return r === v.AE.ACTIVE && (i[v.EY.ALL_ADS] = h(h({}, y[v.EY.ALL_ADS]), {}, {
                                        adsCount: o
                                    }), i[v.EY.UNBOOSTED_ADS] = h(h({}, y[v.EY.UNBOOSTED_ADS]), {}, {
                                        adsCount: o - b
                                    })), i
                                }), {});
                            e.dispatch((0, i.rQ)(_))
                        }
                        return t(a)
                    }
                }
            }]
        },
        24123: function(e, t, a) {
            "use strict";
            var n = a(45831),
                o = a(10666),
                r = a(73794),
                i = a(80308);
            t.ZP = [function(e) {
                return function(t) {
                    return function(a) {
                        var s = a.type,
                            c = a.payload,
                            u = e.getState();
                        if (s === n._s) {
                            var l;
                            e.dispatch((0, o.yh)());
                            var d = (null === u || void 0 === u ? void 0 : u.authentication).token;
                            e.dispatch((0, i.Z)(r.SO, {
                                successfulResponseAction: n.ew
                            }, {
                                variables: {
                                    page: {
                                        number: null === c || void 0 === c ? void 0 : c.page,
                                        size: null === c || void 0 === c ? void 0 : c.size
                                    }
                                },
                                context: {
                                    token: d,
                                    lang: null === u || void 0 === u || null === (l = u.page) || void 0 === l ? void 0 : l.lang,
                                    isNewGateway: !0
                                },
                                fetchPolicy: "no-cache"
                            }))
                        }
                        if (s === n.hk) {
                            var v, p = (null === c || void 0 === c || null === (v = c.data) || void 0 === v ? void 0 : v.getMySavedAds) || {},
                                m = p.ads,
                                g = p.count;
                            e.dispatch((0, n.C2)({
                                savedAds: m,
                                count: g
                            })), e.dispatch((0, o.v3)())
                        }
                        return t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var r = a.type,
                            i = a.payload,
                            s = e.getState();
                        if (r === n.Nb) {
                            var c;
                            e.dispatch((0, o.dL)());
                            var u = (null === s || void 0 === s ? void 0 : s.authentication).token;
                            null === i || void 0 === i || null === (c = i.unsaveAd) || void 0 === c || c.call(i, null === i || void 0 === i ? void 0 : i.listId, u, (function() {
                                var t, a, r = null === s || void 0 === s || null === (t = s.userFavorites) || void 0 === t || null === (a = t.savedAds) || void 0 === a ? void 0 : a.filter((function(e) {
                                    return (null === e || void 0 === e ? void 0 : e.listId) !== (null === i || void 0 === i ? void 0 : i.listId)
                                }));
                                e.dispatch((0, n.C2)({
                                    savedAds: r
                                })), e.dispatch((0, o.o9)(null))
                            }))
                        }
                        return t(a)
                    }
                }
            }]
        },
        14916: function(e, t, a) {
            "use strict";
            var n = a(372),
                o = a(80308),
                r = a(36697),
                i = a(51432),
                s = a(10666);
            t.ZP = [function(e) {
                return function(t) {
                    return function(a) {
                        var r = a.type,
                            c = a.payload,
                            u = e.getState();
                        if (r === n.rQ) {
                            var l = (null === u || void 0 === u ? void 0 : u.authentication).token;
                            e.dispatch((0, s.yh)()), e.dispatch((0, o.Z)(i.In, {
                                successfulResponseAction: n.Wm,
                                erroredResponseAction: n.CN
                            }, {
                                context: {
                                    token: l,
                                    isNewGateway: !0
                                },
                                fetchPolicy: "no-cache"
                            }))
                        }
                        if (r === n.vv) {
                            var d;
                            if (null !== c && void 0 !== c && null !== (d = c.data) && void 0 !== d && d.getUserNotificationPreferences) {
                                var v = c.data.getUserNotificationPreferences.settings,
                                    p = v.adNotificationsEnabled,
                                    m = v.vasNotificationsEnabled,
                                    g = v.paymentNotificationsEnabled,
                                    f = v.newsletterNotificationsEnabled;
                                e.dispatch((0, n.lM)({
                                    adsNotif: p,
                                    vasNotif: m,
                                    paymentNotif: g,
                                    newslettersNotif: f
                                }))
                            }
                            e.dispatch((0, s.v3)())
                        }
                        return r === n.BF && (e.dispatch((0, s.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: c
                        })), e.dispatch((0, s.v3)())), t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var o, c = a.type,
                            u = a.payload,
                            l = e.getState();
                        if (c === n.O_) {
                            var d = (null === l || void 0 === l ? void 0 : l.authentication).token,
                                v = u.adsNotif,
                                p = u.vasNotif,
                                m = u.paymentNotif,
                                g = u.newslettersNotif;
                            e.dispatch((0, r.Z)(i.sx, {
                                successfulResponseAction: n.St,
                                erroredResponseAction: n.B5
                            }, {
                                variables: {
                                    preferences: {
                                        adNotificationsEnabled: v,
                                        vasNotificationsEnabled: p,
                                        paymentNotificationsEnabled: m,
                                        newsletterNotificationsEnabled: g,
                                        chatNotificationsEnabled: !0
                                    }
                                },
                                context: {
                                    token: d,
                                    isNewGateway: !0
                                }
                            }))
                        }
                        if (c === n.Fc && (null !== u && void 0 !== u && null !== (o = u.data) && void 0 !== o && o.updateUserNotificationPreferences)) {
                            var f = u.data.updateUserNotificationPreferences,
                                h = f.adNotificationsEnabled,
                                y = f.vasNotificationsEnabled,
                                b = f.paymentNotificationsEnabled,
                                _ = f.newsletterNotificationsEnabled;
                            e.dispatch((0, n.lM)({
                                adsNotif: h,
                                vasNotif: y,
                                paymentNotif: b,
                                newslettersNotif: _
                            })), e.dispatch((0, s.pb)({
                                icon: "CircleChecked",
                                message: "av.account.setting.alert.notification.updated",
                                status: "success"
                            }))
                        }
                        return c === n.pJ && e.dispatch((0, s.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: u
                        })), t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var r, s, c = a.type,
                            u = a.payload,
                            l = e.getState();
                        if (c === n.D) {
                            var d = (null === l || void 0 === l ? void 0 : l.authentication).token;
                            e.dispatch((0, o.Z)(i.vV, {
                                successfulResponseAction: n.Q5
                            }, {
                                variables: {
                                    channelName: "email"
                                },
                                context: {
                                    token: d,
                                    isNewGateway: !0
                                },
                                fetchPolicy: "no-cache"
                            }))
                        }
                        c === n.vR && (null !== u && void 0 !== u && null !== (r = u.data) && void 0 !== r && r.getUserNotificationChannel && e.dispatch((0, n.HK)(null === u || void 0 === u || null === (s = u.data) || void 0 === s ? void 0 : s.getUserNotificationChannel)));
                        return t(a)
                    }
                }
            }, function(e) {
                return function(t) {
                    return function(a) {
                        var o, c = a.type,
                            u = a.payload,
                            l = e.getState();
                        if (c === n.PW) {
                            e.dispatch((0, s.dL)());
                            var d = (null === l || void 0 === l ? void 0 : l.authentication).token,
                                v = (null === l || void 0 === l ? void 0 : l.page).lang;
                            e.dispatch((0, r.Z)(i.AK, {
                                successfulResponseAction: n.FJ,
                                erroredResponseAction: n.E$
                            }, {
                                variables: {
                                    lang: null === v || void 0 === v ? void 0 : v.toUpperCase()
                                },
                                context: {
                                    token: d,
                                    isNewGateway: !0
                                }
                            }))
                        }
                        c === n.lI && ("sent" === (null === u || void 0 === u || null === (o = u.data) || void 0 === o ? void 0 : o.sendEmailVerification) && e.dispatch((0, s.o9)({
                            title: "av.form.user.forgot.password.title-success",
                            text: "av.form.user.forgot.password.text-success",
                            logo: "/phoenix-assets/imgs/ai/lost_password/lost_password_success.png",
                            btnSubmit: null
                        })), e.dispatch((0, s.if)()));
                        return c === n.fz && (e.dispatch((0, s.o9)({
                            title: "av.account.setting.email.verification.title",
                            text: "av.account.setting.email.verification.text",
                            logo: "/phoenix-assets/imgs/ai/lost_password/lost_password_failed.png",
                            btnSubmit: !0
                        })), e.dispatch((0, s.if)())), t(a)
                    }
                }
            }]
        },
        63194: function(e, t, a) {
            "use strict";
            var n = a(93088),
                o = a(58139),
                r = a(10666),
                i = a(36697),
                s = a(51432),
                c = a(95271),
                u = a(86743);
            t.Z = function(e) {
                return function(t) {
                    return function(a) {
                        var l, d, v, p = a.type,
                            m = a.payload,
                            g = e.getState();
                        if (p === o.pX) {
                            e.dispatch((0, r.yh)());
                            var f = (null === g || void 0 === g ? void 0 : g.userProfile).userId,
                                h = (null === g || void 0 === g ? void 0 : g.authentication).token,
                                y = (null === g || void 0 === g ? void 0 : g.userProfile).type,
                                b = m.currentPassword,
                                _ = m.password;
                            e.dispatch((0, i.Z)(s.vr, {
                                successfulResponseAction: o.E,
                                erroredResponseAction: o.zt
                            }, {
                                variables: {
                                    userId: String(f),
                                    currentPassword: b,
                                    password: _,
                                    accountType: y
                                },
                                context: {
                                    token: h,
                                    isNewGateway: !1
                                }
                            }))
                        }
                        p === o.Rf && (((0, u.u)(null === g || void 0 === g || null === (l = g.userProfile) || void 0 === l ? void 0 : l.type) ? (null === m || void 0 === m || null === (d = m.data) || void 0 === d ? void 0 : d.editUserPassword) === n.TD.CREATED.CODE : (null === m || void 0 === m || null === (v = m.data) || void 0 === v ? void 0 : v.editUserPassword) === n.TD.NO_CONTENT.CODE) && (e.dispatch((0, c.tv)("Success")), e.dispatch((0, r.pb)({
                            icon: "CircleChecked",
                            message: "av.account.setting.alert.account-updated",
                            status: "success"
                        }))), e.dispatch((0, r.v3)()));
                        return p === o.AS && (e.dispatch((0, c.tv)("Error")), e.dispatch((0, r.pb)({
                            icon: "InformationLine",
                            message: "av.account.toaster.activate.error",
                            status: "error",
                            customMessage: m
                        })), e.dispatch((0, r.v3)())), t(a)
                    }
                }
            }
        },
        76466: function(e, t, a) {
            "use strict";
            a.d(t, {
                D8: function() {
                    return p
                },
                Yx: function() {
                    return v
                },
                cv: function() {
                    return d
                }
            });
            var n = a(35259),
                o = a(11521),
                r = a(10666),
                i = a(80308),
                s = a(36697),
                c = a(51432),
                u = a(86743),
                l = a(95271),
                d = function(e) {
                    return function(t) {
                        return function(a) {
                            var r = a.type,
                                i = e.getState();
                            if (r === n.fR) {
                                var s = (null === i || void 0 === i ? void 0 : i.userProfile).type;
                                (0, u.u)(s) ? e.dispatch((0, o.gU)()): e.dispatch((0, n.Lt)())
                            }
                            return t(a)
                        }
                    }
                },
                v = function(e) {
                    return function(t) {
                        return function(a) {
                            var o, s, u = a.type,
                                l = a.payload,
                                d = e.getState();
                            if (u === n.Xq) {
                                e.dispatch((0, r.dL)());
                                var v = (null === d || void 0 === d ? void 0 : d.authentication).token;
                                e.dispatch((0, i.Z)(c.E8, {
                                    successfulResponseAction: n.kJ,
                                    erroredResponseAction: n.WX
                                }, {
                                    context: {
                                        token: v,
                                        isNewGateway: !0
                                    },
                                    fetchPolicy: "no-cache"
                                }))
                            }
                            u === n.gA && (null !== l && void 0 !== l && null !== (o = l.data) && void 0 !== o && o.getMyAccountInfo ? (e.dispatch((0, n.Lj)(null === l || void 0 === l || null === (s = l.data) || void 0 === s ? void 0 : s.getMyAccountInfo)), e.dispatch((0, r.if)())) : e.dispatch((0, r.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error"
                            })));
                            return u === n.b1 && e.dispatch((0, r.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error"
                            })), t(a)
                        }
                    }
                },
                p = function(e) {
                    return function(t) {
                        return function(a) {
                            var o, i, u = a.type,
                                d = a.payload,
                                v = e.getState();
                            if (u === n.q7) {
                                e.dispatch((0, r.yh)());
                                var p = (null === v || void 0 === v ? void 0 : v.authentication).token,
                                    m = (null === v || void 0 === v ? void 0 : v.page).lang,
                                    g = d.name,
                                    f = d.phone,
                                    h = d.email,
                                    y = d.location;
                                e.dispatch((0, s.Z)(c.q5, {
                                    successfulResponseAction: n.gM,
                                    erroredResponseAction: n.kh
                                }, {
                                    variables: {
                                        input: {
                                            name: g,
                                            phone: f,
                                            location: y,
                                            email: h
                                        }
                                    },
                                    context: {
                                        token: p,
                                        lang: m,
                                        isNewGateway: !0
                                    }
                                }))
                            }
                            u === n.YY && (null !== d && void 0 !== d && null !== (o = d.data) && void 0 !== o && o.updateMyAccountInfo && (e.dispatch((0, n.Lj)(null === d || void 0 === d || null === (i = d.data) || void 0 === i ? void 0 : i.updateMyAccountInfo)), e.dispatch((0, l.Ug)("Success")), e.dispatch((0, r.v3)()), e.dispatch((0, r.pb)({
                                icon: "CircleChecked",
                                message: "av.account.setting.alert.account-updated",
                                status: "success"
                            }))));
                            return u === n.RT && (e.dispatch((0, l.Ug)("Error")), e.dispatch((0, r.pb)({
                                icon: "InformationLine",
                                message: "av.account.toaster.activate.error",
                                status: "error",
                                customMessage: d
                            })), e.dispatch((0, r.v3)())), t(a)
                        }
                    }
                };
            t.ZP = [d, v, p]
        },
        45685: function(e, t, a) {
            "use strict";
            a.d(t, {
                $G: function() {
                    return l
                },
                Cd: function() {
                    return c
                },
                L3: function() {
                    return u
                },
                NW: function() {
                    return i
                },
                Qp: function() {
                    return o
                },
                UC: function() {
                    return d
                },
                jQ: function() {
                    return s
                },
                ji: function() {
                    return r
                },
                pq: function() {
                    return p
                },
                uB: function() {
                    return v
                }
            });
            var n = a(68697);
            var o = (0, n.P1)((function(e) {
                    return null === e || void 0 === e ? void 0 : e.userProfile
                }), (function(e) {
                    var t, a, n, o;
                    return {
                        name: null === e || void 0 === e ? void 0 : e.name,
                        phone: null === e || void 0 === e || null === (t = e.phone) || void 0 === t ? void 0 : t.number,
                        phoneHidden: null === e || void 0 === e || null === (a = e.phone) || void 0 === a ? void 0 : a.isHidden,
                        email: null === e || void 0 === e ? void 0 : e.email,
                        region: Number(null === e || void 0 === e || null === (n = e.location) || void 0 === n || null === (o = n.city) || void 0 === o ? void 0 : o.id)
                    }
                })),
                r = (0, n.P1)((function(e) {
                    return null === e || void 0 === e ? void 0 : e.userProfile
                }), (function(e) {
                    return null === e || void 0 === e ? void 0 : e.authentication
                }), (function(e, t) {
                    var a;
                    return {
                        userId: null === e || void 0 === e ? void 0 : e.userId,
                        isLoggedIn: null === t || void 0 === t ? void 0 : t.isLoggedIn,
                        token: null === t || void 0 === t ? void 0 : t.token,
                        expiresIn: null === t || void 0 === t ? void 0 : t.expiresIn,
                        type: null === e || void 0 === e ? void 0 : e.type,
                        name: null === e || void 0 === e ? void 0 : e.name,
                        email: null === e || void 0 === e ? void 0 : e.email,
                        phone: null === e || void 0 === e || null === (a = e.phone) || void 0 === a ? void 0 : a.number,
                        isAdmin: null === e || void 0 === e ? void 0 : e.isAdmin
                    }
                })),
                i = (0, n.P1)((function(e) {
                    return null === e || void 0 === e ? void 0 : e.userProfile
                }), (function(e) {
                    var t, a, n, o;
                    return {
                        name: null === e || void 0 === e ? void 0 : e.name,
                        email: null === e || void 0 === e ? void 0 : e.email,
                        region: Number(null === e || void 0 === e || null === (t = e.location) || void 0 === t || null === (a = t.city) || void 0 === a ? void 0 : a.id),
                        phone: null === e || void 0 === e || null === (n = e.phone) || void 0 === n ? void 0 : n.number,
                        showPhone: !(null !== e && void 0 !== e && null !== (o = e.phone) && void 0 !== o && o.isHidden),
                        shopParams: null === e || void 0 === e ? void 0 : e.shopInfo
                    }
                })),
                s = function(e) {
                    var t;
                    return null === e || void 0 === e || null === (t = e.userProfile) || void 0 === t ? void 0 : t.name
                },
                c = function(e) {
                    var t;
                    return null === e || void 0 === e || null === (t = e.userProfile) || void 0 === t ? void 0 : t.type
                },
                u = function(e) {
                    var t;
                    return null === e || void 0 === e || null === (t = e.userProfile) || void 0 === t ? void 0 : t.role
                },
                l = function(e) {
                    var t;
                    return null === e || void 0 === e || null === (t = e.userProfile) || void 0 === t ? void 0 : t.email
                },
                d = function(e) {
                    var t;
                    return null === e || void 0 === e || null === (t = e.userProfile) || void 0 === t ? void 0 : t.userNotifChannel
                },
                v = function(e) {
                    var t;
                    return null === e || void 0 === e || null === (t = e.userProfile) || void 0 === t ? void 0 : t.notifParams
                },
                p = (0, n.P1)((function(e) {
                    return null === e || void 0 === e ? void 0 : e.userProfile
                }), (function(e) {
                    var t;
                    return {
                        userId: Number(null === e || void 0 === e ? void 0 : e.userId),
                        account_type: null === e || void 0 === e ? void 0 : e.type,
                        email: null === e || void 0 === e ? void 0 : e.email,
                        phone_number: null === e || void 0 === e || null === (t = e.phone) || void 0 === t ? void 0 : t.number
                    }
                }))
        },
        86743: function(e, t, a) {
            "use strict";
            a.d(t, {
                t: function() {
                    return i
                },
                u: function() {
                    return r
                }
            });
            var n = a(45217),
                o = a(80925),
                r = function(e) {
                    return e === o.USER_TYPES.SHOP
                },
                i = function(e) {
                    return function(t, a) {
                        return (0, n.UY)(e)(t, a)
                    }
                }
        },
        36697: function(e, t, a) {
            "use strict";
            var n = a(59499),
                o = a(50029),
                r = a(87794),
                i = a.n(r),
                s = a(37594),
                c = a(16700);

            function u(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : u(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            t.Z = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                        successfulResponseAction: null,
                        erroredResponseAction: null
                    },
                    a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
                        variables: void 0,
                        context: void 0
                    },
                    n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0;
                return function() {
                    var r = (0, o.Z)(i().mark((function o(r) {
                        var u, d, v, p;
                        return i().wrap((function(o) {
                            for (;;) switch (o.prev = o.next) {
                                case 0:
                                    return u = (0, s.R)(), d = t.successfulResponseAction, v = t.erroredResponseAction, o.next = 4, u.mutate(l({
                                        mutation: e
                                    }, a)).catch((function(t) {
                                        var o, i, s, u, l;
                                        c.Z.error("Encountered an error while calling gql mutation", {
                                            error: null === t || void 0 === t ? void 0 : t.toString(),
                                            queryName: null === e || void 0 === e || null === (o = e.definitions) || void 0 === o || null === (i = o[0]) || void 0 === i || null === (s = i.name) || void 0 === s ? void 0 : s.value,
                                            variables: a.variables
                                        }), v && r(v(null === t || void 0 === t || null === (u = t.graphQLErrors) || void 0 === u || null === (l = u[0]) || void 0 === l ? void 0 : l.message, n))
                                    }));
                                case 4:
                                    (p = o.sent) && d && (n && (p.metadata = n), r(d(p)));
                                case 6:
                                case "end":
                                    return o.stop()
                            }
                        }), o)
                    })));
                    return function(e) {
                        return r.apply(this, arguments)
                    }
                }()
            }
        },
        80308: function(e, t, a) {
            "use strict";
            var n = a(59499),
                o = a(50029),
                r = a(87794),
                i = a.n(r),
                s = a(37594),
                c = a(16700);

            function u(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : u(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            t.Z = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {
                        successfulResponseAction: null,
                        erroredResponseAction: null
                    },
                    a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {
                        variables: void 0,
                        context: void 0,
                        fetchPolicy: "cache-first"
                    },
                    n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : void 0;
                return function() {
                    var r = (0, o.Z)(i().mark((function o(r) {
                        var u, d, v, p, m, g, f, h, y, b;
                        return i().wrap((function(o) {
                            for (;;) switch (o.prev = o.next) {
                                case 0:
                                    return d = (0, s.R)(), v = t.successfulResponseAction, p = t.erroredResponseAction, o.next = 4, d.query(l({
                                        query: e
                                    }, a));
                                case 4:
                                    null !== (m = o.sent) && void 0 !== m && null !== (u = m.errors) && void 0 !== u && u.length && (b = null === (g = m.errors[0]) || void 0 === g ? void 0 : g.message, c.Z.error("Encountered an error while calling gql query", {
                                        error: b,
                                        queryName: null === e || void 0 === e || null === (f = e.definitions) || void 0 === f || null === (h = f[0]) || void 0 === h || null === (y = h.name) || void 0 === y ? void 0 : y.value,
                                        variables: a.variables
                                    }), p && r(p(b))), m && v && r(v(m, n));
                                case 7:
                                case "end":
                                    return o.stop()
                            }
                        }), o)
                    })));
                    return function(e) {
                        return r.apply(this, arguments)
                    }
                }()
            }
        },
        20511: function(e, t, a) {
            "use strict";
            a.d(t, {
                $: function() {
                    return i
                },
                D: function() {
                    return r
                }
            });
            var n = a(45697),
                o = a.n(n),
                r = {
                    AD_INSERT__INSERT_AD: "insert_ad",
                    USER_ACCOUNT__LOGGED_IN: "LOGGED IN",
                    USER_ACCOUNT__LOGIN_ATTEMPT: "LOGIN ATTEMPT",
                    USER_ACCOUNT__SIGNED_UP: "SIGNED UP",
                    USER_ACCOUNT__SIGNUP_ATTEMPT: "SIGNUP ATTEMPT",
                    USER_ACCOUNT__PASSWORD_RESET: "PASSWORD RESET",
                    USER_ACCOUNT__LOGGED_OUT: "LOGGED OUT",
                    USER_ACCOUNT__TAB_CLICKED: "TAB CLICKED",
                    USER_ACCOUNT__FILTER_CLICKED: "FILTER CLICKED",
                    USER_ACCOUNT__AD_CLICKED: "AD CLICKED",
                    USER_ACCOUNT__ACTIVATE_AD_CLICKED: "ACTIVATE AD CLICKED",
                    USER_ACCOUNT__BOOST_AD_CLICKED: "BOOST AD CLICKED",
                    USER_ACCOUNT__DEACTIVATE_AD_CLICKED: "DEACTIVATE AD CLICKED",
                    USER_ACCOUNT__INITIATED_AD_DELETION: "INITIATED AD DELETION",
                    USER_ACCOUNT__CLICKED_EDIT_CALENDAR: "CLICKED EDIT CALENDAR",
                    USER_ACCOUNT__EDIT_AD_CLICKED: "EDIT AD CLICKED",
                    USER_ACCOUNT__PROFILE_INFOS_UPDATED: "PROFILE INFOS UPDATED",
                    USER_ACCOUNT__PASSWORD_UPDATED: "PASSWORD UPDATED",
                    USER_ACCOUNT__CLICKED_ON_MORE_STATISTICS: "CLICKED ON MORE STATISTICS",
                    USER_ACCOUNT__CLICKED_ON_AD_INSERT: "CLICKED ON AD INSERT",
                    USER_ACCOUNT__CLICKED_ON_PAY: "CLICKED ON PAY",
                    USER_ACCOUNT__OPTOUT_MY_ACCOUNT: "OPTOUT MY ACCOUNT",
                    USER_ACCOUNT__AD_DETAILS_DISPLAYED: "AD DETAILS DISPLAYED",
                    USER_ACCOUNT__MANAGE_MY_ADS: "MANAGE MY ADS",
                    USER_ACCOUNT__EDIT_AD_DELETION: "EDIT AD DELETION",
                    USER_ACCOUNT__CANCEL_AD_DELETION: "CANCEL AD DELETION",
                    USER_ACCOUNT__DEACTIVATED_AD: "DEACTIVATED_AD",
                    USER_ACCOUNT__DELETED_AD_CLICKED: "DELETED_AD_CLICKED",
                    USER_ACCOUNT__DELETED_AD: "DELETED AD",
                    USER_ACCOUNT__CREATE_PRIVATE_ACCOUNT: "CREATE PRIVATE ACCOUNT",
                    USER_ACCOUNT__SUB_TAB_CLICKED: "SUB TAB CLICKED",
                    USER_ACCOUNT__FILTER_TRIGGRED: "FILTER TRIGGRED",
                    USER_ACCOUNT__MULTIPLE_ADS_SELECTED: "MULTIPLE ADS SELECTED",
                    USER_ACCOUNT__MANAGE_AD_CLICKED: "MANAGE AD CLICKED",
                    USER_ACCOUNT__DATE_RANG_SELECTED: "DATE RANG SELECTED",
                    AD_ADVIEW__LEAD: "lead",
                    AD_ADVIEW__SHARE_AD: "share_ad",
                    AD_ADVIEW__SAVE_AD: "save_ad",
                    AD_ADVIEW__UNSAVE_AD: "unsave_ad",
                    AD_ADVIEW__REPORT_AD: "report_ad",
                    AD_LISTING__SEARCH_RESULT: "search_result",
                    COMMON__ELEMENT_CLICKED: "element_clicked",
                    COMMON__ELEMENT_DISPLAYED: "element_displayed",
                    COMMON__AB_TESTING_VIEWED_EXPERIMENT: "VIEWED EXPERIMENT",
                    UTILS__UPDATE_DATA_LAYER: "UPDATE DATA LAYER"
                },
                i = [{
                    name: r.COMMON__AB_TESTING_VIEWED_EXPERIMENT,
                    propTypes: {
                        experiment_id: o().string.isRequired,
                        variation_id: o().string.isRequired,
                        feature_id: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.AD_INSERT__INSERT_AD,
                    propTypes: {
                        category_name: o().string.isRequired,
                        category_id: o().number.isRequired,
                        subcategory_name: o().string.isRequired,
                        subcategory_id: o().number.isRequired,
                        ad_type: o().string.isRequired,
                        city: o().string.isRequired,
                        city_id: o().number.isRequired,
                        area: o().string.isRequired,
                        area_id: o().number.isRequired,
                        seller_type: o().string.isRequired,
                        seller_id: o().number.isRequired,
                        error_type: o().string.isRequired,
                        seller_phone: o().string.isRequired,
                        value: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__LOGGED_IN,
                    propTypes: {
                        user_id: o().number.isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__LOGIN_ATTEMPT,
                    propTypes: {
                        error_type: o().string.isRequired,
                        element_source: o().string.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__SIGNUP_ATTEMPT,
                    propTypes: {
                        error_type: o().string,
                        step: o().string,
                        element_source: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__SIGNED_UP,
                    propTypes: {
                        element_source: o().string.isRequired,
                        account_type: o().string.isRequired,
                        is_phone_verified: o().bool.isRequired,
                        page_pathname: o().string.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__PASSWORD_RESET,
                    propTypes: {
                        element_source: o().string.isRequired,
                        account_type: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__LOGGED_OUT,
                    propTypes: {
                        user_id: o().number.isRequired,
                        email: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        account_type: o().string.isRequired,
                        element_source: o().string.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__TAB_CLICKED,
                    propTypes: {
                        tab: o().oneOf(["Mes annonces", "R\xe9glages", "Statistiques", "Favoris"]).isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        account_type: o().string.isRequired,
                        user_id: o().number.isRequired,
                        element_source: o().string.isRequired,
                        from: o().oneOf(["Header", "tab"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__FILTER_CLICKED,
                    propTypes: {
                        filter: o().oneOf(["Actives", "Dans la mod\xe9ration", "Rejet\xe9es", "Paiement en attente", "Supprim\xe9es", "d\xe9sactiv\xe9es"]).isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__AD_CLICKED,
                    propTypes: {
                        ad_id: o().number.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        element_source: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__ACTIVATE_AD_CLICKED,
                    propTypes: {
                        ad_id: o().number.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__BOOST_AD_CLICKED,
                    propTypes: {
                        ad_id: o().number.isRequired,
                        device: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        source: o().oneOf(["Adview", "Myaccount"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        element_source: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__DEACTIVATE_AD_CLICKED,
                    propTypes: {
                        ad_id: o().number.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__INITIATED_AD_DELETION,
                    propTypes: {
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        user_id: o().number.isRequired,
                        element_source: o().string.isRequired,
                        number_of_ads: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__CLICKED_EDIT_CALENDAR,
                    propTypes: {
                        element_source: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__EDIT_AD_CLICKED,
                    propTypes: {
                        ad_id: o().number.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        element_source: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__PROFILE_INFOS_UPDATED,
                    propTypes: {
                        status: o().oneOf(["Success", "Error"]).isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        element_source: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__PASSWORD_UPDATED,
                    propTypes: {
                        status: o().oneOf(["Success", "Error"]).isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__CLICKED_ON_MORE_STATISTICS,
                    propTypes: {
                        filter: o().oneOf(["Appels", "Messages", "vues", "Consommation", "Annonces Actives"]).isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__CLICKED_ON_AD_INSERT,
                    propTypes: {
                        filter: o().oneOf(["header", "side bar", "my account listing"]).isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__CLICKED_ON_PAY,
                    propTypes: {
                        ad_id: o().number.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__OPTOUT_MY_ACCOUNT,
                    propTypes: {
                        user_id: o().number.isRequired,
                        choice: o().string.isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__AD_DETAILS_DISPLAYED,
                    propTypes: {
                        ad_id: o().number.isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        ad_type: o().string.isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired,
                        from: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__MANAGE_MY_ADS,
                    propTypes: {
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        element_source: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__EDIT_AD_DELETION,
                    propTypes: {
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        user_id: o().number.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        element_source: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        number_of_ads: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__CANCEL_AD_DELETION,
                    propTypes: {
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        number_of_ads: o().number.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__DEACTIVATED_AD,
                    propTypes: {
                        element_source: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__DELETED_AD_CLICKED,
                    propTypes: {
                        element_source: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__DELETED_AD,
                    propTypes: {
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        user_id: o().number.isRequired,
                        reason: o().string.isRequired,
                        sold_within: o().string.isRequired,
                        ad_ids: o().number.isRequired,
                        number_of_ads: o().number.isRequired,
                        element_source: o().string.isRequired,
                        status: o().oneOf(["Success", "Error"]).isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__CREATE_PRIVATE_ACCOUNT,
                    propTypes: {
                        is_phone_hidden: o().bool.isRequired,
                        city: o().string.isRequired,
                        city_id: o().string.isRequired,
                        element_source: o().string.isRequired,
                        facebook_signup: o().bool.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__SUB_TAB_CLICKED,
                    propTypes: {
                        tab: o().oneOf(["Shop info", "Shop contact", "change password"]).isRequired,
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        account_type: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__FILTER_TRIGGRED,
                    propTypes: {
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__MULTIPLE_ADS_SELECTED,
                    propTypes: {
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__MANAGE_AD_CLICKED,
                    propTypes: {
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        element_source: o().string.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.USER_ACCOUNT__DATE_RANG_SELECTED,
                    propTypes: {
                        source: o().oneOf(["Desktop", "Mobile"]).isRequired,
                        email: o().string.isRequired,
                        account_type: o().string.isRequired,
                        phone_number: o().number.isRequired,
                        page_domaine: o().string.isRequired,
                        page_pathname: o().string.isRequired,
                        days: o().number.isRequired,
                        user_id: o().number.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.AD_ADVIEW__LEAD,
                    propTypes: {
                        content_type: o().string.isRequired,
                        lead_type: o().string.isRequired,
                        ad_id: o().number.isRequired,
                        ad_list_id: o().number.isRequired,
                        ad_name: o().string.isRequired,
                        ad_type: o().string.isRequired,
                        ad_price: o().string.isRequired,
                        category_name: o().string.isRequired,
                        category_id: o().number.isRequired,
                        subcategory_name: o().string.isRequired,
                        subcategory_id: o().string.isRequired,
                        city: o().string.isRequired,
                        city_id: o().number.isRequired,
                        area: o().string.isRequired,
                        area_id: o().number.isRequired,
                        seller_type: o().string.isRequired,
                        seller_name: o().string.isRequired,
                        seller_id: o().number.isRequired,
                        picture_count: o().number.isRequired,
                        has_phone: o().bool.isRequired,
                        is_phone_verified: o().bool.isRequired,
                        publish_date: o().string.isRequired,
                        lang: o().string.isRequired,
                        source_element: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.AD_ADVIEW__SHARE_AD,
                    propTypes: {
                        page_name: o().string.isRequired,
                        ad_id: o().number.isRequired,
                        ad_list_id: o().number.isRequired,
                        ad_name: o().string.isRequired,
                        ad_type: o().string.isRequired,
                        ad_price: o().string.isRequired,
                        ad_phone_number: o().number.isRequired,
                        category_id: o().number.isRequired,
                        subcategory_id: o().number.isRequired,
                        category_name: o().string.isRequired,
                        subcategory_name: o().string.isRequired,
                        city: o().string.isRequired,
                        city_id: o().number.isRequired,
                        area: o().string.isRequired,
                        area_id: o().number.isRequired,
                        seller_type: o().string.isRequired,
                        seller_name: o().string.isRequired,
                        seller_id: o().number.isRequired,
                        picture_count: o().number.isRequired,
                        has_phone: o().bool.isRequired,
                        is_phone_verified: o().bool.isRequired,
                        publish_date: o().string.isRequired,
                        lang: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.AD_ADVIEW__SAVE_AD,
                    propTypes: {
                        page_name: o().string.isRequired,
                        ad_id: o().number.isRequired,
                        ad_list_id: o().number.isRequired,
                        ad_name: o().string.isRequired,
                        ad_type: o().string.isRequired,
                        ad_price: o().string.isRequired,
                        ad_phone_number: o().number.isRequired,
                        category_id: o().number.isRequired,
                        subcategory_id: o().number.isRequired,
                        category_name: o().string.isRequired,
                        subcategory_name: o().string.isRequired,
                        city: o().string.isRequired,
                        city_id: o().number.isRequired,
                        area: o().string.isRequired,
                        area_id: o().number.isRequired,
                        seller_type: o().string.isRequired,
                        seller_name: o().string.isRequired,
                        seller_id: o().number.isRequired,
                        picture_count: o().number.isRequired,
                        has_phone: o().bool.isRequired,
                        is_phone_verified: o().bool.isRequired,
                        publish_date: o().string.isRequired,
                        element_source: o().string.isRequired,
                        lang: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.AD_ADVIEW__UNSAVE_AD,
                    propTypes: {
                        page_name: o().string.isRequired,
                        ad_id: o().number.isRequired,
                        ad_list_id: o().number.isRequired,
                        ad_name: o().string.isRequired,
                        ad_type: o().string.isRequired,
                        ad_price: o().string.isRequired,
                        ad_phone_number: o().number.isRequired,
                        category_id: o().number.isRequired,
                        subcategory_id: o().number.isRequired,
                        category_name: o().string.isRequired,
                        subcategory_name: o().string.isRequired,
                        city: o().string.isRequired,
                        city_id: o().number.isRequired,
                        area: o().string.isRequired,
                        area_id: o().number.isRequired,
                        selller_type: o().string.isRequired,
                        seller_name: o().string.isRequired,
                        seller_id: o().number.isRequired,
                        picture_count: o().number.isRequired,
                        has_phone: o().bool.isRequired,
                        is_phone_verified: o().bool.isRequired,
                        publish_date: o().string.isRequired,
                        lang: o().string.isRequired,
                        element_source: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.AD_ADVIEW__REPORT_AD,
                    propTypes: {
                        page_name: o().string.isRequired,
                        ad_id: o().number.isRequired,
                        ad_list_id: o().number.isRequired,
                        ad_name: o().string.isRequired,
                        ad_type: o().string.isRequired,
                        ad_price: o().string.isRequired,
                        ad_phone_number: o().number.isRequired,
                        category_id: o().number.isRequired,
                        subcategory_id: o().number.isRequired,
                        category_name: o().string.isRequired,
                        subcategory_name: o().string.isRequired,
                        city: o().string.isRequired,
                        area: o().string.isRequired,
                        seller_type: o().string.isRequired,
                        seller_name: o().string.isRequired,
                        seller_id: o().number.isRequired,
                        picture_count: o().number.isRequired,
                        has_phone: o().bool.isRequired,
                        is_phone_verified: o().bool.isRequired,
                        publish_date: o().string.isRequired,
                        lang: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.AD_LISTING__SEARCH_RESULT,
                    propTypes: {
                        Keyword: o().string.isRequired,
                        category_name: o().string.isRequired,
                        subcategory_name: o().string.isRequired,
                        city: o().string.isRequired,
                        city_id: o().number.isRequired,
                        annonces_avec_prix: o().bool.isRequired,
                        annonces_avec_images: o().bool.isRequired,
                        phone_brand: o().string.isRequired,
                        number_ad_params: o().number.isRequired,
                        phone_status: o().string.isRequired,
                        phone_model: o().string.isRequired,
                        capacity: o().string.isRequired,
                        seller_type: o().string.isRequired,
                        category_id: o().number.isRequired,
                        subcategory_id: o().number.isRequired,
                        nbr_cities: o().number.isRequired,
                        nbr_areas: o().number.isRequired,
                        nbr_brands: o().number.isRequired,
                        nbr_models: o().number.isRequired,
                        etat: o().string.isRequired,
                        ad_type: o().string.isRequired,
                        lang: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.COMMON__ELEMENT_CLICKED,
                    propTypes: {
                        element_name: o().string.isRequired,
                        page_name: o().string.isRequired,
                        subcategory_id: o().number.isRequired,
                        seller_type: o().string.isRequired,
                        value: o().string.isRequired,
                        element_source: o().string.isRequired,
                        seller_id: o().number.isRequired,
                        seller_phone: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.COMMON__ELEMENT_DISPLAYED,
                    propTypes: {
                        element_name: o().string.isRequired,
                        page_name: o().string.isRequired,
                        subcategory_id: o().number.isRequired,
                        seller_type: o().string.isRequired,
                        value: o().string.isRequired
                    },
                    enabled: function() {
                        return !0
                    }
                }, {
                    name: r.UTILS__UPDATE_DATA_LAYER,
                    propTypes: {},
                    enabled: function() {
                        return !0
                    }
                }]
        },
        31823: function(e, t, a) {
            "use strict";
            a.d(t, {
                AE: function() {
                    return p
                },
                B: function() {
                    return h
                },
                B3: function() {
                    return r
                },
                EY: function() {
                    return d
                },
                L7: function() {
                    return v
                },
                TT: function() {
                    return f
                },
                XO: function() {
                    return u
                },
                X_: function() {
                    return y
                },
                _C: function() {
                    return g
                },
                aC: function() {
                    return c
                },
                d9: function() {
                    return R
                },
                dO: function() {
                    return A
                },
                f3: function() {
                    return _
                },
                hD: function() {
                    return m
                },
                ii: function() {
                    return E
                },
                no: function() {
                    return S
                },
                ot: function() {
                    return l
                },
                qJ: function() {
                    return i
                },
                sM: function() {
                    return b
                },
                xY: function() {
                    return s
                }
            });
            var n = a(70269),
                o = a(20511),
                r = {
                    PRIVATE_USER: {
                        ADS: {
                            NAME: "my-ads",
                            TAB: "Mes annonces",
                            LABEL: "av.common.my-ads",
                            PATH: "account.my-ads",
                            HEADER_TAGGING_VALUE: "myads"
                        },
                        ORDERS: {
                            NAME: "my-orders",
                            TAB: "Mes commandes",
                            LABEL: "av.common.my-orders",
                            PATH: "account.my-orders"
                        },
                        FAVORITES: {
                            NAME: "my-favorites",
                            TAB: "Favoris",
                            LABEL: "av.account.tabs.favorite",
                            PATH: "account.my-favorites",
                            HEADER_TAGGING_VALUE: "myfavorites"
                        },
                        SETTINGS: {
                            NAME: "settings",
                            TAB: "R\xe9glages",
                            LABEL: "av.common.settings.short",
                            PATH: "account.settings",
                            HEADER_TAGGING_VALUE: "mysetting"
                        },
                        HOME: {
                            NAME: "home",
                            TAB: "Accueil",
                            PATH: "home-page"
                        },
                        CHAT: {
                            NAME: "chat",
                            TAB: "chat",
                            PATH: "messaging.chat"
                        }
                    },
                    SHOP: {
                        ADS: {
                            NAME: "my-ads",
                            TAB: "Mes annonces",
                            LABEL: "av.common.my-ads",
                            PATH: "account.my-ads",
                            HEADER_TAGGING_VALUE: "myads"
                        },
                        STATS: {
                            NAME: "stats",
                            TAB: "Statistiques",
                            LABEL: "av.account.tabs.stats",
                            PATH: "account.stats",
                            HEADER_TAGGING_VALUE: "mystatistics"
                        },
                        SETTINGS: {
                            NAME: "settings",
                            TAB: "R\xe9glages",
                            LABEL: "av.common.settings.short",
                            PATH: "account.settings",
                            HEADER_TAGGING_VALUE: "mysetting"
                        }
                    }
                },
                i = [{
                    icon: "ListCheck2",
                    label: r.PRIVATE_USER.ADS.LABEL,
                    text: r.PRIVATE_USER.ADS.NAME,
                    path: r.PRIVATE_USER.ADS.PATH,
                    tab: r.PRIVATE_USER.ADS.TAB
                }, {
                    icon: "CartFill",
                    label: r.PRIVATE_USER.ORDERS.LABEL,
                    text: r.PRIVATE_USER.ORDERS.NAME,
                    path: r.PRIVATE_USER.ORDERS.PATH,
                    tab: r.PRIVATE_USER.ORDERS.TAB
                }, {
                    icon: "HeartOutline",
                    label: r.PRIVATE_USER.FAVORITES.LABEL,
                    text: r.PRIVATE_USER.FAVORITES.NAME,
                    path: r.PRIVATE_USER.FAVORITES.PATH,
                    tab: r.PRIVATE_USER.FAVORITES.TAB
                }, {
                    icon: "Settings3Line",
                    label: r.PRIVATE_USER.SETTINGS.LABEL,
                    text: r.PRIVATE_USER.SETTINGS.NAME,
                    path: r.PRIVATE_USER.SETTINGS.PATH,
                    tab: r.PRIVATE_USER.SETTINGS.TAB
                }].filter(Boolean),
                s = [{
                    icon: "ListCheck2",
                    label: r.SHOP.ADS.LABEL,
                    subLabel: "av.account.tabs.classified.text",
                    text: r.SHOP.ADS.NAME,
                    path: r.SHOP.ADS.PATH,
                    tab: r.SHOP.ADS.TAB
                }, {
                    icon: "BarGraph",
                    label: r.SHOP.STATS.LABEL,
                    subLabel: "av.account.tabs.stats.text",
                    text: r.SHOP.STATS.NAME,
                    path: r.SHOP.STATS.PATH,
                    tab: r.SHOP.STATS.TAB
                }, {
                    icon: "Settings3Line",
                    label: r.SHOP.SETTINGS.LABEL,
                    subLabel: "av.account.tabs.settings.text",
                    text: r.SHOP.SETTINGS.NAME,
                    path: r.SHOP.SETTINGS.PATH,
                    tab: r.SHOP.SETTINGS.TAB
                }],
                c = [{
                    label: "av.account.filter.settings",
                    icon: "AccountCircle",
                    name: "profile",
                    path: "account.settings"
                }, {
                    label: "av.account.filter.password",
                    icon: "Protected",
                    name: "password",
                    path: "account.settings.password"
                }, {
                    label: "av.account.filter.notification",
                    name: "notification",
                    path: "account.settings.notification"
                }],
                u = [{
                    label: "av.account.filter.shop.settings",
                    name: "profile",
                    path: "account.settings"
                }, {
                    label: "av.account.filter.shop.contact",
                    name: "contact",
                    path: "account.settings.contact"
                }, {
                    label: "av.account.filter.shop.password",
                    name: "password",
                    path: "account.settings.password"
                }, {
                    label: "av.account.filter.notification",
                    name: "notification",
                    path: "account.settings.notification"
                }],
                l = {
                    ACTIVE: "ACTIVE",
                    UNVERIFIED: "UNVERIFIED"
                },
                d = {
                    ALL_ADS: "all_ads",
                    BOOSTED_ADS: "boosted_active_ads",
                    UNBOOSTED_ADS: "unboosted_active_ads"
                },
                v = [{
                    id: d.ALL_ADS,
                    value: d.ALL_ADS,
                    label: "av.account.listing.sort.all-ads"
                }, {
                    id: d.BOOSTED_ADS,
                    value: d.BOOSTED_ADS,
                    label: "av.account.listing.sort.boosted-ads"
                }, {
                    id: d.UNBOOSTED_ADS,
                    value: d.UNBOOSTED_ADS,
                    label: "av.account.listing.sort.unboosted-ads"
                }],
                p = {
                    ACTIVE: "active",
                    IN_MODERATION: "pending_review",
                    REJECTED: "refused",
                    DEACTIVATED: "deactivated",
                    DELETED: "deleted",
                    PENDING_PAYMENT: "pending_payment"
                },
                m = (p.ACTIVE, p.ACTIVE, p.IN_MODERATION, p.IN_MODERATION, p.REJECTED, p.REJECTED, p.DEACTIVATED, p.DEACTIVATED, p.DELETED, p.DELETED, p.PENDING_PAYMENT, p.PENDING_PAYMENT, "show_stats"),
                g = "display_mode",
                f = "orders_display_mode",
                h = {
                    GRID: "card",
                    LIST: "list"
                },
                y = 12,
                b = ["phoneView", "conversation", "view", "bump", "publish", "delete"],
                _ = {
                    BOOST: {
                        label: "av.actions.boost",
                        variant: "caption",
                        fontWeight: n.Z.bold,
                        size: "xs",
                        color: "mars_normal",
                        backgroundColor: "mars_lighter",
                        icon: "RocketLine",
                        uppercase: !0,
                        tag: o.D.USER_ACCOUNT__BOOST_AD_CLICKED
                    },
                    EDIT: {
                        label: "av.account.card.menu.modify",
                        variant: "caption",
                        fontWeight: n.Z.bold,
                        size: "sm",
                        color: "sea_normal",
                        backgroundColor: "sea_lighter",
                        icon: "EditLine",
                        uppercase: !0,
                        tag: o.D.USER_ACCOUNT__EDIT_AD_CLICKED
                    },
                    REACTIVATE: {
                        label: "av.account.card.btn.reactive",
                        variant: "caption",
                        fontWeight: n.Z.bold,
                        size: "sm",
                        color: "sea_normal",
                        backgroundColor: "sea_lighter",
                        icon: "LockLine",
                        uppercase: !0,
                        withMargin: !0
                    },
                    DELETE_DEFINITELY: {
                        label: "av.account.card.btn.delete-definitely",
                        variant: "caption",
                        fontWeight: n.Z.bold,
                        size: "xs",
                        color: "wine_normal",
                        backgroundColor: "wine_lighter",
                        icon: "Delete2Line",
                        uppercase: !0
                    },
                    PAY: {
                        label: "av.account.card.btn.pay",
                        variant: "caption",
                        fontWeight: n.Z.bold,
                        size: "sm",
                        color: "spring_normal",
                        backgroundColor: "spring_lighter",
                        icon: "SecurePaymentLine",
                        uppercase: !0,
                        withMargin: !0,
                        tag: o.D.USER_ACCOUNT__CLICKED_ON_PAY
                    }
                },
                A = {
                    INITIATED: {
                        label: "av.account.status.orders.initiated",
                        value: "INITIATED",
                        taggingValue: "initited_orders"
                    },
                    PREPARING: {
                        label: "av.account.status.orders.preparing",
                        value: "PREPARING",
                        taggingValue: "orders_ready"
                    },
                    DELIVERING: {
                        label: "av.account.status.orders.delivering",
                        value: "DELIVERING",
                        taggingValue: "order_ondelivery"
                    },
                    DELIVERED: {
                        label: "av.account.status.orders.delivered",
                        value: "DELIVERED",
                        taggingValue: "deliveredorder"
                    },
                    CANCELLED: {
                        label: "av.account.status.orders.canceled",
                        value: "CANCELLED",
                        taggingValue: "canceled_order"
                    }
                },
                E = [{
                    label: "av.account.filter.orders.initiated",
                    value: A.INITIATED.value
                }, {
                    label: "av.account.filter.orders.preparing",
                    value: A.PREPARING.value
                }, {
                    label: "av.account.filter.orders.delivering",
                    value: A.DELIVERING.value
                }, {
                    label: "av.account.filter.orders.delivered",
                    value: A.DELIVERED.value
                }, {
                    label: "av.account.filter.orders.canceled",
                    value: A.CANCELLED.value
                }],
                S = "/phoenix-assets/imgs/account/no-image-placeholder.jpg",
                R = {
                    email: "email",
                    name: "name",
                    "description.long": "desc",
                    "description.short": "shortDesc",
                    category: "category",
                    "logo.defaultPath": "imageLogo",
                    locations: "locations",
                    phones: "phones",
                    website: "storeUrl",
                    "points.count": "storePoints",
                    "points.expiryDate": "storePointsExpiry",
                    startDate: "storeStartDate",
                    expiryDate: "storeEndDate",
                    offersDelivery: "offersDelivery",
                    membership: "membership",
                    isVerifiedSeller: "isVerifiedSeller"
                }
        },
        60559: function(e, t, a) {
            "use strict";
            a.d(t, {
                ti: function() {
                    return f
                },
                Yv: function() {
                    return d
                },
                GZ: function() {
                    return g
                },
                KV: function() {
                    return m
                },
                lR: function() {
                    return v
                },
                OZ: function() {
                    return p
                }
            });
            var n = a(59499),
                o = a(94533),
                r = a(31823),
                i = {
                    src: "/_next/static/media/refused-img.87e7d1b9.svg",
                    height: 238,
                    width: 329
                },
                s = {
                    src: "/_next/static/media/ad-activated.4e56bb23.svg",
                    height: 202,
                    width: 328
                },
                c = {
                    src: "/_next/static/media/active-limit.99729ab8.svg",
                    height: 223,
                    width: 364
                };

            function u(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : u(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var d = function(e, t, a) {
                    return "".concat(e(r.B3[t ? "SHOP" : "PRIVATE_USER"][a].LABEL), " | ").concat(e(t ? "av.account.pageTitle.shop" : "av.account.pageTitle.private"))
                },
                v = function(e) {
                    var t = e.operationModalParams,
                        a = e.handleCloseModalClick,
                        n = e.handleAdActivatedClick,
                        o = e.handlePayIfAdActivatedLimit,
                        r = e.handleConfirmDeleteDeactivatedAdClick,
                        u = e.__t;
                    switch (null === t || void 0 === t ? void 0 : t.type) {
                        case "AD_ACTIVATED":
                            return {
                                logo: s,
                                title: u("av.account.modals.activate.ad.title"),
                                text: u("av.account.modals.activate.ad.text"),
                                ctaText: u("av.account.modals.activate.ad.btn"),
                                cta: n
                            };
                        case "REFUSE_DELETE_AD":
                            return {
                                logo: i,
                                title: u("av.account.modals.delete.refused.title"),
                                text: u("av.account.modals.delete.refused.text", {
                                    days: null === t || void 0 === t ? void 0 : t.dayBeforeDelete
                                }),
                                ctaText: u("av.account.modals.delete.refused.btn"),
                                cta: a
                            };
                        case "AD_ACTIVATED_LIMIT":
                            return {
                                logo: c,
                                title: u("av.account.modals.activate.limit.title"),
                                text: u("av.account.modals.activate.limit.text"),
                                ctaText: u("av.account.modals.activate.limit.btn"),
                                cta: o
                            };
                        default:
                            return {
                                logo: null,
                                title: u("av.account.modals.delete.confirmation.title"),
                                text: u("av.account.modals.delete.confirmation.text"),
                                ctaText: u("av.account.modals.delete.confirmation.btn"),
                                cta: r
                            }
                    }
                },
                p = function(e, t) {
                    var a;
                    return null === e || void 0 === e || null === (a = e.slice()) || void 0 === a ? void 0 : a.sort((function(e, t) {
                        return new Date(null === t || void 0 === t ? void 0 : t.modifiedAt) - new Date(null === e || void 0 === e ? void 0 : e.modifiedAt)
                    }))
                },
                m = function(e) {
                    return r.sM.map((function(t) {
                        return e.filter((function(e) {
                            return e.name === t
                        }))[0]
                    })).map((function(e) {
                        var t = e.name,
                            a = e.data,
                            n = e.total;
                        return {
                            name: t,
                            data: a.slice().reverse().map((function(e) {
                                var t = e.x,
                                    a = e.y;
                                return {
                                    x: new Date(t),
                                    y: a
                                }
                            })),
                            total: n
                        }
                    }))
                },
                g = function(e) {
                    switch (e) {
                        case "LAST_30_DAYS":
                            return 30;
                        case "LAST_15_DAYS":
                            return 15;
                        case "LAST_7_DAYS":
                            return 7;
                        case "ALLTIME":
                            return (0, o.Z)(new Date, new Date(2021, 12, 1)) + 1
                    }
                },
                f = function(e, t, a) {
                    return e.map((function(e) {
                        var n;
                        return l(l({}, e), {}, a ? {
                            label: "".concat(t(e.label), " (").concat((null === a || void 0 === a || null === (n = a[e.id]) || void 0 === n ? void 0 : n.adsCount) || 0, ")")
                        } : {
                            label: t(e.label)
                        })
                    }))
                }
        },
        68683: function(e, t, a) {
            "use strict";
            a.d(t, {
                b: function() {
                    return c
                }
            });
            var n = a(90116),
                o = a(50029),
                r = a(87794),
                i = a.n(r),
                s = a(16700);

            function c(e, t, a) {
                return u.apply(this, arguments)
            }

            function u() {
                return (u = (0, o.Z)(i().mark((function e(t, a, o) {
                    var r, c;
                    return i().wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return r = null, e.prev = 1, e.next = 4, t.apply(void 0, (0, n.Z)(a));
                            case 4:
                                c = e.sent, r = null === c || void 0 === c ? void 0 : c.status, e.next = 11;
                                break;
                            case 8:
                                e.prev = 8, e.t0 = e.catch(1), s.Z.error(o, e.t0);
                            case 11:
                                return e.abrupt("return", r);
                            case 12:
                            case "end":
                                return e.stop()
                        }
                    }), e, null, [
                        [1, 8]
                    ])
                })))).apply(this, arguments)
            }
        },
        96977: function(e, t, a) {
            "use strict";
            a.d(t, {
                Q: function() {
                    return s
                },
                p: function() {
                    return i
                }
            });
            var n = a(67294),
                o = a(74062),
                r = a(17153),
                i = {
                    fr: {
                        __t: new o.Z(r.a.FR.CODE, {
                            fr: {
                                "av.common.homepage": "Accueil",
                                "av.common.ad-insert": "D\xe9poser une annonce",
                                "av.common.ad-insert.short": "D\xe9poser",
                                "av.common.ad-insert.publish": "Publier une annonce",
                                "av.common.ad-insert.publish.short": "Publier",
                                "av.common.chat": "Chat",
                                "av.common.my-ads": "Mes annonces",
                                "av.common.my-orders": "Mes commandes",
                                "av.common.classified.short": "Annonces",
                                "av.common.classified.zero-results": "0 annonces",
                                "av.common.classified.zero-results.for": "pour",
                                "av.common.classified.zero-results.in": "\xe0",
                                "av.common.classified.shops.zero-results": "0 boutiques",
                                "av.common.favorites": "Mes favoris",
                                "av.common.favorites.short": "Favoris",
                                "av.common.stats": "Mes statistiques",
                                "av.common.stats.short": "Statistiques",
                                "av.common.settings.short": "R\xe9glages",
                                "av.common.account": "Mon compte",
                                "av.common.account.short": "Compte",
                                "av.common.search": "Rechercher des annonces",
                                "av.common.search.avito": "Rechercher sur {{category}} {{type}}",
                                "av.common.search.short": "Rechercher",
                                "av.common.shops.short": "Boutiques",
                                "av.common.magazine": "Magazine",
                                "av.common.greeting": "Bonjour,",
                                "av.common.separator_txt": "Ou avec",
                                "av.common.our_services": "NEUF",
                                "av.common.immoNeuf": "Immo neuf",
                                "av.common.immoNeuf.description": "Des biens immobiliers neufs \xe0 d\xe9couvrir partout au Maroc",
                                "av.common.autoNeuf": "Auto neuf",
                                "av.common.autoNeuf.description": "Le r\xe9f\xe9rentiel des v\xe9hicules neufs au Maroc",
                                "av.common.currency": "DH",
                                "av.common.years": "ans",
                                "av.common.cancel": "Annuler",
                                "av.common.country": "Maroc",
                                "av.common.page": "Page",
                                "av.common.action.validate": "valider",
                                "av.common.action.delete": "Effacer",
                                "av.common.city": "Ville",
                                "av.common.area": "Secteur",
                                "av.common.areas": "Secteurs",
                                "av.common.min": "Min",
                                "av.common.max": "Max",
                                "av.common.error": "Une erreur est survenue, Veuillez r\xe9essayer!",
                                "av.common.error.wentWrong": "Un probl\xe8me est survenu!",
                                "av.common.error.retry": "R\xe9essayer",
                                "av.common.error.contactSupport": "Si le probl\xe8me persiste, veuillez contacter le support client. {{csPhone}}",
                                "av.common.new": "new",
                                "av.common.description": "Description",
                                "av.common.price.dhs": "{{price}} Dhs",
                                "av.common.price.points": "{{price}} Points",
                                "av.common.location_category": "{{category}} dans {{location}}",
                                "av.common.avito": "Avito",
                                "av.common.lang_switch": "\u0627\u0644\u0639\u0631\u0628\u064a\u0629",
                                "av.common.download": "T\xe9l\xe9charger",
                                "av.common.allRegions": "Toutes les villes",
                                "av.common.allCity": "Toute la ville",
                                "av.common.allMorocco": "Tout le Maroc",
                                "av.common.allModels": "Tous les mod\xe8les",
                                "av.common.allBreeds": "Toutes les races",
                                "av.common.welcome": "Bienvenue sur Avito",
                                "av.common.homePage": "Page D'accueil",
                                "av.common.paymentSuccess.pageName": "Paiement r\xe9ussi",
                                "av.common.paymentFailure.pageName": "Paiement \xe9chou\xe9",
                                "av.common.congrats": "F\xe9licitations {{name}}",
                                "av.common.address": "Adresse",
                                "av.common.calendar": "Calendrier",
                                "av.common.apply": "Appliquer",
                                "av.common.availability": "Disponibilit\xe9",
                                "av.common.total": "Total",
                                "av.common.dismiss": "J'ai compris",
                                "av.common.price": "Prix",
                                "av.common.save": "Sauvegarder",
                                "av.common.name": "Nom",
                                "av.common.fullName": "Nom et pr\xe9nom",
                                "av.common.email": "E-mail",
                                "av.common.lastName.placeholder": "Votre nom",
                                "av.common.fullName.placeholder": "Nom complet",
                                "av.common.phone.placeholder": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.common.age.placeholder": "\xc2ge",
                                "av.common.phone": "T\xe9l\xe9phone",
                                "av.common.send": "Envoyer",
                                "av.common.forgotPassword": "Mot de passe oubli\xe9 ?",
                                "av.common.close": "Fermer",
                                "av.common.month": "mois",
                                "av.common.medias.images": "Images",
                                "av.common.medias.videos": "Videos",
                                "av.common.categories": "Cat\xe9gories",
                                "av.common.location": "Localisation",
                                "av.common.magazine.title": "Nos Articles Avito Magazine",
                                "av.common.admin.alert": "Bonjour admin, vous \xeates connect\xe9 au nom de cet utilisateur, notez que vos actions seront enregistr\xe9es \xe0 l'aide de votre compte admin, votre session admin expire le {{expiresIn}}",
                                "av.common.confirm": "Confirmer",
                                "av.common.select": "S\xe9lectionner",
                                "av.common.privacy.policy.cgu.text": "J\u2019ai lu et j\u2019accepte",
                                "av.common.privacy.policy.cgu.link": "les conditions d\u2019utilisation.",
                                "av.common.privacy.policy.tdp.text": "Et je donne mon accord",
                                "av.common.privacy.policy.tdp.link": "au traitement de mes donn\xe9es personnelles.",
                                "av.common.privacy.stay_informed.text": "Je veux etre inform\xe9(e) de nouveaut\xe9s.",
                                "av.common.promotion.banner.cta": "S'INSCRIRE",
                                "av.common.promotion.banner.avitoexpo.content": "SALON DE L'IMMOBILIER NEUF 2024",
                                "av.common.promotion.app-banner.header": "Voir Avito sur...",
                                "av.common.promotion.app-banner.avito-app": "Application Avito",
                                "av.common.promotion.app-banner.open": "Ouvrir",
                                "av.common.promotion.app-banner.continue": "Continuer",
                                "av.common.category-cards.heading": "Que cherchez-vous?",
                                "av.common.category-cards.cta": "Voir plus",
                                "av.common.step": "\xc9tape {{step}}",
                                "av.common.call": "Appeler",
                                "av.common.choice": "ou",
                                "av.common.visit.external.link.cta": "Visiter ici",
                                "av.common.choose.localisation": "Choisir ville - secteur",
                                "av.common.suggestions": "Suggestions",
                                "av.common.choose.area": "Ajouter ville - secteur",
                                "av.common.choose.brand": "Choisir marque - mod\xe8le",
                                "av.common.choose.model": "Ajouter marque - mod\xe8le",
                                "av.common.category": "Categorie",
                                "av.common.more-info": "Plus d'information",
                                "av.common.exact-number": "Nombre exact",
                                "av.common.see-all": "Voir tout",
                                "av.common.search-in": "Rechercher dans {{name}}",
                                "av.common.seller.my-products": "Mes produits",
                                "av.common.seller.my-payments": "Mes paiements",
                                "av.common.footer.links.aide": "Aide et renseignements",
                                "av.common.footer.avito.copyright": "Avito Group 2012-{{currentYear}}",
                                "av.common.discovery.slider.title.premium": "S\xe9lection Premium",
                                "av.common.discovery.slider.title.private": "Nouvelles annonces de particuliers",
                                "av.common.discovery.slider.title.shop": "Nouvelles annonces des professionnels",
                                "av.common.discovery.slider.title.recent-searches": "Recherches r\xe9centes",
                                "av.common.sidebar.immoLoan": "Cr\xe9dit Immobilier",
                                "av.common.sidebar.consoLoan": "Cr\xe9dit conso",
                                "av.common.sidebar.immoExpo": "Salon de l'immobilier neuf",
                                "av.common.sidebar.liveChat": "Parler \xe0 un agent",
                                "av.common.oauth.fb.button_text": "Se connecter",
                                "av.common.oauth.fb.error.request_failed": "Veuillez r\xe9essayer de vous connecter avec facebook.",
                                "av.common.oauth.fb.error.declined_field": "Il est n\xe9cessaire que vous partagiez votre email pour vous connecter avec Facebook",
                                "av.common.oauth.fb.error.retry": "Quelque chose ne va pas, veuillez r\xe9essayer plus tard.",
                                "av.page.title.default": "Annonces au Maroc | Avito.ma",
                                "av.page.description.default": "Annonces au Maroc gratuites. Vente et location d'immobilier: maisons, appartements. V\xe9hicules : voitures occasion. Biens domestiques et personnels.",
                                "av.page.adIn.pageTitle": "Cr\xe9ation d'annonce | {{vertical}}",
                                "av.page.loading": "Chargement..",
                                "av.page.error.default.error_message": "HTTP {{statusCode}} Error",
                                "av.page.error.default.error_summary": "Une erreur HTTP {{statusCode}} s'est produite lors d'une tentative d'acc\xe8s {{asPath}}",
                                "av.page.error.404.error_message": "Ce lien est introuvable!",
                                "av.page.error.404.error_summary": "D\xe9sol\xe9, mais votre demande a entra\xeen\xe9 une erreur.",
                                "av.page.error.500.error_message": "Erreur Interne du Serveur",
                                "av.page.error.500.error_summary": "Une erreur de serveur interne s'est produite.",
                                "av.page.error.adNotFound": "D\xe9sol\xe9, mais cette annonce est introuvable  ",
                                "av.page.error.adNotFound.description.title": "Causes possibles : <br/> {{causes}} <br/> Merci de votre confiance ! ",
                                "av.page.error.adNotFound.description.cause1": "Le bien a d\xe9j\xe0 \xe9t\xe9 vendu et l\u2019annonceur a supprim\xe9 son annonce",
                                "av.page.error.adNotFound.description.cause2": "Si vous venez de recevoir l\u2019email de validation de votre annonce, il faut compter un d\xe9lai d\u2019une heure avant qu\u2019elle ne soit visible sur le site.",
                                "av.page.error.adNotFound.description.cause3": "Le lien sur lequel vous avez cliqu\xe9 peut \xeatre invalide. Nous vous conseillons de le v\xe9rifier.",
                                "av.actions.go_to_home_page": "ALLER \xc0 LA PAGE D'ACCUEIL",
                                "av.actions.go_to_previous_page": "Page pr\xe9c\xe9dente",
                                "av.actions.choose": "Choisissez",
                                "av.actions.choose.category": "Choisissez une cat\xe9gorie",
                                "av.actions.boost": "Booster",
                                "av.actions.show_more": "Afficher plus",
                                "av.actions.show_less": "Afficher moins",
                                "av.actions.call": "Afficher le num\xe9ro",
                                "av.actions.show_whatsapp": "Chat via WhatsApp",
                                "av.actions.contact": "Contacter l'annonceur",
                                "av.actions.logout": "Se d\xe9connecter",
                                "av.actions.login": "Se connecter",
                                "av.page.ad.in.success.body.subheading1.text": "Votre annonce sera v\xe9rifi\xe9e par notre \xe9quipe",
                                "av.page.ad.in.success.body.subheading2.text": "Nous venons de vous envoyer un mail de confirmation",
                                "av.page.ad.in.success.body.helper.text": "Votre annonce sera active dans 60 minutes",
                                "av.page.ad.in.success.action.textVacRental": "Apr\xe8s acceptation de votre annonce, vous pouvez g\xe9rer son calendrier (bloquer ou d\xe9bloquer des dates) \xe0 partir de `Mon Compte/Mes Annonces/Actives`",
                                "av.page.ad.in.max.photos": "Photos ({{max}} maximum)",
                                "av.page.ad.in.cars.subject": "{{brand}} {{model}} {{fuel}} {{regdate}}",
                                "av.page.ad.in.realestate.offerSubject": "{{categorySlug}} {{surface}} en {{transactionSlug}} \xe0 {{regionSlug}}",
                                "av.page.ad.in.realestate.demandSubject": "{{transactionSlug}} {{categorySlug}} {{surface}} \xe0 {{regionSlug}}",
                                "av.validation.required": "Veuillez renseigner ce champ",
                                "av.validation.minLength": "Minimum {{min}} caract\xe8res",
                                "av.validation.maxLength": "Maximum {{max}} caract\xe8res",
                                "av.validation.minValue": "Minimum {{min}}",
                                "av.validation.minValue.price": "Ce prix est sup\xe9rieur au maximum autoris\xe9",
                                "av.validation.maxValue": "Maximum {{max}}",
                                "av.validation.number": "Doit \xeatre un nombre",
                                "av.validation.email": "Doit \xeatre un email",
                                "av.validation.phone": "Doit \xeatre un num\xe9ro de t\xe9l\xe9phone valide",
                                "av.validation.phone_or_email": "Doit \xeatre un email ou un num\xe9ro de t\xe9l\xe9phone valide",
                                "av.validation.regex": "Valeur non support\xe9e",
                                "av.validation.regex.no_email_in_text": "Ce champ ne doit pas contenir un e-mail",
                                "av.validation.regex.no_phone_in_text": "Ce champ ne doit pas contenir un num\xe9ro de t\xe9l\xe9phone",
                                "av.validation.regex.no_url_in_text": "Ce champ ne doit pas contenir des liens ",
                                "av.validation.regex.no_special_chars": 'Ce champ ne doit pas contenir les caract\xe8res: ! = " : ; _ , % +',
                                "av.form.ad.prevent.exit.message": "Les modifications que vous avez apport\xe9es peuvent ne pas \xeatre enregistr\xe9es.",
                                "av.category.menu.select": "S\xe9lectionner la cat\xe9gorie",
                                "av.category.menu.back": "Retour \xe0 toutes les cat\xe9gories",
                                "av.page.ad.in.title.generation.immo": "{{categoryName}} {{habitableSize}} {{city}}",
                                "av.page.ad.in.title.generation.auto": "{{brand}} {{model}} {{fuelType}} {{gearType}} {{year}} {{city}}",
                                "av.lap.limitation": "{{adNbr}} / {{limit}} Annonces gratuites dans la cat\xe9gorie {{category}}",
                                "av.lap.reached.limitation.info": "Cher utilisateur, merci d\u2019utiliser Avito. Vous avez ins\xe9rez {{adNbr}} sur {{limit}} gratuitement dans la cat\xe9gorie {{category}}. Pass\xe9 ce plafond le choix d'un pack de visibilit\xe9 est requis pour maintenir notre service en termes de qualit\xe9, de s\xe9curit\xe9 et d'h\xe9bergement.",
                                "av.lap.exceeded.limitation.info": "Cher utilisateur, merci d'utiliser Avito. Pour poster une {{adNbr}}\xe8me annonce, le choix d'un pack est requis pour maintenir notre service en termes de qualit\xe9, de s\xe9curit\xe9 et d'h\xe9bergement. En souscrivant \xe0 une des offres suivantes, vous b\xe9n\xe9ficiez d\u2019un maximum de visibilit\xe9 et vous augmentez vos chances pour vendre rapidement. Merci pour votre contribution",
                                "av.lap.reached.shop.limitation.warning": "Cher utilisateur, merci d'utiliser Avito. Vous avez ins\xe9r\xe9 {{adNbr}} annonces dans la cat\xe9gorie {{category}}. Vous \xeates \xe9ligible aux avantages de la boutique Avito et \xe0 des remises exceptionnelles. Vous pouvez nous contacter sur {{csPhone}} et un agent Avito vous proposera une offre \xe0 votre mesure. Si vous voulez continuer l\u2019insertion vous pouvez choisir un des packs suivants",
                                "av.lap.reached.private.limitation.warning": "Cher utilisateur, merci d'utiliser Avito. Pour poster votre annonce, le choix d'un pack est requis pour maintenir notre service en termes de qualit\xe9, de s\xe9curit\xe9 et d'h\xe9bergement. En souscrivant \xe0 une des offres suivantes, vous b\xe9n\xe9ficiez d\u2019un maximum de visibilit\xe9 et vous augmentez vos chances pour vendre rapidement. Merci pour votre contribution",
                                "av.form.ad.stepper.step1.title": "Commencez par l\u2019essentiel",
                                "av.form.vehicule.ad.stepper.step2.title": "D\xe9crivez-nous votre v\xe9hicule",
                                "av.form.emploi.ad.stepper.step2.title": "D\xe9crivez-nous votre annonce",
                                "av.form.misc.ad.stepper.step2.title": "D\xe9crivez-nous votre bien",
                                "av.form.immobilier.ad.stepper.step2.title": "D\xe9crivez-nous votre bien",
                                "av.form.ad.stepper.step4.title": "Vos informations",
                                "av.form.ad.sections.general.title": "Informations g\xe9n\xe9rales",
                                "av.form.ad.sections.general.info": 'les champs avec (<span style="color:#d13649">*</span>) sont obligatoires',
                                "av.form.immobilier.ad.category": "Type de bien",
                                "av.form.vehicule.ad.category": "Type de v\xe9hicule",
                                "av.form.misc.ad.category": "Type de bien",
                                "av.form.emploi.ad.category": "Type d\u2019annonce",
                                "av.form.ad.city.field.label": "Ville et secteur",
                                "av.form.ad.city.select.placeholder": "Choisissez votre ville et Secteur",
                                "av.form.ad.city.select.title": "S\xe9lectionner La Ville",
                                "av.form.ad.city.select.search.placeholder": "Rechercher dans Villes",
                                "av.form.ad.city.select.subTitle": "S\xe9lectionner le Secteur",
                                "av.form.ad.city.select.subSearch.placeholder": "Rechercher dans Secteurs",
                                "av.form.ad.city.select.prev.label": "Retour \xe0 la liste des Villes",
                                "av.form.ad.phone.field.label": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.form.ad.phone.field.placeholder": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.form.ad.delivery": "Livraison",
                                "av.form.ad.serviceAvito": " Service Avito",
                                "av.form.ad.activateDelivery": "Livraison Avito active pour cet article",
                                "av.extended.delivery.notice.message": "Votre recherche a \xe9t\xe9 \xe9tendue \xe0 des annonces avec livraison partout au Maroc.",
                                "av.extended.delivery.cancel.cta": "Annuler",
                                "av.form.ad.type": "Type de transaction",
                                "av.form.ad.city.placeholder": "Tapez la ville",
                                "av.form.ad.area.placeholder": "Tapez le secteur",
                                "av.form.ad.address.placeholder": "Num\xe9ro et nom de la rue",
                                "av.form.1000.ad.sections.adParams.title": "D\xe9tails du bien",
                                "av.form.2000.ad.sections.adParams.title": "D\xe9tails du v\xe9hicule",
                                "av.form.3000.ad.sections.adParams.title": "D\xe9tails du bien",
                                "av.form.4000.ad.sections.adParams.title": "D\xe9tails du bien",
                                "av.form.5000.ad.sections.adParams.title": "D\xe9tails du bien",
                                "av.form.6000.ad.sections.adParams.title": "D\xe9tails du bien",
                                "av.form.7000.ad.sections.adParams.title": "D\xe9tails du bien",
                                "av.form.8000.ad.sections.adParams.title": "D\xe9tails du bien",
                                "av.form.9000.ad.sections.adParams.title": "D\xe9tails du bien",
                                "av.form.ad.sections.adParams.extra.title": "D\xe9tails suppl\xe9mentaires",
                                "av.form.ad.sections.adParams.extra.subTitle": " Vous pouvez s\xe9lectionner un ou plusieurs crit\xe8res.",
                                "av.form.ad.sections.availability.title": "Disponibilit\xe9 de votre bien",
                                "av.form.ad.sections.availability.subtitle": "Disponible \xe0 partir d'aujourd'hui, sinon mettez \xe0 jour le calendrier",
                                "av.availability.onboarding.body": "Mettez \xe0 jour votre calendrier en bloquant les jours indisponibles.<br/><br/>Vous pouvez toujours modifier ce calendrier \xe0 partir de <b>Mon compte</b> / <b>Annonces actives</b>",
                                "av.form.ad.sections.availability.calendar.blockMonth": "Bloquer mois",
                                "av.form.ad.sections.availability.calendar.unblockMonth": "deBloquer mois",
                                "av.availability.modal.title": "Bloquer ou d\xe9bloquer des dates",
                                "av.vacRental.adview.calendar.nights.label": "Total de s\xe9jour",
                                "av.vacRental.search.calendar.nights.label": "S\xe9jour",
                                "av.vacRental.adview.calendar.nights": "{{nightCount}} Nuits",
                                "av.vacRental.adview.calendar.checkin": "Arriv\xe9e",
                                "av.vacRental.adview.calendar.checkout": "D\xe9part",
                                "av.vacRental.adview.calendar.total": "{{total}} DH",
                                "av.vacRental.adview.calendar.insctuctions.checkin": "S\xe9lectionner votre date d'arriv\xe9e",
                                "av.vacRental.adview.calendar.insctuctions.checkout": "S\xe9lectionner votre date de d\xe9part",
                                "av.vacRental.adview.calendar.notice.head": "dates insdisponible",
                                "av.vacRental.adview.calendar.notice.body": "La p\xe9riode s\xe9lectionn\xe9e contient des dates indisponibles",
                                "av.vacRental.myaccount.onboarding.title": "G\xe9rer votre annonce",
                                "av.vacRental.myaccount.onboarding.text": "Cliquer ici pour modifier, supprimer votre annonce ou bien g\xe9rer le calendrier des r\xe9servations\u2026.",
                                "av.vacRental.myaccount.card.title": "location de vacances",
                                "av.vacRental.myaccount.card.subTitle": "G\xe9rer la disponibilit\xe9 de votre bien pour plus de visibilit\xe9",
                                "av.vacRental.myaccount.card.seeComment": "voir comment",
                                "av.vacRental.perNight": "/Nuit",
                                "av.vacRental.titleCaption": "exemple",
                                "av.vacRental.available": "Disponible",
                                "av.vacRental.notAvailable": "Reserv\xe9",
                                "av.form.emploi.ad.sections.details.title": "Description de l'annonce",
                                "av.form.immobilier.ad.sections.details.title": "Description du bien",
                                "av.form.vehicule.ad.sections.details.title": "Description du v\xe9hicule",
                                "av.form.misc.ad.sections.details.title": "Description du bien",
                                "av.form.ad.subject": "Titre de l'annonce",
                                "av.form.ad.subject.placeholder": "Titre de l'annonce",
                                "av.form.ad.body": "Texte de l\u2019annonce",
                                "av.form.1000.ad.body.placeholder": "Ensoleill\xe9 toute la journ\xe9e avec un emplacement id\xe9al, proche de toute commodit\xe9",
                                "av.form.ad.price_night": "Prix/nuit",
                                "av.form.ad.price.trick": "Astuce !",
                                "av.form.ad.price_controller_message": "Une annonce avec un prix total est 5 fois plus consult\xe9e qu'une annonce avec un prix par m2.",
                                "av.form.ad.price_recommendation_message": "Prix sugg\xe9r\xe9 entre <b>{{minPrice}} Dhs</b> et <b>{{maxPrice}} Dhs</b>. <br /> <br /> A partir des informations renseign\xe9es et des prix affich\xe9s sur less annonces en ligne de professionnels pour ce m\xeame type d'appartement.",
                                "av.form.ad.cv_mandatory": "Cochez cette case si vous voulez que le CV soit obligatoire",
                                "av.form.ad.videos": "Videos",
                                "av.form.ad.video.tips.1": "Dur\xe9e vid\xe9o : les vid\xe9os de plus de 1 min ne seront pas accept\xe9es",
                                "av.form.ad.video.tips.2": "Taille  vid\xe9o : les vid\xe9os de plus 30 Mo ne seront pas accept\xe9es",
                                "av.form.ad.video.tips.3": "Orientation : Format horizontal(paysage) uniquement (tenez le t\xe9l\xe9phone sur le c\xf4t\xe9 pour enregistrer)",
                                "av.form.ad.video.tips.4": "Musique : uniquement de la musique libre de droits pour laquelle vous disposez de la licence n\xe9cessaire",
                                "av.form.ad.videos.upload.error.duration": "la dur\xe9e de la vid\xe9o doit \xeatre inf\xe9rieure \xe0 1 Min",
                                "av.form.ad.videos.upload.error.weight": " la taille de la vid\xe9o doit \xeatre inf\xe9rieure \xe0 30 Mo",
                                "av.form.ad.images.upload.cta": "Ajouter",
                                "av.form.ad.images.tips.title": "Conseils",
                                "av.form.ad.images.tips.1": "Une annonce avec photos est 10 fois plus consult\xe9e qu'une annonce sans photos",
                                "av.form.ad.images.tips.2": "Prenez de belles photos bien \xe9clair\xe9es.",
                                "av.form.ad.images.tips.3": "C'est la premi\xe8re impression qui compte!",
                                "av.form.ad.images.upload.failed": "Image(s) non support\xe9e(s)!",
                                "av.form.ad.images.upload.loading": "Veuillez patientez quelques instants, nous chargeons vos m\xe9dias",
                                "av.form.ad.images.upload.max_images.modalHead": "Jusqu\u2019\xe0 8 photos",
                                "av.form.ad.images.upload.max_images.modalBody": "Vous pouvez d\xe9sormais ajouter jusqu\u2019\xe0 8 photos gratuitement pour d\xe9crire vos annonces.",
                                "av.form.ad.images.upload.max_images.modalCta": "Ok, parfait !",
                                "av.upload.reorder.hint": "R\xe9organisez les photos pour modifier la couverture",
                                "av.upload.idle": "Faites glisser une image \xe0 t\xe9l\xe9charger ou cliquez pour en rechercher une",
                                "av.upload.dragging": "Glisser l'image ici",
                                "av.upload.image.limit": "Limite des images a ajouter est atteinte!",
                                "av.upload.video.limit": "Limite des vid\xe9os a ajouter est atteinte!",
                                "av.upload.video.warning": "La vid\xe9o doit \xeatre en format horizontal (paysage) avec une dur\xe9e moins de 1min et une taille moins de 30 Mo.",
                                "av.upload.error.fileType.image": "Le fichier doit etre une photo",
                                "av.upload.error.fileType.video": "Le fichier doit etre une video",
                                "av.upload.success": "Le fichier a \xe9t\xe9 import\xe9 avec succ\xe8s",
                                "av.upload.error": "Une erreur est survenue lors de l'importation du fichier!",
                                "av.form.user.email.placeholder": "exemple@domaine.com",
                                "av.form.user.password": "Mot de passe",
                                "av.form.user.phone.placeholder": "06XXXXXXXX",
                                "av.form.user.forgot.password.title-success": "Un lien de r\xe9initialisation a \xe9t\xe9 envoy\xe9.",
                                "av.form.user.forgot.password.text": "Veuillez saisir votre adresse e-mail, afin de recevoir un lien de r\xe9initialisation de votre mot de passe.",
                                "av.form.user.forgot.password.text-success": "Si vous ne recevez pas cet email, nous vous invitons \xe0 v\xe9rifier que l'email n'a pas \xe9t\xe9 redirig\xe9 dans vos Courriers ind\xe9sirables ou Spam de votre bo\xeete de r\xe9ception",
                                "av.form.user.forgot.password.error-text": "Adresse e-mail incorrecte ou inexistante.",
                                "av.user.member_since": "membre depuis",
                                "av.user.in_avito_since": "Sur Avito depuis",
                                "av.form.ad.sections.vas.title": "Vendre efficacement",
                                "av.form.ad.sections.vas.pack.title": "Veuillez choisir un pack et la dur\xe9e ci-dessous.",
                                "av.form.ad.sections.vas.notChoosen": "Veuillez choisir un pack",
                                "av.form.ad.sections.vas.subTitle": "Veuillez choisir un pack et la dur\xe9e pour garantir un maximum de visibilit\xe9 de votre annonce",
                                "av.form.ad.sections.vas.pack.subTitle": "le seuil d'insertion libre est atteint pour cette cat\xe9gorie. Veuillez choisir l'un des packs suivants pour finaliser votre insertion",
                                "av.form.ad.sections.vas.pack.boost.subTitle": "Les packs de boost vous garantissent l'augmentation de visibilit\xe9 de votre annonce, selon le pack choisis.",
                                "av.form.ad.sections.vas.paymentMessage": "Vous avez atteint la limite d'insertion gratuite pour cette cat\xe9gorie. Veuillez choisir un pack pour finaliser votre insertion.",
                                "av.form.ad.sections.vas.pack.overlay.message": "Ins\xe9rez au moins une image pour activer ce pack",
                                "av.form.ad.sections.vas.bump.title": "T\xeate de liste",
                                "av.form.ad.sections.vas.bump.description": "Pour une meilleur visibilit\xe9, votre annonce sera plac\xe9e en <b>T\xcaTE DE LISTE</b> automatiquement chaque jour \xe0 la m\xeame heure apr\xe8s le paiement",
                                "av.form.ad.sections.vas.bump.feature1": "Votre annonce sera republi\xe9e automatiquement une fois par jour et sera en t\xeate de la liste",
                                "av.form.ad.sections.vas.bump.feature2": "Votre annonce sera vue par 9 fois plus d\u2019acheteurs potentiels qu\u2019une annonce normale",
                                "av.form.ad.sections.vas.bump.feature3": "Gagnez plus de temps en activant l\u2019option \u201cRenouvellement d\u2019annonce\u201d",
                                "av.form.ad.sections.vas.gallery.title": "T\xeate de liste + Premium",
                                "av.form.ad.sections.vas.gallery.description": "Pour une meilleur visibilit\xe9, votre annonce sera automatiquement plac\xe9e tous les jours sur la section <b>PREMIUM</b> et sera en <b>T\xcaTE DE LISTE</b>",
                                "av.form.ad.sections.vas.gallery.feature1": "Affichez votre annonce dans la section Premium, un emplacement exclusif et privil\xe9gi\xe9 en grand format en t\xeate de la liste d\u2019annonces.",
                                "av.form.ad.sections.vas.gallery.feature2": "Votre annonce sera vue par 16 fois plus d\u2019acheteurs potentiels qu\u2019une annonce normale",
                                "av.form.ad.sections.vas.gallery.feature3": "Votre annonce sera republi\xe9e automatiquement chaque jour et sera en t\xeate de la liste",
                                "av.form.ad.sections.vas.special.title": "T\xeate de liste + Star",
                                "av.form.ad.sections.vas.special.description": "Pour une meilleur visibilit\xe9, votre annonce sera automatiquement plac\xe9e en <b>T\xcaTE DE LISTE</b> en plus d'une <b>Surbrillance</b> de l'arri\xe8re plan de l'annonce durant toute la p\xe9riode choisie.",
                                "av.form.ad.sections.vas.special.feature1": "Votre annonce sera re-publi\xe9e automatiquement chaque jour et en premi\xe8re position avec un arri\xe8re-plan unique et attractif",
                                "av.form.ad.sections.vas.special.feature2": "Votre annonce sera vue par 12 fois plus d\u2019acheteurs potentiels qu\u2019une annonce normale",
                                "av.form.ad.sections.vas.highlight.title": "T\xeate de liste + Star",
                                "av.form.ad.sections.vas.highlight.description": "Pour une meilleur visibilit\xe9, votre annonce sera automatiquement plac\xe9e en <b>T\xcaTE DE LISTE</b> en plus d'une <b>Surbrillance</b> de l'arri\xe8re plan de l'annonce durant toute la p\xe9riode choisie.",
                                "av.form.ad.sections.vas.highlight.feature1": "Affichez votre annonce dans la liste avec un arri\xe8re-plan diff\xe9rent et attractif",
                                "av.form.ad.sections.vas.highlight.feature2": "Votre annonce sera vue par 6 fois plus d\u2019acheteurs potentiels qu\u2019une annonce normale",
                                "av.form.ad.sections.vas.insertion.title": "Annonce Gratuite",
                                "av.form.ad.sections.vas.insertion.description": "Frais d'insertion appliqu\xe9s lorsque vous d\xe9passez la limite d'annonces gratuites",
                                "av.form.ad.sections.vas.insertionFees.title": "Insertion (sans pack)",
                                "av.form.ad.sections.vas.insertion.label": "D\xc9POSER SANS PACK",
                                "av.form.ad.sections.vas.pricePerDay": "{{pricePerDay}} Dh/Jour",
                                "av.form.ad.sections.vas.pricePerDay.shops": "{{pricePerDay}} Pt/Jour",
                                "av.form.ad.sections.vas.price.unit": "{{price}} {{priceUnit}}",
                                "av.form.ad.sections.vas.pricePerDay.priceUnit": "{{pricePerDay}} {{priceUnit}}/Jour",
                                "av.form.ad.sections.vas.totalPrice": "{{totalPrice}} Dh Total",
                                "av.form.ad.sections.vas.addPhotos": "Ajouter des images",
                                "av.form.ad.sections.vas.moreInfo": "Plus d'info",
                                "av.form.ad.sections.vas.bestSeller": "Best Seller",
                                "av.form.ad.sections.vas.xMoreViews": "{{views}}X plus de vues",
                                "av.form.ad.sections.vas.moreViews": "plus de vues",
                                "av.form.ad.sections.vas.moreLeads": "plus de leads",
                                "av.form.ad.sections.vas.currentlyActive": "Le Pack Activ\xe9 Actuellement",
                                "av.vas.slot.section.title": "Veuillez programmer votre boost",
                                "av.vas.slot.section.date": "Date de d\xe9but du boost",
                                "av.vas.slot.section.time": "Heure de d\xe9but du Boost",
                                "av.vas.slot.section.info": "L'application du pack sera effectu\xe9e de mani\xe8re al\xe9atoire pendant la plage d'horaire choisie.",
                                "av.payment.steps.vas": "Choix de pack",
                                "av.payment.steps.paymentMethod": "M\xe9thode de paiement",
                                "av.payment.steps.payment": "Paiement",
                                "av.payment.sections.ad.title": "Votre annonce",
                                "av.payment.sections.ad.subTitle": "Vendez vos bien rapidement en appliquant un de nos packs de renouvelement ci-dessous",
                                "av.payment.sections.order.title": "Votre commande",
                                "av.payment.sections.order.duration": "Dur\xe9e",
                                "av.payment.sections.order.totalPrice": "Prix Total",
                                "av.payment.sections.order.change": "Changer",
                                "av.payment.sections.paymentMethod.title": "M\xe9thode de paiement",
                                "av.payment.sections.paymentMethod.subTitle": "Veuillez choisir votre m\xe9thode de paiement.",
                                "av.payment.sections.paymentMethod.category.online": "Paiement en Ligne",
                                "av.payment.sections.paymentMethod.category.offline": "Paiement en \xe9speces",
                                "av.payment.sections.paymentMethod.category.apps": "Paiement par Application",
                                "av.payment.sections.paymentMethod.category.messaging": "Paiement par messagerie",
                                "av.payment.sections.paymentMethod.name.cc": "Carte Bancaire",
                                "av.payment.sections.paymentMethod.name.cod": "Paiement \xe0 la livraison",
                                "av.payment.sections.paymentMethod.name.fatourati": "Fatourati",
                                "av.payment.sections.paymentMethod.name.fatourati.plural": "agences Fatourati",
                                "av.payment.sections.paymentMethod.name.cashPlus": "Cash plus",
                                "av.payment.sections.paymentMethod.name.cashPlus.plural": "agences Cash plus",
                                "av.payment.sections.paymentMethod.name.tasshilat": "Tasshilat",
                                "av.payment.sections.paymentMethod.name.tasshilat.plural": "agences Tasshilat",
                                "av.payment.sections.paymentMethod.name.bankingApp": "Application Bancaire",
                                "av.payment.sections.paymentMethod.name.bankingApp.plural": "applications bancaires",
                                "av.payment.sections.paymentMethod.name.sms": "SMS",
                                "av.payment.sections.paymentMethod.name.avitoken": "Payer avec AviTokens",
                                "av.payment.sections.paymentMethod.description.cc": "Payer avec Mastercard ou Visa",
                                "av.payment.sections.paymentMethod.description.cod": "Payer en esp\xe8ces \xe0 la livraison",
                                "av.payment.sections.paymentMethod.description.fatourati": "Payer en esp\xe8ces dans une agence",
                                "av.payment.sections.paymentMethod.description.cashPlus": "Payer en esp\xe8ces dans une agence",
                                "av.payment.sections.paymentMethod.description.tasshilat": "Payer en esp\xe8ces dans une agence",
                                "av.payment.sections.paymentMethod.description.bankingApp": "Payez sur une application ou site bancaire ",
                                "av.payment.sections.paymentMethod.description.avitoken": "Paiement en utilisant votre solde des Avitokens",
                                "av.payment.ccRedirect.heading": "Votre s\xe9curit\xe9 est notre priorit\xe9",
                                "av.payment.ccRedirect.subHeading": "Vous serez redirig\xe9s pour effectuer votre paiement, veuillez ne pas cliquer sur retour ou actualiser jusqu'\xe0 rechargement de votre page\u2026",
                                "av.payment.sections.payment.invoice.title": "D\xe9tails de la facture",
                                "av.payment.sections.payment.invoice.vendor": "Marchand",
                                "av.payment.sections.payment.invoice.orderNbr": "Commande n",
                                "av.payment.sections.payment.invoice.amount": "Montant",
                                "av.payment.sections.payment.paymentMethod.apps": "Paiement par application/site bancaire.",
                                "av.payment.sections.payment.paymentMethod.offline": "Paiement en Cash - {{method}}",
                                "av.payment.sections.payment.paymentMethod.messaging": "Paiement par SMS",
                                "av.payment.sections.payment.messaging.direction": "Envoyez 1 fois le code <em>{{smsCode}}</em> par SMS au num\xe9ro <em>{{smsReceiver}}</em>",
                                "av.payment.sections.payment.messaging.pending": "En attente de votre paiement par SMS ....",
                                "av.payment.sections.payment.messaging.send": "Envoyer SMS",
                                "av.payment.sections.payment.token.expiryWarning": "Attention, ce code est valide pour une dur\xe9e limit\xe9 de 48 heures.",
                                "av.payment.sections.payment.offline.direction1": "Rendez-vous \xe0 une agence {{method}} la plus proche",
                                "av.payment.sections.payment.token.direction2": "Saissez ce code dans la rubrique payment de factures Avito.",
                                "av.payment.sections.payment.token.direction3": "R\xe9glez l'achat et profitez du service",
                                "av.payment.sections.payment.apps.direction1": "Rendez-vous sur votre application bancaire.",
                                "av.payment.sections.payment.token.fees": "Des frais de services et de timbre suppl\xe9mentaires de 2,5 Dhs sont appliqu\xe9s pour chaque transaction",
                                "av.payment.sections.payment.apps.viewList": "Voir la liste des applications bancaires",
                                "av.payment.sections.payment.apps.view.list": "Voir la liste ",
                                "av.payment.sections.payment.invoice.boost": "Promouvoir une annonce",
                                "av.payment.sections.payment.offline.viewList": "Voir la liste des agences",
                                "av.payment.sections.payment.offline.view.list": "Trouver une agence",
                                "av.payment.sections.payment.token": "Votre code commande",
                                "av.payment.sections.payment.token.print": "Imprimer",
                                "av.payment.option.proximo": "Proximo Tassehilat",
                                "av.payment.option.chaabicash": "Chaabi Cash",
                                "av.payment.option.cashplus": "Cash Plus",
                                "av.payment.option.baridcash": "Barid Cash",
                                "av.payment.option.damanecash": "Damane Cash",
                                "av.payment.option.fawatir": "Fawatir",
                                "av.payment.option.cih": "CIH Bank",
                                "av.payment.option.bp": "Banque Populaire",
                                "av.payment.option.bmce": "BMCE",
                                "av.payment.option.sg": "Soci\xe9t\xe9 G\xe9n\xe9rale",
                                "av.payment.option.awb": "Attijariwafa Bank",
                                "av.payment.option.barid": "Al Barid Bank",
                                "av.payment.option.umnia": "Umnia Bank",
                                "av.payment.option.cam": "Cr\xe9dit Agricole",
                                "av.payment.option.cdm": "Cr\xe9dit du Maroc",
                                "av.payment.option.bof": "Bank of Africa",
                                "av.payment.option.cfg": "CFG bank",
                                "av.payment.errors.NoOrderIsUpdated": "Cette commande est introuvable",
                                "av.payment.errors.UpdateIsNotAllowed": "Cette commande est d\xe9j\xe0 initi\xe9e",
                                "av.payment.errors.OrderAlreadyCompleted": "Cette commande est d\xe9j\xe0 termin\xe9e",
                                "av.payment.errors.UnknownPaymentMethod": "Cet paiement inconnu",
                                "av.payment.ad.preview.category.location": "{{category}} dans {{city}}, {{area}}",
                                "av.form.ad.sections.services.title": "Service de vente",
                                "av.form.ad.sections.services.subTitle": "Veuillez choisir le pack ci-dessous",
                                "av.form.ad.sections.sifm.vip.onboarding.title": "Comment \xe7a marche",
                                "av.form.ad.sections.sifm.vip.pack.title": "Avito Bi3 Liya",
                                "av.form.ad.sections.sifm.vip.onboarding.1.text": "Organisation d\u2019une s\xe9ance de prise de photo et d\u2019inspection de votre v\xe9hicule",
                                "av.form.ad.sections.sifm.vip.onboarding.2.text": "Insertion de l\u2019annonce et recommandation d\u2019un prix de vente",
                                "av.form.ad.sections.sifm.vip.onboarding.3.text": "Traitement des appels et s\xe9lection des acheteurs potentiels",
                                "av.form.ad.sections.sifm.vip.onboarding.4.text": "Pr\xe9sence aux RDV et accompagnement pour finaliser la transaction",
                                "av.form.ad.sections.sifm.vip.onboarding.description": 'Si la vente est faite gr\xe2ce \xe0 notre service "Avito Bi3 Liya", vous vous engagez \xe0 payer un montant de 1300 dhs TTC, soit un prix total de 1499 dhs TTC.',
                                "av.form.ad.sections.sifm.pitch": "Nouveau service",
                                "av.form.ad.sections.sifm.advance": "Avance",
                                "av.action.back": "Retour",
                                "av.action.continue": "Continuer",
                                "av.common.quit": "Quitter",
                                "av.action.see-video": "Voir la vid\xe9o",
                                "av.payment.shop.benefits.title.1": "Insertion illimit\xe9e",
                                "av.payment.shop.benefits.text.1": "Une insertion d'annonces illimit\xe9e (se renseigner sur les conditions aupr\xe8s du SAV au 0520428686)",
                                "av.payment.shop.benefits.title.2": "Plus de visibilit\xe9",
                                "av.payment.shop.benefits.text.2": "2,5 fois plus de contacts et de visibilit\xe9",
                                "av.payment.shop.benefits.title.3": "Boostez vos revenues",
                                "av.payment.shop.benefits.text.3": "Augmenter vos revenues tout en profitant des r\xe9ductions sur les renouvellement d'annonces par rapports aux particuliers",
                                "av.payment.shop.cta.header": "Devenir professionnel",
                                "av.payment.shop.action.openShop": "Ouvrir une boutique",
                                "av.payment.vasPack.header": "1- V\xe9rifiez votre commande",
                                "av.payment.methods.header": "2- M\xe9thode de paiement",
                                "av.payment.methods.headerMethods": "M\xe9thode de paiement",
                                "av.payment.methods.header.secure": "securis\xe9",
                                "av.payment.methods.protection.title": "Paiement s\xe9curis\xe9",
                                "av.payment.methods.protection.text": "Si vous avez choisit un pack, ce dernier sera appliqu\xe9 24h apr\xe8s l'acceptation de votre annonce",
                                "av.payment.submit": "Payer",
                                "av.payment.back": "RETOUR",
                                "av.payment.insufficient.balance": "Votre solde est insuffisant pour effectuer cette action veuillez contacter notre service clients afin d'acheter plus de point",
                                "av.payment.methods.subHeader": "Veuillez choisir votre m\xe9thode de paiement.",
                                "av.account.pageTitle.private": "Mon Compte",
                                "av.account.pageTitle.shop": "Mon shop",
                                "av.account.tabs.classified.text": "G\xe9rer",
                                "av.account.tabs.orders": "Mes commandes",
                                "av.account.tabs.favorite": "Mes favoris",
                                "av.account.tabs.settings.text": "Modifier votre boutique",
                                "av.account.tabs.stats": "Statistiques",
                                "av.account.tabs.stats.text": "Voir vos statistiques",
                                "av.account.stats": "Statistique",
                                "av.account.sort": "Tri",
                                "av.account.listing.status": "Statut",
                                "av.account.listing.orders.status": "Statuts des commandes",
                                "av.account.listing.sort.all-ads": "Toutes les Annonces",
                                "av.account.listing.sort.boosted-ads": "Annonces Boost\xe9es",
                                "av.account.listing.sort.unboosted-ads": "Annonces non Boost\xe9es",
                                "av.account.filters": "Filtres",
                                "av.account.filters.orders": "Filtrer mes commandes",
                                "av.account.filter.active": "Actives",
                                "av.account.filter.rejected": "Rejet\xe9es",
                                "av.account.filter.deactivated": "D\xe9sactiv\xe9es",
                                "av.account.filter.deleted": "Supprim\xe9es",
                                "av.account.filter.pending-moderation": "Dans la mod\xe9ration",
                                "av.account.filter.pending-payment": "Paiement en attente",
                                "av.account.filter.favorite-ads": "Annonces sauvegard\xe9es",
                                "av.account.filter.saved-search": "Recherche sauvegard\xe9e",
                                "av.account.filter.saved-searches": "Recherches sauvegard\xe9es",
                                "av.account.filter.settings": "Modifier vos informations",
                                "av.account.filter.password": "Modifier le mot de passe",
                                "av.account.filter.shop.settings": "Informations de la boutique",
                                "av.account.filter.shop.contact": "Contact de la boutique",
                                "av.account.filter.shop.password": "Changer le mot de passe",
                                "av.account.filter.notification": "Param\xe8tres de notification",
                                "av.account.filter.orders.initiated": "Commandes initi\xe9es",
                                "av.account.filter.orders.preparing": "Commandes en cours de pr\xe9paration",
                                "av.account.filter.orders.delivering": "Commandes en livraison",
                                "av.account.filter.orders.delivered": "Commandes livr\xe9es",
                                "av.account.filter.orders.canceled": "Commandes annul\xe9es",
                                "av.account.status.orders.initiated": "Commande initi\xe9e",
                                "av.account.status.orders.preparing": "Commande en cours de pr\xe9paration",
                                "av.account.status.orders.delivering": "Commande en livraison",
                                "av.account.status.orders.delivered": "Commande livr\xe9e",
                                "av.account.status.orders.canceled": "Commande annul\xe9e",
                                "av.account.appeal.form_modal.title": "Relancer la mod\xe9ration",
                                "av.account.appeal.limit.reached": "Vous avez atteint la limite pour relancer la mod\xe9ration de cette annonce.",
                                "av.account.appeal.submit": "Envoyer la demande de relance",
                                "av.account.appeal.success": "Votre demande de relance a \xe9t\xe9 envoy\xe9e avec succ\xe8s !",
                                "av.account.appeal.reason.placeholder": "S\xe9lectionnez une raison",
                                "av.account.appeal.problem.description.placeholder": "Pr\xe9cisez votre probl\xe8me",
                                "av.account.card.btn.pay": "Payer",
                                "av.account.card.btn.reactive": "Reactiver",
                                "av.account.card.btn.delete-definitely": "Supprimer d\xe9finitivement",
                                "av.account.card.btn.cancel-order": "Annuler la commande",
                                "av.account.card.footer.rejected": "Rejet\xe9es",
                                "av.account.card.footer.pending-payment": "Paiement en attente",
                                "av.account.card.footer.pending-review": "En Mod\xe9ration",
                                "av.account.card.menu.more-detail": "Plus de details",
                                "av.account.card.menu.availability": "Calendrier",
                                "av.account.card.menu.error-availability": "Quelque chose ne va pas!",
                                "av.account.card.menu.sucess-availability": "Disponibilit\xe9 modifi\xe9e avec succ\xe8s",
                                "av.account.card.menu.urgent-promo": "Marquer comme urgent/promo",
                                "av.account.card.menu.modify": "Modifier",
                                "av.account.card.menu.appeal": "Relancer la mod\xe9ration",
                                "av.account.card.menu.delete": "Supprimer",
                                "av.account.card.menu.view-on-avito": "Voir sur Avito",
                                "av.account.card.admodal.description.read-more": "Voir plus",
                                "av.account.card.admodal.description.read-less": "Voir moins",
                                "av.account.card.admodal.category": "Cat\xe9gorie",
                                "av.account.card.admodal.applied-boosts": "Boosts en cours",
                                "av.account.card.admodal.price.unit": " Dhs",
                                "av.account.card.admodal.price.not-specified": "Prix non sp\xe9cifi\xe9",
                                "av.account.card.admodal.read-more": "lire plus >",
                                "av.account.card.admodal.executed-at": "Appliqu\xe9 le",
                                "av.account.card.admodal.expire-in": "Expire",
                                "av.account.card.admodal.actions.availability": "Calendrier",
                                "av.account.card.admodal.actions.edit": "Modifier",
                                "av.account.card.admodal.actions.delete": "Supprimer",
                                "av.account.card.admodal.actions.view-on-avito": "Voir sur Avito",
                                "av.account.card.admodal.actions.continue-payment": "Continuer le paiement",
                                "av.account.card.admodal.pack": "Pack",
                                "av.account.card.admodal.vas.expire-in": "Expire",
                                "av.account.card.admodal.vas.start": "Commence le {{date}} \xe0 {{time}}",
                                "av.account.card.admodal.ads.unboosted": "Annonce non boost\xe9e",
                                "av.account.card.ad.properties.modal.title": "Modifier l'annonce",
                                "av.account.card.ad.properties.modal.urgent-toggle-text": 'Ajouter le logo "Urgent"',
                                "av.account.card.ad.properties.modal.hotdeal-toggle-text": "Appliquer une promotion",
                                "av.account.card.ad.properties.modal.submit-button": "Appliquer Les Changements",
                                "av.account.card.ad.properties.modal.sucess-message": "Modification valid\xe9e avec succ\xe8s",
                                "av.account.card.ad.properties.modal.error-message": "Modification non valid\xe9e",
                                "av.account.setting.private.name": "Pr\xe9nom",
                                "av.account.setting.private.phone": "T\xe9l\xe9phone",
                                "av.account.setting.private.hide-number": "Afficher mon num\xe9ro de t\xe9l\xe9phone",
                                "av.account.setting.private.faq": "Vous ne pouvez pas changer votre adresse e-mail.",
                                "av.account.setting.private.faq-link": "Lisez les questions les plus fr\xe9quemment pos\xe9es",
                                "av.account.setting.city.notFound": "Aucun r\xe9sultat trouv\xe9",
                                "av.account.setting.private.error.name.incorrect": "Le pr\xe9nom est incorrect !",
                                "av.account.setting.private.error.phone.incorrect": "Le num\xe9ro de t\xe9l\xe9phone est incorrect !",
                                "av.account.setting.private.password.current": "Mot de passe actuel",
                                "av.account.setting.private.password.new": "Nouveau mot de passe",
                                "av.account.setting.private.password.confirm": "Confirmer le mot de passe",
                                "av.account.setting.private.password.btn-submit": "Modifier le mot de passe",
                                "av.account.setting.private.error.password.too-short": "Votre mot de passe est trop court. Il doit contenir au minimum 5 caract\xe8res.",
                                "av.account.setting.private.error.password.identical-passwords": "Veuillez entrer un mot de passe diff\xe9rent du mot de passe actuel",
                                "av.account.setting.private.error.password.verify": "Veuillez v\xe9rifier votre mot de passe ",
                                "av.account.setting.private.missing.info.alert.title": "Important:",
                                "av.account.setting.private.missing.info.alert.description": "Veuillez saisir les informations manquantes pour finaliser la configuration de votre compte.",
                                "av.account.setting.shop": "Boutique",
                                "av.account.setting.shop.show": "Voir les annonces de la boutique",
                                "av.account.setting.shop.info": "Informations de la boutique",
                                "av.account.setting.shop.name": "Nom de la boutique",
                                "av.account.setting.shop.category": "Cat\xe9gorie",
                                "av.account.setting.shop.url": "Site web de la boutique",
                                "av.account.setting.shop.bref-description": "Br\xe8ve description",
                                "av.account.setting.shop.contact": "Contact de la boutique",
                                "av.account.setting.shop.phone": "T\xe9l\xe9phone principal",
                                "av.account.setting.shop.extra-phone": "Ajouter un autre num\xe9ro",
                                "av.account.setting.shop.extra-phone.number": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.account.setting.shop.change-password": "Changer le mot de passe",
                                "av.account.setting.shop.btn-submit": "Sauvegarder les modifications",
                                "av.account.setting.shop.edit-logo": "Modifier le logo",
                                "av.account.setting.shop.add-logo": "Ajouter un logo",
                                "av.account.setting.shop.error.name.incorrect": "Le nom de la boutique est incorrect !",
                                "av.account.setting.shop.error.phone.incorrect": "Le num\xe9ro de t\xe9l\xe9phone est incorrect !",
                                "av.account.setting.shop.error.description.incorrect": "La description est incorrect !",
                                "av.account.setting.shop.error.url.incorrect": "Le site web est incorrect !",
                                "av.account.setting.alert.success.message": "Super !",
                                "av.account.setting.alert.account-updated": "Votre compte a \xe9t\xe9 mis \xe0 jour !",
                                "av.account.setting.alert.logo-updated": "Votre logo a \xe9t\xe9 mis \xe0 jour !",
                                "av.account.setting.cs.help": "Besoin d'aide ? ",
                                "av.account.setting.cs.phone": "0520428686",
                                "av.account.setting.cs.text": "Num\xe9ro de t\xe9l\xe9phone sav",
                                "av.account.setting.cs.phone.number": "05 20 42 86 86",
                                "av.account.setting.contact.email.note": "Pour des raisons de confidentialit\xe9, l\u2019adresse mail ne peut pas \xeatre modifi\xe9e, pour plus d\u2019information veuillez contacter notre service client au T\xe9l: 0520-42-86-86 / ",
                                "av.account.setting.contact.phone.update.alert": "Pour modifier votre  num\xe9ro de t\xe9l\xe9phone merci de nous contacter au 05 20 42 86 86",
                                "av.account.setting.contact.email.note.live-chat": "Live chat ICI",
                                "av.account.setting.notification.account-manage.title": "Emails de Gestion de compte",
                                "av.account.setting.notification.account-manage.text": "Email relatif a votre compte comme la recuperation de mot de passe \u2026",
                                "av.account.setting.notification.ads.title": "Emails des Annonces",
                                "av.account.setting.notification.ads.text": "Email envoy\xe9 a chaque changement de status de vos annonces.",
                                "av.account.setting.notification.vas.title": "Emails des Packs",
                                "av.account.setting.notification.vas.text": "Email envoy\xe9 \xe0 l'application de chaque pack.",
                                "av.account.setting.notification.payment.title": "Emails des Payments",
                                "av.account.setting.notification.payment.text": "Email envoy\xe9 a chaque paiement effectu\xe9.",
                                "av.account.setting.notification.newsletters.title": "Newsletters",
                                "av.account.setting.notification.newsletters.text": "Email relatif aux offres et promotions et aussi aux actualit\xe9s d'Avito",
                                "av.account.setting.alert.notification.updated": "Vos param\xe8tres de notification ont \xe9t\xe9 mis \xe0 jour !",
                                "av.account.setting.email.verification.title": "V\xe9rifier votre adresse email",
                                "av.account.setting.email.verification.text": "Veuillez saisir votre adresse e-mail, afin de recevoir un lien de validation.",
                                "av.account.modals.activate.ad.title": "Annonce activ\xe9e",
                                "av.account.modals.activate.ad.text": "Vous pouvez la booster en allant sur Mom compte>annonce actives ou en cliquant ici",
                                "av.account.modals.activate.ad.btn": "Mes annonces Actives",
                                "av.account.modals.delete.refused.title": "Suppression Refus\xe9e !",
                                "av.account.modals.delete.refused.text": "Votre annonce ne peut \xeatre supprim\xe9e qu'apr\xe8s {{days}} jours",
                                "av.account.modals.delete.refused.btn": "ok ! j'ai compris",
                                "av.account.modals.delete.confirmation.title": "Confirmer la suppression",
                                "av.account.modals.delete.confirmation.text": "Vous ne pouvez effectuer aucune action sur cette annonce si vous la supprimer.",
                                "av.account.modals.delete.confirmation.btn": "Supprimer",
                                "av.account.modals.activate.limit.title": "Limite d'annonces actives atteinte",
                                "av.account.modals.activate.limit.text": "Vous pouvez toujours payer pour activer cette annonce",
                                "av.account.modals.activate.limit.btn": "Activer",
                                "av.account.toaster.activate.success": "Annonce Suprim\xe9 avec succ\xe8s",
                                "av.account.toaster.activate.error": "Erreur Veuillez r\xe9essayer plus tard",
                                "av.account.favorites.modal.delete-ad.title": "Supprimer l'annonce",
                                "av.account.favorites.modal.delete-ad.text": "Etes vous sur de vouloir supprimer cette annonce de vos favoris ?",
                                "av.account.favorites.modal.delete": "Supprimer",
                                "av.account.favorites.modal.cancel": "Annuler",
                                "av.account.favorites.modal.delete-ad-success.title": "Supprim\xe9!",
                                "av.account.favorites.modal.delete-ad-success.text": "L'annonce a bien \xe9t\xe9 supprim\xe9e de vos favoris",
                                "av.account.favorites.modal.delete-ad-success.btn": "OK",
                                "av.account.favorites.modal.delete-ad-error.title": "Oops...",
                                "av.account.favorites.modal.delete-ad-error.text": "Quelque chose ne va pas !",
                                "av.account.favorites.modal.delete-search-success.text": "La recherche a bien \xe9t\xe9 supprim\xe9e de vos favoris",
                                "av.account.stats.today": "Aujourd'hui",
                                "av.account.stats.bi-weekly": "Derniers 14 jours",
                                "av.account.stats.monthly": "Derniers 30 jours",
                                "av.account.stats.15-days": "Derniers 15 jours",
                                "av.account.stats.weekly": "Derniers 7 jours",
                                "av.account.stats.all-time": "Tout le temps",
                                "av.account.stats.custom-range": "Dur\xe9e personnalis\xe9e",
                                "av.account.stats.calendar.apply": "Appliquer",
                                "av.account.stats.calendar.cancel": "Effacer",
                                "av.account.stats.calendar.from": "D\xe9marrer",
                                "av.account.stats.calendar.to": "Finir",
                                "av.account.stats.leads": "Leads de vos annonces",
                                "av.account.stats.leads.short": "Leads",
                                "av.account.stats.vues": "Vues sur vos annonces",
                                "av.account.stats.calls": "Intentions d\u2019appel et SMS",
                                "av.account.stats.chat": "Conversations chat",
                                "av.account.stats.bump": "Renouvellement d\u2019annonces",
                                "av.account.stats.ad.highlight": "Application d\u2019annonce Star",
                                "av.account.stats.ad.gallery": "Application d\u2019annonce Premium",
                                "av.account.stats.ad.published": "Annonces publi\xe9es",
                                "av.account.stats.ad.deleted": "Annonces supprim\xe9es",
                                "av.account.stats.calls.short": "Appels",
                                "av.account.stats.views": "Vues",
                                "av.account.stats.messages": "Messages et WhatsApp",
                                "av.account.stats.messages.short": "Messages",
                                "av.account.stats.calls-intentions": "Intentions d\u2019appels",
                                "av.account.stats.vas-consumption": "VAS Consommation",
                                "av.account.stats.ad.active": "Annonces actives",
                                "av.account.shop.banner.points": "Solde de points",
                                "av.account.shop.banner.expiration.points": "Expiration du solde",
                                "av.account.shop.banner.expiration.shop": "Expiration boutique",
                                "av.account.shop.banner.redirection.message": "Cliquez ici pour acc\xe9der \xe0 votre magasin",
                                "av.account.shop.banner.points.balance": "Solde des points",
                                "av.account.shop.banner.points-word": "points",
                                "av.account.shop.banner.avitoken.balance": "Soldes des Avitoken",
                                "av.account.shop.banner.avitoken-word": "Avitoken",
                                "av.account.shop.banner.membership": "Votre abonnement",
                                "av.account.shop.banner.expiration.balance": "Expiration solde",
                                "av.account.shop.banner.creation.shop": "Cr\xe9ation boutique",
                                "av.account.seller.banner.points": "Solde de points",
                                "av.account.seller.banner.orders.number": "Nombre de commandes",
                                "av.account.seller.banner.items.number": "Nombre d'article",
                                "av.account.seller.banner.not.paid": "Due et non pay\xe9e",
                                "av.account.seller.banner.next.payment": "Prochain virement",
                                "av.account.shop.alert.success": "F\xe9licitations, votre paiement a r\xe9ussi, votre annonce sera mise en \xe9vidence dans quelques minutes.",
                                "av.account.shop.alert.error.SoldeExpired": "D\xe9sol\xe9, votre paiement a \xe9chou\xe9 car vous avez 0 cr\xe9dits, Veuillez contacter notre service clients pour acheter plus de points au 0520-42-86-86",
                                "av.account.shop.alert.error.PermissionDenied": "D\xe9sol\xe9, veuillez re-connecter et essayer",
                                "av.account.shop.alert.error.InvalidOperation": "D\xe9sol\xe9, votre paiement a \xe9chou\xe9",
                                "av.account.shop.alert.error.ERROR_SOLDE_EXPIRED": "D\xe9sol\xe9, votre paiement a \xe9chou\xe9 car vous avez 0 cr\xe9dits, Veuillez contacter notre service clients pour acheter plus de points au 0520-42-86-86",
                                "av.account.shop.alert.error.ERROR_PACKAGE_NOT_FOUND": "D\xe9sol\xe9, nous n\u2019avons pas trouv\xe9 le pack choisi, veuillez S\xe9lectionner un pack valide.",
                                "av.account.shop.alert.error.ERROR_SOLDE_EQUIVALENT": "D\xe9sol\xe9, le pack s\xe9lectionn\xe9 n\u2019a pas d\u2019\xe9quivalence en points, veuillez S\xe9lectionner un pack valide ou bien choisir un autre moyen de paiement",
                                "av.account.shop.alert.error.ERROR_SOLDE_NOT_ENOUGH": "D\xe9sol\xe9, Votre solde est insuffisant pour effectuer cette op\xe9ration.",
                                "av.payment.sorry": "D\xe9sol\xe9 {{name}}",
                                "av.payment.shop.success": "Votre paiement a r\xe9ussi, votre annonce sera mise en \xe9vidence dans quelques minutes.",
                                "av.payment.shop.error.ERROR_SOLDE_EXPIRED": "Votre paiement a \xe9chou\xe9 car vous avez 0 cr\xe9dits, Veuillez contacter notre service clients pour acheter plus de points au 0520-42-86-86",
                                "av.payment.shop.error.ERROR_PACKAGE_NOT_FOUND": "Nous n\u2019avons pas trouv\xe9 le pack choisi, veuillez S\xe9lectionner un pack valide.",
                                "av.payment.shop.error.ERROR_SOLDE_EQUIVALENT": "Le pack s\xe9lectionn\xe9 n\u2019a pas d\u2019\xe9quivalence en points, veuillez S\xe9lectionner un pack valide ou bien choisir un autre moyen de paiement",
                                "av.payment.shop.error.ERROR_SOLDE_NOT_ENOUGH": "Votre solde est insuffisant pour effectuer cette op\xe9ration.",
                                "av.account.help.rejected": "Les annonces non conformes au r\xe8glement ne sont pas accept\xe9es",
                                "av.account.help.pending-payment": "Les annonces en attente de paiement seront publi\xe9es une fois votre paiement est effectu\xe9",
                                "av.account.help.pending-moderation": "Les annonces en cours de mod\xe9ration sont actives dans un d\xe9lai maximum de 60 minutes",
                                "av.account.ads.refusal-reason": "Raison de refus :",
                                "av.account.listing.notes.pending-review.title": "Annonces en attente de mod\xe9ration",
                                "av.account.listing.notes.pending-review.message": "Le temps moyen de mod\xe9ration d\u2019une annonce est de 1 heure, si apr\xe8s ce d\xe9lai l\u2019annonce appara\xeet toujours sur cet onglet, n\u2019h\xe9sitez pas \xe0 contacter notre service client.",
                                "av.account.listing.notes.refused.title": "Annonces rejet\xe9es",
                                "av.account.listing.notes.refused.message": "Un mail explicatif de la raison du rejet de votre annonce vous a \xe9t\xe9 envoy\xe9 sur votre adresse mail.",
                                "av.account.listing.notes.refused.more-info": "Pour avoir plus d\u2019information, vous pouvez consulter ",
                                "av.account.listing.notes.refused.help-center": "notre centre d'aide",
                                "av.account.listing.notes.refused.help-center.phone": " ou contacter notre service client au T\xe9l: 0520-42-86-86 / ",
                                "av.account.listing.notes.refused.help-center.chat": "Live chat ICI",
                                "av.account.listing.notes.deactivated.title": "Annonces d\xe9sactiv\xe9es",
                                "av.account.listing.notes.deactivated.message": "Une annonce d\xe9sactiv\xe9e ne peut \xeatre supprim\xe9e compl\xe8tement qu\u2019apr\xe8s 7 jours de sa d\xe9sactivation.",
                                "av.account.listing.notes.deleted.title": "Annonces supprim\xe9es",
                                "av.account.listing.notes.deleted.message": "Les annonces supprim\xe9es ne peuvent pas \xeatre r\xe9activ\xe9es. Toutefois vous pouvez passez par une nouvelle insertion d'annonces avec les m\xeames informations.",
                                "av.account.listing.notes.pending-payment.title": "Annonces en attente de paiement",
                                "av.account.listing.notes.pending-payment.message": "Pour promouvoir votre annonce, optez pour un pack de renouvellement en plus des frais d\u2019insertion. Pour plus de d\xe9tail ",
                                "av.account.listing.notes.pending-payment.click-here": "cliquez ici",
                                "av.account.settings.notes.notification.verified.email.title": "Parametrage de notification par email",
                                "av.account.settings.notes.notification.verified.email.message": "Les notifications par Email vous permettent d'\xeatre tenu inform\xe9, vous pouvez activer ou d\xe9sactiver le type d'email que vous voulez recevoir",
                                "av.account.settings.notes.notification.unverified.email.title": "V\xe9rifiez votre Adressse Email",
                                "av.account.settings.notes.notification.unverified.email.message": "La verification de votre adresse mail est n\xe9cessaire pour recevoir les emails d'Avito , Veuillez verifier votre adresse email en cliquant sur ",
                                "av.account.settings.notes.notification.unverified.email.link": "ce lien",
                                "av.account.shop.onBording.step1.title": "Votre annonce",
                                "av.account.shop.onBording.step1.body": "Cliquez ici pour modifier, supprimer votre annonce ou bien g\xe9rer le calendrier des r\xe9servations\u2026.",
                                "av.account.shop.onBording.step2.title": "Actions rapides",
                                "av.account.shop.onBording.step2.body": "Ici vous pouvez voir, modifier ou supprimer votre annonce.",
                                "av.account.shop.onBording.step3.title": "Votre boutique",
                                "av.account.shop.onBording.step3.body": "En cliquant sur votre logo, vous aurez acc\xe8s \xe0 votre boutique.",
                                "av.account.shop.onBording.next": "Suivant",
                                "av.oauth.subtitle": "Vous pouvez utiliser l'authentification rapide avec votre compte Facebook ou Gmail.",
                                "av.login.error.email": "Votre adresse email est incorrect.",
                                "av.login.error.msg1": "Oops...",
                                "av.login.error.mesg2": "Addresse email ou mot de passe incorrect !",
                                "av.login.email.connexion": "Connectez-vous \xe0 Avito",
                                "av.login.title": "Connexion ou inscription",
                                "av.login.shop.subtitle": "Utilisez votre email  pour se connecter rapidement",
                                "av.login.private.subtitle": "Utilisez votre num\xe9ro de t\xe9l\xe9phone pour se connecter rapidement",
                                "av.login.shop": "Continuer en tant que Boutique",
                                "av.login.phone_number.label": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.login.email.label": "Email",
                                "av.login.phone_number.placeholder": "Ex: 06233321**",
                                "av.login.email.placeholder": "Ex: user.name@gmail.com",
                                "av.login.password.label": "Mot de passe",
                                "av.login.password.placeholder": "Mot de passe",
                                "av.login.shop.title": "Connectez-vous \xe0 votre boutique",
                                "av.login.shop.subTitle": "Entrez vos coordonn\xe9es ci-dessous",
                                "av.login.cta": "Se connecter ",
                                "av.login.continue": "Continuer",
                                "av.login.shop.entrypoint": "J'ai une boutique Avito",
                                "av.reset_password.head.title": "R\xe9initialiser le mot de passe - Avito.ma",
                                "av.reset_password.form.submit": "Choisir un nouveau mot de passe",
                                "av.reset_password.phone_verification.title": "Mot de passe oubli\xe9?",
                                "av.reset_password.phone_verification.subtitle": "Veuillez saisir le num\xe9ro de t\xe9l\xe9phone associ\xe9 \xe0 votre compte.",
                                "av.reset_password.shop.via.email.subtitle": "Veuillez saisir votre adresse e-mail, afin de recevoir un lien de r\xe9initialisation de votre mot de passe.",
                                "av.reset_password.success": "Votre mot de passe a \xe9t\xe9 enregistr\xe9",
                                "av.reset_password.reset_password.title": "Nouveau mot de passe",
                                "av.reset_password.reset_password.subtitle": "Veuillez saisir le nouveau mot de passe",
                                "av.reset_password.private.name": "Compte particulier",
                                "av.reset_password.shop.name": "Compte boutique",
                                "av.otp.title": "Code de v\xe9rification envoy\xe9",
                                "av.otp.subtitle": "Ins\xe9rez le code \xe0 6 chiffres que nous avons envoy\xe9 au",
                                "av.otp.method": "sur WhatsApp",
                                "av.otp.not_recieved": "Vous n'avez pas re\xe7u le code ?",
                                "av.otp.empty_code": "Veuillez entrer un code avant de continuer",
                                "av.otp.resend": "Renvoyer le code",
                                "av.otp.resend.cooldown": "Renvoyer le code dans {{countdown}} min",
                                "av.otp.resend.success": "Le code a \xe9t\xe9 renvoy\xe9 avec succ\xe8s",
                                "av.otp.continue": "Continuer",
                                "av.otp.verify": "V\xe9rifier",
                                "av.otp.skip.verification": "Continuer sans v\xe9rification",
                                "av.opt-out.text": "Voulez-vous revenir \xe0 l\u2019ancienne version ?",
                                "av.opt-out.btn.yes": "Oui",
                                "av.opt-out.btn.no": "non",
                                "av.show_number.warning": "Il ne faut jamais envoyer de l\u2019argent \xe0 l\u2019avance au vendeur par virement bancaire ou \xe0 travers une agence de transfert d\u2019argent lors de l\u2019achat des biens disponibles sur le site.",
                                "av.show_number.cta": "Appeler",
                                "av.caution": "Attention !",
                                "av.payment.page.success.title": "Votre paiement a \xe9t\xe9 enregistr\xe9 avec succ\xe8s",
                                "av.payment.page.success.text1": "Vous allez recevoir la confirmation de votre commande par email dans les minutes qui suivent.",
                                "av.payment.page.success.text2": "Si vous ne recevez pas l'email,  veuillez consulter votre dossier Spam (Courrier ind\xe9sirable).",
                                "av.payment.page.failure.title": "Une erreur est survenue",
                                "av.payment.page.failure.text1": "Nous ne pouvons pas finaliser votre paiement.",
                                "av.payment.page.failure.text2": "Nous vous conseillons d'essayer une nouvelle fois, ou de choisir une autre m\xe9thode de paiement.",
                                "av.payment.page.failure.text3": "Si vous rencontrez toujours un soucis vous pouvez nous contacter pour plus de d\xe9tails.",
                                "av.payment.page.failure.phone": "05 20 42 86 86",
                                "av.payment.page.failure.btn": "reessayer",
                                "av.adNavigation.nextAd": "Annonce suivante",
                                "av.adNavigation.previousAd": "Annonce pr\xe9c\xe9dente",
                                "av.adNavigation.results": "R\xe9sultats",
                                "av.adActionButton.saveAd": "Sauvegarder l\u2019annonce",
                                "av.adActionButton.unSaveAd": "Supprimer des favoris",
                                "av.adactionButton.shareAd": "Partager l\u2019annonce",
                                "av.adview.nextImage": "L'image suivante",
                                "av.adview.prevImage": "L'image pr\xe9c\xe9dente",
                                "av.saveAd.success": "Annonce sauvegard\xe9e",
                                "av.saveAd.error.adNotFound": "Annonce introuvable",
                                "av.saveAd.error.adNotFound.description": "Short description about the error encountered and the where to go from here.You know what I mean come on.Short description about the error encountered and the where to go from here. You know what I mean come on.Short description about the error encountered and the where to go from here. You know what I mean come on.Short description about the error encountered and the where to go from here. You know what I mean come on.",
                                "av.saveAd.error.sessionExpired": "Votre session a expire",
                                "av.saveAd.error.internalError": "Erreur, merci de r\xe9essayer",
                                "av.unsaveAd.success": "Sauvegarde supprim\xe9e",
                                "av.unsaveAd.error.adNotFound": "Annonce introuvable",
                                "av.unsaveAd.error.sessionExpired": "Votre session a \xe9xpire",
                                "av.unsaveAd.error.internalError": "Erreur, merci de r\xe9essayer",
                                "av.shareAd": "Partager",
                                "av.shareAd.modal": "Partager Sur ...",
                                "av.copyLink": "Copier Le Lien",
                                "av.copyLink.success": "Lien Copi\xe9",
                                "av.adManagement.manage": "G\xe9rer",
                                "av.adManagement.block.title": "Booster votre annonce",
                                "av.adManagement.block.message": "Augmentez votre visibilit\xe9 et vendez plus vite en boostant votre annonce",
                                "av.reportForm.cancel.report": "Signaler un abus",
                                "av.reportForm.title": "Quel est le probl\xe8me avec cette annonce?",
                                "av.reportForm.select.placeholder": "S\xe9lectionner",
                                "av.reportForm.select.label": "S\xe9lectionner le type d\u2019abus",
                                "av.reportForm.message.label": "Message",
                                "av.reportForm.success": "L\u2019annonce a \xe9t\xe9 signal\xe9e avec success, merci!",
                                "av.abuseType.fraud": "Fraude",
                                "av.abuseType.duplicate": "Doublon",
                                "av.abuseType.wrong_cat": "Mauvaise cat\xe9gorie",
                                "av.abuseType.wrong_img": "Mauvaise photo",
                                "av.abuseType.fake_number": "Faux num\xe9ro",
                                "av.abuseType.wrong_price": "Mauvais prix",
                                "av.abuseType.sold": "Article d\xe9j\xe0 vendu",
                                "av.vas.slider.btn.video": "Voir la video",
                                "av.vas.pack.updateBtn": "Modifier",
                                "av.footer.download": "T\xe9l\xe9chargez l'application gratuitement:",
                                "av.footer.download.playstore": "Disponible sur Google Play",
                                "av.footer.download.appstore": "T\xe9l\xe9charger dans l'App store",
                                "av.footer.follow": "Suivez nous sur:",
                                "av.account.listing.bulk.manage-ad": "G\xe9rer vos annonces",
                                "av.account.listing.bulk.delete-ad": "Supprimer vos annonces",
                                "av.account.listing.bulk.select-ad": "Annonces s\xe9lectionn\xe9es",
                                "av.account.listing.bulk.delete-text-why": "Pourquoi voulez-vous supprimer ces {{nbrAds}} annonces?",
                                "av.account.listing.bulk.delete": "Supprimer",
                                "av.account.listing.bulk.delete-confirmation-message": "Votre annonce sera supprim\xe9e dans quelques instants",
                                "av.account.listing.bulk.delete-confirmation-message-plural": "Vos annonces seront supprim\xe9es dans quelques instants",
                                "av.account.listing.bulk.other-text-placeholder": "Ecrire votre message ici",
                                "av.account.listing.bulk.Uncheck": "D\xe9s\xe9lectionner",
                                "av.account.lisiting.ad.status.active": "Active",
                                "av.account.lisiting.ad.status.pending-moderation": "Dans la mod\xe9ration",
                                "av.account.lisiting.ad.status.refused": "Refus\xe9e",
                                "av.account.lisiting.ad.status.deleted": "Supprim\xe9e",
                                "av.account.lisiting.ad.status.deactivated": "D\xe9sactiv\xe9e",
                                "av.account.lisiting.ad.status.pending-payment": "En attente de paiement",
                                "av.account.lisiting.ad.edit-status.pending": "Modification en cours",
                                "av.account.lisiting.ad.edit-status.accepted": "Modification accept\xe9e",
                                "av.account.lisiting.ad.edit-status.refused": "Modification refus\xe9e",
                                "av.account.listing.ad.operations.confirm-ad-deactivation.title": "Annonce d\xe9sactiv\xe9e",
                                "av.account.listing.ad.operations.confirm-ads-deactivation.title": "Annonces d\xe9sactiv\xe9es",
                                "av.account.listing.ad.operations.confirm-ad-deactivation.text": "Vous pouvez toujours la r\xe9activer, ou bien la supprimer apr\xe8s 7 jours",
                                "av.account.listing.ad.operations.confirm-ads-deactivation.text": "Vous pouvez toujours les r\xe9activer, ou bien les supprimer apr\xe8s 7 jours",
                                "av.account.listing.ad.operations.view-ads": "Voir mes annonces",
                                "av.account.listing.ad.operations.delete-text-why": "Pourquoi voulez-vous supprimer cette annonce?",
                                "av.account.listing.no-response.active.text": "Vous avez quelque chose \xe0 vendre?",
                                "av.account.listing.no-response.active.subText": "D\xe9posez votre annonce gratuitement sur Avito.ma aujourd'hui",
                                "av.account.listing.no-response.disabled.text": "Vous avez quelque chose \xe0 vendre?",
                                "av.account.listing.no-response.disabled.subText": "D\xe9posez votre annonce gratuitement sur Avito.ma aujourd'hui",
                                "av.account.listing.no-response.deleted.text": "Vous n'avez aucune annonce supprim\xe9e",
                                "av.account.listing.no-response.moderation.text": "Vous n'avez aucune annonce dans la mod\xe9ration",
                                "av.account.listing.no-response.rejected.text": "Vous n'avez aucune annonce refus\xe9e",
                                "av.account.listing.no-response.payment.text": "Vous n'avez aucune annonce en attente de Paiement",
                                "av.account.listing.no-response.favorite-ads.text": "Vous n'avez aucune annonce sauvegard\xe9e",
                                "av.account.listing.no-response.saved-search.text": "Vous n'avez aucune recherche sauvegard\xe9e",
                                "av.account.listing.no-response.boosted.text": "Vous n'avez aucune annonce boost\xe9e",
                                "av.account.listing.no-response.unboosted.text": "Vous n'avez aucune annonce non boost\xe9e",
                                "av.account.listing.no-response.orders.text": "Vous n'avez pas encore pass\xe9 une commande",
                                "av.account.listing.no-response.orders.subText": "Commencez par trouver l'article qui correspond \xe0 vos besoins sur nos boutiques en ligne, et passez au paiement instantan\xe9",
                                "av.account.listing.no-response.orders.btn": "D\xe9couvrez maintenant",
                                "av.adview.title.default": "{{subject}} | {{category}} \xe0 {{city}} | Avito.ma",
                                "av.adview.title.auto": "{{subject}} | {{category}} \xe0 {{city}} | Avito.ma -- {{listId}}",
                                "av.adview.description.default": "{{description}} - {{verticalPrefix}} announce {{category}} au Maroc au meilleur prix sur Avito, plateforme N\xb01 de vente et achat en ligne au Maroc.",
                                "av.adview.map.button": "Voir sur la carte",
                                "av.adview.map.title": "Localisation de la propri\xe9t\xe9",
                                "av.adview.contactSeller": "Voir la boutique",
                                "av.adview.viewUnits": "Voir les unit\xe9s",
                                "av.adview.isPhoneVerified": "N\xb0 v\xe9rifi\xe9",
                                "av.adview.seller.cta.contactSeller": "Contacter le Vendeur",
                                "av.adview.seller.cta.applyForJobOffer": "Postuler",
                                "av.adview.seller.cta.shortApplyForJobOffer": "Postuler",
                                "av.adview.seller.cta.askForPrice": "Demander le prix",
                                "av.adview.seller.cta.shortAskForPrice": "Prix ?",
                                "av.adview.seller.cta.whatsapp.messageText": "Je vous contacte \xe0 propos de cette annonce: {{adUrl}}",
                                "av.adview.cta.boost": "Booster cette annonce",
                                "av.adview.cta.ncContact": "\xcatre rappel\xe9",
                                "av.nc.badge.text": "Projet Neuf",
                                "av.extraParams.title": "\xc9quipements",
                                "av.adview.share.withFacebook": "Facebook",
                                "av.adview.share.withWhatsapp": "Whatsapp",
                                "av.adview.share.withMessenger": "Messenger",
                                "av.adview.scam.disclaimer": "Il ne faut jamais envoyer d'argent \xe0 l'avance au vendeur par virement ou agence de transfert.",
                                "av.adview.buyer.card.title": "Faites inspecter cette voiture",
                                "av.adview.buyer.card.description": "Achetez votre voiture expertis\xe9e par nos experts (+100 points de contr\xf4les)",
                                "av.adview.buyer.card.cta": "Demander l\u2019inspection",
                                "ad.view.buyer.form_modal.title": "Demande d'expertise pour une voiture",
                                "ad.view.buyer.form_modal.description": "Ce service est propos\xe9 par l\u2019\xe9quipe Avito et actuellement disponible \xe0 Casablanca.",
                                "ad.view.buyer.form_modal.submition": "Envoyer votre demande",
                                "ad.view.buyer.form_modal.submition.success": "F\xe9licitations, votre demande est envoy\xe9e!",
                                "ad.view.buyer.car_inspected.card.title": "Voiture expertis\xe9e (+100 points de contr\xf4les)",
                                "ad.view.buyer.car_inspected.card.description": "Date d\u2019expertise:",
                                "ad.view.buyer.car_inspected.view.cta": "Visualiser le rapport",
                                "ad.view.buyer.car_inspected.download.cta": "T\xe9l\xe9charger le rapport",
                                "ad.view.buyer.car_inspected.download.error": "\xc9chec du t\xe9l\xe9chargement du rapport. Veuillez r\xe9essayer.",
                                "ad.view.car_inspected.label": "Voiture Expertis\xe9e par Avito",
                                "ad.view.car_inspected.tooltip.text": "Rapport d'expertise disponible",
                                "av.suggestions.rec.heading": "Ces annonces peuvent vous int\xe9resser",
                                "av.suggestions.mau.heading": "Autres annonces de cette boutique",
                                "av.suggestions.mau.msite.heading": "Autres annonces",
                                "av.suggestions.mau.heading.see-more": "Plus d\u2019annonces",
                                "av.suggestions.mau.see-more.title": "Decouvrez plus d\u2019annonces",
                                "av.premium.ads.rec.heading": "Notre s\xe9lection premium",
                                "av.premium.ads.rec.heading.badge": "Annonce premium",
                                "av.loanSimulator.amount": "Montant du credit",
                                "av.loanSimulator.monthly": "\xe0 partir de",
                                "av.loanSimulator.period": "Dur\xe9e du cr\xe9dit",
                                "av.loanSimulator.poweredBy": "Powered by ",
                                "av.loanSimulator.legalNotice": "Offre pr\xeat personnel (hors rachat de cr\xe9dit). Validit\xe9 30.06.2022, r\xe9serv\xe9e aux nouveaux clients fonctionnaires du secteur public ou salari\xe9s du secteur priv\xe9e, soumise \xe0 conditions sous r\xe9serve d'acceptation du dossier selon les r\xe8gles prudentielle en vigueur. Pour les fonctionnaires du secteur public : 80000 MAD/68 mois, mensualit\xe9 pour moins de 60 ans : 1392,57 MAD TTC hors frais : Assurance (80MAD). Pr\xe9l\xe8vement DDP (7,7 MAD). Assistance mensuelle (15,66MAD) frais de dossier : 0 MAD/TTC frais de timbre (20 MAD), cr\xe9dit bureau (17,60MAD) frais de r\xe9servation (88MAD). Co\xfbt global du cr\xe9dit : 21848,6 MAD/TTC. TEG HT 5,5 %. Pour les salari\xe9s du secteur priv\xe9e : 80000 MAD/68 mois, mensualit\xe9 pour moins de 60 ans : 1498,30 MAD TTC hors frais : Assurance (80MAD), Assistance annuelle (187,86 MAD) frais de dossier : 0 MAD/TTC frais de timbre (20 MAD), cr\xe9dit bureau (17,60MAD). Co\xfbt global du cr\xe9dit : 28 426,77 MAD/TTC. TEG HT 8% (TVA 10%).",
                                "av.loanSimulator.brand": "Wafasalaf",
                                "av.loanSimulator.title": "Calculateur du pr\xeat",
                                "av.loanSimulator.cta": "Obtenir votre pr\xe9accord",
                                "av.loanSimulator.poweredBy.brand": "Avito",
                                "av.loanSimulator.advance": "Apport personnel",
                                "av.loanSimulator.term": "Dur\xe9e du pr\xeat",
                                "av.loanSimulator.monthlyPayment": "Par mois",
                                "av.loanSimulator.advance.errorMessage": "Le montant d'apport personnel ne doit pas \xeatre sup\xe9rieur au prix",
                                "av.loanSimulator.advance.negativeErrorMessage": "Le montant d'apport personnel ne peut pas \xeatre n\xe9gatif",
                                "av.loanSimulator.disclaimer": "Cette simulation est \xe0 titre indicatif et non contractuelle. Vous pouvez b\xe9n\xe9ficier de conditions pr\xe9f\xe9rentielles en fonction de votre dossier.",
                                "av.loanSimulator.re.price": "Prix du bien",
                                "av.loanSimulator.auto.price": "Prix du v\xe9hicule",
                                "av.creditCalculatorBanner.title.auto": "Financez votre voiture",
                                "av.creditCalculatorBanner.title.realEstate": "Financez votre bien",
                                "av.creditCalculatorBanner.priceLabel": "\xc0 partir de",
                                "av.creditCalculatorBanner.cta": "Simuler",
                                "av.preApprovedCredit.modal.title": "Obtenez votre pr\xe9accord de cr\xe9dit",
                                "av.preApprovedCredit.modal.auto.title": "\xcatre Rappel\xe9",
                                "av.preApprovedCredit.modal.auto.subtitle": "Remplissez les champs pour recevoir plus d'informations",
                                "av.preApprovedCredit.form.borrowerProfile.title": "Profil de l'emprunteur",
                                "av.preApprovedCredit.form.profession.placeholder": "S\xe9lectionnez votre profession",
                                "av.preApprovedCredit.form.creditAmount.placeholder": "Montant de cr\xe9dit",
                                "av.preApprovedCredit.form.financingType.placeholder": "Type de financement",
                                "av.preApprovedCredit.form.submit.button": "Obtenir mon pr\xe9accord",
                                "av.preApprovedCredit.form.submit.success": "Votre demande a \xe9t\xe9 envoy\xe9e avec succ\xe8s !",
                                "av.preApprovedCredit.form.submit.error": "Une erreur est survenue lors de l'envoi de votre demande.",
                                "av.preApprovedCredit.form.validation.age.invalid": "Veuillez entrer un \xe2ge valide",
                                "av.preApprovedCredit.form.validation.age.min": "L'\xe2ge minimum est de 18 ans",
                                "av.preApprovedCredit.form.validation.age.max": "L'\xe2ge maximum est de 100 ans",
                                "av.preApprovedCredit.form.validation.price.invalid": "Veuillez entrer un prix valide",
                                "av.adview.gt.section.heading.title": "Cette offre pourrait vous int\xe9resser",
                                "av.adview.gt.section.heading.subtitle": "D\xe9couvez la nouvelle {{car}} sur Moteur.ma",
                                "av.adview.gt.section.onboarding.1": "Sp\xe9cifications et caract\xe9ristiques",
                                "av.adview.gt.section.onboarding.2": "Prix des diff\xe9rentes versions",
                                "av.adview.gt.section.onboarding.3": "Concessionnaires pr\xe8s de chez vous",
                                "av.adview.gt.tag": "AUTO NEUF",
                                "av.adview.mouteur.tag": "MOTEUR.MA",
                                "av.adview.gt.price": "\xe0 partir de",
                                "av.adview.gt.section.cta": "VOIR LE PRIX",
                                "av.advertising.googleAdsTitle": "Annonces Google",
                                "av.advertising.avito-advertising-logo-url": "/phoenix-assets/imgs/layout/avito-advertising-logo.webp",
                                "av.delivery.step.continue": "Continuer",
                                "av.delivery.step.back": "Retour",
                                "av.delivery.step1.title": "Vos informations",
                                "av.delivery.step1.firsName": "Pr\xe9nom",
                                "av.delivery.step1.firsName-placeholder": "Votre pr\xe9nom",
                                "av.delivery.step1.email-placeholder": "Votre addresse email",
                                "av.delivery.step1.phone": "T\xe9l\xe9phone",
                                "av.delivery.step1.phone-placeholder": "Votre num\xe9ro de t\xe9l\xe9phone",
                                "av.delivery.step2.title": "Adresse de livraison",
                                "av.delivery.step2.city-placeholder": "Choisir une ville",
                                "av.delivery.step2.area-placeholder": "Choisir un Secteur",
                                "av.delivery.step2.address": "Adresse",
                                "av.delivery.step3.title": "R\xe9capitulatif",
                                "av.delivery.step3.detail-delivery": "D\xe9tail de livraison",
                                "av.delivery.step3.detail-order": "D\xe9tail de la commande",
                                "av.delivery.step3.info-text": "Les paiements seront effectu\xe9s en esp\xe8ces \xe0 la livraison",
                                "av.delivery.step4.thanks": "Merci",
                                "av.delivery.step4.contact-text": "Nous allons vous contacter par t\xe9l\xe9phone dans moins de 2 heures pour confirmer avec vous l'adresse et le moment de livraison",
                                "av.delivery.step4.back": "Retour \xe0 l'annonce",
                                "av.adview.delivery.badge.title": "Livraison",
                                "av.adview.delivery.badge.text": "Faites-vous livrer cet article sans bouger de chez vous.",
                                "av.adview.delivery.noPrice": "Prix non indiqu\xe9",
                                "av.adview.delivery.paymentOnDelivery": "Paiement \xe0 la livraison",
                                "av.adview.delivery.titleDetails": "D\xe9tail de la commande",
                                "av.adview.delivery.initialPrice": "Prix sur l'annonce",
                                "av.adview.delivery.deliveryPrice": "Frais de livraison",
                                "av.adview.delivery.fromPrice": " \xe0 partir de ",
                                "av.adview.delivery.order": "Commander",
                                "av.offers.heading": "Offres du moment",
                                "av.services.heading": "Services",
                                "av.adview.Kifal.adview.btn": "expertiser cette voiture",
                                "av.adview.Kifal.popup.text": "V\xe9rifier l'\xe9tat m\xe9canique et administratif du v\xe9hicule avant l'achat. Veuillez laisser vos coordonn\xe9es, vous serez contact\xe9 le plus t\xf4t possible par un de nos agents.",
                                "av.adview.Kifal.popup.subTitle": "Prix: 450 DH TTC (payable sur place au moment de l'expertise)",
                                "av.adview.Kifal.popup.textDownload": "Cliquez ici pour voir un exemple de rapport d'expertise",
                                "av.adview.Kifal.popup.titleSubmited": "Votre demande a \xe9t\xe9 envoy\xe9e avec succ\xe8s. Vous serez contact\xe9 le plus t\xf4t possible par un de nos agents.",
                                "av.listing.searchBox.filters.heading": "Filtres",
                                "av.listing.searchBox.filters.moreFilters": "Plus de filtres",
                                "av.listing.searchBox.placeholder.keyword": "Que recherchez-vous?",
                                "av.listing.searchBox.extraDetails.instruction": "Vous pouvez selectionner un o\xf9 plusieurs crit\xe8res.",
                                "av.listing.searchBox.placeholder.city": "Tapez la ville",
                                "av.listing.searchBox.placeholder.area": "Tapez le secteur",
                                "av.listing.searchBox.placeholder.price.min": "Prix min",
                                "av.listing.searchBox.placeholder.price.max": "Prix max",
                                "av.listing.searchBox.placeholder.brand": "Tapez la marque",
                                "av.listing.searchBox.placeholder.model": "Tapez le mod\xe8le",
                                "av.listing.searchBox.placeholder.pfiscale": "Tapez la puissance fiscale",
                                "av.listing.searchBox.label.transaction": "Transaction",
                                "av.listing.searchBox.placholder.all": "Tout",
                                "av.listing.searchBox.searchSuggestions.inCategory": "dans {{categoryName}}",
                                "av.listing.searchBox.recentSearch.title": "Recherches r\xe9centes",
                                "av.listing.searchBox.recentSearch.minPrice": "plus de {{minPrice}} Dhs",
                                "av.listing.searchBox.recentSearch.maxPrice": "moins de {{maxPrice}} Dhs",
                                "av.listing.searchBox.recentSearch.betweenPrice": "entre {{minPrice}} et {{maxPrice}} Dhs",
                                "av.listing.searchSidebar.search": "Recherche",
                                "av.listing.highlighted.tag": "Star",
                                "av.listing.premium.heading": "Premium",
                                "av.listing.premium.tag": "premium",
                                "av.listing.layout.grid": "Cartes",
                                "av.listing.layout.list": "Liste",
                                "av.listing.AllCategories": "Toutes les cat\xe9gories",
                                "av.listing.H1.Template": "{{category}} {{brand}} {{model}} {{pfiscale}} {{adTypeSlug}} {{preposition}} {{area}} {{cityOrCountry}} {{allAdsCount}} {{adTypeLabel}}",
                                "av.listing.saveSearch.long": "Sauvegarder la recherche",
                                "av.listing.saveSearch.toast.savedSearch": " Votre recherche est sauvegard\xe9e",
                                "av.listing.saveSearch.toast.searchAlreadySaved": "Cette recherche est d\xe9j\xe0 sauvegard\xe9e",
                                "av.listing.saveSearch.toast.error": "Nous rencontrons actuellement des difficult\xe9s pour sauvegarder cette recherche, r\xe9essayez plus tard!",
                                "av.listing.results.deliveryLabel": "Livraison",
                                "av.listing.categories.heading": "D\xe9couvrez nos cat\xe9gories",
                                "av.listing.popular-ads.title": "Populaire sur Avito",
                                "av.listing.extended.city": "Aucune annonce trouv\xe9e dans le quartier choisi, votre r\xe9sultat de recherche a \xe9t\xe9 \xe9tendu \xe0 toute la ville.",
                                "av.listing.extended.region": "Aucune annonce trouv\xe9e dans la ville choisie, votre r\xe9sultat de recherche a \xe9t\xe9 \xe9tendu \xe0 toute la r\xe9gion.",
                                "av.listing.extended.country": "Aucune annonce trouv\xe9e dans la localisation choisie, votre r\xe9sultat de recherche a \xe9t\xe9 \xe9tendu \xe0 tout le Maroc.",
                                "av.listing.extended.price": "Aucune annonce trouv\xe9e selon vos filtres, votre recherche a \xe9t\xe9 \xe9tendue.",
                                "av.listing.seoLinks.similar.heading": "Recherches similaires",
                                "av.listing.seoLinks.popular.heading": "Recherches rapides",
                                "av.listing.seoLinks.popular.cities.heading": "Villes populaires",
                                "av.listing.filter.hint.button": "Filtrer",
                                "av.listing.filter.sideNav.title": "Filtrer votre recherche",
                                "av.listing.filter.search.cta": "{{searchCountResult}} annonces",
                                "av.listing.urgent": "Urgent",
                                "av.listing.promo": "Promo {{discount}}",
                                "av.listing.price.decreased.tooltip.label": "Prix \xe0 la baisse",
                                "av.listing.price.increased.tooltip.label": "Prix en hausse",
                                "av.listing.verified.seller.tooltip.label": "V\xe9rifi\xe9",
                                "av.listing.vrd.heading": "Vous cherchez de la location journali\xe8re?",
                                "av.listing.vrd.content": "On vous a trouv\xe9 {{count}} annonces dans la cat\xe9gorie location de vacances, voulez vous les voir?",
                                "av.listing.vrd.action": "Voir plus d\u2019annonces",
                                "av.listing.seo.title": "Vente et achat en ligne partout au Maroc - Avito",
                                "av.listing.seo.title.category": "{{category}} - Avito Maroc | {{vertical}}",
                                "av.listing.seo.title.category.subcategory": "{{category}} {{subcategory}} - Avito Maroc | {{vertical}}",
                                "av.listing.seo.title.keyword": "{{keyword}} : D\xe9couvrez {{results_number}} annonces - Avito",
                                "av.listing.seo.title.keyword.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{keyword}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.category.subcategory": "D\xe9couvrez {{results_number}} annonces pour {{subcategory}} {{keyword}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.location": "Annonces pour {{keyword}} \xe0 {{location}} - Avito",
                                "av.listing.seo.title.keyword.location.sublocation": "{{keyword}} \xe0 {{sublocation}} {{location}} - Avito",
                                "av.listing.seo.title.keyword.location.category": "Annonces de {{keyword}} {{category}} \xe0 {{location}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.location.category.subcategory": "Annonces de {{subcategory}} {{keyword}} \xe0 {{location}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.location.sublocation.category": "{{keyword}} dans {{category}} \xe0 {{sublocation}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.location.sublocation.category.subcategory": "Annonces de {{keyword}} dans {{subcategory}} \xe0 {{sublocation}} {{location}} - Avito | {{vertical}}",
                                "av.listing.seo.title.location": "Achetez et vendez en ligne pr\xe8s de chez vous \xe0 {{location}} Maroc - Avito",
                                "av.listing.seo.title.location.category": "{{category}} \xe0 {{location}} - Avito | {{vertical}}",
                                "av.listing.seo.title.location.category.subcategory": "{{subcategory}} \xe0 {{location}} - Avito | {{vertical}}",
                                "av.listing.seo.title.location.sublocation": "Annonces en ligne \xe0 {{sublocation}} {{location}} - Avito",
                                "av.listing.seo.title.location.sublocation.category": "{{category}} \xe0 {{sublocation}} - Avito | {{vertical}}",
                                "av.listing.seo.title.location.sublocation.category.subcategory": "{{subcategory}} \xe0 {{sublocation}} {{location}} - Avito | {{vertical}}",
                                "av.listing.seo.title.category.brandModel": "{{brand}}{{model}} - au Maroc | {{vertical}}",
                                "av.listing.seo.title.location.category.brandModel": "{{brand}}{{model}} - \xe0 {{location}} Maroc | {{vertical}}",
                                "av.listing.seo.title.location.sublocation.category.brandModel": "{{brand}}{{model}} - \xe0 {{sublocation}} {{location}} Maroc | {{vertical}}",
                                "av.listing.seo.title.keyword.location.sublocation.category.brandModel": "{{brand}}{{model}} - \xe0 {{sublocation}} {{location}} Maroc | {{vertical}}",
                                "av.listing.seo.title.keyword.location.category.brandModel": "{{brand}}{{model}} - \xe0 {{location}} Maroc | {{vertical}}",
                                "av.listing.seo.title.keyword.category.brandModel": "{{brand}}{{model}} - au Maroc | {{vertical}}",
                                "av.listing.seo.description": "Vendez, achetez et louez vos biens sur Avito \u2705 la platefotrme num\xe9ro 1 de vente et d'achat au Maroc : Voitures, T\xe9l\xe9phones, Appartements, Motos etc.",
                                "av.listing.seo.description.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{adTypeSlug}} au Maroc, sur Avito.ma \u2705 La plateforme num\xe9ro 1 de vente et d'achat des biens et services",
                                "av.listing.seo.description.category.subcategory": "Visitez {{results_number}} annonces dans la cat\xe9gorie {{subcategory}} {{adTypeSlug}} partout au Maroc sur Avito la premi\xe8re plateforme d'achat et vente en ligne",
                                "av.listing.seo.description.keyword": "D\xe9couvrez {{results_number}} annonces pour {{keyword}} au Maroc au meilleur prix. Avito \u2705 la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.seo.description.keyword.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{keyword}} {{adTypeSlug}} au Maroc au meilleur prix. Avito \u2705 la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.seo.description.keyword.category.subcategory": "D\xe9couvrez {{results_number}} annonces pour {{subcategory}} {{keyword}} {{adTypeSlug}} au Maroc au meilleur prix. Avito \u2705 la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.seo.description.keyword.location": "D\xe9couvrez {{results_number}} annonces pour {{keyword}} \xe0 {{location}} au meilleur prix. Avito \u2705 la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.seo.description.keyword.location.sublocation": "D\xe9couvrez {{results_number}} annonces pour {{keyword}} \xe0 {{sublocation}} avec des prix attractifs. Avito \u2705 la premi\xe8re plateforme de vente et d'achat \xe0 {{location}}",
                                "av.listing.seo.description.keyword.location.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{keyword}} \xe0 {{location}} au meilleur prix. Avito \u2705 la plus grande plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.keyword.location.category.subcategory": "D\xe9couvrez {{results_number}} annonces pour {{subcategory}} {{keyword}} {{adTypeSlug}} \xe0 {{location}} au meilleur prix. Avito \u2705 la plus grande plateforme de vente et d'achat en ligne au Maroc",
                                "av.listing.seo.description.keyword.location.sublocation.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{keyword}} {{adTypeSlug}} \xe0 {{sublocation}} au meilleur prix. Avito \u2705 la premi\xe8re plateforme de petites annonces \xe0 {{location}}",
                                "av.listing.seo.description.keyword.location.sublocation.category.subcategory": "D\xe9couvrez {{results_number}} annonces pour {{subcategory}} {{adTypeSlug}} {{keyword}} \xe0 {{sublocation}} au meilleur prix. Avito \u2705 la premi\xe8re plateforme de petites annonces \xe0 {{location}}",
                                "av.listing.seo.description.location": "Avito \u2705 la premi\xe8re plateforme de vente et d'achat en ligne au Maroc",
                                "av.listing.seo.description.location.category": "Avito vous propose {{results_number}} annonces dans la cat\xe9gorie {{category}} {{adTypeSlug}} disponibles \xe0 {{location}}. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.category.subcategory": "Avito a environ {{results_number}} annonces disponibles pour {{subcategory}} {{adTypeSlug}} \xe0 {{location}}. Avito \u2705 la plateforme num\xe9ro 1 de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.sublocation": "Avito.ma \u2705 la premi\xe8re plateforme de vente et d'achat \xe0 {{sublocation}} {{location}}",
                                "av.listing.seo.description.location.sublocation.category": "Avito vous propose {{results_number}} offres disponibles dans la cat\xe9gorie {{category}} {{adTypeSlug}} \xe0 {{sublocation}} {{location}}. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.sublocation.category.subcategory": "Avito vous propose {{results_number}} annonces en ligne dans la cat\xe9gorie {{subcategory}} {{adTypeSlug}} {{sublocation}}. Avito \u2705 la plateforme num\xe9ro 1 de vente et d'achat \xe0 {{location}}",
                                "av.listing.seo.description.with_keyword": "D\xe9couvrez {{results_number}} annonces concernant {{keyword}} {{adTypeSlug}} \xe0 {{location}} au meilleur prix sur Avito.ma \u2705",
                                "av.listing.seo.description.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles au Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles \xe0 {{location}} Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.sublocation.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles \xe0 {{sublocation}} {{location}} Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.keyword.location.sublocation.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles \xe0 {{sublocation}} {{location}} Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.keyword.location.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles \xe0 {{location}} Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.keyword.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles au Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.messages.adinfo.title": "R\xe9sum\xe9 de l'annonce",
                                "av.messages.adinfo.localisation": "Localisation",
                                "av.messages.form.title": "Envoyer message \xe0 \xab {{sellerName}} \xbb",
                                "av.messages.form.email.placeholder": "exemple@domain.com",
                                "av.messages.form.description.placeholder": "Ecrivez votre message ici",
                                "av.messages.form.cv": "CV",
                                "av.messages.form.cv.caption": "(2.5Mo Max)",
                                "av.messages.form.cv.caption.optional": "(2.5Mo Max, facultatif)",
                                "av.messages.form.cv.placeholder": "Formats autoris\xe9s : pdf, jpg, jpeg, rtf, odt",
                                "av.messages.form.attachmentCTA": "Attacher votre CV",
                                "av.messages.form.error.emailExist": "{{email}} cet adresse mail existe d\xe9j\xe0 ",
                                "av.messages.form.error.email.notRegitred": "Votre email {{email}} ne correspond \xe0 aucun compte. veuillez cr\xe9er un compte gratuitement en cliquant ici.",
                                "av.messages.form.error.signin": "veuillez vous connecter",
                                "av.messages.form.cta": "Envoyer votre message",
                                "av.messages.form.alert.title": "Attention :",
                                "av.messages.form.alert.text": "Il ne faut jamais envoyer de l\u2019argent par virement bancaire ou \xe0 travers les agences de transfert d\u2019argent lors de l\u2019achat des biens disponibles sur le site. Avito.ma n\u2019est pas garant des transactions et ne joue pas le r\xf4le d\u2019interm\xe9diaire.",
                                "av.messages.sent.title": "Votre message a bien \xe9t\xe9 envoy\xe9.",
                                "av.messages.sent.desc": "Si vous disposez d'un compte, connectez-vous pour acc\xe9der au chat et retrouver vos conversations.\nSinon, vos \xe9changes continuent par email.",
                                "av.messages.sent.cta.back": "Retour a l'annonce",
                                "av.listing.phone.seo.title": "{{filters}} au Maroc",
                                "av.listing.phone.seo.title.location": "{{filters}} \xe0 {{location}}",
                                "av.listing.phone.seo.title.location.sublocation": "{{filters}} \xe0 {{sublocation}} {{location}}",
                                "av.listing.phone.seo.description": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} au Maroc. \ud83d\udcf1  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.phone.seo.description.location": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} \xe0 {{location}}. \ud83d\udcf1  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.phone.seo.description.location.sublocation": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} \xe0 {{sublocation}} {{location}}. \ud83d\udcf1  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.title": "{{filters}} au Maroc",
                                "av.listing.cars.seo.title.minYear": "{{filters}} ou plus au Maroc",
                                "av.listing.cars.seo.title.maxYear": "{{filters}} ou moins au Maroc",
                                "av.listing.cars.seo.title.location": "{{filters}} \xe0 {{location}}",
                                "av.listing.cars.seo.title.location.sublocation": "{{filters}} \xe0 {{sublocation}} {{location}}",
                                "av.listing.cars.seo.title.location.minYear": "{{filters}} ou plus \xe0 {{location}}",
                                "av.listing.cars.seo.title.location.maxYear": "{{filters}} ou moins \xe0 {{location}}",
                                "av.listing.cars.seo.title.location.sublocation.minYear": "{{filters}} ou plus \xe0 {{sublocation}} {{location}}",
                                "av.listing.cars.seo.title.location.sublocation.maxYear": "{{filters}} ou moins \xe0 {{sublocation}} {{location}}",
                                "av.listing.cars.seo.description": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} au Maroc. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.description.minYear": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} ou plus au Maroc. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.description.maxYear": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} ou moins au Maroc. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.description.location": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} \xe0 {{location}}. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.description.location.sublocation": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} \xe0 {{sublocation}} {{location}}. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.description.location.minYear": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} ou plus \xe0 {{location}}. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.description.location.maxYear": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} ou moins \xe0 {{location}}. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.description.location.sublocation.minYear": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} ou plus \xe0 {{sublocation}} {{location}}. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.cars.seo.description.location.sublocation.maxYear": "D\xe9couvrez {{resultsCount}} annonces pour {{filters}} ou moins \xe0 {{sublocation}} {{location}}. \ud83d\ude97  Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.signup.cta": "S\u2019inscrire",
                                "av.signup.page.title": "Cr\xe9er un compte Avito.ma",
                                "av.signup.phone_verification.page.subtitle": "Entrez votre num\xe9ro de t\xe9l\xe9phone ci-dessous",
                                "av.signup.form.page.subtitle": "Entrez vos coordonn\xe9es ci-dessous",
                                "av.signup.city.placeholder": "S\xe9lectionner une ville",
                                "av.signup.password.placeholder": "Choisissez un mot de passe",
                                "av.signup.password.tip": "(Au moins 5 caract\xe8res) Choisissez un mot de passe qui n'est pas facile \xe0 deviner.",
                                "av.signup.password.confirm": "Confirmer le mot de passe",
                                "av.signup.create.account.button": "Cr\xe9er un compte",
                                "av.signup.error.field.empty": "Veuillez S\xe9lectionner une ville",
                                "av.signup.shop.title": "Commencez Votre Aventure Avec Avito Boutique Aujourd'hui !",
                                "av.signup.shop.category.label": "La Cat\xe9gorie de votre boutique ?",
                                "av.signup.shop.subscriptionType.label": "Quel plan d'abonnement ?",
                                "av.signup.shop.request.title": "Votre demande est envoy\xe9e",
                                "av.signup.shop.request.subTitle": "Un agent vous contactera dans les 24 heures.",
                                "av.signup.create.shop.cta": "Cr\xe9ez votre boutique",
                                "av.shop.signup.cta": "Soumettre",
                                "av.messaging.channel.action.block": "Bloquer la conversation",
                                "av.messaging.channel.action.unBlock": "D\xe9bloquer la conversation",
                                "av.messaging.channel.action.delete": "Supprimer la conversation",
                                "av.messaging.attachment.errorMaxSize": "Votre fichier depasse la limite autoriser veuillez selectionner une fichier moins de 5 Mb",
                                "av.messaging.textarea.hide": "pour continuer a utiliser cette conversation veuillez s\xe9lectionner l option debloquer dans le sous menu en haut ",
                                "av.messaging.emptymessage.title": "Bienvenue sur votre messagerie !",
                                "av.messaging.emptymessage.description": "Simple et rapide, elle vous permet d'\xe9changer entre particulier La mise en relation s'effectue toujours depuis une annonce en cliquant sur \"Envoyer un message\".",
                                "av.homepage.popular-categories": "Cat\xe9gories populaires",
                                "av.homepage.introHighlight.title": "1er site d'annonces gratuites au Maroc",
                                "av.homepage.introHighlight.subTitle": "Trouver la bonne affaire parmi {{count}} annonces",
                                "av.homepage.newCars": "Voitures neuves",
                                "av.homepage.popularCities": "Villes populaires",
                                "av.homepage.popularSearch": "Recherches populaires",
                                "av.homepage.appBanner.title": "Achetez et vendez partout!",
                                "av.homepage.appBanner.subTitle": "T\xe9l\xe9chargez notre application",
                                "av.homepage.appStats.percent1": "73%",
                                "av.homepage.appStats.text1": "Des objets et annonces sont vendus en moins de 3 jours",
                                "av.homepage.appStats.percent2": "92%",
                                "av.homepage.appStats.text2": "De nos utilisateurs sont satisfaits",
                                "av.homepage.viewmore.btn": "Voir plus",
                                "av.re.homepage.searchbox.buy.tab.title": "Ventes",
                                "av.re.homepage.searchbox.rental.tab.title": "Locations",
                                "av.re.homepage.searchbox.ImmoNeuf.tab.title": "Immo Neuf",
                                "av.re.homepage.searchbox.vacation.tab.title": "Location vacances",
                                "av.re.homepage.searchbox.colocation.tab.title": "Colocations",
                                "av.re.homepage.searches.popular_searches.title": "Recherches populaires",
                                "av.re.homepage.searches.saved_searches.title": "Recherches sauvegard\xe9es",
                                "av.re.homepage.searches.saved_searches.login.title": "Se connecter pour visualiser la liste de vos recherches sauvegard\xe9es",
                                "av.re.homepage.searches.saved_searches.cta": "Effectuez une recherche",
                                "av.re.homepage.services.slider_section.title": "Nos services immobiliers",
                                "av.re.homepage.services.immo_neuf.title": "Immoneuf",
                                "av.re.homepage.services.immo_neuf.description": "Avito Immoneuf est la plateforme num\xe9ro 1 de l'immobilier neuf au Maroc, offrant le plus grand choix de biens immobiliers pour r\xe9aliser tous les r\xeaves.",
                                "av.re.homepage.services.loan_simulator.title": "Simulateur de Cr\xe9dit",
                                "av.re.homepage.services.loan_simulator.description": "Obtenez une estimation rapide de votre cr\xe9dit avec le simulateur simple et pr\xe9cis d\u2019Avito. Ce service exclusif vous permet de calculer vos mensualit\xe9s et d'\xe9valuer la faisabilit\xe9 de votre pr\xeat en quelques clics.",
                                "av.re.homepage.services.shops.title": "Boutiques Immo",
                                "av.re.homepage.services.shops.description": "Cr\xe9ez votre boutique immobili\xe8re sur Avito Maroc et augmentez vos ventes ! Inscrivez-vous facilement et publiez vos annonces pour atteindre un large public \xe0 la recherche de biens immobiliers.",
                                "av.re.homepage.services.boost.title": "Services de Boost pour particulier",
                                "av.re.homepage.services.boost.description": "Maximisez la visibilit\xe9 de vos annonces avec nos services de boost pour particuliers. Augmentez vos chances de vente ou de location en pla\xe7ant vos annonces en t\xeate des r\xe9sultats de recherche, attirant ainsi plus d'acheteurs ou de locataires potentiels.",
                                "av.global.error.title": "erreur lors de connexion",
                                "av.global.error.description": "D\xe9sol\xe9. Un probl\xe8me est survenu. Veuillez r\xe9essayer ult\xe9rieurement.\n    Si le probl\xe8me persiste, veuillez consulter le site Web www.avito.ma/help ",
                                "av.shops.sort.date.title": "Trier par : Date",
                                "av.shops.sort.price.title": "Trier par : Prix",
                                "av.shops.searchbox.heading": "Rechercher dans la boutique ",
                                "av.shops.listing.heading": "Toutes les annonces de la boutique {{name}} ({{count}})",
                                "av.shops.summary.heading": "Boutique Avito: ",
                                "av.shops.summary.website": "Aller sur le site",
                                "av.shops.title.default": "Boutique {{name}} | {{category}} \xe0 {{city}} | Avito.ma",
                                "av.shops.description.default": "Boutique {{name}} vous propose un large choix de produits {{category}} \xe0 {{city}}",
                                "av.shops.listing.categoryCard.label": "Boutique(s)",
                                "av.shops.listing.shopCard.article": "Articles",
                                "av.shops.listing.shopCard.memberSince": "Membre depuis ",
                                "av.shops.listing.searchBox.keyword.placeholder": "Nom de la boutique",
                                "av.shops.listing.categoryPanel.heading": "Cat\xe9gories des boutiques",
                                "av.shops.listing.categoryPanel.subtitle": "Trouvez rapidement votre magasin pr\xe9f\xe9r\xe9",
                                "av.shops.listing.shopCard.heading": "Boutiques ",
                                "av.shops.listing.title.default": "Boutiques {{category}} {{keyword}} {{city}} | Avito.ma",
                                "av.shops.listing.description.default": "D\xe9couvrez {{count}} annonces pour nos boutiques {{category}} {{keyword}} {{city}} | Avito la plus grande plateforme de petites annonces au Maroc",
                                "av.shops.listing.banner.heading": "Avec la Boutique Avito, vous obtenez tous ces avantages:",
                                "av.shops.listing.banner.openShop": "Ouvrir une boutique",
                                "av.shops.listing.banner.alreadyAMember": "D\xe9ja inscrit?",
                                "av.shops.listing.banner.text1": "Un tarif imbattable pour les professionnels",
                                "av.shops.listing.banner.text2": "Gestion simple de votre profil et des annonces",
                                "av.shops.listing.banner.text3": "Une adresse unique: avito.ma/votremagasin",
                                "av.shops.listing.banner.text4": "Une vitrine de votre marque dans les listes de Avito PRO",
                                "av.ecommerce.checkout.order.itemsInStock": "{{itemsLeft}} Articles en stock",
                                "av.ecommerce.checkout.order.itemsOutOfStock": "Stock \xe9puis\xe9",
                                "av.ecommerce.checkout.order.subtotal": "Sous-total",
                                "av.ecommerce.checkout.order.shipping": "Frais de livraison",
                                "av.ecommerce.checkout.order.total": "Total TTC",
                                "av.ecommerce.checkout.delivery.heading": "D\xe9tails de livraison",
                                "av.ecommerce.checkout.delivery.subtitle": "Compl\xe9tez votre achat en fournissant vos coordonn\xe9es de livraison",
                                "av.ecommerce.checkout.delivery.name.label": "Nom et pr\xe9nom",
                                "av.ecommerce.checkout.delivery.name.placeholder": "Nom et pr\xe9nom",
                                "av.ecommerce.checkout.delivery.email.label": "Adresse Email",
                                "av.ecommerce.checkout.delivery.email.placeholder": "Adresse Email",
                                "av.ecommerce.checkout.delivery.phone.label": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.ecommerce.checkout.delivery.phone.placeholder": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.ecommerce.checkout.delivery.address.label": "Adresse de livraison",
                                "av.ecommerce.checkout.delivery.address.placeholder": "Adresse de livraison",
                                "av.ecommerce.checkout.cta.pay": "Acheter",
                                "av.ecommerce.checkout.cta.order": "Valider",
                                "av.ecommerce.adview.badge": "Achat en ligne",
                                "av.ecommerce.adview.cta": "Acheter Maintenant",
                                "av.ecommerce.adview.shop.note": "Utilisez votre compte utilisateur pour effectuer l'achat. ",
                                "av.ecommerce.adview.shop.note.login": "se connecter",
                                "av.ecommerce.checkout.cod.success.heading": "Votre commande est prise en compte",
                                "av.ecommerce.checkout.cod.success.subheading": "Merci pour votre confiance. Commande est en cours de pr\xe9paration pour la livraison.",
                                "av.ecommerce.checkout.cod.success.primaryCta": "Voir mes commandes",
                                "av.ecommerce.checkout.cod.success.secondaryCta": "Continuer vos achats",
                                "av.ecommerce.checkout.delivery.rememberCoords": "Sauvegarder mes coordonn\xe9es pour la prochaine fois",
                                "av.cotation.step": "\xc9tape {{stepText}}",
                                "av.cotation.steps.nextButton.label": "Passer \xe0 l'\xe9tape suivante",
                                "av.cotation.steps.carParams.label": "Renseignez les informations de votre voiture",
                                "av.cotation.steps.carStatus.label": "Pr\xe9cisez l\u2019\xe9tat de votre voiture ( Optionel )",
                                "av.cotation.steps.summary.label": "R\xe9capitulatif de vos donn\xe9es",
                                "av.cotation.steps.userInfo.label": "Renseignez vos informations personnelles",
                                "av.cotation.params.brand.label": "Marque",
                                "av.cotation.params.model.label": "Mod\xe8le",
                                "av.cotation.params.fuelType.label": "Carburant",
                                "av.cotation.params.gearType.label": "Bo\xeete \xe0 vitesses",
                                "av.cotation.params.year.label": "Ann\xe9e - Phase",
                                "av.cotation.params.version.label": "Version",
                                "av.cotation.params.horsePower.label": "Puissance r\xe9elle",
                                "av.cotation.params.fiscalPower.label": "Puissance fiscale",
                                "av.cotation.params.origin.label": "Origine",
                                "av.cotation.params.mileage.label": "Kilom\xe9trage",
                                "av.cotation.params.optional": "( Optionel )",
                                "av.cotation.params.errorMessage": "Ce champs est obligatoire",
                                "av.cotation.params.placeholder": "S\xe9lectionner",
                                "av.cotation.carStatusParams.mechanicalCondition.label": "Quel est l'\xe9tat m\xe9canique de votre voiture?",
                                "av.cotation.carStatusParams.carBodyCondition.label": "Quel est l'\xe9tat de la carrosserie?",
                                "av.cotation.carStatusParams.warningLights.label": "Est ce qu'il ya des voyants d'alerte allum\xe9s sur votre tableau de bord?",
                                "av.cotation.carStatusParams.reason.label": "Je suis int\xe9ress\xe9 par: ",
                                "av.cotation.userInfosFields.name.label": "Nom complet",
                                "av.cotation.userInfosFields.name.placeholder": "Veuillez saisir votre nom et pr\xe9nom",
                                "av.cotation.userInfosFields.name.error": "Veuillez renseigner ce champ",
                                "av.cotation.userInfosFields.phone.label": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.cotation.userInfosFields.phone.placeholder": "Veuillez saisir votre num\xe9ro de t\xe9l\xe9phone",
                                "av.cotation.userInfosFields.phone.error": "Saisissez un num\xe9ro de t\xe9l\xe9phone valide",
                                "av.cotation.userInfosFields.email.label": "Adresse Email",
                                "av.cotation.userInfosFields.email.placeholder": "Veuillez saisir votre adresse Email",
                                "av.cotation.userInfosFields.email.error": "Saisissez une adresse Email valide",
                                "av.cotation.userInfosFields.terms.wording": "J'accepte les ",
                                "av.cotation.userInfosFields.terms.link": "conditions g\xe9n\xe9rales d'utilisation",
                                "av.cotation.userInfosFields.terms.error": "Veuillez accepter les conditions d'utilisation",
                                "av.cotation.userInfosFields.reason.error": "Veuillez choisir une option",
                                "av.cotation.evaluations": "Mes estimations",
                                "av.cotation.landing.hero.heading": "Calculez la valeur de votre voiture avec la c\xf4te Avito",
                                "av.cotation.landing.hero.body": "Avito vous propose une estimation rapide, fiable et pr\xe9cise de votre voiture, remplissez les informations de votre voiture et recevez une estimation instantan\xe9e bas\xe9e sur le prix du march\xe9 automobile au Maroc.",
                                "av.cotation.common.evaluate": "Estimer votre voiture",
                                "av.cotation.common.howto": "Comment \xe7a marche",
                                "av.cotation.landing.hero.popularBrands": "\xc9VALUATION DES MARQUES POPULAIRES",
                                "av.cotation.evaluations.landing.onboarding.1.heading": "Calculez gratuitement votre C\xf4te occasion",
                                "av.cotation.evaluations.landing.onboarding.1.body": "Estimer pr\xe9cis\xe9ment son v\xe9hicule quand on vend, c'est fondamental. Savoir si le prix que l'on vous demande quand vous achetez est juste, c'est pr\xe9cieux avec la cote Avito vous aurez le juste prix march\xe9.",
                                "av.cotation.evaluations.landing.onboarding.2.heading": "Pourquoi la cote Avito",
                                "av.cotation.evaluations.landing.onboarding.2.body": "La valeur Avito est reconnu fiable par une majorit\xe9 de vendeurs et d'acheteurs. Des millions d'acheteurs consultent chaque mois nos platformes Avito& Moteur. La valeur Avito : Unique, Pr\xe9cise, Reconnue sur le march\xe9.",
                                "av.cotation.evaluations.landing.onboarding.3.heading": "Comment Estimer votre voiture",
                                "av.cotation.evaluations.landing.onboarding.3.body": "Ajoutez quelques d\xe9tails de base sur votre voiture d'occasion et recevez gratuitement la valeur de reprise de votre voiture en quelques minutes.",
                                "av.cotation.evaluations.landing.onboarding.premium.1.heading": "\xc9TAPE 1",
                                "av.cotation.evaluations.landing.onboarding.premium.1.body": "D\xe9marrer l'estimation en renseignant les informations suivantes afin d\u2019avoir une estimation fiable (marque, mod\xe8le, ann\xe9e, boite de vitesse, carburant, puissance fiscale...).",
                                "av.cotation.evaluations.landing.onboarding.premium.2.heading": "\xc9TAPE 2",
                                "av.cotation.evaluations.landing.onboarding.premium.2.body": "Renseigner l'\xe9tat de la voiture (carrosserie, m\xe9canique, les voyants du tableau de bord ).",
                                "av.cotation.evaluations.landing.onboarding.premium.3.heading": "\xc9TAPE 3",
                                "av.cotation.evaluations.landing.onboarding.premium.3.body": "Obtenez une estimation du prix du v\xe9hicule d\u2019occasion mais aussi sa valeur transaction, sa valeur annonce, son attractivit\xe9, son d\xe9lai de rotation et sa marge de n\xe9gociation.",
                                "av.cotation.landing.generic.text1": "Evaluez votre voiture en <span>2 minutes</span> et obtenez une premi\xe8re estimation gratuite",
                                "av.cotation.thankyou.heading": "F\xe9licitations!",
                                "av.cotation.thankyou.empty.heading": "Whoops!",
                                "av.cotation.thankyou.subheading": "L'estimation de votre voiture est compl\xe9t\xe9e",
                                "av.cotation.thankyou.limitReached.subheading": "Vous avez atteint votre limite de g\xe9n\xe9ration d'estimation",
                                "av.cotation.thankyou.limitReached.suggestion": "Merci de contacter le service client pour avoir plus d'informations",
                                "av.cotation.thankyou.empty.subheading": "Nous n'avons pas pu \xe9valuer votre voiture",
                                "av.cotation.thankyou.empty.suggestion": " Merci de v\xe9rifier les informations que vous avez saisies.",
                                "av.cotation.thankyou.email.body": "Nous vous avons envoy\xe9 l'estimation de votre voiture \xe0 l'adresse Email suivante:",
                                "av.cotation.thankyou.suggestion": "La fourchette de prix estim\xe9e est juste \xe0 titre indicatif, l'\xe9tat r\xe9el et les sp\xe9cifications suppl\xe9mentaires pourraient augmenter le prix de vente.",
                                "av.cotation.thankyou.resendEmail": "Renvoyer l'email",
                                "av.cotation.thankyou.emailSent": "Email envoy\xe9",
                                "av.cotation.thankyou.estimation.price": "Le prix de vente peut varier entre ",
                                "av.cotation.thankyou.estimation.price.and": " et ",
                                "av.cotation.thankyou.estimation.button": "Voir mes estimations",
                                "av.cotation.summary.heading": "Calcul du prix en cours",
                                "av.cotation.summary.email.body": "Merci de v\xe9rifier les informations de votre voiture avant de valider votre demande et passer \xe0 l\u2019\xe9tape finale.",
                                "av.cotation.summary.button.estimation": "Voir l\u2019estimation de ma voiture",
                                "av.cotation.summary.button.editInfos": "Modifiez les informations",
                                "av.cotation.estimations.heading": "Mes estimations",
                                "av.cotation.estimations.subheading": "Les valeurs des prix estim\xe9s sont uniquement \xe0 titre indicatif bas\xe9es sur les donn\xe9es du march\xe9 des voitures d'occasion au Maroc, pour vous donner une id\xe9e g\xe9n\xe9rale par rapport au prix du march\xe9. L'\xe9tat r\xe9el et les sp\xe9cifications suppl\xe9mentaires pourraient augmenter ou diminuer le prix de vente.",
                                "av.cotation.estimations.contactUs": "Contacter un Agent",
                                "av.cotation.estimations.expiryDate": "Date d'expiration",
                                "av.cotation.estimations.limitReached": "Vous avez atteint votre limite d'\xe9valuations!",
                                "av.cotation.estimations.seeMore": "Voir plus de d\xe9tails",
                                "av.cotation.estimations.contact.body": "Notre service client est disponible 7j/7 de 9h \xe0 20h sur le 0520428686",
                                "av.cotation.estimations.contact.number": "0520428686",
                                "av.cotation.estimations.contact.title": "Contacter un agent",
                                "av.cotation.estimations.expiry.title": "Date d'expiration",
                                "av.cotation.estimations.residualValue.title": "La valeur de r\xe9f\xe9rence",
                                "av.cotation.estimations.residualValue.body": "La valeur de r\xe9f\xe9rence est issue d\u2019un calcul sp\xe9cifique, l\u2019algorithme prend \xe0 la fois en compte le mod\xe8le, la date de mise en circulation et l\u2019\xe9tat de la voiture. Les donn\xe9es entr\xe9es par le vendeur sont ensuite compar\xe9es aux offres d\xe9j\xe0 en ligne et aux v\xe9hicules vendus pr\xe9c\xe9demment. Ainsi Avito auto pro fournit une estimation approximative de la c\xf4te du v\xe9hicule",
                                "av.cotation.estimations.adsValue.title": "La c\xf4te Avito",
                                "av.cotation.estimations.adsValue.body": "Une valeur de march\xe9 des derniers prix affiche\u0301s par les vendeurs sur nos plateformes (Avito& Moteur)",
                                "av.cotation.estimations.transactionValue.title": "La valeur de transaction",
                                "av.cotation.estimations.transactionValue.body": "L\u2019estimation du prix de vente re\u0301el pour un ve\u0301hicule, bas\xe9e sur l\u2019observation des valeurs de revente effectives et les transacations faites sur nos plateformes (Avito& Moteur)",
                                "av.cotation.estimations.margeOfNegoctiaition.title": "Marge de Negociation",
                                "av.cotation.estimations.margeOfNegoctiaition.body": " La marge de transaction attendue sur le prix de transaction",
                                "av.cotation.estimations.rotation.title": "D\xe9lai de Rotation",
                                "av.cotation.estimations.rotation.body": "D\xe9lai moyen de vente de votre voiture",
                                "av.cotation.estimations.attractiveness.title": "Attractivit\xe9 du Mod\xe8le",
                                "av.cotation.estimations.attractiveness.body": "Indice de liquidit\xe9 du mod\xe8le dans le march\xe9 automobile marocain dans les trois derniers mois.",
                                "av.cotation.estimations.newCarsPrice.title": "Prix du neuf",
                                "av.cotation.estimations.newCarsPrice.body": "Le prix catalogue, les caracte\u0301ristiques techniques, les e\u0301quipements de se\u0301rie et en option, issus du Re\u0301fe\u0301rentiel Avito Auto neuf",
                                "av.cotation.estimations.confidenceIndex.title": "Indice de confiance",
                                "av.cotation.estimations.confidenceIndex.body": "L'indice de confiance (1 \xe0 5) refl\xe9te la repr\xe9sentativit\xe9 des donn\xe9es et la taille de l'\xe9chantillon de v\xe9hicules permettant de calculer la cote Avito et de la pr\xe9cision des informations de votre v\xe9hicule.",
                                "av.cotation.estimations.great.title": "Agr\xe9able!",
                                "av.cotation.estimations.great.body": " Nous avons estim\xe9 la valeur de votre voiture!",
                                "av.cotation.login.heading": "Connexion",
                                "av.cotation.login.body": "\xc9conomisez plus de temps et recevez une estimation rapide et fiable.",
                                "av.cotation.login.email.label": "Adresse e-mail",
                                "av.cotation.login.email.placeholder": "Veuillez saisir votre adresse e-mail",
                                "av.cotation.login.email.error": "Saisissez une adresse e-mail valide",
                                "av.cotation.login.username.label": "Nom d'utilisateur",
                                "av.cotation.login.username.placeholder": "Veuillez saisir votre nom d'utilisateur",
                                "av.cotation.login.username.error": "Saisissez un nom d'utilisateur valide",
                                "av.cotation.login.password.label": "Mot de passe",
                                "av.cotation.login.password.placeholder": "Veuillez saisir votre mot de passe",
                                "av.cotation.login.password.error": "Saisissez un mot de passe valide",
                                "av.cotation.login.button": "Se connecter",
                                "av.cotation.login.error.retry": "Quelque chose ne va pas, veuillez r\xe9essayer plus tard.",
                                "av.cotation.login.error.unauthorized": "Vous n'\xeates pas autoris\xe9 \xe0 vous connecter! Merci de contacter le Service Client.",
                                "av.cotation.login.error.badCredentials": "Email et/ou mot de passe incorrect(s)",
                                "av.seller.center.product.status.active": "Produits actifs",
                                "av.seller.center.product.status.active.short": "Actif",
                                "av.seller.center.product.status.outOfStock": "Produits \xe9puis\xe9s",
                                "av.seller.center.product.status.outOfStock.short": "\xc9puis\xe9",
                                "av.seller.center.product.status.deactivated": "Produits d\xe9sactiv\xe9s",
                                "av.seller.center.product.status.deactivated.short": "D\xe9sactiv\xe9",
                                "av.seller.center.product.status.deleted": "Produits supprim\xe9s",
                                "av.seller.center.product.status.deleted.short": "Supprim\xe9",
                                "av.seller.center.order.status.pending.short": "En attente",
                                "av.seller.center.order.status.readyForDelivery": "Pr\xeat pour l'exp\xe9dition",
                                "av.seller.center.order.status.readyForDelivery.short": "Pr\xeat",
                                "av.seller.center.order.status.delivering": "Commandes en livraison",
                                "av.seller.center.order.status.delivering.short": "En livraison",
                                "av.seller.center.order.status.cancelled": "Commandes annul\xe9es",
                                "av.seller.center.order.status.cancelled.short": "Annul\xe9e",
                                "av.seller.center.order.status.returned.short": "Retourn\xe9e",
                                "av.seller.center.order.status.delivred": "Commandes livr\xe9es",
                                "av.seller.center.order.status.delivred.short": "Livr\xe9e",
                                "av.seller.center.payment.status.pending": "Commandes en attente",
                                "av.seller.center.payment.status.ongoing": "Commandes en cours",
                                "av.seller.center.payment.status.ongoing.short": "En cours",
                                "av.seller.center.payment.status.paid": "Commandes pay\xe9es",
                                "av.seller.center.payment.status.paid.short": "Pay\xe9e",
                                "av.seller.center.payment.status.refunded": "Commandes rembours\xe9es",
                                "av.seller.center.payment.status.refunded.short": "Rembours\xe9e",
                                "av.seller.center.headers.actions": "Actions",
                                "av.seller.center.product.preview": "Aper\xe7u",
                                "av.seller.center.product.ref": "R\xe9f#",
                                "av.seller.center.product.short": "Produit",
                                "av.seller.center.product.units": "Stock",
                                "av.seller.center.product.discount": "Remise",
                                "av.seller.center.product.status": "Statuts",
                                "av.seller.center.product.orders": "Commandes",
                                "av.seller.center.product.boost": "Pack de boost",
                                "av.seller.center.order.print": "Imprimer",
                                "av.seller.center.order.id": "Num\xe9ro de commande",
                                "av.seller.center.order.units": "N\xb0 d\u2019unit\xe9s",
                                "av.seller.center.order.date": "Date de commande",
                                "av.seller.center.order.paymentMethod": "Mode de paiement",
                                "av.seller.center.payment.commission": "Commission",
                                "av.seller.center.payment.status": "Statuts de paiement",
                                "av.seller.center.payment.orderStatus": "Statuts de commande",
                                "av.seller.center.my-products.mobile.text": "Pour traiter vos produits veuillez visiter la version desktop",
                                "av.seller.center.product.mobile.subText": "Commencez par trouver l'article qui correspond \xe0 vos besoins sur nos boutiques en ligne, et passez \xe0 la fonction de paiement instantan\xe9",
                                "av.seller.center.product.mobile.btn": "Voir mes commandes",
                                "av.seller.center.my-products.empty-state.text": "Vous n'avez pas de produit {{status}}",
                                "av.seller.center.my-products.empty-state.text.status.active": "ins\xe9r\xe9",
                                "av.seller.center.my-products.empty-state.text.status.outOfStock": "\xe9puis\xe9",
                                "av.seller.center.my-products.empty-state.text.status.deactivated": "d\xe9sactiv\xe9",
                                "av.seller.center.my-products.empty-state.text.status.deleted": "supprim\xe9",
                                "av.seller.center.my-products.empty-state.subText": 'Veuillez cliquer sur le bouton "Ajouter un produit" pour ins\xe9rer votre premier produit.',
                                "av.seller.center.my-orders.empty-state.text": "Vous n'avez pas de commande {{status}}",
                                "av.seller.center.my-orders.empty-state.text.status.pending": "en attente",
                                "av.seller.center.my-orders.empty-state.text.status.readyForDelivery": "pr\xeate pour l'exp\xe9dition",
                                "av.seller.center.my-orders.empty-state.text.status.delivering": "en livraison",
                                "av.seller.center.my-orders.empty-state.text.status.delivered": "livr\xe9e",
                                "av.seller.center.my-orders.empty-state.text.status.cancelled": "annul\xe9e",
                                "av.seller.center.my-payments.mobile.text": "Pour traiter vos paiements veuillez visiter la version desktop",
                                "av.seller.center.my-payments.empty-state.text": "Vous n'avez pas de {{paymentsStatus}}",
                                "av.seller.center.my-payments.empty-state.text.status.pending": "paiement en attente",
                                "av.seller.center.my-payments.empty-state.text.status.on-going": "paiement en cours",
                                "av.seller.center.my-payments.empty-state.text.status.payed": "paiement effectu\xe9",
                                "av.seller.center.my-payments.empty-state.text.status.refunded": "commande rembours\xe9e",
                                "av.seller.center.product.operations.searchbox.placeholder": "Que recherchez-vous ?",
                                "av.seller.center.product.operations.add.short": "Ajouter",
                                "av.seller.center.product.operations.add": "Ajouter un produit",
                                "av.seller.center.product.operations.export": "Exporter",
                                "av.seller.center.product.operations.activate.success.title": "Produit activ\xe9",
                                "av.seller.center.product.operations.activate.success.text": "Vous pouvez le booster en allant sur Mom compte > produits actifs ou en cliquant ici",
                                "av.seller.center.product.operations.deactivate": "D\xe9sactiver",
                                "av.seller.center.product.operations.deactivate.success": "Produit d\xe9sactiv\xe9 avec success",
                                "av.seller.center.product.operations.delete.confirmation.text": "Vous ne pouvez effectuer aucune action sur ce produit si vous le supprimer.",
                                "av.seller.center.product.operations.delete.success": "Produit supprim\xe9 avec success",
                                "av.seller.center.product.operations.adjust.stock.success": "Nombre d'unit\xe9 ajust\xe9 avec success",
                                "av.seller.center.product.operations.apply.discount.success": "Remise appliqu\xe9e avec success",
                                "av.seller.center.order.operations.prepare": "Article est pr\xeat",
                                "av.seller.center.order.operations.prepare.success": "l'article est maintenant pr\xeat pour l'exp\xe9dition",
                                "av.seller.center.order.operations.cancel.success": "Commande annul\xe9e avec success",
                                "av.seller.center.order.operations.delete.confirmation.text": "Vous ne pouvez effectuer aucune action sur cette commande si vous la supprimer.",
                                "av.seller.center.order.operations.delete.success": "Commande supprim\xe9e avec success",
                                "av.seller.center.product.insert.sections.insert": "Ajouter un produit",
                                "av.seller.center.product.insert.sections.general": "Informations g\xe9n\xe9rales",
                                "av.seller.center.product.insert.sections.details": "D\xe9tails du bien",
                                "av.seller.center.product.insert.fileds.category.label": "S\xe9lectionner la sous cat\xe9gorie",
                                "av.seller.center.product.insert.fileds.product.label": "Nom du produit",
                                "av.seller.center.product.insert.fileds.units.label": "Nombre d'unit\xe9s",
                                "av.seller.center.product.insert.fileds.price.label": "Prix unitaire",
                                "av.seller.center.product.insert.fileds.discount.label": "Remise",
                                "av.seller.center.product.insert.fileds.category.error.message": "Veuillez s\xe9lectionner la sous cat\xe9gorie",
                                "av.seller.center.product.insert.fileds.min.error.message": "Trop court, doit contenir au minimum {{min}} caract\xe8res.",
                                "av.seller.center.product.insert.fileds.max.error.message": "Trop long. doit contenir au maximum {{max}} caract\xe8res.",
                                "av.seller.center.product.insert.ctas.add": "Ajouter",
                                "av.seller.center.product.insert.ctas.return": "Retour",
                                "av.seller.center.product.edit": "Modifier le produit",
                                "av.seller.center.product.insert.success.subheading1": "Votre produit est ins\xe9r\xe9 avec succ\xe8s",
                                "av.seller.center.product.insert.success.subheading2": "Nous venons de vous envoyer un email de confirmation",
                                "av.seller.center.product.insert.success.helper": "Votre produit sera active dans quelque instants",
                                "av.common.messaging.conversations": "Toutes les conversations",
                                "av.common.messaging.input.placeholder": "\xc9crivez votre message...",
                                "av.common.attachment.label": "Pi\xe9ce jointe",
                                "av.common.messaging.start.history": "D\xe9marrer la conversation",
                                "av.common.messaging.select": "Selectionner une Conversation",
                                "av.common.messaging.select.helper": "Essayez de s\xe9lectionner une conversation pour commencer la discussion",
                                "av.common.messaging.start.history.helper": "d\xe9marrer la conversation en posant des questions sur la disponibilit\xe9 de l\u2019article",
                                "av.adview.nc.lead.generation.modal.title": "Etre rappel\xe9 par l'annonceur",
                                "av.adview.nc.lead.generation.modal.subtitle": "Remplissez les champs pour recevoir plus d'informations",
                                "av.adview.nc.lead.generation.modal.form.name": "Votre Nom & Pr\xe9nom",
                                "av.adview.nc.lead.generation.modal.form.name.error": "Veuillez entrer votre Nom & Pr\xe9nom !",
                                "av.adview.nc.lead.generation.modal.form.phone": "Votre T\xe9l\xe9phone",
                                "av.adview.nc.lead.generation.modal.form.phone.error": "Votre num\xe9ro de t\xe9l\xe9phone est incorrect !",
                                "av.adview.nc.lead.generation.modal.form.cgu.error": "Veuillez accepter les conditions g\xe9n\xe9rales d'utilisation !",
                                "av.adview.nc.lead.generation.modal.form.success": "Demande envoy\xe9e. Nous vous rappelons dans les plus brefs d\xe9lais.",
                                "av.vertical.RE.homepage.our-promoters": "Promoteurs immobiliers",
                                "av.vertical.RE.homepage.our-agents": "Agences immobili\xe8res",
                                "av.vertical.RE.homepage.hero.title": "Le plus grand choix de biens immobiliers pour r\xe9aliser tous vos r\xeaves",
                                "av.vertical.RE.homepage.searchbox.reset": "R\xe9initialiser le filtre",
                                "av.vertical.RE.homepage.searchbox.propertyTypeLabel": "S\xe9lectionnez un type de propri\xe9t\xe9",
                                "av.vertical.RE.homepage.searchbox.villeLabel": "S\xe9lectionnez une ville",
                                "av.vertical.market": "Avito Market",
                                "av.vertical.vehicules": "Avito V\xe9hicules",
                                "av.vertical.immobilier": "Avito Immobilier",
                                "av.vertical.entreprise": "Avito Entreprise",
                                "av.vertical.market.short": "Marketplace",
                                "av.vertical.vehicules.short": "V\xe9hicules",
                                "av.vertical.immobilier.short": "Immobilier",
                                "av.vertical.entreprise.short": "Emplois et Services"
                            }
                        }).t,
                        lang: r.a.FR.CODE
                    },
                    ar: {
                        __t: new o.Z(r.a.AR.CODE, {
                            ar: {
                                "av.common.homepage": "\u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629",
                                "av.common.ad-insert": "\u0648\u0636\u0652\u0639\u064f\u0648\u0627 \u0625\u0639\u0644\u0627\u0646\u0643\u064f\u0645",
                                "av.common.ad-insert.short": "\u0627\u0646\u0634\u0623",
                                "av.common.ad-insert.publish": "\u0627\u0646\u0634\u0631\u0648\u0627 \u0625\u0639\u0644\u0627\u0646\u0643\u064f\u0645",
                                "av.common.ad-insert.publish.short": "\u0627\u0646\u0634\u0631",
                                "av.common.chat": " \u0627\u0644\u0631\u0633\u0627\u0626\u0644 ",
                                "av.common.chat.short": "\u0645\u062d\u0627\u062f\u062b\u0629 \u0645\u0628\u0627\u0634\u0631\u0629",
                                "av.common.my-ads": "\u0627\u0639\u0644\u0627\u0646\u0627\u062a\u064a",
                                "av.common.my-orders": "\u0637\u0644\u0628\u0627\u062a\u064a",
                                "av.common.seller.my-products": "\u0645\u0646\u062a\u062c\u0627\u062a\u064a",
                                "av.common.seller.my-payments": "\u0645\u062f\u0641\u0648\u0639\u0627\u062a\u064a",
                                "av.common.classified.short": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a",
                                "av.common.classified.zero-results": "0 \u0625\u0639\u0644\u0627\u0646\u0627\u062a",
                                "av.common.classified.zero-results.for": "\u0644",
                                "av.common.classified.zero-results.in": "\u0641\u064a",
                                "av.common.classified.shops.zero-results": "0 \u0645\u062a\u0627\u062c\u0631",
                                "av.common.favorites": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a\u064a \u0627\u0644\u0645\u0641\u0636\u0644\u0629",
                                "av.common.favorites.short": "\u062a\u0641\u0636\u064a\u0644\u0627\u062a",
                                "av.common.stats": "\u0625\u062d\u0635\u0627\u0626\u064a\u0627\u062a\u064a",
                                "av.common.stats.short": "\u0625\u062d\u0635\u0627\u0626\u064a\u0627\u062a",
                                "av.common.settings.short": "\u0627\u0639\u062f\u0627\u062f\u0627\u062a",
                                "av.common.account": "\u062d\u0633\u0627\u0628\u064a \u0627\u0644\u062e\u0627\u0635",
                                "av.common.account.short": "\u062d\u0633\u0627\u0628",
                                "av.common.search": "\u0627\u0644\u0628\u062d\u062b \u0639\u0646 \u0625\u0639\u0644\u0627\u0646\u0627\u062a",
                                "av.common.search.avito": "\u0627\u0628\u062d\u062b \u0641\u064a {{category}} {{type}}",
                                "av.common.search.short": "\u0627\u0628\u062d\u062b",
                                "av.common.shops.short": "\u0627\u0644\u0645\u062a\u0627\u062c\u0631",
                                "av.common.magazine": "\u0645\u062c\u0644\u0629",
                                "av.common.greeting": "\u0645\u0631\u062d\u0628\u0627\u060c",
                                "av.common.separator_txt": "\u0623\u0648 \u0639\u0628\u0631",
                                "av.common.our_services": "\u062c\u062f\u064a\u062f",
                                "av.common.immoNeuf": "\u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062a \u0627\u0644\u062c\u062f\u064a\u062f\u0629",
                                "av.common.immoNeuf.description": "\u0639\u0642\u0627\u0631\u0627\u062a \u062c\u062f\u064a\u062f\u0629 \u0641\u064a \u062c\u0645\u064a\u0639 \u0623\u0646\u062d\u0627\u0621 \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.common.autoNeuf": "\u0627\u0644\u0633\u064a\u0627\u0631\u0627\u062a \u0627\u0644\u062c\u062f\u064a\u062f\u0629",
                                "av.common.autoNeuf.description": "\u0645\u0631\u062c\u0639 \u0627\u0644\u0633\u064a\u0627\u0631\u0627\u062a \u0627\u0644\u062c\u062f\u064a\u062f\u0629 \u0628\u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.common.currency": "\u062f\u0631\u0647\u0645",
                                "av.common.years": "\u0633\u0646\u0648\u0627\u062a",
                                "av.common.cancel": "\u0625\u0644\u063a\u0627\u0621",
                                "av.common.country": "\u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.common.page": "Page",
                                "av.common.action.validate": "\u062a\u0623\u0643\u064a\u062f",
                                "av.common.action.delete": "\u0645\u0633\u062d",
                                "av.common.city": "\u0627\u0644\u0645\u062f\u064a\u0646\u0629",
                                "av.common.area": "\u0627\u0644\u062d\u064a",
                                "av.common.areas": "\u0623\u062d\u064a\u0627\u0621",
                                "av.common.min": "\u0623\u062f\u0646\u0649",
                                "av.common.max": "\u0623\u0642\u0635\u0649",
                                "av.common.error": "!\u0642\u062f \u062d\u062f\u062b \u062e\u0637\u0623. \u0627\u0644\u0645\u0631\u062c\u0648 \u0627\u0639\u0627\u062f\u0629 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629",
                                "av.common.error.wentWrong": "\u0647\u0646\u0627\u0643 \u062e\u0637\u0623 \u0645\u0627!",
                                "av.common.error.retry": "\u0627\u0644\u0645\u0631\u062c\u0648 \u0625\u0639\u0627\u062f\u0629 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629",
                                "av.common.error.contactSupport": "\u0625\u0630\u0627 \u0627\u0633\u062a\u0645\u0631\u062a \u0627\u0644\u0645\u0634\u0643\u0644\u0629 \u060c \u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u062f\u0639\u0645 \u0627\u0644\u0639\u0645\u0644\u0627\u0621. {{csPhone}}",
                                "av.common.new": "\u062c\u062f\u064a\u062f",
                                "av.common.description": "\u0648\u0635\u0641",
                                "av.common.price.dhs": "{{price}} \u062f\u0631\u0647\u0645",
                                "av.common.price.points": "{{price}} \u0646\u0642\u0637\u0629",
                                "av.common.location_category": "{{category}} \u0641\u064a {{location}}",
                                "av.common.avito": "\u0623\u0641\u064a\u062a\u0648",
                                "av.common.lang_switch": "Fran\xe7ais",
                                "av.common.download": "\u062a\u062d\u0645\u064a\u0644",
                                "av.common.allRegions": "\u062c\u0645\u064a\u0639 \u0627\u0644\u0645\u062f\u0646",
                                "av.common.allCity": "\u0627\u0644\u0645\u062f\u064a\u0646\u0629 \u0643\u0644\u0647\u0627",
                                "av.common.allMorocco": "\u0627\u0644\u0645\u063a\u0631\u0628 \u0643\u0644\u0647",
                                "av.common.allModels": "\u062c\u0645\u064a\u0639 \u0627\u0644\u0646\u0645\u0627\u062f\u062c",
                                "av.common.allBreeds": "\u062c\u0645\u064a\u0639 \u0627\u0644\u0633\u0644\u0627\u0644\u0627\u062a",
                                "av.common.welcome": "\u0645\u0631\u062d\u0628\u064b\u0627 \u0628\u0643 \u0641\u064a \u0623\u0641\u064a\u062a\u0648",
                                "av.common.homePage": " \u0627\u0644\u0635\u0641\u062d\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629",
                                "av.common.congrats": "\u062a\u0647\u0627\u0646\u064a\u0646\u0627 {{name}}",
                                "av.common.address": "\u0639\u0646\u0648\u0627\u0646",
                                "av.common.calendar": "\u062c\u062f\u0648\u0644 \u0627\u0644\u0645\u0648\u0627\u0639\u064a\u062f",
                                "av.common.apply": "\u062a\u0623\u0643\u064a\u062f",
                                "av.common.availability": "\u062a\u0648\u0641\u0631",
                                "av.common.total": "\u0645\u062c\u0645\u0648\u0639",
                                "av.common.dismiss": "\u0641\u0647\u0645\u062a",
                                "av.common.price": "\u0627\u0644\u0633\u0639\u0631",
                                "av.common.save": "\u062d\u0641\u0638",
                                "av.common.name": "\u0627\u0644\u0625\u0633\u0645",
                                "av.common.fullName": "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0643\u0627\u0645\u0644",
                                "av.common.email": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.common.lastName.placeholder": "\u0627\u0633\u0645\u0643",
                                "av.common.fullName.placeholder": "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0643\u0627\u0645\u0644",
                                "av.common.phone.placeholder": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.common.age.placeholder": "\u0627\u0644\u0639\u0645\u0631",
                                "av.common.phone": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.common.send": "\u0625\u0631\u0633\u0627\u0644",
                                "av.common.forgotPassword": "\u0646\u0633\u064a\u062a \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631\u061f",
                                "av.common.close": "\u0627\u063a\u0644\u0627\u0642",
                                "av.common.month": "\u0634\u0647\u0631",
                                "av.common.medias.images": "\u0635\u0648\u0631",
                                "av.common.medias.videos": "\u0645\u0642\u0627\u0637\u0639 \u0641\u064a\u062f\u064a\u0648",
                                "av.common.categories": "\u0627\u0644\u0641\u0626\u0627\u062a",
                                "av.common.location": "\u0623\u064a\u0646 \u062a\u0631\u064a\u062f \u0627\u0644\u0628\u062d\u062a \u061f",
                                "av.common.magazine.title": "\u0645\u0642\u0627\u0644\u0627\u062a\u0646\u0627 \u0641\u064a \u0645\u062c\u0644\u0629 \u0623\u0641\u064a\u062a\u0648",
                                "av.common.admin.alert": "\u0645\u0631\u062d\u0628\u064b\u0627 \u0627\u0644\u0645\u062f\u064a\u0631 \u060c \u0644\u0642\u062f \u0642\u0645\u062a \u0628\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 \u0646\u064a\u0627\u0628\u0629 \u0639\u0646 \u0647\u0630\u0627 \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u060c \u0644\u0627\u062d\u0638 \u0623\u0646\u0647 \u0633\u064a\u062a\u0645 \u062a\u0633\u062c\u064a\u0644 \u0627\u062c\u0631\u0627\u0623\u062a\u0643 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u062d\u0633\u0627\u0628\u0643 \u0627\u0644\u062e\u0627\u0635 \u060c \u0648\u0633\u062a\u0646\u062a\u0647\u064a \u0635\u0644\u0627\u062d\u064a\u0629 \u0627\u0644\u062d\u0633\u0627\u0628 \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643 \u0641\u064a {{expiresIn}} ",
                                "av.common.confirm": "\u062a\u0623\u0643\u064a\u062f",
                                "av.common.select": "\u062d\u062f\u062f",
                                "av.common.privacy.policy.cgu.text": "\u0644\u0642\u062f \u0642\u0631\u0623\u062a \u0648\u0623\u0648\u0627\u0641\u0642 \u0639\u0644\u0649",
                                "av.common.privacy.policy.cgu.link": "\u0634\u0631\u0648\u0637 \u0627\u0644\u0627\u0633\u062a\u0639\u0645\u0627\u0644.",
                                "av.common.privacy.policy.tdp.text": "\u0648 \u0623\u0646\u0627 \u0645\u0648\u0627\u0641\u0642",
                                "av.common.privacy.policy.tdp.link": "\u0639\u0644\u0649 \u0645\u0639\u0627\u0644\u062c\u0629 \u0645\u0639\u0637\u064a\u0627\u062a\u064a \u0627\u0644\u0634\u062e\u0635\u064a\u0629.",
                                "av.common.privacy.stay_informed.text": "\u0623\u0631\u063a\u0628 \u0641\u064a \u0623\u0646 \u0623\u0643\u0648\u0646 \u0639\u0644\u0649 \u0627\u0637\u0644\u0627\u0639 \u0628\u0622\u062e\u0631 \u0627\u0644\u0623\u062e\u0628\u0627\u0631 \u0648\u0627\u0644\u062a\u062d\u062f\u064a\u062b\u0627\u062a",
                                "av.common.step": "\u0627\u0644\u0645\u0631\u062d\u0644\u0629 {{step}}",
                                "av.common.call": "\u0625\u062a\u0635\u0644",
                                "av.common.choice": "\u0623\u0648",
                                "av.common.visit.external.link.cta": "\u0627\u0644\u0645\u0632\u064a\u062f",
                                "av.common.choose.localisation": "\u0625\u062e\u062a\u0627\u0631 \u0627\u0644\u0645\u062f\u064a\u0646\u0629 - \u0627\u0644\u062d\u064a",
                                "av.common.suggestions": "\u0627\u0642\u062a\u0631\u0627\u062d\u0627\u062a",
                                "av.common.choose.area": "\u0625\u062e\u062a\u0627\u0631 \u0627\u0644\u0645\u062f\u064a\u0646\u0629 - \u0627\u0644\u062d\u064a",
                                "av.common.choose.brand": "\u0625\u062e\u062a\u0627\u0631 \u0627\u0644\u0645\u0627\u0631\u0643\u0629 - \u0627\u0644\u0645\u0648\u062f\u064a\u0644",
                                "av.common.choose.model": "\u0625\u062e\u062a\u0627\u0631 \u0627\u0644\u0645\u0627\u0631\u0643\u0629 - \u0627\u0644\u0645\u0648\u062f\u064a\u0644",
                                "av.common.category": "\u0627\u0644\u0641\u0626\u0629",
                                "av.common.more-info": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0623\u0643\u062b\u0631",
                                "av.common.exact-number": "\u0639\u062f\u062f \u0645\u062d\u062f\u062f",
                                "av.common.see-all": "\u0639\u0631\u0636 \u0627\u0644\u0645\u0632\u064a\u062f",
                                "av.common.search-in": "\u0627\u0628\u062d\u062b \u0641\u064a {{name}}",
                                "av.common.footer.links.aide": "\u0645\u0633\u0627\u0639\u062f\u0629 \u0648 \u0645\u0639\u0644\u0648\u0645\u0627\u062a",
                                "av.common.footer.avito.copyright": "\u0645\u062c\u0645\u0648\u0639\u0629 \u0623\u0641\u064a\u0637\u0648 2012-{{currentYear}}",
                                "av.common.discovery.slider.title.premium": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u062a\u0645\u064a\u0632\u0629",
                                "av.common.discovery.slider.title.private": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u062c\u062f\u064a\u062f\u0629 \u0644\u0623\u0634\u062e\u0627\u0635",
                                "av.common.discovery.slider.title.shop": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u062c\u062f\u064a\u062f\u0629 \u0644\u0644\u0645\u062a\u0627\u062c\u0631",
                                "av.common.discovery.slider.title.recent-searches": "\u0639\u0645\u0644\u064a\u0627\u062a \u0627\u0644\u0628\u062d\u062b \u0627\u0644\u0623\u062e\u064a\u0631\u0629",
                                "av.common.sidebar.immoLoan": "\u0642\u0631\u0636 \u0639\u0642\u0627\u0631\u064a",
                                "av.common.sidebar.consoLoan": "\u0642\u0631\u0636 \u0627\u0633\u062a\u0647\u0644\u0627\u0643\u064a",
                                "av.common.sidebar.immoExpo": "\u0645\u0639\u0631\u0636 \u0627\u0644\u0639\u0642\u0627\u0631 \u0627\u0644\u062c\u062f\u064a\u062f",
                                "av.common.sidebar.liveChat": "\u0627\u0644\u062a\u0648\u0627\u0635\u0644 \u0645\u0639 \u0648\u0643\u064a\u0644 \u062e\u062f\u0645\u0629 \u0627\u0644\u0632\u0628\u0646\u0627\u0621",
                                "av.common.oauth.fb.button_text": "\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644",
                                "av.common.oauth.fb.error.request_failed": "\u064a\u0631\u062c\u0649 \u0625\u0639\u0627\u062f\u0629 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0644\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0641\u0627\u064a\u0633\u0628\u0648\u0643",
                                "av.common.oauth.fb.error.declined_field": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0636\u0631\u0648\u0631\u064a \u0645\u0646 \u0623\u062c\u0644 \u0625\u0643\u0645\u0627\u0644 \u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u062a\u0633\u062c\u064a\u0644",
                                "av.common.oauth.fb.error.retry": "\u0647\u0646\u0627\u0643 \u062e\u0637\u0623 \u0645\u0627 \u060c \u064a\u0631\u062c\u0649 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0641\u064a \u0648\u0642\u062a \u0644\u0627\u062d\u0642. ",
                                "av.common.promotion.banner.cta": "\u0627\u062d\u062c\u0632 \u0645\u062c\u0627\u0646\u0627\u064b",
                                "av.common.promotion.banner.avitoexpo.content": "\u0645\u0639\u0631\u0636 \u0627\u0644\u0639\u0642\u0627\u0631 \u0627\u0644\u062c\u062f\u064a\u062f 2024",
                                "av.common.promotion.app-banner.header": "\u062a\u0635\u0641\u062d Avito \u0639\u0644\u0649...",
                                "av.common.promotion.app-banner.avito-app": "\u062a\u0637\u0628\u064a\u0642 Avito",
                                "av.common.promotion.app-banner.open": "\u0641\u062a\u062d",
                                "av.common.promotion.app-banner.continue": "\u0627\u0633\u062a\u0645\u0631\u0627\u0631",
                                "av.common.category-cards.heading": "\u0645\u0627 \u0627\u0644\u0630\u064a \u062a\u0628\u062d\u062b \u0639\u0646\u0647\u061f",
                                "av.common.category-cards.cta": "\u0634\u0627\u0647\u062f \u0627\u0644\u0645\u0632\u064a\u062f",
                                "av.page.title.default": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 | Avito.ma",
                                "av.page.description.default": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 \u0628\u0627\u0644\u0645\u062c\u0627\u0646. \u0628\u064a\u0639 \u0648\u0643\u0631\u0627\u0621 \u0627\u0644\u062f\u064a\u0648\u0631 \u0648\u0627\u0644\u0634\u0642\u0642. \u0633\u064a\u0627\u0631\u0627\u062a \u0644\u0644\u0628\u064a\u0639 \u0648\u0623\u062f\u0648\u0627\u062a \u0645\u0646\u0632\u0644\u064a\u0629 \u0648\u0634\u062e\u0635\u064a\u0629",
                                "av.page.adIn.pageTitle": "\u0625\u0646\u0634\u0627\u0621\u0625\u0639\u0644\u0627\u0646 | {{vertical}}",
                                "av.page.loading": "\u062c\u0627\u0631 \u0627\u0644\u062a\u062d\u0645\u064a\u0644..",
                                "av.page.error.default.error_message": "HTTP {{statusCode}} \u062e\u0637\u0623",
                                "av.page.error.default.error_summary": "\u062d\u062f\u062b \u062e\u0637\u0623 HTTP {{statusCode}} \u0623\u062b\u0646\u0627\u0621 \u0645\u062d\u0627\u0648\u0644\u0629 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 {{asPath}}",
                                "av.page.error.404.error_message": "\u0647\u0630\u0627 \u0627\u0644\u0631\u0627\u0628\u0637 \u063a\u064a\u0631 \u0645\u0648\u062c\u0648\u062f!",
                                "av.page.error.404.error_summary": "\u0639\u0630\u0631\u0627 \u060c \u0648\u0644\u0643\u0646 \u0637\u0644\u0628\u0643 \u0646\u062a\u062c \u0639\u0646\u0647 \u062e\u0637\u0623.",
                                "av.page.error.500.error_message": "\u0645\u0634\u0643\u0644 \u0641\u064a \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a",
                                "av.page.error.500.error_summary": "\u062d\u062f\u062a\u062a \u0645\u0634\u0643\u0644\u0629 \u0641\u064a \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a",
                                "av.page.error.adNotFound": "\u0639\u0630\u0631\u0627 \u060c \u0648\u0644\u0643\u0646 \u0644\u0645 \u064a\u062a\u0645 \u0627\u0644\u0639\u062b\u0648\u0631 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0625\u0639\u0644\u0627\u0646  ",
                                "av.page.error.adNotFound.description.title": "C\u0627\u0644\u0623\u0633\u0628\u0627\u0628 \u0627\u0644\u0645\u062d\u062a\u0645\u0644\u0629: <br/> {{causes}} <br/> \u0634\u0643\u0631\u0627 \u0639\u0644\u0649 \u062b\u0642\u062a\u0643\u0645 ! ",
                                "av.page.error.adNotFound.description.cause1": "\u0644\u0642\u062f \u062a\u0645 \u0628\u064a\u0639 \u0627\u0644\u0639\u0642\u0627\u0631 \u0648\u062d\u0630\u0641 \u0627\u0644\u0628\u0627\u0626\u0639 \u0625\u0639\u0644\u0627\u0646\u0647",
                                "av.page.error.adNotFound.description.cause2": "\u0625\u0630\u0627 \u0643\u0646\u062a \u0642\u062f \u062a\u0644\u0642\u064a\u062a \u0644\u0644\u062a\u0648 \u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0644\u0644\u062a\u062d\u0642\u0642 \u0645\u0646 \u0635\u062d\u0629 \u0625\u0639\u0644\u0627\u0646\u0643 \u060c \u0641\u0633\u0648\u0641 \u064a\u0633\u062a\u063a\u0631\u0642 \u0627\u0644\u0623\u0645\u0631 \u0633\u0627\u0639\u0629 \u0648\u0627\u062d\u062f\u0629 \u0642\u0628\u0644 \u0623\u0646 \u064a\u0635\u0628\u062d \u0645\u0631\u0626\u064a\u064b\u0627 \u0639\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639.",
                                "av.page.error.adNotFound.description.cause3": "\u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0630\u064a \u0642\u0645\u062a \u0628\u0627\u0644\u0646\u0642\u0631 \u0639\u0644\u064a\u0647 \u0642\u062f \u064a\u0643\u0648\u0646 \u063a\u064a\u0631 \u0635\u0627\u0644\u062d. \u0646\u0646\u0635\u062d\u0643 \u0628\u0627\u0644\u062a\u062d\u0642\u0642 \u0645\u0646 \u0630\u0644\u0643.",
                                "av.actions.go_to_home_page": "\u0627\u0630\u0647\u0628 \u0627\u0644\u0649 \u0627\u0644\u0635\u0641\u062d\u0629 \u0627\u0644\u0631\u0626\u064a\u0633\u064a\u0629",
                                "av.actions.go_to_previous_page": "\u0627\u0644\u0635\u0641\u062d\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629",
                                "av.actions.choose": "\u0627\u062e\u062a\u0631",
                                "av.actions.choose.category": "\u0627\u062e\u062a\u0631 \u0641\u0626\u0629",
                                "av.actions.boost": "\u062a\u0639\u0632\u064a\u0632",
                                "av.actions.chat": "\u0645\u062d\u0627\u062f\u062b\u0629 \u0645\u0628\u0627\u0634\u0631\u0629",
                                "av.actions.show_more": "\u0639\u0631\u0636 \u0627\u0644\u0645\u0632\u064a\u062f",
                                "av.actions.show_less": "\u0639\u0631\u0636 \u0623\u0642\u0644",
                                "av.actions.call": "\u0625\u0638\u0647\u0627\u0631 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.actions.show_whatsapp": "\u0645\u062d\u0627\u062f\u062b\u0629 \u0639\u0628\u0631 \u0627\u0644\u0648\u0627\u062a\u0633\u0627\u0628",
                                "av.actions.contact": "\u062a\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0645\u064f\u0636\u064a\u0641",
                                "av.actions.show_phone": "\u0625\u0638\u0647\u0627\u0631 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.actions.logout": "\u0627\u062e\u0631\u062c",
                                "av.actions.login": "\u0627\u0644\u062f\u062e\u0648\u0644 \u0625\u0644\u0649 \u062d\u0633\u0627\u0628\u0643",
                                "av.account.seller.banner.points": "\u0631\u0635\u064a\u062f \u0627\u0644\u0646\u0642\u0637",
                                "av.account.seller.banner.orders.number": "\u0639\u062f\u062f \u0627\u0644\u0637\u0644\u0628\u0627\u062a",
                                "av.account.seller.banner.items.number": "\u0639\u062f\u062f \u0627\u0644\u0645\u0646\u062a\u0648\u062c\u0627\u062a",
                                "av.account.seller.banner.not.paid": "Due et non pay\xe9e",
                                "av.account.seller.banner.next.payment": "\u0627\u0644\u062a\u062d\u0648\u064a\u0644 \u0627\u0644\u0642\u0627\u062f\u0645",
                                "av.page.ad.in.success.body.subheading1.text": "\u0634\u0643\u0631\u0627. \u0627\u0639\u0644\u0627\u0646\u0643\u0645 \u0642\u064a\u062f \u0627\u0644\u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.page.ad.in.success.body.subheading2.text": "\u0633\u062a\u062a\u0648\u0635\u0644\u0648\u0646 \u0628\u0631\u0633\u0627\u0644\u0629 \u062a\u0641\u0639\u064a\u0644 \u0639\u0644\u0649 \u0628\u0631\u064a\u062f\u0643\u0645 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.page.ad.in.success.body.helper.text": "\u0633\u0646\u0642\u0648\u0645 \u0628\u062a\u0641\u0639\u064a\u0644 \u0627\u0639\u0644\u0627\u0646\u0643\u0645 \u062e\u0644\u0627\u0644 \u0633\u0627\u0639\u0629 \u0639\u0644\u0649 \u0627\u0644\u0623\u0643\u062b\u0631",
                                "av.page.ad.in.success.action.textVacRental": "\u0628\u0639\u062f \u0642\u0628\u0648\u0644 \u0625\u0639\u0644\u0627\u0646\u0643 \u060c \u064a\u0645\u0643\u0646\u0643 \u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0628\u0631\u0646\u0627\u0645\u062c \u0627\u0644\u062e\u0627\u0635 \u0628\u0647 (\u062d\u0638\u0631 \u0627\u0644\u062a\u0648\u0627\u0631\u064a\u062e \u0623\u0648 \u0625\u0644\u063a\u0627\u0621 \u062d\u0638\u0631\u0647\u0627) \u0645\u0646 `` \u062d\u0633\u0627\u0628\u064a / \u0625\u0639\u0644\u0627\u0646\u0627\u062a\u064a / \u0646\u0634\u0637",
                                "av.page.ad.in.cars.subject": "{{brand}} {{model}} {{fuel}} {{regdate}}",
                                "av.page.ad.in.realestate.offerSubject": "{{categorySlug}} {{surface}}  {{transactionSlug}} \u0641\u064a {{regionSlug}}",
                                "av.page.ad.in.realestate.demandSubject": "{{transactionSlug}} {{categorySlug}} {{surface}} \u0627\u0644\u0649 {{regionSlug}}",
                                "av.page.ad.in.max.photos": " {{max}} \u0635\u0648\u0631 \u0643\u062d\u062f \u0623\u0642\u0635\u0649",
                                "av.validation.required": "\u064a\u0631\u062c\u0649 \u0625\u0643\u0645\u0627\u0644 \u0647\u0630\u0627 \u0627\u0644\u062d\u0642\u0644",
                                "av.validation.minLength": "\u0627\u0644\u062d\u062f \u0627\u0644\u0623\u062f\u0646\u0649 {{min}} \u0623\u062d\u0631\u0641",
                                "av.validation.maxLength": "\u0627\u0644\u062d\u062f \u0627\u0644\u0623\u0642\u0635\u0649 {{max}} \u062d\u0631\u0641\u064b\u0627",
                                "av.validation.minValue": "\u0627\u0644\u062d\u062f \u0627\u0644\u0623\u062f\u0646\u0649 {{min}}",
                                "av.validation.minValue.price": "\u0647\u0630\u0627 \u0627\u0644\u0633\u0639\u0631 \u0623\u0639\u0644\u0649 \u0645\u0646 \u0627\u0644\u062d\u062f \u0627\u0644\u0623\u0642\u0635\u0649 \u0627\u0644\u0645\u0633\u0645\u0648\u062d \u0628\u0647",
                                "av.validation.maxValue": "\u0627\u0644\u062d\u062f \u0627\u0644\u0623\u0642\u0635\u0649 {{max}}",
                                "av.validation.number": "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0631\u0642\u0645\u0627",
                                "av.validation.email": "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0628\u0631\u064a\u062f\u0627 \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0627",
                                "av.validation.phone": "\u064a\u0631\u062c\u0649 \u0625\u062f\u062e\u0627\u0644 \u0631\u0642\u0645 \u0647\u0627\u062a\u0641 \u0635\u062d\u064a\u062d",
                                "av.validation.phone_or_email": "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0628\u0631\u064a\u062f\u064b\u0627 \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u064b\u0627 \u0623\u0648 \u0631\u0642\u0645 \u0647\u0627\u062a\u0641 \u0635\u062d\u064a\u062d",
                                "av.validation.regex": "\u0627\u0644\u0642\u064a\u0645\u0629 \u063a\u064a\u0631 \u0645\u062f\u0639\u0648\u0645\u0629",
                                "av.validation.regex.no_email_in_text": "\u064a\u062c\u0628 \u0623\u0644\u0627 \u064a\u062d\u062a\u0648\u064a \u0647\u0630\u0627 \u0627\u0644\u062d\u0642\u0644 \u0639\u0644\u0649 \u0628\u0631\u064a\u062f \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.validation.regex.no_phone_in_text": "\u064a\u062c\u0628 \u0623\u0644\u0627 \u064a\u062d\u062a\u0648\u064a \u0647\u0630\u0627 \u0627\u0644\u062d\u0642\u0644 \u0639\u0644\u0649 \u0631\u0642\u0645 \u0647\u0627\u062a\u0641",
                                "av.validation.regex.no_url_in_text": "\u064a\u062c\u0628 \u0623\u0644\u0627 \u064a\u062d\u062a\u0648\u064a \u0647\u0630\u0627 \u0627\u0644\u062d\u0642\u0644 \u0639\u0644\u0649 \u0631\u0648\u0627\u0628\u0637",
                                "av.validation.regex.no_special_chars": '\u064a\u062c\u0628 \u0623\u0644\u0627 \u064a\u062d\u062a\u0648\u064a \u0647\u0630\u0627 \u0627\u0644\u062d\u0642\u0644 \u0639\u0644\u0649 \u0627\u0644\u0623\u062d\u0631\u0641:! = ": \u061b _ \u060c\u066a +',
                                "av.form.ad.actions.add": "\u0636\u0639 \u0625\u0639\u0644\u0627\u0646\u0643",
                                "av.form.ad.prevent.exit.message": "\u0642\u062f \u0644\u0627 \u064a\u062a\u0645 \u062d\u0641\u0638 \u0627\u0644\u062a\u063a\u064a\u064a\u0631\u0627\u062a \u0627\u0644\u062a\u064a \u0642\u0645\u062a \u0628\u0625\u062c\u0631\u0627\u0626\u0647\u0627.",
                                "av.category.menu.select": "\u0627\u062e\u062a\u0631 \u0627\u0644\u0641\u0626\u0629",
                                "av.category.menu.back": "\u0631\u062c\u0648\u0639 \u0625\u0644\u0649 \u0643\u0644 \u0627\u0644\u0641\u0626\u0627\u062a",
                                "av.page.ad.in.title.generation.immo": "{{categoryName}} {{habitableSize}} {{city}}",
                                "av.page.ad.in.title.generation.auto": "{{brand}} {{model}} {{fuelType}} {{gearType}} {{year}} {{city}}",
                                "av.lap.limitation": "{{adNbr}} / {{limit}} \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u062c\u0627\u0646\u064a\u0629 \u0641\u064a \u0627\u0644\u0641\u0626\u0629 {{category}}",
                                "av.lap.reached.limitation.info": "\u0639\u0632\u064a\u0632\u064a \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u060c \u0634\u0643\u0631\u064b\u0627 \u0644\u0643 \u0639\u0644\u0649 \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0623\u0641\u064a\u062a\u0648. \u0644\u0642\u062f \u0642\u0645\u062a \u0628\u0625\u062f\u0631\u0627\u062c {{adNbr}} \u0645\u0646 {{limit}} \u0645\u062c\u0627\u0646\u064b\u0627 \u0641\u064a \u0627\u0644\u0641\u0626\u0629 {{category}}. \u0623\u0628\u0639\u062f \u0645\u0646 \u0647\u0630\u0627 \u0627\u0644\u0633\u0642\u0641 \u060c \u0641\u0625\u0646 \u0627\u062e\u062a\u064a\u0627\u0631 \u062d\u0632\u0645\u0629 \u0627\u0644\u0631\u0624\u064a\u0629 \u0645\u0637\u0644\u0648\u0628 \u0644\u0644\u062d\u0641\u0627\u0638 \u0639\u0644\u0649 \u062c\u0648\u062f\u0629 \u0648\u0623\u0645\u0627\u0646  \u062e\u062f\u0645\u062a\u0646\u0627.",
                                "av.lap.exceeded.limitation.info": "\u0639\u0632\u064a\u0632\u064a \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645\u060c \u0634\u0643\u0631\u064b\u0627 \u0644\u0643 \u0639\u0644\u0649 \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0623\u0641\u064a\u062a\u0648. \u0644\u0646\u0634\u0631 {{adNbr}} \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u060c \u064a\u0644\u0632\u0645 \u0627\u062e\u062a\u064a\u0627\u0631 \u062d\u0632\u0645\u0629 \u0644\u0644\u062d\u0641\u0627\u0638 \u0639\u0644\u0649 \u062e\u062f\u0645\u062a\u0646\u0627 \u0645\u0646 \u062d\u064a\u062b \u0627\u0644\u062c\u0648\u062f\u0629 \u0648\u0627\u0644\u0623\u0645\u0627\u0646. \u0628\u0627\u0644\u0627\u0634\u062a\u0631\u0627\u0643 \u0641\u064a \u0623\u062d\u062f \u0627\u0644\u0639\u0631\u0648\u0636 \u0627\u0644\u062a\u0627\u0644\u064a\u0629 \u060c \u062a\u0633\u062a\u0641\u064a\u062f \u0645\u0646 \u0623\u0643\u0628\u0631 \u0639\u062f\u062f \u0645\u0646 \u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0627\u062a \u0648\u062a\u0632\u064a\u062f \u0645\u0646 \u0641\u0631\u0635\u0643 \u0644\u0644\u0628\u064a\u0639 \u0628\u0633\u0631\u0639\u0629. \u0634\u0643\u0631\u0627 \u0644\u0645\u0633\u0627\u0647\u0645\u062a\u0643",
                                "av.lap.reached.shop.limitation.warning": "\u0639\u0632\u064a\u0632\u064a \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u060c \u0634\u0643\u0631\u064b\u0627 \u0644\u0643 \u0644\u0625\u0633\u062a\u062e\u062f\u0627\u0645 \u0623\u0641\u064a\u062a\u0648. \u0644\u0642\u062f \u0642\u0645\u062a \u0628\u0625\u062f\u0631\u0627\u062c {{adNbr}} \u0625\u0639\u0644\u0627\u0646\u0627\u062a  \u0641\u064a \u0627\u0644\u0641\u0626\u0629 {{category}}. \u0623\u0646\u062a \u0645\u0624\u0647\u0644 \u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0645\u0632\u0627\u064a\u0627 \u0645\u062a\u062c\u0631 \u0623\u0641\u064a\u062a\u0648 \u0645\u0639 \u062e\u0635\u0648\u0645\u0627\u062a \u062a\u0641\u0636\u064a\u0644\u064a\u0629. \u064a\u0645\u0643\u0646\u0643 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0646\u0627 \u0639\u0644\u0649 {{csPhone}} \u0648\u0633\u064a\u0642\u062f\u0645 \u0644\u0643 \u0648\u0643\u064a\u0644  \u0623\u0641\u064a\u062a\u0648 \u0639\u0631\u0636\u064b\u0627 \u0645\u062e\u0635\u0635\u064b\u0627 \u0644\u0643. \u0625\u0630\u0627 \u0643\u0646\u062a \u062a\u0631\u063a\u0628 \u0641\u064a \u0645\u062a\u0627\u0628\u0639\u0629 \u0627\u0644\u0625\u062f\u0631\u0627\u062c \u060c \u064a\u0645\u0643\u0646\u0643 \u0627\u062e\u062a\u064a\u0627\u0631 \u0625\u062d\u062f\u0649 \u0627\u0644\u062d\u0632\u0645 \u0627\u0644\u062a\u0627\u0644\u064a\u0629.",
                                "av.lap.reached.private.limitation.warning": "\u0639\u0632\u064a\u0632\u064a \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u060c \u0634\u0643\u0631\u064b\u0627 \u0644\u0643 \u0644\u0625\u0633\u062a\u062e\u062f\u0627\u0645 \u0623\u0641\u064a\u062a\u0648. \u0644\u0646\u0634\u0631 \u0625\u0639\u0644\u0627\u0646\u0643 \u060c \u064a\u0644\u0632\u0645 \u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u062d\u0632\u0645\u0629 \u0644\u0644\u062d\u0641\u0627\u0638 \u0639\u0644\u0649 \u062c\u0648\u062f\u0629 \u0648\u0623\u0645\u0627\u0646 \u062e\u062f\u0645\u062a\u0646\u0627. \u0628\u0627\u0644\u0627\u0634\u062a\u0631\u0627\u0643 \u0641\u064a \u0623\u062d\u062f \u0627\u0644\u0639\u0631\u0648\u0636 \u0627\u0644\u062a\u0627\u0644\u064a\u0629 \u060c \u062a\u0633\u062a\u0641\u064a\u062f \u0645\u0646 \u0623\u0643\u0628\u0631 \u0639\u062f\u062f \u0645\u0646 \u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0627\u062a \u0648\u062a\u0632\u064a\u062f \u0645\u0646 \u0641\u0631\u0635\u0643  \u0644\u0644\u0628\u064a\u0639 \u0628\u0633\u0631\u0639\u0629. \u0634\u0643\u0631\u0627 \u0644\u0645\u0633\u0627\u0647\u0645\u062a\u0643",
                                "av.form.ad.stepper.step1.title": "\u0628\u062f\u0623 \u0628\u0627\u0644\u0623\u0633\u0627\u0633\u064a\u0627\u062a",
                                "av.form.vehicule.ad.stepper.step2.title": "\u0623\u062e\u0628\u0631\u0646\u0627 \u0639\u0646 \u0633\u064a\u0627\u0631\u062a\u0643",
                                "av.form.emploi.ad.stepper.step2.title": "\u0642\u0645 \u0628\u0648\u0635\u0641 \u0625\u0639\u0644\u0627\u0646\u0643",
                                "av.form.misc.ad.stepper.step2.title": "\u0635\u0650\u0641 \u0645\u0645\u062a\u0644\u0643\u0627\u062a\u0643",
                                "av.form.immobilier.ad.stepper.step2.title": "\u0635\u0650\u0641 \u0645\u0645\u062a\u0644\u0643\u0627\u062a\u0643",
                                "av.form.ad.stepper.step4.title": "\u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u062e\u0627\u0635\u0629",
                                "av.form.ad.sections.general.title": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0639\u0627\u0645\u0629",
                                "av.form.ad.sections.general.info": '\u0627\u0644\u062d\u0642\u0648\u0644 \u0627\u0644\u062a\u064a \u0628\u0647\u0627 (<span style="color:#d13649">*</span>) \u0625\u0644\u0632\u0627\u0645\u064a\u0629',
                                "av.form.immobilier.ad.category": "\u0646\u0648\u0639 \u0627\u0644\u0639\u0642\u0627\u0631",
                                "av.form.vehicule.ad.category": "\u0646\u0648\u0639 \u0627\u0644\u0633\u064a\u0627\u0631\u0629",
                                "av.form.misc.ad.category": "\u0646\u0648\u0639 \u0627\u0644\u0645\u0646\u062a\u0648\u062c",
                                "av.form.emploi.ad.category": "\u0646\u0648\u0639 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.form.ad.city.field.label": "Ville et secteur",
                                "av.form.ad.city.select.placeholder": "Choisissez votre ville et Secteur",
                                "av.form.ad.city.select.title": "S\xe9lectionner La Ville",
                                "av.form.ad.city.select.search.placeholder": "Rechercher dans Villes",
                                "av.form.ad.city.select.subTitle": "S\xe9lectionner le Secteur",
                                "av.form.ad.city.select.subSearch.placeholder": "Rechercher dans Secteurs",
                                "av.form.ad.city.select.prev.label": "Retour \xe0 la liste des Villes",
                                "av.form.ad.phone.field.label": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.form.ad.phone.field.placeholder": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.form.ad.delivery": "\u0627\u0644\u062a\u0648\u0635\u064a\u0644",
                                "av.form.ad.serviceAvito": "\u062e\u062f\u0645\u0629 \u0623\u0641\u064a\u062a\u0648",
                                "av.form.ad.activateDelivery": "\u062e\u062f\u0645\u0629 \u0627\u0644\u062a\u0648\u0635\u064a\u0644 \u0623\u0641\u064a\u062a\u0648 \u0645\u0641\u0639\u0644\u0629 \u0644\u0647\u0630\u0647 \u0627\u0644\u0645\u0646\u062a\u062c\u0627\u062a",
                                "av.form.ad.type": "\u0646\u0648\u0639 \u0627\u0644\u0635\u0641\u0642\u0629 ",
                                "av.form.ad.city.placeholder": "\u0627\u062e\u062a\u0627\u0631 \u0627\u0644\u0645\u062f\u064a\u0646\u0629",
                                "av.form.ad.area": "\u0627\u0644\u0645\u0646\u0637\u0642\u0629",
                                "av.form.ad.area.placeholder": "\u0627\u0643\u062a\u0628 \u0627\u0644\u062d\u064a",
                                "av.form.ad.address.placeholder": "\u0631\u0642\u0645 \u0648\u0627\u0633\u0645 \u0627\u0644\u0634\u0627\u0631\u0639",
                                "av.form.1000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.form.2000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0633\u064a\u0627\u0631\u0629",
                                "av.form.3000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.form.4000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.form.5000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.form.6000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.form.7000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.form.8000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.form.9000.ad.sections.adParams.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.form.ad.sections.adParams.extra.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0636\u0627\u0641\u064a\u0629",
                                "av.form.ad.sections.adParams.extra.subTitle": " \u064a\u0645\u0643\u0646\u0643 \u062a\u062d\u062f\u064a\u062f \u0645\u0639\u064a\u0627\u0631 \u0648\u0627\u062d\u062f \u0623\u0648 \u0623\u0643\u062b\u0631.",
                                "av.form.ad.sections.availability.title": "\u062a\u0648\u0641\u0631 \u0645\u0646\u062a\u062c\u0643",
                                "av.form.ad.sections.availability.subtitle": "\u0645\u062a\u0627\u062d \u0645\u0646 \u0627\u0644\u064a\u0648\u0645 \u060c \u062e\u0644\u0627\u0641 \u0630\u0644\u0643 \u062a\u062d\u062f\u064a\u062b \u0627\u0644\u062a\u0642\u0648\u064a\u0645",
                                "av.availability.onboarding.body": "\u062a\u062d\u062f\u064a\u062b \u0627\u0644\u062a\u0642\u0648\u064a\u0645 \u0627\u0644\u062e\u0627\u0635 \u0628\u0643 \u0639\u0646 \u0637\u0631\u064a\u0642 \u062d\u062c\u0628 \u0627\u0644\u0623\u064a\u0627\u0645 \u063a\u064a\u0631 \u0627\u0644\u0645\u062a\u0627\u062d\u0629.<br/><br/>\u064a\u0645\u0643\u0646\u0643 \u062f\u0627\u0626\u0645\u064b\u0627 \u062a\u063a\u064a\u064a\u0631 \u0647\u0630\u0627 \u0627\u0644\u062c\u062f\u0648\u0644 \u0645\u0646 <b>\u062d\u0633\u0627\u0628\u064a</b> / <b>\u0627\u0644\u0627\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0646\u0634\u0637\u0629</b>",
                                "av.form.ad.sections.availability.calendar.blockMonth": "\u062d\u0638\u0631 \u0627\u0644\u0634\u0647\u0631",
                                "av.form.ad.sections.availability.calendar.unblockMonth": "\u0641\u062a\u062d \u0627\u0644\u0634\u0647\u0631",
                                "av.availability.modal.title": "\u0645\u0646\u0639 \u0623\u0648 \u0625\u0644\u063a\u0627\u0621 \u062d\u0638\u0631 \u0627\u0644\u062a\u0648\u0627\u0631\u064a\u062e",
                                "av.vacRental.adview.calendar.nights.label": "\u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0625\u0642\u0627\u0645\u0629",
                                "av.vacRental.search.calendar.nights.label": "\u0627\u0644\u0625\u0642\u0627\u0645\u0629",
                                "av.vacRental.adview.calendar.nights": "{{nightCount}} \u0644\u064a\u0644\u0629",
                                "av.vacRental.adview.calendar.checkin": "\u0627\u0644\u0648\u0635\u0648\u0644",
                                "av.vacRental.adview.calendar.checkout": "\u0627\u0644\u0645\u063a\u0627\u062f\u0631\u0629",
                                "av.vacRental.adview.calendar.total": "{{total}} \u062f\u0631\u0647\u0645",
                                "av.vacRental.adview.calendar.clearDates": "\u0631\u062c\u0648\u0639",
                                "av.vacRental.adview.calendar.notice.head": "\u062a\u0648\u0627\u0631\u064a\u062e \u063a\u064a\u0631 \u0645\u062a\u0648\u0641\u0631\u0629",
                                "av.vacRental.adview.calendar.notice.body": "\u0627\u0644\u0641\u062a\u0631\u0629 \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629 \u062a\u062d\u062a\u0648\u064a \u0639\u0644\u0649 \u062a\u0648\u0627\u0631\u064a\u062e \u063a\u064a\u0631 \u0645\u062a\u0627\u062d\u0629",
                                "av.vacRental.myaccount.onboarding.title": "\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.vacRental.myaccount.onboarding.text": "\u0627\u0646\u0642\u0631 \u0647\u0646\u0627 \u0644\u062a\u0639\u062f\u064a\u0644 \u0623\u0648 \u062d\u0630\u0641 \u0625\u0639\u0644\u0627\u0646\u0643 \u0623\u0648 \u0625\u062f\u0627\u0631\u0629 \u062a\u0642\u0648\u064a\u0645 \u0627\u0644\u062d\u062c\u0632\u2026.",
                                "av.vacRental.myaccount.card.title": "\u0643\u0631\u0627\u0621 \u0627\u0644\u0639\u0637\u0644",
                                "av.vacRental.myaccount.card.subTitle": "\u0625\u062f\u0627\u0631\u0629 \u062a\u0648\u0641\u0631 \u0627\u0644\u0645\u0645\u062a\u0644\u0643\u0627\u062a \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643 \u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0648\u0636\u0648\u062d",
                                "av.vacRental.myaccount.card.seeComment": "\u0627\u0646\u0638\u0631 \u0644\u0644\u062a\u0639\u0644\u064a\u0642",
                                "av.vacRental.adview.calendar.insctuctions.checkin": "\u062d\u062f\u062f \u062a\u0627\u0631\u064a\u062e \u0648\u0635\u0648\u0644\u0643",
                                "av.vacRental.adview.calendar.insctuctions.checkout": "\u062d\u062f\u062f \u062a\u0627\u0631\u064a\u062e \u0645\u063a\u0627\u062f\u0631\u062a\u0643",
                                "av.vacRental.perNight": "/\u0644\u064a\u0644\u0629",
                                "av.vacRental.titleCaption": "\u0645\u062b\u0627\u0644",
                                "av.vacRental.available": "\u0645\u062a\u0648\u0641\u0631\u0629",
                                "av.vacRental.notAvailable": "\u0645\u062d\u062c\u0648\u0632",
                                "av.form.emploi.ad.sections.details.title": "\u0648\u0635\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.form.immobilier.ad.sections.details.title": "\u0648\u0635\u0641 \u0627\u0644\u0639\u0642\u0627\u0631",
                                "av.form.vehicule.ad.sections.details.title": "\u0648\u0635\u0641 \u0627\u0644\u0633\u064a\u0627\u0631\u0629",
                                "av.form.misc.ad.sections.details.title": "\u0648\u0635\u0641 \u0627\u0644\u0645\u0646\u062a\u0648\u062c",
                                "av.form.ad.subject": "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0627\u0639\u0644\u0627\u0646",
                                "av.form.ad.subject.placeholder": "\u0625\u0633\u0645 \u0627\u0644\u0645\u0646\u062a\u062c \u0623\u0648 \u0645\u0648\u0636\u0648\u0639 \u0627\u0644\u0627\u0639\u0644\u0627\u0646 ",
                                "av.form.ad.body": "\u0646\u0635 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.form.1000.ad.body.placeholder": "\u0645\u0634\u0645\u0633 \u0637\u0648\u0627\u0644 \u0627\u0644\u064a\u0648\u0645 \u0628\u0645\u0648\u0642\u0639 \u0645\u062b\u0627\u0644\u064a \u0628\u0627\u0644\u0642\u0631\u0628 \u0645\u0646 \u062c\u0645\u064a\u0639 \u0648\u0633\u0627\u0626\u0644 \u0627\u0644\u0631\u0627\u062d\u0629",
                                "av.form.ad.price_night": "\u0627\u0644\u0633\u0639\u0631 / \u0627\u0644\u0644\u064a\u0644\u0629",
                                "av.form.ad.price.trick": "! \u0646\u0635\u064a\u062d\u0629 ",
                                "av.form.ad.price_controller_message": "\u064a\u062a\u0645 \u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646 \u0628\u0633\u0639\u0631 \u0625\u062c\u0645\u0627\u0644\u064a 5 \u0645\u0631\u0627\u062a \u0623\u0643\u062b\u0631 \u0645\u0646 \u0625\u0639\u0644\u0627\u0646 \u0628\u0633\u0639\u0631 \u0645\u062a\u0631 \u0645\u0631\u0628\u0639.",
                                "av.form.ad.price_recommendation_message": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0645\u0642\u062a\u0631\u062d \u0628\u064a\u0646 <b> {{minPrice}} \u062f\u0631\u0647\u0645\u064b\u0627 </ b> \u0648 <b> {{maxPrice}} \u062f\u0631\u0647\u0645\u064b\u0627 </ b>. <br /> <br /> \u0628\u0646\u0627\u0621\u064b \u0639\u0644\u0649 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u0645\u0642\u062f\u0645\u0629 \u0648\u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u0639\u0644\u0649 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0644\u0644\u0645\u062d\u062a\u0631\u0641\u064a\u0646 \u0644\u0647\u0630\u0627 \u0627\u0644\u0646\u0648\u0639 \u0645\u0646 \u0627\u0644\u0634\u0642\u0642.",
                                "av.form.ad.price.unit": "\u062f\u0631\u0647\u0645",
                                "av.form.ad.cv_mandatory": "\u0636\u0639 \u0639\u0644\u0627\u0645\u0629 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u0645\u0631\u0628\u0639 \u0625\u0630\u0627 \u0643\u0646\u062a \u062a\u0631\u064a\u062f \u0623\u0646 \u062a\u0643\u0648\u0646 \u0627\u0644\u0633\u064a\u0631\u0629 \u0627\u0644\u0630\u0627\u062a\u064a\u0629 \u0625\u0644\u0632\u0627\u0645\u064a\u0629",
                                "av.form.ad.videos": "\u0623\u0634\u0631\u0637\u0629 \u0641\u064a\u062f\u064a\u0648",
                                "av.form.ad.video.tips.1": "\u0645\u062f\u0629 \u0627\u0644\u0641\u064a\u062f\u064a\u0648: \u064a\u0646\u0635\u062d \u0628\u0645\u062f\u0629 \u0627\u0644\u0641\u064a\u062f\u064a\u0648 \u0627\u0646 \u062a\u0643\u0648\u0646 \u062f\u0642\u064a\u0642\u0629 \u0648\u0627\u062d\u062f\u0629 - \u0644\u0646 \u064a\u062a\u0645 \u0642\u0628\u0648\u0644 \u0645\u0642\u0627\u0637\u0639 \u0627\u0644\u0641\u064a\u062f\u064a\u0648 \u0627\u0644\u062a\u064a \u062a\u0632\u064a\u062f \u0645\u062f\u062a\u0647\u0627 \u0639\u0646 \u062f\u0642\u064a\u0642\u0629 \u0648\u0627\u062d\u062f\u0629",
                                "av.form.ad.video.tips.2": "\u062d\u062c\u0645 \u0627\u0644\u0641\u064a\u062f\u064a\u0648: \u064a\u062c\u0628 \u0623\u0644\u0627 \u064a\u062a\u062c\u0627\u0648\u0632 \u062d\u062c\u0645 \u0627\u0644\u0641\u064a\u062f\u064a\u0648 30 \u0645\u064a\u063a\u0627 \u0628\u0627\u064a\u062a",
                                "av.form.ad.video.tips.3": "\u0627\u0644\u0627\u062a\u062c\u0627\u0647: \u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u0641\u064a\u062f\u064a\u0648\u0623\u0641\u0642\u064a\u0627 \u0644\u0625\u0638\u0647\u0627\u0631 \u0645\u0633\u0627\u062d\u0629 \u0643\u0628\u064a\u0631\u0629",
                                "av.form.ad.video.tips.4": "\u0627\u0644\u0645\u0648\u0633\u064a\u0642\u0649: \u0627\u0644\u0645\u0648\u0633\u064a\u0642\u0649 \u0627\u0644\u062e\u0627\u0644\u064a\u0629 \u0645\u0646 \u062d\u0642\u0648\u0642 \u0627\u0644\u0645\u0644\u0643\u064a\u0629 \u0641\u0642\u0637 \u0648\u0627\u0644\u062a\u064a \u062a\u0645\u062a\u0644\u0643 \u0627\u0644\u062a\u0631\u062e\u064a\u0635 \u0627\u0644\u0644\u0627\u0632\u0645 \u0644\u0647\u0627",
                                "av.form.ad.videos.upload.error.duration": "\u0623\u0634\u0631\u0637\u0629 \u0641\u064a\u062f\u064a\u0648\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0637\u0648\u0644 \u0627\u0644\u0641\u064a\u062f\u064a\u0648 \u0623\u0642\u0644 \u0645\u0646 \u062f\u0642\u064a\u0642\u0629 \u0648\u0627\u062d\u062f\u0629",
                                "av.form.ad.videos.upload.error.weight": "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u062d\u062c\u0645 \u0627\u0644\u0641\u064a\u062f\u064a\u0648 \u0623\u0642\u0644 \u0645\u0646 30 \u0645\u064a\u062c\u0627",
                                "av.form.ad.images.upload.cta": "\u0623\u0636\u0641",
                                "av.form.ad.images.tips.title": "\u0646\u0635\u064a\u062d\u0629",
                                "av.form.ad.images.tips.1": "\u064a\u062a\u0645 \u0639\u0631\u0636 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0627\u0644\u0630\u064a \u064a\u062d\u062a\u0648\u064a \u0639\u0644\u0649 \u0635\u0648\u0631 10 \u0645\u0631\u0627\u062a \u0623\u0643\u062b\u0631 \u0645\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0628\u062f\u0648\u0646 \u0635\u0648\u0631.",
                                "av.form.ad.images.tips.2": "\u0627\u0644\u062a\u0642\u0637 \u0635\u0648\u0631\u064b\u0627 \u062c\u0645\u064a\u0644\u0629 \u0648\u062c\u064a\u062f\u0629 \u0627\u0644\u0625\u0636\u0627\u0621\u0629.",
                                "av.form.ad.images.tips.3": "!\u0627\u0644\u0625\u0646\u0637\u0628\u0627\u0639 \u0627\u0644\u0623\u0648\u0644 \u0647\u0648 \u0645\u0647\u0645",
                                "av.form.ad.images.upload.failed": "\u0627\u0644\u0635\u0648\u0631\u0629 (\u0627\u0644\u0635\u0648\u0631) \u063a\u064a\u0631 \u0645\u062f\u0639\u0648\u0645\u0629!",
                                "av.form.ad.images.upload.loading": "\u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u0646\u062a\u0638\u0627\u0631 \u0628\u0636\u0639 \u0644\u062d\u0638\u0627\u062a \u060c \u0646\u062d\u0646 \u0646\u062d\u0645\u0644 \u0635\u0648\u0631\u0643",
                                "av.form.ad.images.upload.max_images.modalHead": "\u0645\u0627 \u064a\u0635\u0644 \u0625\u0644\u0649 8 \u0635\u0648\u0631",
                                "av.form.ad.images.upload.max_images.modalBody": "\u064a\u0645\u0643\u0646\u0643 \u0627\u0644\u0622\u0646 \u0625\u0636\u0627\u0641\u0629 \u0645\u0627 \u064a\u0635\u0644 \u0625\u0644\u0649 8 \u0635\u0648\u0631 \u0645\u062c\u0627\u0646\u064b\u0627 \u0644\u0648\u0635\u0641 \u0625\u0639\u0644\u0627\u0646\u0627\u062a\u0643.",
                                "av.form.ad.images.upload.max_images.modalCta": "\u062d\u0633\u0646\u0627 \u0645\u0645\u062a\u0627\u0632 !",
                                "av.upload.reorder.hint": "\u0623\u0639\u062f \u062a\u0631\u062a\u064a\u0628 \u0627\u0644\u0635\u0648\u0631 \u0644\u062a\u063a\u064a\u064a\u0631 \u0627\u0644\u063a\u0644\u0627\u0641",
                                "av.upload.idle": "\u0627\u0633\u062d\u0628 \u0635\u0648\u0631\u0629 \u0644\u0644\u062a\u062d\u0645\u064a\u0644 \u0623\u0648 \u0627\u0646\u0642\u0631 \u0644\u0644\u062a\u0635\u0641\u062d \u0644\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0648\u0627\u062d\u062f\u0629",
                                "av.upload.dragging": "\u0627\u0633\u062d\u0628 \u0627\u0644\u0635\u0648\u0631\u0629 \u0647\u0646\u0627",
                                "av.upload.image.limit": "\u062a\u0645 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u062d\u062f \u0627\u0644\u0635\u0648\u0631 \u0627\u0644\u0645\u0631\u0627\u062f \u0625\u0636\u0627\u0641\u062a\u0647\u0627!",
                                "av.upload.video.limit": "\u062a\u0645 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u062d\u062f \u0627\u0644\u0641\u064a\u062f\u064a\u0648\u0647\u0627\u062a \u0627\u0644\u0645\u0631\u0627\u062f \u0625\u0636\u0627\u0641\u062a\u0647\u0627!",
                                "av.upload.video.warning": "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0627\u0644\u0641\u064a\u062f\u064a\u0648 \u0628\u062a\u0646\u0633\u064a\u0642 \u0623\u0641\u0642\u064a (\u0623\u0641\u0642\u064a) \u0628\u0645\u062f\u0629 \u062a\u0642\u0644 \u0639\u0646 \u062f\u0642\u064a\u0642\u0629 \u0648\u0627\u062d\u062f\u0629 \u0648\u062d\u062c\u0645 \u0623\u0642\u0644 \u0645\u0646 30 \u0645\u064a\u062c\u0627\u0628\u0627\u064a\u062a.",
                                "av.upload.error.fileType.image": "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0627\u0644\u0645\u0644\u0641 \u0635\u0648\u0631\u0629",
                                "av.upload.error.fileType.video": "\u064a\u062c\u0628 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0627\u0644\u0645\u0644\u0641 \u0645\u0642\u0637\u0639 \u0641\u064a\u062f\u064a\u0648",
                                "av.upload.success": "\u062a\u0645 \u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0627\u0644\u0645\u0644\u0641 \u0628\u0646\u062c\u0627\u062d",
                                "av.upload.error": "\u062d\u062f\u062b \u062e\u0637\u0623 \u0623\u062b\u0646\u0627\u0621 \u0627\u0633\u062a\u064a\u0631\u0627\u062f \u0627\u0644\u0645\u0644\u0641",
                                "av.form.user.email.placeholder": "exemple@domaine.com",
                                "av.form.user.password": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
                                "av.form.user.phone.placeholder": "06XXXXXXXX",
                                "av.form.user.phone.show": "\u0639\u0631\u0636 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.form.user.chat": "\u0645\u062d\u0627\u062f\u062b\u0629 \u0645\u0628\u0627\u0634\u0631\u0629",
                                "av.form.user.account.type": "\u0646\u0648\u0639 \u0627\u0644\u062d\u0633\u0627\u0628",
                                "av.form.user.account.type.professional": "Professionel",
                                "av.form.user.account.type.particular": "Particulier",
                                "av.form.user.forgot.password.form-text": "\u0646\u0633\u064a\u062a \u0631\u0642\u0645\u0643 \u0627\u0644\u0633\u0631\u064a \u061f",
                                "av.form.user.forgot.password.btn-submit": "\u0623\u0631\u0633\u0644",
                                "av.form.user.forgot.password.btn-cancel": "\u0627\u0644\u063a\u0627\u0621",
                                "av.form.user.forgot.password.title": "\u0646\u0633\u064a\u062a \u0631\u0642\u0645\u0643 \u0627\u0644\u0633\u0631\u064a \u061f",
                                "av.form.user.forgot.password.title-success": "\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0631\u0627\u0628\u0637 \u0644\u0625\u0633\u062a\u0639\u0627\u062f\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631",
                                "av.form.user.forgot.password.text": "\u064a\u0631\u062c\u0649 \u0625\u062f\u062e\u0627\u0644 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0627\u0644\u062e\u0627\u0635 \u0628\u0643 \u0644\u062a\u062a\u0648\u0635\u0644 \u0628\u0631\u0627\u0628\u0637 \u0625\u0633\u062a\u0639\u0627\u062f\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631.",
                                "av.form.user.forgot.password.text-success": "\u0625\u0630\u0627 \u0644\u0645 \u062a\u062a\u0648\u0635\u0644 \u0628\u0627\u0644\u0631\u0627\u0628\u0637 \u0639\u0644\u0649 \u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u060c \u0642\u0645 \u0628\u0627\u0644\u062a\u062d\u0642\u0642 \u0645\u0646 \u0639\u062f\u0645 \u062a\u0648\u062c\u064a\u0647\u0647 \u0625\u0644\u0649 \u0642\u0633\u0645 \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0629 \u0627\u0644\u0645\u0632\u0639\u062c\u0629 \u0641\u064a \u0635\u0646\u062f\u0648\u0642 \u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a.",
                                "av.form.user.forgot.password.error-text": "\u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u063a\u064a\u0631 \u0635\u062d\u064a\u062d.",
                                "av.user.type.all": "\u0643\u0644\u0651\u0634\u064a",
                                "av.user.type.private": "\u062e\u0627\u0635",
                                "av.user.type.professional": "\u0645\u0647\u0646\u064a",
                                "av.user.member_since": "\u0645\u0634\u062a\u0631\u0643 \u0645\u0646\u0630",
                                "av.user.in_avito_since": "\u0639\u0644\u0649 \u0627\u0641\u064a\u062a\u0648 \u0645\u0646\u0630",
                                "av.form.ad.sections.vas.title": "\u0628\u064a\u0639 \u0628\u0634\u0643\u0644 \u0641\u0639\u0627\u0644",
                                "av.form.ad.sections.vas.pack.title": "\u064a\u0631\u062c\u0649 \u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u062d\u0632\u0645\u0629 \u0648\u0627\u0644\u0645\u062f\u0629 \u0623\u062f\u0646\u0627\u0647.",
                                "av.form.ad.sections.vas.notChoosen": "\u0627\u0644\u0645\u0631\u062c\u0648 \u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0628\u0627\u0642\u0629",
                                "av.form.ad.sections.vas.subTitle": "\u064a\u0631\u062c\u0649 \u0625\u062e\u062a\u064a\u0627\u0631 \u062d\u0632\u0645\u0629 \u0648\u0627\u0644\u0645\u062f\u0629 \u0644\u0636\u0645\u0627\u0646 \u0623\u0643\u0628\u0631 \u0639\u062f\u062f \u0645\u0646 \u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0627\u062a \u0644\u0625\u0639\u0644\u0627\u0646\u0643\u0645",
                                "av.form.ad.sections.vas.pack.subTitle": "\u062a\u0645 \u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u062d\u062f \u0627\u0644\u0625\u062f\u0631\u0627\u062c \u0627\u0644\u0645\u062c\u0627\u0646\u064a \u0644\u0647\u0630\u0647 \u0627\u0644\u0641\u0626\u0629. \u0627\u0644\u0631\u062c\u0627\u0621 \u0627\u062e\u062a\u064a\u0627\u0631 \u0625\u062d\u062f\u0649 \u0627\u0644\u062d\u0632\u0645 \u0627\u0644\u062a\u0627\u0644\u064a\u0629 \u0644\u0625\u0646\u0647\u0627\u0621 \u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u0625\u062f\u0631\u0627\u062c",
                                "av.form.ad.sections.vas.pack.boost.subTitle": " \u062a\u0636\u0645\u0646 \u062d\u0632\u0645 \u0627\u0644\u062a\u0639\u0632\u064a\u0632 \u0631\u0624\u064a\u0629 \u0623\u0643\u0628\u0631 \u0644\u0625\u0639\u0644\u0627\u0646\u0643\u060c \u0627\u0639\u062a\u0645\u0627\u062f\u064b\u0627 \u0639\u0644\u0649 \u0627\u0644\u062d\u0632\u0645\u0629 \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629.",
                                "av.form.ad.sections.vas.paymentMessage": "\u0644\u0642\u062f \u0648\u0635\u0644\u062a \u0625\u0644\u0649 \u062d\u062f \u0627\u0644\u0625\u062f\u0631\u0627\u062c \u0627\u0644\u0645\u062c\u0627\u0646\u064a \u0644\u0647\u0630\u0647 \u0627\u0644\u0641\u0626\u0629. \u0627\u0644\u0631\u062c\u0627\u0621 \u0627\u062e\u062a\u064a\u0627\u0631 \u062d\u0632\u0645\u0629 \u0644\u0625\u0646\u0647\u0627\u0621 \u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u0625\u062f\u0631\u0627\u062c.",
                                "av.form.ad.sections.vas.pack.overlay.message": "\u0623\u062f\u062e\u0644 \u0635\u0648\u0631\u0629 \u0648\u0627\u062d\u062f\u0629 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644 \u0644\u062a\u0641\u0639\u064a\u0644 \u0647\u0630\u0647 \u0627\u0644\u0628\u0627\u0642\u0629",
                                "av.form.ad.sections.vas.bump.title": "\u062a\u062c\u062f\u064a\u062f \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u064a\u0648\u0645\u064a\u0627",
                                "av.form.ad.sections.vas.bump.description": "\u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0631\u0624\u064a\u0629 \u0623\u0641\u0636\u0644 \u060c \u0633\u064a\u062a\u0645 \u0648\u0636\u0639 \u0625\u0639\u0644\u0627\u0646\u0643 \u0641\u064a <b>\u0623\u0639\u0644\u0649 \u0627\u0644\u0642\u0627\u0626\u0645\u0629</b> \u062a\u0644\u0642\u0627\u0626\u064a\u064b\u0627 \u0643\u0644 \u064a\u0648\u0645 \u0641\u064a \u0646\u0641\u0633 \u0627\u0644\u0648\u0642\u062a \u0628\u0639\u062f \u0627\u0644\u062f\u0641\u0639",
                                "av.form.ad.sections.vas.bump.feature1": '\u0645\u0639 \u062e\u064a\u0627\u0631 "\u062a\u062c\u062f\u064a\u062f \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u064a\u0648\u0645\u064a\u0627" \u0633\u064a\u062a\u0645 \u0625\u0639\u0627\u062f\u0629 \u0646\u0634\u0631 \u0625\u0639\u0644\u0627\u0646\u0643 \u062a\u0644\u0642\u0627\u0626\u064a\u064b\u0627 \u0643\u0644 \u064a\u0648\u0645 \u0644\u064a\u0643\u0648\u0646 \u0639\u0644\u0649 \u0631\u0623\u0633 \u0627\u0644\u0642\u0627\u0626\u0645\u0629',
                                "av.form.ad.sections.vas.bump.feature2": "\u0633\u064a\u0634\u0627\u0647\u062f \u0625\u0639\u0644\u0627\u0646\u0643 9 \u0645\u0631\u0627\u062a \u0623\u0643\u062b\u0631 \u0645\u0646 \u0637\u0631\u0641 \u0627\u0644\u0645\u0634\u062a\u0631\u064a\u0646 \u0627\u0644\u0645\u062d\u062a\u0645\u0644\u064a\u0646",
                                "av.form.ad.sections.vas.bump.feature3": '\u0648\u0641\u0631 \u0627\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0648\u0642\u062a \u0628\u062a\u0641\u0639\u064a\u0644 \u062e\u064a\u0627\u0631 "\u062a\u062c\u062f\u064a\u062f \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u064a\u0648\u0645\u064a\u0627"',
                                "av.form.ad.sections.vas.gallery.title": "\u0627\u0639\u0644\u0627\u0646 \u0645\u062a\u0645\u064a\u0632",
                                "av.form.ad.sections.vas.gallery.description": "\u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0631\u0624\u064a\u0629 \u0623\u0641\u0636\u0644 \u060c \u0633\u064a\u062a\u0645 \u0648\u0636\u0639 \u0625\u0639\u0644\u0627\u0646\u0643 \u062a\u0644\u0642\u0627\u0626\u064a\u064b\u0627 \u0643\u0644 \u064a\u0648\u0645 \u0641\u064a \u0627\u0644\u0642\u0633\u0645 <b>\u0627\u0644\u0645\u062a\u0645\u064a\u0632</b> \u0648\u0633\u064a\u0643\u0648\u0646 \u0641\u064a <b>\u0623\u0639\u0644\u0649 \u0627\u0644\u0642\u0627\u0626\u0645\u0629</b>",
                                "av.form.ad.sections.vas.gallery.feature1": "\u0625\u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0643 \u0641\u064a \u0642\u0633\u0645  (\u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0627\u0644\u0645\u062a\u0645\u064a\u0632) \u060c \u0648\u0647\u0648 \u0645\u0648\u0642\u0639 \u062d\u0635\u0631\u064a \u0648\u0645\u0645\u064a\u0632 \u0628\u062d\u062c\u0645\u0629 \u0627\u0644\u0643\u0628\u064a\u0631 \u0641\u064a \u0623\u0639\u0644\u0649 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a",
                                "av.form.ad.sections.vas.gallery.feature2": "\u0633\u064a\u0634\u0627\u0647\u062f \u0625\u0639\u0644\u0627\u0646\u0643 15 \u0645\u0631\u0629 \u0623\u0643\u062b\u0631 \u0645\u0646 \u0637\u0631\u0641 \u0627\u0644\u0645\u0634\u062a\u0631\u064a\u0646 \u0627\u0644\u0645\u062d\u062a\u0645\u0644\u064a\u0646",
                                "av.form.ad.sections.vas.gallery.feature3": "\u0623\u0628\u0631\u0632 \u0625\u0639\u0644\u0627\u0646\u0643 \u0641\u064a \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0628\u062e\u0644\u0641\u064a\u0629 \u0645\u062e\u062a\u0644\u0641\u0629 \u0648\u062c\u0630\u0627\u0628\u0629",
                                "av.form.ad.sections.vas.special.title": "\u0625\u0639\u0644\u0627\u0646 \u0646\u062c\u0645 + \u062a\u062c\u062f\u064a\u062f \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u064a\u0648\u0645\u064a\u0627",
                                "av.form.ad.sections.vas.special.description": "\u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0631\u0624\u064a\u0629 \u0623\u0641\u0636\u0644 \u060c \u0633\u064a\u062a\u0645 \u0648\u0636\u0639 \u0625\u0639\u0644\u0627\u0646\u0643 \u062a\u0644\u0642\u0627\u0626\u064a\u064b\u0627 \u0641\u064a <b>\u0623\u0639\u0644\u0649 \u0627\u0644\u0642\u0627\u0626\u0645\u0629</b> \u0628\u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0625\u0644\u0649 <b>\u062a\u0645\u064a\u064a\u0632 \u0641\u064a \u062e\u0644\u0641\u064a\u0629</b> \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0637\u0648\u0627\u0644 \u0627\u0644\u0641\u062a\u0631\u0629 \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629.",
                                "av.form.ad.sections.vas.special.feature1": "\u0633\u064a\u062a\u0645 \u0625\u0639\u0627\u062f\u0629 \u0646\u0634\u0631 \u0625\u0639\u0644\u0627\u0646\u0643 \u062a\u0644\u0642\u0627\u0626\u064a\u064b\u0627 \u0643\u0644 \u064a\u0648\u0645 \u0648\u0644\u064a\u0643\u0648\u0646 \u0641\u064a \u0627\u0644\u0645\u0631\u0643\u0632 \u0627\u0644\u0623\u0648\u0644 \u0628\u062e\u0644\u0641\u064a\u0629 \u0641\u0631\u064a\u062f\u0629 \u0648\u062c\u0630\u0627\u0628\u0629",
                                "av.form.ad.sections.vas.special.feature2": "\u0633\u064a\u0634\u0627\u0647\u062f \u0625\u0639\u0644\u0627\u0646\u0643 12 \u0645\u0631\u0629 \u0623\u0643\u062b\u0631 \u0645\u0646 \u0637\u0631\u0641 \u0627\u0644\u0645\u0634\u062a\u0631\u064a\u0646 \u0627\u0644\u0645\u062d\u062a\u0645\u0644\u064a\u0646",
                                "av.form.ad.sections.vas.highlight.title": "\u0625\u0639\u0644\u0627\u0646 \u0646\u062c\u0645",
                                "av.form.ad.sections.vas.highlight.description": "\u0625\u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0643 \u0641\u064a \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0628\u062e\u0644\u0641\u064a\u0629 \u0645\u062e\u062a\u0644\u0641\u0629 \u0648\u062c\u0630\u0627\u0628\u0629",
                                "av.form.ad.sections.vas.highlight.feature1": "\u0625\u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0643 \u0641\u064a \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0645\u0639 \u062e\u0644\u0641\u064a\u0629 \u0645\u062e\u062a\u0644\u0641\u0629 \u0648\u062c\u0630\u0627\u0628\u0629",
                                "av.form.ad.sections.vas.highlight.feature2": "\u0633\u064a\u0634\u0627\u0647\u062f \u0625\u0639\u0644\u0627\u0646\u0643 6 \u0645\u0631\u0627\u062a \u0623\u0643\u062b\u0631 \u0645\u0646 \u0637\u0631\u0641 \u0627\u0644\u0645\u0634\u062a\u0631\u064a\u0646 \u0627\u0644\u0645\u062d\u062a\u0645\u0644\u064a\u0646 \u0645\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0627\u0644\u0639\u0627\u062f\u064a",
                                "av.form.ad.sections.vas.insertion.title": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0627\u0644\u0645\u062c\u0627\u0646\u064a",
                                "av.form.ad.sections.vas.insertion.description": "\u064a\u062a\u0645 \u062a\u0637\u0628\u064a\u0642 \u0631\u0633\u0648\u0645 \u0627\u0644\u0625\u062f\u0631\u0627\u062c \u0639\u0646\u062f\u0645\u0627 \u062a\u062a\u062c\u0627\u0648\u0632 \u0627\u0644\u062d\u062f \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062c\u0627\u0646\u064a\u0629",
                                "av.form.ad.sections.vas.insertionFees.title": "\u0627\u0644\u0625\u062f\u0631\u0627\u062c (\u0628\u062f\u0648\u0646 \u062d\u0632\u0645\u0629)",
                                "av.form.ad.sections.vas.insertion.label": "\u0627\u0644\u0625\u064a\u062f\u0627\u0639 \u0628\u062f\u0648\u0646 \u062d\u0632\u0645\u0629",
                                "av.form.ad.sections.vas.pricePerDay": "{{pricePerDay}} \u062f\u0631\u0647\u0645 / \u064a\u0648\u0645",
                                "av.form.ad.sections.vas.pricePerDay.shops": "{{pricePerDay}} \u0646\u0642\u0637\u0629 / \u064a\u0648\u0645",
                                "av.form.ad.sections.vas.price.unit": "{{priceUnit}} {{price}}",
                                "av.form.ad.sections.vas.pricePerDay.priceUnit": "\u064a\u0648\u0645 / {{priceUnit}} {{pricePerDay}}",
                                "av.form.ad.sections.vas.totalPrice": "\u0625\u062c\u0645\u0627\u0644\u064a {{totalPrice}} \u062f\u0631\u0647\u0645",
                                "av.form.ad.sections.vas.addPhotos": "\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0635\u0648\u0631",
                                "av.form.ad.sections.vas.moreInfo": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0623\u0643\u062b\u0631",
                                "av.form.ad.sections.vas.bestSeller": "\u0627\u0644\u0623\u0643\u062b\u0631 \u0645\u0628\u064a\u0639\u0627",
                                "av.form.ad.sections.vas.xMoreViews": "{{views}} X \u0645\u0634\u0627\u0647\u062f\u0629 \u0623\u062e\u0631\u0649",
                                "av.form.ad.sections.vas.moreViews": "\u0645\u0634\u0627\u0647\u062f\u0629 \u0623\u062e\u0631\u0649",
                                "av.form.ad.sections.vas.moreLeads": "\u0646\u064a\u0629 \u0627\u062a\u0635\u0627\u0644 \u0623\u062e\u0631\u0649",
                                "av.form.ad.sections.vas.currentlyActive": "\u0627\u0644\u0628\u0627\u0642\u0629 \u0627\u0644\u0645\u0641\u0639\u0644\u0629 \u062d\u0627\u0644\u064a\u0627",
                                "av.vas.slot.section.title": "\u064a\u0631\u062c\u0649 \u062a\u062d\u062f\u064a\u062f \u0648\u0642\u062a \u0627\u0644\u062a\u0639\u0632\u064a\u0632 \u0627\u0644\u062e\u0627\u0635 \u0628\u0643",
                                "av.vas.slot.section.date": "\u064a\u0648\u0645 \u0628\u062f\u0621 \u0627\u0644\u062a\u0639\u0632\u064a\u0632",
                                "av.vas.slot.section.time": "\u0648\u0642\u062a \u0628\u062f\u0621 \u0627\u0644\u062a\u0639\u0632\u064a\u0632",
                                "av.vas.slot.section.info": "\u0633\u064a\u062a\u0645 \u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u062d\u0632\u0645\u0629 \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629 \u0628\u0634\u0643\u0644 \u0639\u0634\u0648\u0627\u0626\u064a \u062e\u0644\u0627\u0644 \u0641\u062a\u0631\u0629 \u0627\u0644\u0632\u0645\u0646\u064a\u0629 \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629.",
                                "av.payment.steps.vas": "\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0639\u0628\u0648\u0629",
                                "av.payment.steps.paymentMethod": "\u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062f\u0641\u0639",
                                "av.payment.steps.payment": "\u062f\u0641\u0639",
                                "av.payment.sections.ad.title": "\u0625\u0639\u0644\u0627\u0646\u0643\u0645",
                                "av.payment.sections.ad.subTitle": "\u0642\u0645 \u0628\u0628\u064a\u0639 \u0627\u0644\u0645\u0645\u062a\u0644\u0643\u0627\u062a \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643 \u0628\u0633\u0631\u0639\u0629 \u0639\u0646 \u0637\u0631\u064a\u0642 \u062a\u0637\u0628\u064a\u0642 \u0625\u062d\u062f\u0649 \u062d\u0632\u0645 \u0627\u0644\u062a\u062c\u062f\u064a\u062f \u0623\u062f\u0646\u0627\u0647",
                                "av.payment.sections.order.title": "\u0637\u0644\u0628\u064a\u062a\u0643",
                                "av.payment.sections.order.duration": "\u0645\u062f\u0629",
                                "av.payment.sections.order.totalPrice": "\u0645\u062c\u0645\u0648\u0639 \u0627\u0644\u062c\u0627\u0626\u0632\u0629",
                                "av.payment.sections.order.change": "\u062a\u063a\u064a\u064a\u0631",
                                "av.payment.sections.paymentMethod.title": "\u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062f\u0641\u0639",
                                "av.payment.sections.paymentMethod.subTitle": "\u0627\u0644\u0631\u062c\u0627\u0621 \u0627\u062e\u062a\u064a\u0627\u0631 \u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062f\u0641\u0639 \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643.",
                                "av.payment.sections.paymentMethod.category.online": "\u0627\u0644\u062f\u0641\u0639 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.payment.sections.paymentMethod.category.offline": "\u0627\u0644\u062f\u0641\u0639 \u0646\u0642\u062f\u0627",
                                "av.payment.sections.paymentMethod.category.apps": "\u0627\u0644\u062f\u0641\u0639 \u0639\u0646 \u0637\u0631\u064a\u0642 \u0627\u0644\u062a\u0637\u0628\u064a\u0642",
                                "av.payment.sections.paymentMethod.category.messaging": "\u0627\u0644\u062f\u0641\u0639 \u0628\u0627\u0644\u0628\u0631\u064a\u062f",
                                "av.payment.sections.paymentMethod.name.cc": "\u0628\u0637\u0627\u0642\u0629 \u0628\u0646\u0643\u064a\u0629",
                                "av.payment.sections.paymentMethod.name.cod": "\u0627\u0644\u062f\u0641\u0639 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645",
                                "av.payment.sections.paymentMethod.name.fatourati": "\u0641\u0627\u062a\u0648\u0631\u0627\u062a\u064a",
                                "av.payment.sections.paymentMethod.name.fatourati.plural": "\u0648\u0643\u0627\u0644\u0627\u062a \u0641\u0637\u0648\u0631\u062a\u064a",
                                "av.payment.sections.paymentMethod.name.cashPlus": "\u0643\u0627\u0634 \u0628\u0644\u0648\u0633",
                                "av.payment.sections.paymentMethod.name.cashPlus.plural": "\u0648\u0643\u0627\u0644\u0627\u062a \u0643\u0627\u0634 \u0628\u0644\u0648\u0633",
                                "av.payment.sections.paymentMethod.name.tasshilat": "\u062a\u0633\u0647\u064a\u0644\u0627\u062a",
                                "av.payment.sections.paymentMethod.name.tasshilat.plural": "\u0648\u0643\u0627\u0644\u0627\u062a \u062a\u0633\u0647\u064a\u0644\u0627\u062a",
                                "av.payment.sections.paymentMethod.name.bankingApp": "\u062a\u0637\u0628\u064a\u0642 \u0645\u0635\u0631\u0641\u064a",
                                "av.payment.sections.paymentMethod.name.bankingApp.plural": "\u0627\u0644\u062a\u0637\u0628\u064a\u0642\u0627\u062a \u0627\u0644\u0645\u0635\u0631\u0641\u064a\u0629",
                                "av.payment.sections.paymentMethod.name.sms": "\u0631\u0633\u0627\u0644\u0629 \u0642\u0635\u064a\u0631\u0629",
                                "av.payment.sections.paymentMethod.name.avitoken": "\u0627\u0644\u062f\u0641\u0639 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0623\u0641\u064a\u062a\u0648\u0643\u0646",
                                "av.payment.sections.paymentMethod.description.cc": "\u0627\u062f\u0641\u0639 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 Mastercard \u0623\u0648 Visa",
                                "av.payment.sections.paymentMethod.description.cod": "\u0627\u0644\u062f\u0641\u0639 \u0646\u0642\u062f\u0627 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645",
                                "av.payment.sections.paymentMethod.description.fatourati": "\u0627\u0644\u062f\u0641\u0639 \u0646\u0642\u062f\u0627 \u0641\u064a \u0648\u0643\u0627\u0644\u0629",
                                "av.payment.sections.paymentMethod.description.cashPlus": "\u0627\u0644\u062f\u0641\u0639 \u0646\u0642\u062f\u0627 \u0641\u064a \u0648\u0643\u0627\u0644\u0629",
                                "av.payment.sections.paymentMethod.description.tasshilat": "\u0627\u0644\u062f\u0641\u0639 \u0646\u0642\u062f\u0627 \u0641\u064a \u0648\u0643\u0627\u0644\u0629",
                                "av.payment.sections.paymentMethod.description.bankingApp": "\u0627\u062f\u0641\u0639 \u0639\u0644\u0649 \u062a\u0637\u0628\u064a\u0642 \u0623\u0648 \u0645\u0648\u0642\u0639 \u0645\u0635\u0631\u0641\u064a",
                                "av.payment.sections.paymentMethod.description.avitoken": "\u0627\u0644\u062f\u0641\u0639 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0631\u0635\u064a\u062f \u0623\u0641\u064a\u062a\u0648\u0643\u0646 \u0627\u0644\u062e\u0627\u0635 \u0628\u0643",
                                "av.payment.ccRedirect.heading": "\u0623\u0645\u0646\u0643 \u0647\u0648 \u0623\u0648\u0644\u0648\u064a\u062a\u0646\u0627",
                                "av.payment.ccRedirect.subHeading": '\u0633\u062a\u062a\u0645 \u0625\u0639\u0627\u062f\u0629 \u062a\u0648\u062c\u064a\u0647\u0643 \u0644\u0625\u062c\u0631\u0627\u0621 \u0627\u0644\u062f\u0641\u0639 \u060c \u064a\u0631\u062c\u0649 \u0639\u062f\u0645 \u0627\u0644\u0646\u0642\u0631 \u0641\u0648\u0642 "\u0631\u062c\u0648\u0639" \u0623\u0648 "\u062a\u062d\u062f\u064a\u062b" \u062d\u062a\u0649 \u064a\u062a\u0645 \u0625\u0639\u0627\u062f\u0629 \u062a\u062d\u0645\u064a\u0644 \u0635\u0641\u062d\u062a\u0643 ...',
                                "av.payment.sections.payment.invoice.title": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0641\u0627\u062a\u0648\u0631\u0629",
                                "av.payment.sections.payment.invoice.vendor": "\u062a\u0627\u062c\u0631",
                                "av.payment.sections.payment.invoice.orderNbr": "\u0631\u0642\u0645 \u0627\u0644\u0637\u0644\u0628",
                                "av.payment.sections.payment.invoice.amount": "\u0645\u0628\u0644\u063a",
                                "av.payment.sections.payment.paymentMethod.apps": "\u0627\u0644\u062f\u0641\u0639 \u0639\u0646 \u0637\u0631\u064a\u0642 \u0627\u0644\u062a\u0637\u0628\u064a\u0642 / \u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u0645\u0635\u0631\u0641\u064a",
                                "av.payment.sections.payment.paymentMethod.offline": "\u0627\u0644\u062f\u0641\u0639 \u0627\u0644\u0646\u0642\u062f\u064a - {{method}}",
                                "av.payment.sections.payment.paymentMethod.messaging": "\u0627\u0644\u062f\u0641\u0639 \u0639\u0628\u0631 \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u0642\u0635\u064a\u0631\u0629",
                                "av.payment.sections.payment.messaging.direction": "\u0623\u0631\u0633\u0644 \u0627\u0644\u0631\u0645\u0632 <em>{{smsCode}}</em> \u0645\u0631\u0629 \u0648\u0627\u062d\u062f\u0629 \u0628\u0631\u0633\u0627\u0644\u0629 SMS \u0625\u0644\u0649 \u0627\u0644\u0631\u0642\u0645 <em>{{smsReceiver}}</em>",
                                "av.payment.sections.payment.messaging.pending": "\u0641\u064a \u0627\u0646\u062a\u0638\u0627\u0631 \u0627\u0644\u062f\u0641\u0639 \u0639\u0646 \u0637\u0631\u064a\u0642 \u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u0642\u0635\u064a\u0631\u0629 ....",
                                "av.payment.sections.payment.messaging.send": "\u0623\u0631\u0633\u0644 \u0631\u0633\u0627\u0644\u0629",
                                "av.payment.sections.payment.token.expiryWarning": "\u064a\u0631\u062c\u0649 \u0645\u0644\u0627\u062d\u0638\u0629 \u0623\u0646 \u0647\u0630\u0627 \u0627\u0644\u0631\u0645\u0632 \u0635\u0627\u0644\u062d \u0644\u0641\u062a\u0631\u0629 \u0645\u062d\u062f\u0648\u062f\u0629 \u0645\u0646 48 \u0633\u0627\u0639\u0629.",
                                "av.payment.sections.payment.offline.direction1": "\u0627\u0630\u0647\u0628 \u0625\u0644\u0649 \u0623\u0642\u0631\u0628 \u0648\u0643\u0627\u0644\u0629 {{method}}",
                                "av.payment.sections.payment.token.direction2": "\u0623\u062f\u062e\u0644 \u0647\u0630\u0627 \u0627\u0644\u0631\u0645\u0632 \u0641\u064a \u0642\u0633\u0645 \u062f\u0641\u0639 \u0641\u0627\u062a\u0648\u0631\u0629 Avito.",
                                "av.payment.sections.payment.token.direction3": "\u0627\u062f\u0641\u0639 \u062b\u0645\u0646 \u0627\u0644\u0634\u0631\u0627\u0621 \u0648\u0627\u0633\u062a\u0645\u062a\u0639 \u0628\u0627\u0644\u062e\u062f\u0645\u0629",
                                "av.payment.sections.payment.apps.direction1": "\u0627\u0646\u062a\u0642\u0644 \u0625\u0644\u0649 \u062a\u0637\u0628\u064a\u0642\u0643 \u0627\u0644\u0645\u0635\u0631\u0641\u064a.",
                                "av.payment.sections.payment.token.fees": "\u062a\u0637\u0628\u0642 \u0631\u0633\u0648\u0645 \u0627\u0644\u062e\u062f\u0645\u0629 \u0648\u0627\u0644\u0637\u0648\u0627\u0628\u0639 \u0627\u0644\u0625\u0636\u0627\u0641\u064a\u0629 \u0628\u0642\u064a\u0645\u0629 2.5 \u062f\u0631\u0647\u0645 \u0644\u0643\u0644 \u0645\u0639\u0627\u0645\u0644\u0629",
                                "av.payment.sections.payment.apps.viewList": "\u0627\u0646\u0638\u0631 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\u0627\u062a \u0627\u0644\u0645\u0635\u0631\u0641\u064a\u0629",
                                "av.payment.sections.payment.apps.view.list": "\u0627\u0646\u0638\u0631 \u0627\u0644\u0642\u0627\u0626\u0645\u0629",
                                "av.payment.sections.payment.invoice.boost": "\u0627\u0644\u062a\u0631\u0648\u064a\u062c \u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.payment.sections.payment.offline.viewList": "\u0627\u0646\u0638\u0631 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0648\u0643\u0627\u0644\u0627\u062a",
                                "av.payment.sections.payment.offline.view.list": "\u0627\u0646\u0638\u0631 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0648\u0643\u0627\u0644\u0627\u062a",
                                "av.payment.sections.payment.token": "\u0643\u0648\u062f \u0627\u0644\u0637\u0644\u0628 \u0627\u0644\u062e\u0627\u0635 \u0628\u0643",
                                "av.payment.sections.payment.token.print": "\u0637\u0628\u0627\u0639\u0629",
                                "av.payment.option.proximo": "Proximo Tassehilat",
                                "av.payment.option.chaabicash": "Chaabi Cash",
                                "av.payment.option.cashplus": "\u0643\u0627\u0634 \u0628\u0644\u0648\u0633",
                                "av.payment.option.baridcash": "Barid Cash",
                                "av.payment.option.damanecash": "\u0636\u0645\u0627\u0646 \u0643\u0627\u0634",
                                "av.payment.option.fawatir": "\u0641\u0648\u0627\u062a\u064a\u0631",
                                "av.payment.option.cih": "CIH Bank",
                                "av.payment.option.bp": "Banque Populaire",
                                "av.payment.option.bmce": "BMCE",
                                "av.payment.option.sg": "Soci\xe9t\xe9 G\xe9n\xe9rale",
                                "av.payment.option.awb": "Attijariwafa Bank",
                                "av.payment.option.barid": "Al Barid Bank",
                                "av.payment.option.umnia": "Umnia Bank",
                                "av.payment.option.cam": "Cr\xe9dit Agricole",
                                "av.payment.option.cdm": "Cr\xe9dit du Maroc",
                                "av.payment.option.bof": "Bank of Africa",
                                "av.payment.option.cfg": "CFG bank",
                                "av.payment.errors.NoOrderIsUpdated": "\u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628 \u063a\u064a\u0631 \u0645\u0648\u062c\u0648\u062f",
                                "av.payment.errors.UpdateIsNotAllowed": "\u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628 \u0628\u062f\u0621 \u062a\u0641\u0639\u064a\u0644\u0647",
                                "av.payment.errors.OrderAlreadyCompleted": "\u0647\u0630\u0627 \u0627\u0644\u0637\u0644\u0628 \u0633\u0628\u0642 \u062a\u0641\u0639\u064a\u0644\u0647",
                                "av.payment.errors.UnknownPaymentMethod": "\u0647\u0630\u0627 \u0627\u0644\u062f\u0641\u0639 \u063a\u064a\u0631 \u0627\u0644\u0645\u0639\u0631\u0648\u0641",
                                "av.payment.ad.preview.category.location": "{{category}} \u0641\u064a {{city}}, {{area}}",
                                "av.form.ad.sections.sifm.vip.onboarding.title": "\u0643\u064a\u0641 \u062a\u0639\u0645\u0644",
                                "av.form.ad.sections.sifm.vip.pack.title": "Avito Bi3 Liya",
                                "av.form.ad.sections.sifm.vip.onboarding.1.text": "\u062a\u0646\u0638\u064a\u0645 \u062c\u0644\u0633\u0629 \u062a\u0635\u0648\u064a\u0631 \u0648\u0641\u062d\u0635 \u0633\u064a\u0627\u0631\u062a\u0643",
                                "av.form.ad.sections.sifm.vip.onboarding.2.text": "\u0625\u062f\u062e\u0627\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0648\u0627\u0644\u062a\u0648\u0635\u064a\u0629 \u0628\u0633\u0639\u0631 \u0627\u0644\u0628\u064a\u0639",
                                "av.form.ad.sections.sifm.vip.onboarding.3.text": "\u0627\u0644\u062a\u0639\u0627\u0645\u0644 \u0645\u0639 \u0627\u0644\u0645\u0643\u0627\u0644\u0645\u0627\u062a \u0648\u0627\u062e\u062a\u064a\u0627\u0631 \u0627\u0644\u0645\u0634\u062a\u0631\u064a\u0646 \u0627\u0644\u0645\u062d\u062a\u0645\u0644\u064a\u0646",
                                "av.form.ad.sections.sifm.vip.onboarding.4.text": "\u0627\u0644\u062d\u0636\u0648\u0631 \u0641\u064a \u0627\u0644\u0645\u0648\u0627\u0639\u062f \u0648\u0627\u0644\u062f\u0639\u0645 \u0644\u0625\u0646\u0647\u0627\u0621 \u0627\u0644\u0635\u0641\u0642\u0629",
                                "av.form.ad.sections.sifm.vip.onboarding.description": '\u0625\u0630\u0627 \u062a\u0645 \u0627\u0644\u0628\u064a\u0639 \u0645\u0646 \u062e\u0644\u0627\u0644 \u062e\u062f\u0645\u0629 "Avito Bi3 Liya"\u060c \u0641\u0623\u0646\u062a \u0645\u0637\u0627\u0644\u0628\u0648\u0646 \u0628\u062f\u0641\u0639 \u0645\u0628\u0644\u063a 1300 \u062f\u0631\u0647\u0645\u064b\u0627\u060c \u0623\u064a \u0627\u0644\u0633\u0639\u0631 \u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a 1499 \u062f\u0631\u0647\u0645\u064b\u0627.',
                                "av.action.back": "\u0639\u0648\u062f\u0629",
                                "av.action.continue": "\u0627\u0633\u062a\u0645\u0631\u0627\u0631",
                                "av.common.quit": "\u062e\u0631\u0648\u062c",
                                "av.action.see-video": "\u0645\u0634\u0627\u0647\u062f\u0629 \u0627\u0644\u0641\u064a\u062f\u064a\u0648",
                                "av.payment.shop.benefits.title.1": "I\u0625\u062f\u0631\u0627\u062c \u063a\u064a\u0631 \u0645\u062d\u062f\u0648\u062f ",
                                "av.payment.shop.benefits.text.1": "\u0625\u062f\u062e\u0627\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u063a\u064a\u0631 \u0645\u062d\u062f\u0648\u062f (\u062a\u0639\u0631\u0641 \u0639\u0644\u0649 \u0634\u0631\u0648\u0637 \u062e\u062f\u0645\u0629 \u0645\u0627 \u0628\u0639\u062f \u0627\u0644\u0628\u064a\u0639 \u0639\u0644\u0649 0520428686)",
                                "av.payment.shop.benefits.title.2": "\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0648\u0636\u0648\u062d",
                                "av.payment.shop.benefits.text.2": "2.5 \u0645\u0631\u0627\u062a \u0623\u0643\u062b\u0631 \u0645\u0646 \u0627\u0644\u0627\u062a\u0635\u0627\u0644\u0627\u062a \u0648\u0627\u0644\u0631\u0624\u064a\u0629",
                                "av.payment.shop.benefits.title.3": "\u0639\u0632\u0632 \u062f\u062e\u0644\u0643",
                                "av.payment.shop.benefits.text.3": "\u0632\u064a\u0627\u062f\u0629 \u062f\u062e\u0644\u0643 \u0645\u0639 \u0627\u0644\u0627\u0633\u062a\u0641\u0627\u062f\u0629 \u0645\u0646 \u0627\u0644\u062e\u0635\u0648\u0645\u0627\u062a \u0639\u0644\u0649 \u062a\u062c\u062f\u064a\u062f \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u0642\u0627\u0631\u0646\u0629 \u0628\u0627\u0644\u0623\u0641\u0631\u0627\u062f",
                                "av.payment.shop.cta.header": "\u0623\u0635\u0628\u062d \u0645\u0647\u0646\u064a",
                                "av.payment.shop.action.openShop": "\u0641\u062a\u062d \u0645\u062a\u062c\u0631",
                                "av.payment.vasPack.header": "1- \u062a\u062d\u0642\u0642 \u0645\u0646 \u0637\u0644\u0628\u0643",
                                "av.payment.methods.header": "2- \u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062f\u0641\u0639",
                                "av.payment.methods.headerMethods": "\u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062f\u0641\u0639",
                                "av.payment.methods.header.secure": "\u0645\u0624\u0645\u0646",
                                "av.payment.methods.protection.title": "\u062f\u0641\u0639 \u0627\u0645\u0646",
                                "av.payment.methods.protection.text": "\u0625\u0630\u0627 \u0627\u062e\u062a\u0631\u062a \u062d\u0632\u0645\u0629 \u060c \u0641\u0633\u064a\u062a\u0645 \u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u0623\u062e\u064a\u0631\u0629 \u0628\u0639\u062f 24 \u0633\u0627\u0639\u0629 \u0645\u0646 \u0642\u0628\u0648\u0644 \u0625\u0639\u0644\u0627\u0646\u0643",
                                "av.payment.submit": "\u0627\u0644\u062f\u0641\u0639",
                                "av.payment.back": "\u0631\u062c\u0648\u0639",
                                "av.payment.insufficient.balance": "\u0631\u0635\u064a\u062f\u0643 \u063a\u064a\u0631 \u0643\u0627\u0641\u064d \u0644\u0644\u0642\u064a\u0627\u0645 \u0628\u0647\u0630\u0627 \u0627\u0644\u0625\u062c\u0631\u0627\u0621 \u060c \u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0645\u0644\u0627\u0621 \u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0646\u0642\u0627\u0637",
                                "av.payment.methods.subHeader": "\u0627\u0644\u0645\u0631\u062c\u0648 \u0627\u062e\u062a\u064a\u0627\u0631 \u0648\u0627\u062d\u062f\u0629 \u0645\u0646 \u0637\u0631\u0642 \u0627\u0644\u062f\u0641\u0639 \u0627\u0644\u0622\u0645\u0646\u0629",
                                "av.payment.sorry": "\u0622\u0633\u0641 {{name}}",
                                "av.account.shop.alert.success": "\u062a\u0647\u0627\u0646\u064a\u0646\u0627\u060c \u0644\u0642\u062f \u062a\u0645\u062a \u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u062f\u0641\u0639 \u0628\u0646\u062c\u0627\u062d\u060c \u0648\u0633\u064a\u062a\u0645 \u062a\u0639\u0632\u064a\u0632 \u0625\u0639\u0644\u0627\u0646\u0643 \u062e\u0644\u0627\u0644 \u0628\u0636\u0639 \u062f\u0642\u0627\u0626\u0642.",
                                "av.payment.shop.success": "\u062a\u0645 \u0627\u0644\u062f\u0641\u0639 \u0628\u0646\u062c\u0627\u062d \u060c \u0633\u064a\u062a\u0645 \u062a\u0645\u064a\u064a\u0632 \u0625\u0639\u0644\u0627\u0646\u0643 \u0641\u064a \u063a\u0636\u0648\u0646 \u0628\u0636\u0639 \u062f\u0642\u0627\u0626\u0642.",
                                "av.account.shop.alert.error.SoldeExpired": "\u0641\u0634\u0644\u062a \u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u062f\u0641\u0639 \u0646\u0638\u0631\u064b\u0627 \u0644\u0639\u062f\u0645 \u0648\u062c\u0648\u062f \u0631\u0635\u064a\u062f \u0644\u062f\u064a\u0643 \u060c \u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0645\u0644\u0627\u0621 \u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0646\u0642\u0627\u0637 \u0639\u0644\u0649 86-86-42-0520",
                                "av.account.shop.alert.error.PermissionDenied": "\u0622\u0633\u0641 \u060c \u064a\u0631\u062c\u0649 \u0625\u0639\u0627\u062f\u0629 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0648\u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629",
                                "av.account.shop.alert.error.InvalidOperation": "\u0639\u0630\u0631\u0627 \u060c \u0641\u0634\u0644 \u0627\u0644\u062f\u0641\u0639 \u0627\u0644\u062e\u0627\u0635 \u0628\u0643",
                                "av.payment.shop.error.ERROR_SOLDE_EXPIRED": "\u0641\u0634\u0644\u062a \u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u062f\u0641\u0639 \u0646\u0638\u0631\u064b\u0627 \u0644\u0639\u062f\u0645 \u0648\u062c\u0648\u062f \u0631\u0635\u064a\u062f \u0644\u062f\u064a\u0643 \u060c \u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0645\u0644\u0627\u0621 \u0644\u0634\u0631\u0627\u0621 \u0627\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0646\u0642\u0627\u0637 \u0639\u0644\u0649 86-86-42-0520",
                                "av.payment.shop.error.ERROR_PACKAGE_NOT_FOUND": "\u0644\u0645 \u0646\u0639\u062b\u0631 \u0639\u0644\u0649 \u0627\u0644\u062d\u0632\u0645\u0629 \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629 \u060c \u064a\u0631\u062c\u0649 \u062a\u062d\u062f\u064a\u062f \u062d\u0632\u0645\u0629 \u0635\u0627\u0644\u062d\u0629.",
                                "av.payment.shop.error.ERROR_SOLDE_EQUIVALENT": "\u0644\u0627 \u062a\u062d\u062a\u0648\u064a \u0627\u0644\u062d\u0632\u0645\u0629 \u0627\u0644\u0645\u062d\u062f\u062f\u0629 \u0639\u0644\u0649 \u0645\u0639\u0627\u062f\u0644\u0629 \u0646\u0642\u0627\u0637 \u060c \u064a\u0631\u062c\u0649 \u062a\u062d\u062f\u064a\u062f \u062d\u0632\u0645\u0629 \u0635\u0627\u0644\u062d\u0629 \u0623\u0648 \u0627\u062e\u062a\u064a\u0627\u0631 \u0637\u0631\u064a\u0642\u0629 \u062f\u0641\u0639 \u0623\u062e\u0631\u0649",
                                "av.payment.shop.error.ERROR_SOLDE_NOT_ENOUGH": "\u0631\u0635\u064a\u062f\u0643 \u063a\u064a\u0631 \u0643\u0627\u0641\u064d \u0644\u0625\u062c\u0631\u0627\u0621 \u0647\u0630\u0647 \u0627\u0644\u0639\u0645\u0644\u064a\u0629.",
                                "av.account.pageTitle.private": "\u062d\u0633\u0627\u0628\u064a",
                                "av.account.pageTitle.shop": "\u0645\u062a\u062c\u0631\u064a",
                                "av.account.tabs.classified.text": "\u0625\u062f\u0627\u0631\u0629",
                                "av.account.tabs.orders": "Mes commandes",
                                "av.account.tabs.favorite": "\u0627\u0644\u0644\u0627\u0626\u062d\u0629 \u0627\u0644\u0645\u0641\u0636\u0644\u0629",
                                "av.account.tabs.settings.text": "\u062a\u0639\u062f\u064a\u0644 \u0645\u062a\u062d\u0631\u0643",
                                "av.account.tabs.stats": "\u0625\u062d\u0635\u0627\u0626\u064a\u0627\u062a",
                                "av.account.tabs.stats.text": "\u0645\u0634\u0627\u0647\u062f\u0629 \u0625\u062d\u0635\u0627\u0626\u064a\u0627\u062a\u0643",
                                "av.account.stats": "\u0625\u062d\u0635\u0627\u0626\u064a\u0627\u062a",
                                "av.account.sort": "Tri",
                                "av.account.listing.status": "\u062d\u0627\u0644\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.account.listing.orders.status": " \u0645\u0631\u0627\u062d\u0644 \u0627\u0644\u0637\u0644\u0628\u0627\u062a",
                                "av.account.listing.sort.all-ads": "\u0643\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a",
                                "av.account.listing.sort.boosted-ads": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u0639\u0632\u0632\u0629",
                                "av.account.listing.sort.unboosted-ads": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u063a\u064a\u0631 \u0645\u0639\u0632\u0632\u0629",
                                "av.account.filters": "\u0627\u0644\u062a\u062f\u0642\u064a\u0642 \u0641\u064a \u0627\u0644\u0628\u062d\u062b",
                                "av.account.filters.orders": "Filtrer mes commandes",
                                "av.account.filters.apply": "\u062a\u0623\u0643\u064a\u062f",
                                "av.account.filter.active": "\u0641\u0639\u0627\u0644\u0629",
                                "av.account.filter.rejected": "\u0645\u0631\u0641\u0648\u0636",
                                "av.account.filter.deactivated": "\u063a\u064a\u0631 \u0641\u0639\u0627\u0644\u0629",
                                "av.account.filter.deleted": "\u0645\u062d\u0630\u0648\u0641\u0629",
                                "av.account.filter.pending-moderation": "\u0641\u064a \u0627\u0644\u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.account.filter.pending-payment": "\u0641\u064a \u0627\u0646\u062a\u0638\u0627\u0631 \u0627\u0644\u062f\u0641\u0639",
                                "av.account.filter.favorite-ads": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062d\u0641\u0648\u0638\u0629",
                                "av.account.filter.saved-search": "\u0628\u062d\u062b \u0645\u062d\u0641\u0648\u0638",
                                "av.account.filter.saved-searches": "\u0627\u0644\u0627\u0628\u062d\u0627\u062b \u0627\u0644\u0645\u062d\u0641\u0648\u0638\u0629",
                                "av.account.filter.settings": "\u062a\u0639\u062f\u064a\u0644 \u0645\u0639\u0644\u0648\u0645\u0627\u062a\u0643",
                                "av.account.filter.password": "\u062a\u063a\u064a\u064a\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
                                "av.account.filter.shop.settings": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.account.filter.shop.contact": "\u0639\u0646\u0627\u0648\u064a\u0646 \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.account.filter.shop.password": "\u062a\u063a\u064a\u064a\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
                                "av.account.filter.notification": "\u0645\u0639\u0627\u064a\u064a\u0631 \u0627\u0644\u0625\u0634\u0639\u0627\u0631",
                                "av.account.filter.orders.initiated": "\u0627\u0644\u0637\u0644\u0628\u0627\u062a \u0627\u0644\u0645\u0641\u0639\u0644\u0629",
                                "av.account.filter.orders.preparing": "\u0637\u0644\u0628\u0627\u062a \u0641\u064a \u0637\u0648\u0631 \u0627\u0644\u062a\u062d\u0636\u064a\u0631",
                                "av.account.filter.orders.delivering": "\u0637\u0644\u0628\u0627\u062a \u0641\u064a \u0637\u0648\u0631 \u0627\u0644\u062a\u0633\u0644\u064a\u0645",
                                "av.account.filter.orders.delivered": "\u0637\u0644\u0628\u0627\u062a \u062a\u0645 \u062a\u0648\u0635\u064a\u0644\u0647\u0627",
                                "av.account.filter.orders.canceled": "\u0637\u0644\u0628\u0627\u062a \u062a\u0645 \u0625\u0644\u063a\u0627\u0626\u0647\u0627",
                                "av.account.status.orders.initiated": "\u0637\u0644\u0628 \u0645\u0641\u0639\u0644",
                                "av.account.status.orders.preparing": "\u0637\u0644\u0628 \u0641\u064a \u0637\u0648\u0631 \u0627\u0644\u062a\u062d\u0636\u064a\u0631",
                                "av.account.status.orders.delivering": "\u0637\u0644\u0628 \u0641\u064a \u0637\u0648\u0631 \u0627\u0644\u062a\u0633\u0644\u064a\u0645",
                                "av.account.status.orders.delivered": "\u0637\u0644\u0628 \u062a\u0645 \u062a\u0648\u0635\u064a\u0644\u0647",
                                "av.account.status.orders.canceled": "\u0637\u0644\u0628 \u062a\u0645 \u0625\u0644\u063a\u0627\u0626\u0647",
                                "av.account.appeal.form_modal.title": "\u0637\u0644\u0628 \u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.account.appeal.limit.reached": "\u0644\u0642\u062f \u0628\u0644\u063a\u062a \u0627\u0644\u062d\u062f \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0625\u0639\u0627\u062f\u0629 \u0625\u0631\u0633\u0627\u0644 \u0647\u0630\u0627 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0644\u0644\u0645\u0631\u0627\u062c\u0639\u0629.",
                                "av.account.appeal.submit": "\u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628 \u0627\u0644\u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.account.appeal.success": "\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628 \u0627\u0644\u0645\u0631\u0627\u062c\u0639\u0629 \u0628\u0646\u062c\u0627\u062d!",
                                "av.account.appeal.reason.placeholder": "\u0627\u062e\u062a\u0631 \u0633\u0628\u0628 \u0627\u0644\u0631\u0641\u0636",
                                "av.account.appeal.problem.description.placeholder": "\u0648\u0636\u0651\u062d \u0645\u0634\u0643\u0644\u062a\u0643",
                                "av.account.card.btn.pay": "\u062f\u0641\u0639",
                                "av.account.card.btn.reactive": "\u0625\u0639\u0627\u062f\u0629 \u0627\u0644\u062a\u0646\u0634\u064a\u0637",
                                "av.account.card.btn.delete-definitely": "\u062d\u062f\u0641 \u0628\u0635\u0641\u0629 \u0646\u0647\u0627\u0626\u064a\u0629",
                                "av.account.card.btn.cancel-order": "Annuler la commande",
                                "av.account.card.footer.rejected": "\u0645\u0631\u0641\u0648\u0636",
                                "av.account.card.footer.pending-payment": "\u0641\u064a \u0627\u0646\u062a\u0638\u0627\u0631 \u0627\u0644\u062f\u0641\u0639",
                                "av.account.card.footer.pending-review": "\u0641\u064a \u0627\u0644\u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.account.card.menu.more-detail": "\u0627\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644",
                                "av.account.card.menu.availability": "\u062a\u0642\u0648\u064a\u0645",
                                "av.account.card.menu.error-availability": "\u0647\u0646\u0627\u0643 \u062e\u0637\u0623 \u0645\u0627 !",
                                "av.account.card.menu.sucess-availability": "\u062a\u0645 \u062a\u063a\u064a\u064a\u0631\u0627\u0644\u0625\u062a\u0627\u062d\u0629 \u0628\u0646\u062c\u0627\u062d",
                                "av.account.card.menu.urgent-promo": "\u0648\u0636\u0639 \u0639\u0644\u0627\u0645\u0629 \u0639\u0644\u0649 \u0623\u0646\u0647\u0627 \u0639\u0627\u062c\u0644\u0629/\u062a\u0631\u0648\u064a\u062c\u064a\u0629",
                                "av.account.card.menu.modify": "\u062a\u0639\u062f\u064a\u0644",
                                "av.account.card.menu.appeal": "\u0637\u0644\u0628 \u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.account.card.menu.delete": "\u062d\u0630\u0641",
                                "av.account.card.menu.view-on-avito": "\u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0629 \u0639\u0644\u0649 Avito",
                                "av.account.card.admodal.description": "\u0627\u0644\u0648\u0635\u0641",
                                "av.account.card.admodal.description.read-more": "\u0645\u0632\u064a\u062f",
                                "av.account.card.admodal.description.read-less": "\u0623\u0642\u0644",
                                "av.account.card.admodal.area": "\u0642\u0637\u0627\u0639",
                                "av.account.card.admodal.category": "\u0627\u0644\u0641\u0626\u0629",
                                "av.account.card.admodal.applied-boosts": "\u062e\u0627\u0635\u064a\u0627\u062a \u0627\u0644\u062a\u062c\u062f\u064a\u062f \u0627\u0644\u0645\u0641\u0639\u0644\u0629 \u062d\u0627\u0644\u064a\u0627",
                                "av.account.card.admodal.price.unit": " \u062f\u0631\u0647\u0645",
                                "av.account.card.admodal.price.not-specified": "\u0633\u0639\u0631 \u063a\u064a\u0631 \u0645\u062d\u062f\u062f",
                                "av.account.card.admodal.read-more": "\u0644\u0644\u0645\u0632\u064a\u062f >",
                                "av.account.card.admodal.executed-at": "\u062a\u0645 \u062a\u0637\u0628\u064a\u0642\u0647 \u0641\u064a",
                                "av.account.card.admodal.expire-in": "\u062a\u0646\u062a\u0647\u064a \u0635\u0644\u0627\u062d\u064a\u062a\u0647",
                                "av.account.card.admodal.actions.availability": "\u062a\u0642\u0648\u064a\u0645",
                                "av.account.card.admodal.actions.edit": "\u062a\u0639\u062f\u064a\u0644",
                                "av.account.card.admodal.actions.boost": "\u062a\u062c\u062f\u064a\u062f",
                                "av.account.card.admodal.actions.delete": "\u062d\u0630\u0641",
                                "av.account.card.admodal.actions.view-on-avito": "\u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0629 \u0639\u0644\u0649 \u0645\u0648\u0642\u0639 Avito",
                                "av.account.card.admodal.actions.continue-payment": "\u0645\u0648\u0627\u0635\u0644\u0629 \u0627\u0644\u062f\u0641\u0639",
                                "av.account.card.admodal.pack": "\u062e\u0627\u0635\u064a\u0627\u062a \u0627\u0644\u062a\u062c\u062f\u064a\u062f",
                                "av.account.card.admodal.vas.expire-in": "\u062a\u0646\u062a\u0647\u064a \u0635\u0644\u0627\u062d\u064a\u062a\u0647",
                                "av.account.card.admodal.vas.start": "\u064a\u0628\u062f\u0623 \u064a\u0648\u0645 {{date}} \u0627\u0644\u0633\u0627\u0639\u0629 {{time}}",
                                "av.account.card.admodal.ads.unboosted": "\u0625\u0639\u0644\u0627\u0646 \u063a\u064a\u0631 \u0645\u062c\u062f\u062f",
                                "av.account.card.ad.properties.modal.title": "\u062a\u0639\u062f\u064a\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.account.card.ad.properties.modal.urgent-toggle-text": '\u0623\u0636\u0641 \u0634\u0639\u0627\u0631 "\u0639\u0627\u062c\u0644"',
                                "av.account.card.ad.properties.modal.hotdeal-toggle-text": "\u0623\u0636\u0641 \u062a\u062e\u0641\u064a\u0636",
                                "av.account.card.ad.properties.modal.submit-button": "\u062a\u0637\u0628\u064a\u0642 \u0627\u0644\u062a\u063a\u064a\u064a\u0631\u0627\u062a",
                                "av.account.card.ad.properties.modal.sucess-message": "\u062a\u0645 \u0642\u0628\u0648\u0644 \u0627\u0644\u062a\u0639\u062f\u064a\u0644 \u0628\u0646\u062c\u0627\u062d",
                                "av.account.card.ad.properties.modal.error-message": "\u0627\u0644\u062a\u0639\u062f\u064a\u0644 \u0644\u0645 \u064a\u0642\u0628\u0644",
                                "av.account.lisiting.ad.status.active": "\u0641\u0639\u064e\u0627\u0644",
                                "av.account.lisiting.ad.status.pending-moderation": "\u0641\u064a \u0627\u0644\u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.account.lisiting.ad.status.refused": "\u0645\u0631\u0641\u0648\u0636",
                                "av.account.lisiting.ad.status.deleted": "\u0645\u062d\u0630\u0648\u0641",
                                "av.account.lisiting.ad.status.deactivated": "\u063a\u064a\u0631 \u0641\u0639\u064e\u0627\u0644",
                                "av.account.lisiting.ad.status.pending-payment": "\u0641\u064a \u0627\u0646\u062a\u0638\u0627\u0631 \u0627\u0644\u062f\u0641\u0639",
                                "av.account.lisiting.ad.edit-status.pending": "\u062c\u0627\u0631\u064a \u0627\u0644\u062a\u0639\u062f\u064a\u0644",
                                "av.account.lisiting.ad.edit-status.accepted": "\u062a\u0639\u062f\u064a\u0644 \u0646\u0627\u062c\u062d",
                                "av.account.lisiting.ad.edit-status.refused": "\u062a\u0639\u062f\u064a\u0644 \u0645\u0631\u0641\u0648\u0636",
                                "av.account.listing.ad.operations.confirm-ad-deactivation.title": "\u0625\u0639\u0644\u0627\u0646 \u063a\u064a\u0631 \u0645\u0641\u0639\u0644",
                                "av.account.listing.ad.operations.confirm-ads-deactivation.title": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u063a\u064a\u0631 \u0645\u0641\u0639\u0644\u0629",
                                "av.account.listing.ad.operations.confirm-ad-deactivation.text": "\u064a\u0645\u0643\u0646\u0643 \u0625\u0639\u0627\u062f\u0629 \u062a\u0646\u0634\u064a\u0637\u0647 \u0641\u064a \u0623\u064a \u0648\u0642\u062a \u0623\u0648 \u062d\u0630\u0641\u0647 \u0628\u0639\u062f 7 \u0623\u064a\u0627\u0645",
                                "av.account.listing.ad.operations.confirm-ads-deactivation.text": "\u064a\u0645\u0643\u0646\u0643 \u0625\u0639\u0627\u062f\u0629 \u062a\u0646\u0634\u064a\u0637\u0647\u0627 \u0641\u064a \u0623\u064a \u0648\u0642\u062a \u0623\u0648 \u062d\u0630\u0641\u0647\u0627 \u0628\u0639\u062f 7 \u0623\u064a\u0627\u0645",
                                "av.account.listing.ad.operations.view-ads": "\u0639\u0631\u0636 \u0625\u0639\u0644\u0627\u0646\u0627\u062a\u064a",
                                "av.account.listing.ad.operations.delete-text-why": "\u0644\u0645\u0627\u0630\u0627 \u062a\u0631\u064a\u062f \u062d\u062f\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u061f",
                                "av.account.listing.bulk.manage-ad": "G\xe9rer vos annonces",
                                "av.account.listing.bulk.delete-ad": "Supprimer vos annonces",
                                "av.account.listing.bulk.select-ad": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629",
                                "av.account.listing.bulk.delete-text-why": "\u0644\u0645\u0627\u0630\u0627 \u062a\u0631\u064a\u062f \u062d\u062f\u0641 \u0647\u0630\u0647 {{nbrAds}} \u0627\u0644\u0627\u0639\u0644\u0627\u0646\u0627\u062a?",
                                "av.account.listing.bulk.delete-cancel": "\u0625\u0644\u063a\u0627\u0621",
                                "av.account.listing.bulk.delete": "\u062d\u0630\u0641",
                                "av.account.listing.bulk.delete-confirmation-message": "Votre annonce sera supprim\xe9e dans quelques instants",
                                "av.account.listing.bulk.delete-confirmation-message-plural": "Vos annonces seront supprim\xe9es dans quelques instants",
                                "av.account.listing.bulk.other-text-placeholder": "\u0627\u0643\u062a\u0628 \u0631\u0633\u0627\u0644\u062a\u0643 \u0647\u0646\u0627",
                                "av.account.listing.bulk.Uncheck": "D\xe9s\xe9lectionner",
                                "av.account.listing.no-response.active.text": "\u0647\u0644 \u0644\u062f\u064a\u0643 \u0634\u064a\u0621 \u062a\u0628\u064a\u0639\u0647\u061f",
                                "av.account.listing.no-response.active.subText": "\u0636\u0639 \u0625\u0639\u0644\u0627\u0646\u0643 \u0645\u062c\u0627\u0646\u064b\u0627 \u0639\u0644\u0649 Avito.ma",
                                "av.account.listing.no-response.disabled.text": "\u0647\u0644 \u0644\u062f\u064a\u0643 \u0634\u064a\u0621 \u062a\u0628\u064a\u0639\u0647\u061f",
                                "av.account.listing.no-response.disabled.subText": "\u0636\u0639 \u0625\u0639\u0644\u0627\u0646\u0643 \u0645\u062c\u0627\u0646\u064b\u0627 \u0639\u0644\u0649 Avito.ma",
                                "av.account.listing.no-response.deleted.text": "\u0644\u0627 \u064a\u0648\u062c\u062f \u0644\u062f\u064a\u0643 \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u062d\u062f\u0648\u0641\u0629",
                                "av.account.listing.no-response.moderation.text": "\u0644\u0627 \u064a\u0648\u062c\u062f \u0644\u062f\u064a\u0643 \u0623\u064a \u0625\u0639\u0644\u0627\u0646 \u0641\u064a \u0637\u0648\u0631 \u0627\u0644\u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.account.listing.no-response.rejected.text": "\u0644\u0627 \u064a\u0648\u062c\u062f \u0644\u062f\u064a\u0643 \u0623\u064a \u0625\u0639\u0644\u0627\u0646 \u0645\u0631\u0641\u0648\u0636",
                                "av.account.listing.no-response.payment.text": "\u0644\u0627 \u064a\u0648\u062c\u062f \u0644\u062f\u064a\u0643 \u0623\u064a \u0625\u0639\u0644\u0627\u0646 \u0641\u064a \u0625\u0646\u062a\u0638\u0627\u0631 \u0627\u0644\u062f\u0641\u0639",
                                "av.account.listing.no-response.favorite-ads.text": "\u0644\u064a\u0633 \u0644\u062f\u064a\u0643 \u0625\u0639\u0644\u0627\u0646 \u0645\u062d\u0641\u0648\u0638",
                                "av.account.listing.no-response.saved-search.text": "\u0644\u064a\u0633 \u0644\u062f\u064a\u0643 \u0628\u062d\u062b \u0645\u062d\u0641\u0648\u0638",
                                "av.account.listing.no-response.boosted.text": "Vous n'avez aucune annonce boost\xe9e",
                                "av.account.listing.no-response.unboosted.text": "Vous n'avez aucune annonce non boost\xe9e",
                                "av.account.listing.no-response.orders.text": "\u0644\u0645 \u062a\u0642\u062f\u0645 \u0627\u064a \u0637\u0644\u0628\u064b\u0627 \u062d\u062a\u0649 \u0627\u0644\u0622\u0646",
                                "av.account.listing.no-response.orders.subText": "\u0625\u0628\u062f\u0623 \u0628\u0627\u0644\u0639\u062b\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0645\u0646\u062a\u062c \u0641\u064a \u0645\u062a\u0627\u062c\u0631\u0646\u0627 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a\u060c \u0648\u0627\u0646\u062a\u0642\u0644 \u0625\u0644\u0649 \u0627\u0644\u062f\u0641\u0639 \u0627\u0644\u0641\u0648\u0631\u064a",
                                "av.account.listing.no-response.orders.btn": "\u0625\u0643\u062a\u0634\u0641 \u0627\u0644\u0622\u0646",
                                "av.account.setting.private.name": "\u0625\u0633\u0645",
                                "av.account.setting.private.phone": "\u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.account.setting.private.hide-number": "\u0625\u0638\u0647\u0627\u0631 \u0631\u0642\u0645 \u0647\u0627\u062a\u0641\u064a",
                                "av.account.setting.private.faq": "Vous ne pouvez pas changer votre adresse e-mail.",
                                "av.account.setting.private.faq-link": "Lisez les questions les plus fr\xe9quemment pos\xe9es",
                                "av.account.setting.city.notFound": "\u0644\u0645 \u064a\u062a\u0645 \u0627\u0644\u0639\u062b\u0648\u0631 \u0639\u0644\u0649 \u0646\u062a\u0627\u0626\u062c",
                                "av.account.setting.private.error.name.incorrect": "\u0627\u0644\u0627\u0633\u0645 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d!",
                                "av.account.setting.private.error.phone.incorrect": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d!",
                                "av.account.setting.private.password.current": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631 \u0627\u0644\u062d\u0627\u0644\u064a\u0629",
                                "av.account.setting.private.password.new": "\u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u062c\u062f\u064a\u062f\u0629",
                                "av.account.setting.private.password.confirm": "\u062a\u0623\u0643\u064a\u062f \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
                                "av.account.setting.private.password.btn-submit": "Modifier le mot de passe",
                                "av.account.setting.private.error.password.too-short": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0642\u0635\u064a\u0631\u0629 \u062c\u062f\u0627. \u064a\u062c\u0628 \u0623\u0646 \u062a\u062a\u0643\u0648\u0646 \u0645\u0646 5 \u0623\u062d\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644.",
                                "av.account.setting.private.error.password.identical-passwords": "\u064a\u0631\u062c\u0649 \u0627\u062f\u062e\u0627\u0644 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0645\u062e\u062a\u0644\u0641\u0629 \u0639\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062d\u0627\u0644\u064a",
                                "av.account.setting.private.error.password.verify": "\u064a\u0631\u062c\u0649 \u0627\u0644\u062a\u0623\u0643\u062f \u0645\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
                                "av.account.setting.private.missing.info.alert.title": "\u0647\u0627\u0645:",
                                "av.account.setting.private.missing.info.alert.description": "\u0627\u0644\u0631\u062c\u0627\u0621 \u0625\u062f\u062e\u0627\u0644 \u0643\u0644 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0644\u0625\u0646\u0647\u0627\u0621 \u062a\u0633\u062c\u064a\u0644 \u062d\u0633\u0627\u0628\u0643\u0645.",
                                "av.account.setting.shop": "\u0645\u062a\u062c\u0631",
                                "av.account.setting.shop.show": "\u062c\u0645\u064a\u0639 \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.account.setting.shop.info": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.account.setting.shop.name": "\u0627\u0633\u0645 \u0627\u0644\u0645\u062d\u0644",
                                "av.account.setting.shop.category": "\u0627\u0644\u0641\u0626\u0629",
                                "av.account.setting.shop.url": "\u0645\u0648\u0642\u0639 \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.account.setting.shop.description": "\u0648\u0635\u0641",
                                "av.account.setting.shop.bref-description": "Br\xe8ve description",
                                "av.account.setting.shop.contact": "\u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0627\u0644\u0645\u062d\u0644",
                                "av.account.setting.shop.address": "\u0639\u0646\u0648\u0627\u0646",
                                "av.account.setting.shop.phone": "\u0627\u0644\u0647\u0627\u062a\u0641 \u0627\u0644\u0631\u0626\u064a\u0633\u064a",
                                "av.account.setting.shop.extra-phone": "\u0623\u0636\u0641 \u0631\u0642\u0645\u064b\u0627 \u0622\u062e\u0631",
                                "av.account.setting.shop.extra-phone.number": "\u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.account.setting.shop.email": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.account.setting.shop.change-password": "\u062a\u063a\u064a\u064a\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
                                "av.account.setting.shop.btn-save": "\u062d\u0641\u0638",
                                "av.account.setting.shop.edit-logo": "\u062a\u0639\u062f\u064a\u0644 \u0627\u0644\u0634\u0627\u0631\u0629",
                                "av.account.setting.shop.add-logo": "\u0648\u0636\u0639 \u0634\u0627\u0631\u0629",
                                "av.account.setting.shop.error.name.incorrect": "\u0627\u0633\u0645 \u0627\u0644\u0645\u062a\u062c\u0631 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d!",
                                "av.account.setting.shop.error.phone.incorrect": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d!",
                                "av.account.setting.shop.error.description.incorrect": "\u0627\u0644\u0648\u0635\u0641 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d!",
                                "av.account.setting.shop.error.url.incorrect": "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0645\u0648\u0642\u0639 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d!",
                                "av.account.setting.alert.success.message": "Super !",
                                "av.account.setting.alert.account-updated": "\u062a\u0645 \u062a\u062d\u062f\u064a\u062b \u062d\u0633\u0627\u0628\u0643!",
                                "av.account.setting.alert.logo-updated": "\u062a\u0645 \u062a\u062d\u062f\u064a\u062b \u0634\u0627\u0631\u062a\u0643!",
                                "av.account.setting.cs.help": "Besoin d'aide ? ",
                                "av.account.setting.cs.phone": "0520428686",
                                "av.account.setting.cs.text": "\u0631\u0642\u0645 \u0647\u0627\u062a\u0641 \u062e\u062f\u0645\u0629 \u0645\u0627 \u0628\u0639\u062f \u0627\u0644\u0628\u064a\u0639",
                                "av.account.setting.cs.phone.number": "0520428686",
                                "av.account.setting.contact.email.note": "\u0644\u0623\u0633\u0628\u0627\u0628 \u062a\u062a\u0639\u0644\u0642 \u0628\u0627\u0644\u0633\u0631\u064a\u0629 \u060c \u0644\u0627 \u064a\u0645\u0643\u0646 \u062a\u063a\u064a\u064a\u0631 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u060c \u0644\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u062e\u062f\u0645\u0629 \u0627\u0644\u0632\u0628\u0646\u0627\u0621 \u0639\u0644\u0649 \u0627\u0644\u0647\u0627\u062a\u0641 0520428686 / ",
                                "av.account.setting.contact.phone.update.alert": "\u0644\u062a\u063a\u064a\u064a\u0631 \u0631\u0642\u0645 \u0647\u0627\u062a\u0641\u0643\u0645\u060c \u064a\u0631\u062c\u0649 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0646\u0627 \u0639\u0644\u0649 \u0627\u0644\u0631\u0642\u0645 0520428686",
                                "av.account.setting.contact.email.note.live-chat": "\u0627\u0644\u062a\u062d\u062f\u062b \u0645\u0628\u0627\u0634\u0631\u0629 \u0625\u0644\u0649 \u0623\u062d\u062f \u0639\u0645\u0644\u0627\u0626\u0646\u0627",
                                "av.account.setting.notification.account-manage.title": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0644\u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u062d\u0633\u0627\u0628",
                                "av.account.setting.notification.account-manage.text": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0627\u0644\u0645\u0631\u062a\u0628\u0637 \u0628\u062d\u0633\u0627\u0628\u0643 \u0645\u062b\u0644 \u0627\u0633\u062a\u0639\u0627\u062f\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u2026",
                                "av.account.setting.notification.ads.title": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0644\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.account.setting.notification.ads.text": "\u064a\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0631\u0633\u0627\u0644\u0629 \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0629 \u0641\u064a \u0643\u0644 \u0645\u0631\u0629 \u062a\u062a\u063a\u064a\u0631 \u0641\u064a\u0647\u0627 \u062d\u0627\u0644\u0629 \u0625\u0639\u0644\u0627\u0646\u0627\u062a\u0643.",
                                "av.account.setting.notification.vas.title": "\u0631\u0633\u0627\u0626\u0644 \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0629 \u0628\u062e\u0635\u0648\u0635 \u0639\u0631\u0648\u0636 \u0627\u0644\u062a\u062c\u062f\u064a\u062f",
                                "av.account.setting.notification.vas.text": "\u0631\u0633\u0627\u0644\u0629 \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0629 \u0645\u0628\u0639\u0648\u062b\u0629 \u0639\u0646\u062f \u062a\u0637\u0628\u064a\u0642 \u062e\u0627\u0635\u064a\u0629 \u062a\u062c\u062f\u064a\u062f.",
                                "av.account.setting.notification.payment.title": "\u0631\u0633\u0627\u0644\u0629 \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0629 \u0628\u062e\u0635\u0648\u0635 \u0627\u0644\u062f\u0641\u0639",
                                "av.account.setting.notification.payment.text": "\u0631\u0633\u0627\u0644\u0629 \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a\u0629 \u0645\u0628\u0639\u0648\u062b\u0629 \u0628\u0639\u062f \u0643\u0644 \u062f\u0641\u0639.",
                                "av.account.setting.notification.newsletters.title": "\u0631\u0633\u0627\u0644\u0629 \u0625\u062e\u0628\u0627\u0631\u064a\u0629",
                                "av.account.setting.notification.newsletters.text": "\u0628\u0631\u064a\u062f \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0645\u062a\u0639\u0644\u0642 \u0628\u0627\u0644\u0639\u0631\u0648\u0636 \u0648\u0627\u0644\u062a\u062e\u0641\u064a\u0636\u0627\u062a \u0648\u0623\u064a\u0636\u064b\u0627 \u0623\u062e\u0628\u0627\u0631 \u0645\u0646 Avito",
                                "av.account.setting.alert.notification.updated": "\u062a\u0645 \u062a\u062d\u062f\u064a\u062b \u0645\u0639\u0627\u064a\u064a\u0631 \u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062a \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643!",
                                "av.account.setting.email.verification.title": "\u062a\u062d\u0642\u0642 \u0645\u0646 \u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.account.setting.email.verification.text": "\u0627\u0644\u0645\u0631\u062c\u0648 \u0625\u062f\u062e\u0627\u0644 \u0628\u0631\u064a\u062f\u0643\u0645 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0644\u062a\u0644\u0642\u064a \u0631\u0627\u0628\u0637 \u0627\u0644\u062a\u062d\u0642\u0642.",
                                "av.account.modals.activate.ad.title": "\u062a\u0645 \u062a\u0641\u0639\u064a\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.account.modals.activate.ad.text": "\u064a\u0645\u0643\u0646\u0643 \u062a\u062c\u062f\u064a\u062f \u0625\u0639\u0644\u0627\u0646\u0643 \u0639\u0628\u0631 \u0627\u0644\u0648\u0644\u0648\u062c \u0625\u0644\u0649 \u062d\u0633\u0627\u0628\u0643\u060c \u062b\u0645 \u0627\u0644\u0636\u063a\u0637 \u0639\u0644\u0649 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u0641\u0639\u0644\u0629 \u0623\u0648 \u0627\u0644\u0636\u063a\u0637 \u0647\u0646\u0627",
                                "av.account.modals.activate.ad.btn": "\u0627\u0639\u0644\u0627\u0646\u0627\u062a\u064a \u0627\u0644\u0641\u0639\u0627\u0644\u0629",
                                "av.account.modals.delete.refused.title": " \u0631\u0641\u0636 \u0627\u0644\u062d\u062f\u0641 !",
                                "av.account.modals.delete.refused.text": "\u0644\u0627 \u064a\u0645\u0643\u0646 \u062d\u062f\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0642\u0628\u0644 {{days}} \u0623\u064a\u0627\u0645",
                                "av.account.modals.delete.refused.btn": "\u062d\u0633\u0646\u0627! \u0641\u0647\u0645\u062a",
                                "av.account.modals.delete.confirmation.title": "\u062a\u0623\u0643\u064a\u062f \u0627\u0644\u062d\u062f\u0641",
                                "av.account.modals.delete.confirmation.text": "\u0644\u0627 \u064a\u0645\u0643\u0646 \u0627\u0644\u0642\u064a\u0627\u0645 \u0628\u0623\u064a \u062a\u0635\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0625\u0630\u0627 \u0642\u0645\u062a \u0628\u062d\u062f\u0641\u0647",
                                "av.account.modals.delete.confirmation.btn": "\u062d\u062f\u0641",
                                "av.account.modals.activate.limit.title": "\u0644\u0642\u062f \u062a\u0645 \u0628\u0644\u0648\u063a \u0639\u062f\u062f \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062c\u0627\u0646\u064a\u0629 \u0627\u0644\u0645\u0633\u0645\u0648\u062d \u0628\u0647",
                                "av.account.modals.activate.limit.text": "\u064a\u0645\u0643\u0646\u0643 \u0627\u0644\u062f\u0641\u0639 \u0645\u0646 \u0623\u062c\u0644 \u062a\u0641\u0639\u064a\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.account.modals.activate.limit.btn": "\u062a\u0641\u0639\u064a\u0644",
                                "av.account.toaster.activate.success": "Annonce Suprim\xe9 avec succ\xe8s",
                                "av.account.toaster.activate.error": "\u062d\u062f\u062b \u062e\u0637\u0623! \u064a\u0631\u062c\u0649 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0641\u064a \u0648\u0642\u062a \u0644\u0627\u062d\u0642.",
                                "av.account.favorites.modal.delete-ad.title": "\u062d\u0630\u0641 \u0627\u0644\u0627\u0639\u0644\u0627\u0646",
                                "av.account.favorites.modal.delete-ad.text": "\u0647\u0644 \u0623\u0646\u062a \u0645\u062a\u0623\u0643\u062f \u0623\u0646\u0643 \u062a\u0631\u064a\u062f \u062d\u0630\u0641 \u0647\u0630\u0627 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0645\u0646 \u0644\u0627\u0626\u062d\u062a\u0643 \u0627\u0644\u0645\u0641\u0636\u0644\u0629 \u061f",
                                "av.account.favorites.modal.delete": "\u062d\u0630\u0641",
                                "av.account.favorites.modal.cancel": "\u0625\u0644\u063a\u0627\u0621",
                                "av.account.favorites.modal.delete-ad-success.title": "\u062a\u0645 \u0627\u0644\u062d\u0630\u0641!",
                                "av.account.favorites.modal.delete-ad-success.text": "\u062a\u0645 \u062d\u0630\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0628\u0646\u062c\u0627\u062d \u0645\u0646 \u0644\u0627\u0626\u062d\u062a\u0643 \u0627\u0644\u0645\u0641\u0636\u0644\u0629",
                                "av.account.favorites.modal.delete-ad-success.btn": "\u062d\u0633\u0646\u0627",
                                "av.account.favorites.modal.delete-ad-error.title": "\u0639\u0630\u0631\u0627...",
                                "av.account.favorites.modal.delete-ad-error.text": "\u0647\u0646\u0627\u0643 \u062e\u0637\u0623 \u0645\u0627 !",
                                "av.account.favorites.modal.delete-search-success.text": "\u062a\u0645 \u062d\u0630\u0641 \u0627\u0644\u0628\u062d\u062b \u0628\u0646\u062c\u0627\u062d \u0645\u0646 \u0644\u0627\u0626\u062d\u062a\u0643 \u0627\u0644\u0645\u0641\u0636\u0644\u0629",
                                "av.account.stats.today": "\u0627\u0644\u064a\u0648\u0645",
                                "av.account.stats.bi-weekly": "14 \u064a\u0648\u0645\u064b\u0627 \u0627\u0644\u0645\u0627\u0636\u064a\u0629",
                                "av.account.stats.monthly": "30 \u064a\u0648\u0645\u064b\u0627 \u0627\u0644\u0645\u0627\u0636\u064a\u0629",
                                "av.account.stats.15-days": "15 \u064a\u0648\u0645\u064b\u0627 \u0627\u0644\u0645\u0627\u0636\u064a\u0629",
                                "av.account.stats.weekly": " 7 \u0623\u064a\u0627\u0645 \u0627\u0644\u0645\u0627\u0636\u064a\u0629",
                                "av.account.stats.all-time": "\u0643\u0644 \u0627\u0644\u0648\u0642\u062a",
                                "av.account.stats.custom-range": "\u062a\u062d\u062f\u064a\u062f \u0627\u0644\u0645\u062f\u0629",
                                "av.account.stats.calendar.apply": "\u062a\u0623\u0643\u064a\u062f",
                                "av.account.stats.calendar.cancel": "\u0645\u0633\u062d",
                                "av.account.stats.calendar.from": "D\xe9marrer",
                                "av.account.stats.calendar.to": "Finir",
                                "av.account.stats.leads": "\u0627\u0644\u0645\u0633\u062a\u0639\u0645\u0644\u064a\u0646 \u0627\u0644\u0645\u0647\u062a\u0645\u064a\u0646 \u0628\u0625\u0639\u0627\u0644\u0646\u0643",
                                "av.account.stats.leads.short": "\u0645\u0647\u062a\u0645",
                                "av.account.stats.vues": "\u0639\u062f\u062f \u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0627\u062a \u0644\u0625\u0639\u0644\u0627\u0646\u0643",
                                "av.account.stats.calls": "\u0646\u064a\u0629 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0648\u0627\u0644\u0631\u0633\u0627\u0626\u0644 \u0627\u0644\u0642\u0635\u064a\u0631\u0629",
                                "av.account.stats.chat": "\u062f\u0631\u062f\u0634\u0629",
                                "av.account.stats.bump": "\u062a\u062c\u062f\u064a\u062f\u0627\u062a \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a",
                                "av.account.stats.ad.highlight": "\u062a\u0637\u0628\u064a\u0642 \u062e\u0627\u0635\u064a\u0629 \u0625\u0639\u0644\u0627\u0646 \u0645\u062a\u0623\u0644\u0642",
                                "av.account.stats.ad.gallery": "\u062a\u0637\u0628\u064a\u0642 \u062e\u0627\u0635\u064a\u0629 \u0625\u0639\u0644\u0627\u0646 \u0645\u0645\u064a\u0632",
                                "av.account.stats.ad.published": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u0646\u0634\u0648\u0631\u0629",
                                "av.account.stats.ad.deleted": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062d\u062f\u0648\u0641\u0629",
                                "av.account.stats.calls.short": "\u0627\u0644\u0645\u0643\u0627\u0644\u0645\u0627\u062a",
                                "av.account.stats.views": "\u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0627\u062a",
                                "av.account.stats.messages": "\u0631\u0633\u0627\u0626\u0644 \u0648\u0648\u0627\u062a\u0633 \u0627\u0628",
                                "av.account.stats.messages.short": "\u0631\u0633\u0627\u0626\u0644",
                                "av.account.stats.calls-intentions": "\u0646\u064a\u0629 \u0627\u0644\u0627\u062a\u0635\u0627\u0644",
                                "av.account.stats.vas-consumption": "\u0627\u0633\u062a\u0647\u0644\u0627\u0643 \u0627\u0644\u062d\u0632\u0645",
                                "av.account.stats.ad.active": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u0639\u0627\u0644\u0629",
                                "av.account.shop.banner.points": "\u0631\u0635\u064a\u062f \u0627\u0644\u0646\u0642\u0637",
                                "av.account.shop.banner.expiration.points": "\u0627\u0646\u062a\u0647\u0627\u0621 \u0635\u0644\u0627\u062d\u064a\u0629 \u0627\u0644\u0631\u0635\u064a\u062f",
                                "av.account.shop.banner.expiration.shop": "\u0627\u0646\u062a\u0647\u0627\u0621 \u0635\u0644\u0627\u062d\u064a\u0629 \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.account.shop.banner.redirection.message": "Cliquez ici pour acc\xe9der \xe0 votre magasin",
                                "av.account.shop.banner.points.balance": "\u0631\u0635\u064a\u062f \u0627\u0644\u0646\u0642\u0637",
                                "av.account.shop.banner.points-word": "\u0646\u0642\u0637\u0629",
                                "av.account.shop.banner.avitoken.balance": "\u0631\u0635\u064a\u062f \u0623\u0641\u064a\u062a\u0648\u0643\u064a\u0646",
                                "av.account.shop.banner.avitoken-word": "\u0623\u0641\u064a\u062a\u0648\u0643\u064a\u0646",
                                "av.account.shop.banner.membership": "\u0646\u0648\u0639 \u0627\u0644\u0627\u0634\u062a\u0631\u0627\u0643",
                                "av.account.shop.banner.expiration.balance": "\u0627\u0646\u062a\u0647\u0627\u0621 \u0635\u0644\u0627\u062d\u064a\u0629 \u0627\u0644\u0631\u0635\u064a\u062f",
                                "av.account.shop.banner.creation.shop": "\u0625\u0646\u0634\u0627\u0621 \u0645\u062a\u062c\u0631",
                                "av.account.help.rejected": "Les annonces non conformes au r\xe8glement ne sont pas accept\xe9es",
                                "av.account.help.pending-payment": "Les annonces en attente de paiement seront publi\xe9es une fois votre paiement est effectu\xe9",
                                "av.account.help.pending-moderation": "Les annonces en cours de mod\xe9ration sont actives dans un d\xe9lai maximum de 60 minutes",
                                "av.account.ads.refusal-reason": "\u0633\u0628\u0628 \u0627\u0644\u0631\u0641\u0636 :",
                                "av.account.listing.notes.pending-review.title": "\u0627\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u064a \u0627\u0644\u0645\u0631\u0627\u062c\u0639\u0629",
                                "av.account.listing.notes.pending-review.message": "\u0645\u062a\u0648\u0633\u0637 \u200b\u200b\u0648\u0642\u062a \u0645\u0631\u0627\u062c\u0639\u0629 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0647\u0648 \u0633\u0627\u0639\u0629 \u0648\u0627\u062d\u062f\u0629 \u060c \u0625\u0630\u0627 \u0627\u0633\u062a\u0645\u0631 \u0638\u0647\u0648\u0631 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0641\u064a \u0647\u0630\u0647 \u0627\u0644\u0628\u0648\u0627\u0628\u0629  \u0628\u0639\u062f \u0647\u0630\u0627 \u0627\u0644\u0648\u0642\u062a \u060c \u0641\u0644\u0627 \u062a\u062a\u0631\u062f\u062f \u0641\u064a \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u062e\u062f\u0645\u0629 \u0627\u0644\u0639\u0645\u0644\u0627\u0621.",
                                "av.account.listing.notes.refused.title": "\u0627\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u0631\u0641\u0648\u0636\u0629",
                                "av.account.listing.notes.refused.message": "\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0628\u0631\u064a\u062f \u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u062a\u0648\u0636\u064a\u062d\u064a \u0639\u0646 \u0633\u0628\u0628 \u0631\u0641\u0636 \u0625\u0639\u0644\u0627\u0646\u0643 \u0625\u0644\u0649 \u0639\u0646\u0648\u0627\u0646 \u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a.",
                                "av.account.listing.notes.refused.more-info": "\u0644\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u062d\u0648\u0644 \u0642\u0648\u0627\u0639\u062f \u0627\u0644\u0646\u0634\u0631 \u060c \u064a\u0645\u0643\u0646\u0643 \u0623\u064a\u0636\u064b\u0627 \u0627\u0644\u0631\u062c\u0648\u0639 \u0625\u0644\u0649 ",
                                "av.account.listing.notes.refused.help-center": "\u0645\u0631\u0643\u0632 \u0627\u0644\u0645\u0633\u0627\u0639\u062f\u0629 \u0627\u0644\u062e\u0627\u0635 \u0628\u0646\u0627",
                                "av.account.listing.notes.refused.help-center.phone": " \u0623\u0648 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u062e\u062f\u0645\u0629 \u0627\u0644\u0632\u0628\u0646\u0627\u0621 \u0639\u0644\u0649 \u0627\u0644\u0647\u0627\u062a\u0641 0520428686 / ",
                                "av.account.listing.notes.refused.help-center.chat": "\u0627\u0644\u062a\u062d\u062f\u062b \u0645\u0628\u0627\u0634\u0631\u0629 \u0625\u0644\u0649 \u0623\u062d\u062f \u0639\u0645\u0644\u0627\u0626\u0646\u0627",
                                "av.account.listing.notes.deactivated.title": "\u0627\u0639\u0644\u0627\u0646\u0627\u062a \u063a\u064a\u0631 \u0641\u0639\u0627\u0644\u0629",
                                "av.account.listing.notes.deactivated.message": "\u0644\u0627 \u064a\u0645\u0643\u0646 \u062d\u0630\u0641 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0627\u0644\u0645\u0639\u0637\u0644 \u0628\u0627\u0644\u0643\u0627\u0645\u0644 \u0625\u0644\u0627 \u0628\u0639\u062f 7 \u0623\u064a\u0627\u0645 \u0645\u0646 \u0625\u0644\u063a\u0627\u0621 \u062a\u0646\u0634\u064a\u0637\u0647",
                                "av.account.listing.notes.deleted.title": "\u0627\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u062d\u0630\u0648\u0641\u0629",
                                "av.account.listing.notes.deleted.message": "\u0644\u0627 \u064a\u0645\u0643\u0646 \u0625\u0639\u0627\u062f\u0629 \u062a\u0646\u0634\u064a\u0637 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062d\u0630\u0648\u0641\u0629. \u0648\u0645\u0639 \u0630\u0644\u0643 \u060c \u064a\u0645\u0643\u0646\u0643 \u0645\u062a\u0627\u0628\u0639\u0629 \u0625\u062f\u0631\u0627\u062c \u0625\u0639\u0644\u0627\u0646 \u062c\u062f\u064a\u062f \u0628\u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0646\u0641\u0633\u0647\u0627.",
                                "av.account.listing.notes.pending-payment.title": "\u0627\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u064a \u0627\u0646\u062a\u0638\u0627\u0631 \u0627\u0644\u062f\u0641\u0639",
                                "av.account.listing.notes.pending-payment.message": "\u0644\u0644\u062a\u0631\u0648\u064a\u062c \u0644\u0625\u0639\u0644\u0627\u0646\u0643 \u060c \u0627\u062e\u062a\u0631 \u062d\u0632\u0645\u0629 \u062a\u062c\u062f\u064a\u062f \u0628\u0627\u0644\u0625\u0636\u0627\u0641\u0629 \u0625\u0644\u0649 \u0631\u0633\u0648\u0645 \u0627\u0644\u0625\u062f\u0631\u0627\u062c. \u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644 ",
                                "av.account.listing.notes.pending-payment.click-here": "\u0627\u0636\u063a\u0637 \u0647\u0646\u0627",
                                "av.account.settings.notes.notification.verified.email.title": "\u062a\u0639\u062f\u064a\u0644 \u0625\u0634\u0639\u0627\u0631 \u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.account.settings.notes.notification.verified.email.message": "\u062a\u062a\u064a\u062d \u0644\u0643 \u0625\u0634\u0639\u0627\u0631\u0627\u062a \u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0627\u0644\u0628\u0642\u0627\u0621 \u0639\u0644\u0649 \u0627\u0637\u0644\u0627\u0639 \u062f\u0627\u0626\u0645 \u0628\u0627\u0644\u0645\u0633\u062a\u062c\u062f\u0627\u062a\u060c \u0648\u064a\u0645\u0643\u0646\u0643 \u0642\u0628\u0648\u0644 \u0623\u0648 \u0625\u0644\u063a\u0627\u0621 \u0646\u0648\u0639\u064a\u0629 \u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0627\u0644\u0630\u064a \u062a\u0631\u064a\u062f \u062a\u0644\u0642\u064a\u0647.",
                                "av.account.settings.notes.notification.unverified.email.title": "\u062a\u062d\u0642\u0642 \u0645\u0646 \u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.account.settings.notes.notification.unverified.email.message": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0636\u0631\u0648\u0631\u064a \u0644\u062a\u0644\u0642\u064a \u0631\u0633\u0627\u0626\u0644 \u0645\u0646 \u0637\u0631\u0641 \u0627\u0641\u064a\u062a\u0648 \u060c \u0627\u0644\u0645\u0631\u062c\u0648 \u0627\u0644\u062a\u062d\u0642\u0642 \u0645\u0646 \u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0628\u0627\u0644\u0646\u0642\u0631 \u0639\u0644\u0649 ",
                                "av.account.settings.notes.notification.unverified.email.link": "\u0647\u0630\u0627 \u0627\u0627\u0644\u0631\u0627\u0628\u0637",
                                "av.account.shop.onBording.step1.title": "\u0625\u062f\u0627\u0631\u0629 \u0625\u0639\u0644\u0627\u0646\u0643",
                                "av.account.shop.onBording.step1.body": "\u0627\u0646\u0642\u0631 \u0647\u0646\u0627 \u0644\u062a\u0639\u062f\u064a\u0644 \u0623\u0648 \u062d\u0630\u0641 \u0625\u0639\u0644\u0627\u0646\u0643 \u0623\u0648 \u0625\u062f\u0627\u0631\u0629 \u064a\u0648\u0645\u064a\u0629 \u0627\u0644\u062d\u062c\u0632\u2026.",
                                "av.account.shop.onBording.step2.title": "\u062a\u0639\u062f\u064a\u0644\u0627\u062a \u0633\u0631\u064a\u0639\u0629",
                                "av.account.shop.onBording.step2.body": "\u0647\u0646\u0627 \u064a\u0645\u0643\u0646\u0643 \u0627\u0644\u0625\u0637\u0644\u0627\u0639 \u0639\u0644\u0649 \u0625\u0639\u0644\u0627\u0646\u0643, \u062a\u0639\u062f\u064a\u0644\u0647 \u0623\u0648 \u062d\u0630\u0641\u0647.",
                                "av.account.shop.onBording.step3.title": "\u0645\u062a\u062c\u0631\u0643",
                                "av.account.shop.onBording.step3.body": "\u0628\u0627\u0644\u0646\u0642\u0631 \u0639\u0644\u0649 \u0634\u0627\u0631\u062a\u0643 \u060c \u0633\u062a\u062a\u0645\u0643\u0646 \u0645\u0646 \u0627\u0644\u0648\u0644\u0648\u062c \u0625\u0644\u0649 \u0645\u062a\u062c\u0631\u0643.",
                                "av.account.shop.onBording.next": "\u0627\u0644\u062a\u0627\u0644\u064a",
                                "av.oauth.subtitle": "\u064a\u0645\u0643\u0646\u0643  \u0627\u0633\u062a\u0639\u0645\u0627\u0644 \u0627\u0644\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u0633\u0631\u064a\u0639 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u062d\u0633\u0627\u0628\u0643 \u0639\u0644\u0649 Facebook \u0623\u0648 Gmail.",
                                "av.login.error.email": "\u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0627\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u063a\u064a\u0631 \u0635\u062d\u064a\u062d.",
                                "av.login.error.msg1": "\u0639\u0630\u0631\u0627...",
                                "av.login.error.mesg2": "\u062e\u0637\u0623 \u0641\u064a \u0625\u062f\u062e\u0627\u0644 \u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0628\u0631\u064a\u062f\u064a \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631!",
                                "av.login.email.connexion": "\u0633\u062c\u0651\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 \u0639\u0644\u0649 Avito",
                                "av.login.title": "\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 \u0623\u0648 \u0625\u0646\u0634\u0627\u0621 \u062d\u0633\u0627\u0628",
                                "av.login.private.subtitle": "\u0627\u0633\u062a\u062e\u062f\u0645 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641 \u0644\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 \u0628\u0633\u0631\u0639\u0629",
                                "av.login.shop.subtitle": "\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0631\u0642\u0645 \u0647\u0627\u062a\u0641\u0643 \u0623\u0648 \u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.login.shop": "\u0627\u0644\u0627\u0633\u062a\u0645\u0631\u0627\u0631 \u0643\u0645\u062a\u062c\u0631",
                                "av.login.phone_number.label": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.login.email.label": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.login.phone_number.placeholder": "\u0645\u062b\u0627\u0644: 0623321**",
                                "av.login.email.placeholder": "\u0645\u062b\u0627\u0644: user.name@gmail.com",
                                "av.login.password.label": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631",
                                "av.login.password.placeholder": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631",
                                "av.login.shop.title": "\u0633\u062c\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 \u0625\u0644\u0649 \u0645\u062a\u062c\u0631\u0643",
                                "av.login.shop.subTitle": "\u0623\u062f\u062e\u0644 \u0645\u0639\u0644\u0648\u0645\u0627\u062a\u0643 \u0627\u0644\u0634\u062e\u0635\u064a\u0629 \u0623\u062f\u0646\u0627\u0647",
                                "av.login.cta": "\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 ",
                                "av.login.continue": "\u0645\u062a\u0627\u0628\u0639\u0629",
                                "av.login.shop.entrypoint": "\u0623\u0646\u0627 \u0639\u0646\u062f\u064a \u0628\u0648\u062a\u064a\u0643 \u0623\u0641\u064a\u0637\u0648",
                                "av.reset_password.head.title": "\u0625\u0639\u0627\u062f\u0629 \u062a\u0639\u064a\u064a\u0646 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 - Avito.ma",
                                "av.reset_password.form.submit": "\u062d\u062f\u062f \u0643\u0644\u0645\u0629 \u0633\u0631 \u062c\u062f\u064a\u062f\u0629",
                                "av.reset_password.phone_verification.title": "\u0646\u0633\u064a\u062a \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631\u061f",
                                "av.reset_password.phone_verification.subtitle": "\u064a\u0631\u062c\u0649 \u0625\u062f\u062e\u0627\u0644 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641 \u0627\u0644\u0645\u0633\u062c\u0644 \u0628\u062d\u0633\u0627\u0628\u0643.",
                                "av.reset_password.shop.via.email.subtitle": "\u064a\u0631\u062c\u0649 \u0625\u062f\u062e\u0627\u0644 \u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0627\u0644\u062e\u0627\u0635 \u0628\u0643 \u0644\u062a\u062a\u0648\u0635\u0644 \u0628\u0631\u0627\u0628\u0637 \u0625\u0633\u062a\u0639\u0627\u062f\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631.",
                                "av.reset_password.success": "\u0644\u0642\u062f \u062a\u0645 \u062d\u0641\u0638 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0628\u0646\u062c\u0627\u062d",
                                "av.reset_password.reset_password.title": "\u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631 \u0627\u0644\u062c\u062f\u064a\u062f\u0629",
                                "av.reset_password.reset_password.subtitle": "\u0627\u0644\u0645\u0631\u062c\u0648 \u0625\u062f\u062e\u0627\u0644 \u0643\u0644\u0645\u0629 \u0627\u0644\u0633\u0631 \u0627\u0644\u062c\u062f\u064a\u062f\u0629",
                                "av.reset_password.private.name": "\u062d\u0633\u0627\u0628 \u0641\u0631\u062f\u064a",
                                "av.reset_password.shop.name": "\u062d\u0633\u0627\u0628 \u0645\u062a\u062c\u0631",
                                "av.otp.title": "\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0631\u0645\u0632 \u0627\u0644\u062a\u062d\u0642\u0642",
                                "av.otp.subtitle": "\u0623\u062f\u062e\u0644 \u0627\u0644\u0631\u0645\u0632 \u0627\u0644\u0645\u0643\u0648\u0646 \u0645\u0646 6 \u0623\u0631\u0642\u0627\u0645 \u0627\u0644\u0630\u064a \u0623\u0631\u0633\u0644 \u0625\u0644\u0649 ",
                                "av.otp.method": "\u0639\u0644\u0649 \u0627\u0644\u0648\u062a\u0633\u0627\u0628",
                                "av.otp.not_recieved": "\u0644\u0645 \u062a\u062a\u0644\u0642 \u0627\u0644\u0631\u0645\u0632\u061f",
                                "av.otp.empty_code": "\u0627\u0644\u0631\u062c\u0627\u0621 \u0625\u062f\u062e\u0627\u0644 \u0631\u0645\u0632 \u0627\u0644\u062a\u062d\u0642\u0642 \u0623\u0648\u0644\u0627\u064b",
                                "av.otp.resend": "\u0625\u0639\u0627\u062f\u0629 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0645\u0632",
                                "av.otp.resend.cooldown": "\u0625\u0639\u0627\u062f\u0629 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0631\u0645\u0632 \u0641\u064a {{countdown}} \u062f\u0642\u064a\u0642\u0629",
                                "av.otp.resend.success": "\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0631\u0645\u0632 \u0627\u0644\u062a\u062d\u0642\u0642 \u0628\u0646\u062c\u0627\u062d",
                                "av.otp.continue": "\u0627\u0644\u062a\u0627\u0644\u064a",
                                "av.otp.verify": "\u062a\u062d\u0642\u0642",
                                "av.otp.skip.verification": "\u0627\u0644\u0627\u0633\u062a\u0645\u0631\u0627\u0631 \u062f\u0648\u0646 \u0627\u0644\u062a\u062d\u0642\u0642",
                                "av.opt-out.text": "Que pensez-vous du service boutique Avito ",
                                "av.opt-out.btn.yes": "Donner votre avis",
                                "av.opt-out.btn.no": "non",
                                "av.show_number.warning": "\u0644\u0627 \u064a\u062c\u0628 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0646\u0642\u0648\u062f \u0639\u0646 \u0637\u0631\u064a\u0642 \u062a\u062d\u0648\u064a\u0644\u0627\u062a \u0628\u0646\u0643\u064a\u0629 \u0623\u0648 \u0648\u0643\u0627\u0644\u0627\u062a \u062a\u062d\u0648\u064a\u0644 \u0627\u0644\u0623\u0645\u0648\u0627\u0644 \u0639\u0646\u062f \u0634\u0631\u0627\u0621 \u0627\u0644\u0645\u0646\u062a\u0648\u062c\u0627\u062a \u0627\u0644\u0645\u0639\u0631\u0648\u0636\u0629 \u0639\u0644\u0649 \u0627\u0644\u0645\u0648\u0642\u0639.",
                                "av.show_number.cta": "\u0625\u062a\u0635\u0644 \u0628",
                                "av.caution": "\u062a\u062d\u0630\u064a\u0631 !",
                                "av.payment.page.success.title": "Votre paiement a \xe9t\xe9 enregistr\xe9 avec succ\xe8s",
                                "av.payment.page.success.text1": "Vous allez recevoir la confirmation de votre commande par email dans les minutes qui suivent.",
                                "av.payment.page.success.text2": "Si vous ne recevez pas votre email, veuillez dans un premier temps, consulter votre dossier Courrier\n              ind\xe9sirable.",
                                "av.payment.page.failure.title": "Une erreur est survenue",
                                "av.payment.page.failure.text1": "Nous ne pouvons pas finaliser votre paiement.",
                                "av.payment.page.failure.text2": "Nous vous conseillons d'essayer une nouvelle fois, ou de choisir une autre m\xe9thode de paiement.",
                                "av.payment.page.failure.text3": "Si vous rencontrez toujours un soucis, vous pouvez nous contacter pour plus de d\xe9tails.",
                                "av.payment.page.failure.phone": "05 56 43 23 88",
                                "av.payment.page.failure.btn": "reessayer",
                                "av.adNavigation.nextAd": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0627\u0644\u062a\u0627\u0644\u064a",
                                "av.adNavigation.previousAd": "\u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0627\u0644\u0633\u0627\u0628\u0642",
                                "av.adNavigation.results": "\u0627\u0644\u0646\u062a\u0627\u0626\u062c",
                                "av.adActionButton.saveAd": "\u0627\u062d\u0641\u0638 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.adActionButton.unSaveAd": "\u0625\u0632\u0627\u0644\u0629 \u0645\u0646 \u0627\u0644\u0645\u0641\u0636\u0644\u0629",
                                "av.adactionButton.shareAd": "\u0634\u0627\u0631\u0643 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.adview.nextImage": "\u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u062a\u0627\u0644\u064a\u0629",
                                "av.adview.prevImage": "\u0627\u0644\u0635\u0648\u0631\u0629 \u0627\u0644\u0633\u0627\u0628\u0642\u0629",
                                "av.saveAd.success": "\u0625\u0639\u0644\u0627\u0646 \u0645\u062d\u0641\u0648\u0638",
                                "av.saveAd.error.adNotFound": "Annonce introuvable",
                                "av.saveAd.error.adNotFound.description": "Short description about the error encountered and the where to go from here.You know what I mean come on.Short description about the error encountered and the where to go from here. You know what I mean come on.Short description about the error encountered and the where to go from here. You know what I mean come on.Short description about the error encountered and the where to go from here. You know what I mean come on.",
                                "av.saveAd.error.sessionExpired": "Votre session a expire",
                                "av.saveAd.error.internalError": "\u064a\u0631\u062c\u0649 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0645\u0631\u0629 \u0623\u062e\u0631\u0649",
                                "av.unsaveAd.success": "\u062a\u0645 \u062d\u0630\u0641 \u0627\u0644\u062d\u0641\u0638",
                                "av.unsaveAd.error.adNotFound": "Annonce introuvable",
                                "av.unsaveAd.error.sessionExpired": "Votre session a expire",
                                "av.unsaveAd.error.internalError": "\u064a\u0631\u062c\u0649 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0645\u0631\u0629 \u0623\u062e\u0631\u0649",
                                "av.shareAd": "\u0634\u0627\u0631\u0643",
                                "av.shareAd.modal": "\u0634\u0627\u0631\u0643 \u0639\u0628\u0631 ...",
                                "av.copyLink": "\u0627\u0646\u0633\u062e \u0627\u0644\u0631\u0627\u0628\u0637",
                                "av.copyLink.success": "\u062a\u0645 \u0646\u0633\u062e \u0627\u0644\u0631\u0627\u0628\u0637",
                                "av.adManagement.manage": "G\xe9rer",
                                "av.adManagement.block.title": "\u0628\u064a\u0639 \u0628\u0633\u0631\u0639\u0629",
                                "av.adManagement.block.message": "\u0628\u0639 \u0641\u064a \u0623\u0633\u0631\u0639 \u0648\u0642\u062a \u0645\u0645\u0643\u0646 \u0645\u0646 \u062e\u0644\u0627\u0644 \u062a\u0639\u0632\u064a\u0632 \u0625\u0639\u0644\u0627\u0646\u0643",
                                "av.reportForm.cancel.report": "\u0627\u0644\u0625\u0628\u0644\u0627\u063a \u0639\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.reportForm.title": "\u0645\u0627 \u0647\u0648 \u0627\u0644\u0645\u0634\u0643\u0644 \u0641\u064a \u0647\u0630\u0627 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u061f",
                                "av.reportForm.select.placeholder": "\u062d\u062f\u062f",
                                "av.reportForm.select.label": "\u062d\u062f\u062f \u0646\u0648\u0639 \u0627\u0644\u0625\u0633\u0627\u0621\u0629",
                                "av.reportForm.message.label": "\u0627\u0644\u0648\u0635\u0641",
                                "av.reportForm.success": "!\u062a\u0645 \u0627\u0644\u0625\u0628\u0644\u0627\u063a \u0639\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646 \u0628\u0646\u062c\u0627\u062d \u060c \u0634\u0643\u0631\u0627",
                                "av.abuseType.fraud": "\u0627\u062d\u062a\u064a\u0627\u0644",
                                "av.abuseType.duplicate": "\u062a\u0643\u0631\u0627\u0631",
                                "av.abuseType.wrong_cat": "\u062e\u0637\u0623 \u0641\u064a \u0627\u0644\u0641\u0626\u0629",
                                "av.abuseType.wrong_img": "\u0635\u0648\u0631\u0629 \u0633\u064a\u0626\u0629",
                                "av.abuseType.fake_number": "\u0627\u0644\u062a\u0644\u064a\u0641\u0648\u0646 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d",
                                "av.abuseType.wrong_price": "\u0633\u0639\u0631 \u062e\u0627\u0637\u0626",
                                "av.abuseType.sold": "\u0645\u0646\u062a\u0648\u062c \u0628\u064a\u0639 \u0645\u0633\u0628\u0642\u0627",
                                "av.adview.title.default": "{{subject}} | {{category}} \u0628 {{city}} | Avito.ma",
                                "av.adview.title.auto": "{{subject}} | {{category}} \u0628 {{city}} | Avito.ma -- {{listId}}",
                                "av.adview.description.default": "{{description}} - {{verticalPrefix}} \u0625\u0639\u0644\u0627\u0646 {{category}} \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 \u0628\u0623\u0641\u0636\u0644 \u0627\u0644\u0623\u0633\u0639\u0627\u0631 \u0639\u0644\u0649 Avito  \u0627\u0644\u0645\u0646\u0635\u0629 \u0631\u0642\u0645 1 \u0644\u0644\u0628\u064a\u0639 \u0648 \u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0644\u0649 \u0627\u0644\u0627\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.adview.contactSeller": "\u062a\u0635\u0641\u062d \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.adview.viewUnits": "\u0639\u0631\u0636 \u0627\u0644\u0648\u062d\u062f\u0627\u062a",
                                "av.adview.map.button": "\u0627\u0646\u0638\u0631 \u0639\u0644\u0649 \u0627\u0644\u062e\u0631\u064a\u0637\u0629",
                                "av.adview.map.title": "\u0645\u0648\u0642\u0639 \u0627\u0644\u0639\u0642\u0627\u0631",
                                "av.extraParams.title": "\u062a\u062c\u0647\u064a\u0632\u0627\u062a",
                                "av.adview.isPhoneVerified": "\u0631\u0642\u0645 \u0645\u062a\u062d\u0642\u0642 \u0645\u0646\u0647",
                                "av.adview.seller.cta.contactSeller": "\u062a\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0628\u0627\u0626\u0639",
                                "av.adview.seller.cta.applyForJobOffer": "\u0648\u0636\u0639 \u0637\u0644\u0628",
                                "av.adview.seller.cta.shortApplyForJobOffer": "\u062a\u0631\u0634\u062d",
                                "av.adview.seller.cta.askForPrice": "\u0625\u0633\u0623\u0644 \u0639\u0646 \u0627\u0644\u062b\u0645\u0646",
                                "av.adview.seller.cta.shortAskForPrice": "\u0627\u0644\u062b\u0645\u0646 \u061f",
                                "av.adview.seller.cta.whatsapp.messageText": "{{adUrl}} :\u0623\u0646\u0627 \u0623\u062a\u0635\u0644 \u0628\u0643 \u0628\u062e\u0635\u0648\u0635 \u0647\u0630\u0627 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.adview.cta.boost": "\u062a\u062c\u062f\u064a\u062f \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.adview.cta.ncContact": "\u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u064a",
                                "av.nc.badge.text": "\u0645\u0634\u0631\u0648\u0639 \u062c\u062f\u064a\u062f",
                                "av.adview.scam.disclaimer": "\u0644\u0627 \u064a\u062c\u0628 \u0623\u0628\u062f\u0627\u064b \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0645\u0627\u0644 \u0645\u0642\u062f\u0645\u0627\u064b \u0644\u0644\u0628\u0627\u0626\u0639 \u0639\u0646 \u0637\u0631\u064a\u0642 \u0627\u0644\u062a\u062d\u0648\u064a\u0644 \u0627\u0644\u0645\u0635\u0631\u0641\u064a \u0623\u0648 \u0648\u0643\u0627\u0644\u0627\u062a \u0627\u0644\u062a\u062d\u0648\u064a\u0644.",
                                "av.adview.buyer.card.title": "\u0627\u0637\u0644\u0628 \u0641\u062d\u0635 \u0647\u0630\u0647 \u0627\u0644\u0633\u064a\u0627\u0631\u0629",
                                "av.adview.buyer.card.description": "\u0627\u0634\u062a\u0631\u0650 \u0633\u064a\u0627\u0631\u062a\u0643 \u0645\u0641\u062d\u0648\u0635\u0629 \u0645\u0646 \u0642\u0628\u0644 \u062e\u0628\u0631\u0627\u0626\u0646\u0627 (\u0623\u0643\u062b\u0631 \u0645\u0646 100 \u0646\u0642\u0637\u0629 \u0641\u062d\u0635)",
                                "av.adview.buyer.card.cta": "\u0627\u0637\u0644\u0628 \u0627\u0644\u0641\u062d\u0635 \u0627\u0644\u0622\u0646",
                                "ad.view.buyer.form_modal.title": "\u0637\u0644\u0628 \u062e\u0628\u0631\u0629 \u0644\u0633\u064a\u0627\u0631\u0629",
                                "ad.view.buyer.form_modal.description": "\u0647\u0630\u0647 \u0627\u0644\u062e\u062f\u0645\u0629 \u0645\u0642\u062f\u0645\u0629 \u0645\u0646 \u0641\u0631\u064a\u0642 Avito \u0648\u0645\u064f\u062a\u0627\u062d\u0629 \u062d\u0627\u0644\u064a\u0627\u064b \u0641\u064a \u0645\u062f\u064a\u0646\u0629 \u0627\u0644\u062f\u0627\u0631 \u0627\u0644\u0628\u064a\u0636\u0627\u0621 \u0641\u0642\u0637.",
                                "ad.view.buyer.form_modal.submition": "\u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0637\u0644\u0628",
                                "ad.view.buyer.form_modal.submition.success": "!\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628\u0643 \u0628\u0646\u062c\u0627\u062d",
                                "ad.view.buyer.car_inspected.card.title": "(\u0623\u0643\u062b\u0631 \u0645\u0646 100 \u0646\u0642\u0637\u0629 \u0641\u062d\u0635) \u0633\u064a\u0627\u0631\u0627\u062a \u0645\u0641\u062d\u0648\u0635\u0629",
                                "ad.view.buyer.car_inspected.card.description": "\u062a\u0627\u0631\u064a\u062e \u0627\u0644\u0641\u062d\u0635:",
                                "ad.view.buyer.car_inspected.view.cta": "\u0639\u0631\u0636 \u0627\u0644\u062a\u0642\u0631\u064a\u0631",
                                "ad.view.buyer.car_inspected.download.cta": "\u062a\u0646\u0632\u064a\u0644 \u0627\u0644\u062a\u0642\u0631\u064a\u0631",
                                "ad.view.buyer.car_inspected.download.error": "\u0641\u0634\u0644 \u0641\u064a \u062a\u0646\u0632\u064a\u0644 \u0627\u0644\u062a\u0642\u0631\u064a\u0631. \u0627\u0644\u0631\u062c\u0627\u0621 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0645\u0631\u0629 \u0623\u062e\u0631\u0649.",
                                "ad.view.car_inspected.label": "\u0633\u064a\u0627\u0631\u0629 \u0645\u0641\u062d\u0648\u0635\u0629",
                                "ad.view.car_inspected.tooltip.text": "\u062a\u0642\u0631\u064a\u0631 \u0627\u0644\u0641\u062d\u0635 \u0627\u0644\u062a\u0642\u0646\u064a \u0645\u062a\u0648\u0641\u0631",
                                "av.suggestions.rec.heading": "\u0647\u0630\u0647 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0642\u062f \u062a\u0647\u0645\u0643",
                                "av.suggestions.mau.heading": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0623\u062e\u0631\u0649 \u0644\u0647\u0630\u0627 \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.suggestions.mau.msite.heading": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0623\u062e\u0631\u0649",
                                "av.suggestions.mau.heading.see-more": "\u0627\u0644\u0645\u0632\u064a\u062f",
                                "av.suggestions.mau.see-more.title": "\u0627\u0643\u062a\u0634\u0641 \u0627\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a",
                                "av.premium.ads.rec.heading": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u062a\u0645\u064a\u0632\u0629",
                                "av.premium.ads.rec.heading.badge": "\u0625\u0639\u0644\u0627\u0646 \u0645\u0645\u062a\u0627\u0632",
                                "av.loanSimulator.amount": "\u0645\u0628\u0644\u063a \u0627\u0644\u0627\u0626\u062a\u0645\u0627\u0646",
                                "av.loanSimulator.monthly": "\u0628\u062f\u0627\u064a\u0629 \u0645\u0646",
                                "av.loanSimulator.period": "\u0641\u062a\u0631\u0629 \u0642\u0631\u0636",
                                "av.loanSimulator.poweredBy": "\u0645\u0634\u063a\u0644 \u0628\u0648\u0627\u0633\u0637\u0629 ",
                                "av.loanSimulator.legalNotice": "\u0639\u0631\u0636 \u0627\u0644\u0642\u0631\u0636 \u0627\u0644\u0634\u062e\u0635\u064a (\u0628\u0627\u0633\u062a\u062b\u0646\u0627\u0621 \u0627\u0633\u062a\u0631\u062f\u0627\u062f \u0627\u0644\u0627\u0626\u062a\u0645\u0627\u0646). \u0627\u0644\u0635\u0644\u0627\u062d\u064a\u0629 30.06.2022 \u0645\u062d\u062c\u0648\u0632\u0629 \u0644\u0639\u0645\u0644\u0627\u0621 \u0627\u0644\u062e\u062f\u0645\u0629 \u0627\u0644\u0645\u062f\u0646\u064a\u0629 \u0627\u0644\u062c\u062f\u062f \u0641\u064a \u0627\u0644\u0642\u0637\u0627\u0639 \u0627\u0644\u0639\u0627\u0645 \u0623\u0648 \u0627\u0644\u0639\u0627\u0645\u0644\u064a\u0646 \u0641\u064a \u0627\u0644\u0642\u0637\u0627\u0639 \u0627\u0644\u062e\u0627\u0635 \u060c \u0645\u0639 \u0645\u0631\u0627\u0639\u0627\u0629 \u0627\u0644\u0634\u0631\u0648\u0637 \u0627\u0644\u062e\u0627\u0636\u0639\u0629 \u0644\u0642\u0628\u0648\u0644 \u0627\u0644\u0645\u0644\u0641 \u0648\u0641\u0642 \u0627\u0644\u0642\u0648\u0627\u0639\u062f \u0627\u0644\u0627\u062d\u062a\u0631\u0627\u0632\u064a\u0629 \u0627\u0644\u0645\u0639\u0645\u0648\u0644 \u0628\u0647\u0627. \u0644\u0645\u0648\u0638\u0641\u064a \u0627\u0644\u062e\u062f\u0645\u0629 \u0627\u0644\u0645\u062f\u0646\u064a\u0629 \u0641\u064a \u0627\u0644\u0642\u0637\u0627\u0639 \u0627\u0644\u0639\u0627\u0645: 80000 \u062f\u0631\u0647\u0645 / 68 \u0634\u0647\u0631\u064b\u0627 \u060c \u0627\u0644\u062f\u0641\u0639\u0629 \u0627\u0644\u0634\u0647\u0631\u064a\u0629 \u0644\u0645\u0646 \u0647\u0645 \u062f\u0648\u0646 \u0627\u0644\u0633\u062a\u064a\u0646\u064a\u0627\u062a: 1392.57 \u062f\u0631\u0647\u0645\u064b\u0627 \u0634\u0627\u0645\u0644\u064b\u0627 \u0627\u0644\u0636\u0631\u0627\u0626\u0628 \u063a\u064a\u0631 \u0634\u0627\u0645\u0644\u0629 \u0627\u0644\u062a\u0643\u0627\u0644\u064a\u0641: \u0627\u0644\u062a\u0623\u0645\u064a\u0646 (80 \u0645\u0644\u064a\u0648\u0646 \u062f\u0631\u0647\u0645). \u0627\u0644\u062e\u0635\u0645 \u0627\u0644\u0645\u0628\u0627\u0634\u0631 DDP (7.7 \u062f\u0631\u0647\u0645). \u0631\u0633\u0648\u0645 \u0625\u062f\u0627\u0631\u064a\u0629 \u0645\u0633\u0627\u0639\u062f\u0629 \u0634\u0647\u0631\u064a\u0629 (15.66 \u0645\u0644\u064a\u0648\u0646 \u062f\u0631\u0647\u0645): 0 \u062f\u0631\u0647\u0645 / \u0634\u0627\u0645\u0644\u0629 \u0631\u0633\u0648\u0645 \u0627\u0644\u0637\u0627\u0628\u0639 \u0627\u0644\u0636\u0631\u064a\u0628\u064a (20 \u062f\u0631\u0647\u0645) \u060c \u0627\u0626\u062a\u0645\u0627\u0646 \u0645\u0643\u062a\u0628 (17.60 \u0645\u0644\u064a\u0648\u0646 \u062f\u0631\u0647\u0645) \u0631\u0633\u0648\u0645 \u062d\u062c\u0632 (88 \u0645\u0644\u064a\u0648\u0646 \u062f\u0631\u0647\u0645). \u0627\u0644\u062a\u0643\u0644\u0641\u0629 \u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a\u0629 \u0644\u0644\u0627\u0626\u062a\u0645\u0627\u0646: 21848.6 \u062f\u0631\u0647\u0645 / \u0634\u0627\u0645\u0644 \u0627\u0644\u0636\u0631\u064a\u0628\u0629. \u062a\u064a \u0625\u064a \u062c\u064a \u0625\u062a\u0634 \u062a\u064a 5.5\u066a. \u0644\u0644\u0639\u0627\u0645\u0644\u064a\u0646 \u0641\u064a \u0627\u0644\u0642\u0637\u0627\u0639 \u0627\u0644\u062e\u0627\u0635: 80000 \u062f\u0631\u0647\u0645 / 68 \u0634\u0647\u0631\u064b\u0627 \u060c \u0627\u0644\u062f\u0641\u0639\u0629 \u0627\u0644\u0634\u0647\u0631\u064a\u0629 \u0644\u0645\u0646 \u0647\u0645 \u062f\u0648\u0646 \u0627\u0644\u0633\u062a\u064a\u0646\u064a\u0627\u062a: 1498.30 \u062f\u0631\u0647\u0645\u064b\u0627 \u0634\u0627\u0645\u0644\u0627\u064b \u0627\u0644\u0636\u0631\u0627\u0626\u0628 \u063a\u064a\u0631 \u0634\u0627\u0645\u0644\u0629 \u0627\u0644\u062a\u0643\u0627\u0644\u064a\u0641: \u0627\u0644\u062a\u0623\u0645\u064a\u0646 (80 \u0645\u0644\u064a\u0648\u0646 \u062f\u0631\u0647\u0645) \u060c \u0627\u0644\u0645\u0633\u0627\u0639\u062f\u0629 \u0627\u0644\u0633\u0646\u0648\u064a\u0629 (187.86 \u062f\u0631\u0647\u0645) \u0631\u0633\u0648\u0645 \u0627\u0644\u0637\u0644\u0628: 0 \u062f\u0631\u0647\u0645 / \u0634\u0627\u0645\u0644 \u0627\u0644\u0637\u0627\u0628\u0639 \u0627\u0644\u0636\u0631\u064a\u0628\u064a (20 \u062f\u0631\u0647\u0645) \u060c \u0642\u0631\u0648\u0636 \u0645\u0643\u062a\u0628\u064a\u0629 (17.60 \u0645\u0644\u064a\u0648\u0646 \u062f\u0631\u0647\u0645). \u0627\u0644\u062a\u0643\u0644\u0641\u0629 \u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a\u0629 \u0644\u0644\u0627\u0626\u062a\u0645\u0627\u0646: 28426.77 \u062f\u0631\u0647\u0645 / \u0634\u0627\u0645\u0644 \u0627\u0644\u0636\u0631\u064a\u0628\u0629. TEG HT 8\u066a (\u0636\u0631\u064a\u0628\u0629 \u0627\u0644\u0642\u064a\u0645\u0629 \u0627\u0644\u0645\u0636\u0627\u0641\u0629 10\u066a).",
                                "av.loanSimulator.brand": "\u0648\u0641\u0627\u0633\u0644\u0641",
                                "av.loanSimulator.re.price": "\u0633\u0639\u0631 \u0627\u0644\u0639\u0642\u0627\u0631",
                                "av.loanSimulator.auto.price": "\u0633\u0639\u0631 \u0627\u0644\u0633\u064a\u0627\u0631\u0629",
                                "av.loanSimulator.title": "\u062d\u0627\u0633\u0628\u0629 \u0627\u0644\u0642\u0631\u0636",
                                "av.loanSimulator.cta": "\u0627\u062d\u0635\u0644 \u0639\u0644\u0649 \u0645\u0648\u0627\u0641\u0642\u062a\u0643 \u0627\u0644\u0645\u0633\u0628\u0642\u0629",
                                "av.loanSimulator.poweredBy.brand": "\u0623\u0641\u064a\u062a\u0648",
                                "av.loanSimulator.advance": "\u0627\u0644\u0645\u0633\u0627\u0647\u0645\u0629 \u0627\u0644\u0634\u062e\u0635\u064a\u0629",
                                "av.loanSimulator.term": "\u0645\u062f\u0629 \u0627\u0644\u0642\u0631\u0636",
                                "av.loanSimulator.monthlyPayment": "\u0634\u0647\u0631\u064a\u0627\u064b",
                                "av.loanSimulator.advance.errorMessage": "\u064a\u062c\u0628 \u0623\u0644\u0627 \u064a\u062a\u062c\u0627\u0648\u0632 \u0645\u0628\u0644\u063a \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u0629 \u0627\u0644\u0634\u062e\u0635\u064a\u0629 \u0627\u0644\u0633\u0639\u0631",
                                "av.loanSimulator.advance.negativeErrorMessage": "\u0644\u0627 \u064a\u0645\u0643\u0646 \u0623\u0646 \u064a\u0643\u0648\u0646 \u0645\u0628\u0644\u063a \u0627\u0644\u0645\u0633\u0627\u0647\u0645\u0629 \u0627\u0644\u0634\u062e\u0635\u064a\u0629 \u0633\u0627\u0644\u0628\u0627\u064b",
                                "av.loanSimulator.disclaimer": "\u0647\u0630\u0647 \u0627\u0644\u0645\u062d\u0627\u0643\u0627\u0629 \u0647\u064a \u0644\u0623\u063a\u0631\u0627\u0636 \u0625\u0631\u0634\u0627\u062f\u064a\u0629 \u0648\u063a\u064a\u0631 \u0645\u0644\u0632\u0645\u0629. \u064a\u0645\u0643\u0646\u0643 \u0627\u0644\u0627\u0633\u062a\u0641\u0627\u062f\u0629 \u0645\u0646 \u0634\u0631\u0648\u0637 \u062a\u0641\u0636\u064a\u0644\u064a\u0629 \u062d\u0633\u0628 \u0645\u0644\u0641\u0643 \u0627\u0644\u0634\u062e\u0635\u064a.",
                                "av.creditCalculatorBanner.title.auto": "\u0645\u0648\u0644 \u0633\u064a\u0627\u0631\u062a\u0643",
                                "av.creditCalculatorBanner.title.realEstate": "\u0645\u0648\u0644 \u0639\u0642\u0627\u0631\u0643",
                                "av.creditCalculatorBanner.priceLabel": "\u0627\u0628\u062a\u062f\u0627\u0621\u064b \u0645\u0646",
                                "av.creditCalculatorBanner.cta": "\u0645\u062d\u0627\u0643\u0627\u0629",
                                "av.preApprovedCredit.modal.title": "\u0627\u062d\u0635\u0644 \u0639\u0644\u0649 \u0627\u0644\u0645\u0648\u0627\u0641\u0642\u0629 \u0627\u0644\u0645\u0628\u062f\u0626\u064a\u0629 \u0639\u0644\u0649 \u0627\u0644\u062a\u0645\u0648\u064a\u0644",
                                "av.preApprovedCredit.modal.auto.title": "\u0637\u0644\u0628 \u0645\u0643\u0627\u0644\u0645\u0629",
                                "av.preApprovedCredit.modal.auto.subtitle": "\u0627\u0645\u0644\u0623 \u0627\u0644\u0627\u0633\u062a\u0645\u0627\u0631\u0629 \u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a",
                                "av.preApprovedCredit.form.borrowerProfile.title": "\u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u0642\u062a\u0631\u0636",
                                "av.preApprovedCredit.form.profession.placeholder": "\u0627\u0644\u0645\u0647\u0646\u0629",
                                "av.preApprovedCredit.form.creditAmount.placeholder": "\u0645\u0628\u0644\u063a \u0627\u0644\u0627\u0626\u062a\u0645\u0627\u0646",
                                "av.preApprovedCredit.form.financingType.placeholder": "\u0637\u0631\u064a\u0642\u0629 \u0627\u0644\u062a\u0645\u0648\u064a\u0644",
                                "av.preApprovedCredit.form.submit.button": "\u0627\u062d\u0635\u0644 \u0639\u0644\u0649 \u0645\u0648\u0627\u0641\u0642\u062a\u064a \u0627\u0644\u0645\u0628\u062f\u0626\u064a\u0629",
                                "av.preApprovedCredit.form.submit.success": "\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628\u0643 \u0628\u0646\u062c\u0627\u062d",
                                "av.preApprovedCredit.form.submit.error": "\u062d\u062f\u062b \u062e\u0637\u0623 \u0623\u062b\u0646\u0627\u0621 \u062a\u0642\u062f\u064a\u0645 \u0627\u0644\u0637\u0644\u0628",
                                "av.preApprovedCredit.form.validation.age.invalid": "\u064a\u0631\u062c\u0649 \u0625\u062f\u062e\u0627\u0644 \u0639\u0645\u0631 \u0635\u0627\u0644\u062d",
                                "av.preApprovedCredit.form.validation.age.min": "\u0627\u0644\u062d\u062f \u0627\u0644\u0623\u062f\u0646\u0649 \u0644\u0644\u0639\u0645\u0631 \u0647\u0648 18 \u0639\u0627\u0645\u064b\u0627",
                                "av.preApprovedCredit.form.validation.age.max": "\u0627\u0644\u062d\u062f \u0627\u0644\u0623\u0642\u0635\u0649 \u0644\u0644\u0639\u0645\u0631 \u0647\u0648 100 \u0639\u0627\u0645",
                                "av.preApprovedCredit.form.validation.price.invalid": "\u064a\u0631\u062c\u0649 \u0625\u062f\u062e\u0627\u0644 \u0642\u064a\u0645\u0629 \u0635\u062d\u064a\u062d\u0629",
                                "av.adview.gt.section.heading.title": "\u0647\u0630\u0627 \u0627\u0644\u0639\u0631\u0636 \u0642\u062f \u064a\u0647\u0645\u0643",
                                "av.adview.gt.section.heading.subtitle": "\u0627\u0643\u062a\u0634\u0641 {{car}} \u0627\u0644\u062c\u062f\u064a\u062f\u0629 \u0639\u0644\u0649 Moteur.ma",
                                "av.adview.gt.section.onboarding.1": "\u0627\u0644\u0645\u0648\u0627\u0635\u0641\u0627\u062a \u0648\u0627\u0644\u0645\u064a\u0632\u0627\u062a",
                                "av.adview.gt.section.onboarding.2": "\u0623\u0633\u0639\u0627\u0631 \u0627\u0644\u0625\u0635\u062f\u0627\u0631\u0627\u062a \u0627\u0644\u0645\u062e\u062a\u0644\u0641\u0629",
                                "av.adview.gt.section.onboarding.3": "\u0645\u0639\u0631\u0636 \u0633\u064a\u0627\u0631\u0627\u062a \u0628\u0627\u0644\u0642\u0631\u0628 \u0645\u0646\u0643",
                                "av.adview.gt.tag": "\u0633\u064a\u0627\u0631\u0627\u062a \u062c\u062f\u064a\u062f\u0629",
                                "av.adview.mouteur.tag": "MOTEUR.MA",
                                "av.adview.gt.price": "\u0627\u0628\u062a\u062f\u0627\u0621 \u0645\u0646",
                                "av.adview.gt.section.cta": "\u0627\u0646\u0638\u0631 \u0627\u0644\u0633\u0639\u0631",
                                "av.vas.slider.btn.video": "Voir la video",
                                "av.vas.pack.updateBtn": "Modifier",
                                "av.footer.download": "\u062d\u0645\u0644 \u0627\u0644\u062a\u0637\u0628\u064a\u0642 \u0645\u062c\u0627\u0646\u0627:",
                                "av.footer.download.playstore": "\u0645\u062a\u0648\u0641\u0631 \u0639\u0644\u0649 Google Play",
                                "av.footer.download.appstore": "\u062d\u0645\u0644 \u0641\u064a \u0645\u062a\u062c\u0631 \u0627\u0644\u062a\u0637\u0628\u064a\u0642\u0627\u062a Apple Store",
                                "av.footer.follow": "\u062a\u0627\u0628\u0639\u0646\u0627 \u0639\u0644\u0649:",
                                "av.adview.share.withFacebook": "\u0641\u064a\u0633\u0628\u0648\u0643",
                                "av.adview.share.withWhatsapp": "Whatsapp",
                                "av.adview.share.withMessenger": "Messenger",
                                "av.advertising.googleAdsTitle": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u062c\u0648\u062c\u0644",
                                "av.advertising.avito-advertising-logo-url": "/phoenix-assets/imgs/layout/avito-advertising-logo-arabic.webp",
                                "av.delivery.step.continue": "\u0623\u0643\u0645\u0644",
                                "av.delivery.step.back": "\u0639\u0648\u062f\u0629",
                                "av.extended.delivery.notice.message": "\u0644\u0642\u062f \u062a\u0645 \u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0628\u062d\u062b \u0644\u064a\u0634\u0645\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u0639 \u0627\u0644\u062a\u0633\u0644\u064a\u0645 \u0641\u064a \u062c\u0645\u064a\u0639 \u0623\u0646\u062d\u0627\u0621 \u0627\u0644\u0645\u063a\u0631\u0628.",
                                "av.extended.delivery.cancel.cta": "\u0625\u0644\u063a\u0627\u0621",
                                "av.delivery.step1.title": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a\u0643",
                                "av.delivery.step1.firsName": "\u0627\u0644\u0625\u0633\u0645",
                                "av.delivery.step1.firsName-placeholder": "\u0627\u0633\u0645\u0643",
                                "av.delivery.step1.email-placeholder": "\u0628\u0631\u064a\u062f\u0643 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.delivery.step1.phone": "\u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.delivery.step1.phone-placeholder": "\u0631\u0642\u0645 \u0647\u0627\u062a\u0641\u0643",
                                "av.delivery.step2.title": "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062a\u0648\u0635\u064a\u0644",
                                "av.delivery.step2.city-placeholder": "\u0625\u062e\u062a\u0631 \u0645\u062f\u064a\u0646\u0629",
                                "av.delivery.step2.area-placeholder": "\u0625\u062e\u062a\u0631 \u062d\u064a",
                                "av.delivery.step2.all-area": "\u062c\u0645\u064a\u0639 \u0627\u0644\u0623\u062d\u064a\u0627\u0621",
                                "av.delivery.step2.address": "\u0627\u0644\u0639\u0646\u0648\u0627\u0646",
                                "av.delivery.step3.title": "\u0627\u0644\u0645\u0644\u062e\u0635",
                                "av.delivery.step3.detail-delivery": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u062a\u0648\u0635\u064a\u0644",
                                "av.delivery.step3.detail-order": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0637\u0644\u0628",
                                "av.delivery.step3.info-text": "\u0633\u064a\u062a\u0645 \u0627\u0644\u062f\u0641\u0639 \u0646\u0642\u062f\u0627 \u0639\u0646\u062f \u0627\u0644\u062a\u0633\u0644\u064a\u0645",
                                "av.delivery.step3.thanks": "\u0634\u0643\u0631\u0627\u064b",
                                "av.delivery.step4.thanks": "\u0634\u0643\u0631\u0627\u064b",
                                "av.delivery.step4.contact-text": "\u0633\u0646\u062a\u0635\u0644 \u0628\u0643 \u0639\u0628\u0631 \u0627\u0644\u0647\u0627\u062a\u0641 \u0641\u064a \u0623\u0642\u0644 \u0645\u0646 \u0633\u0627\u0639\u062a\u064a\u0646 \u0644\u062a\u0623\u0643\u064a\u062f \u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0648\u0648\u0642\u062a \u0627\u0644\u062a\u0633\u0644\u064a\u0645",
                                "av.delivery.step4.back": "\u0639\u0648\u062f\u0629 \u0625\u0644\u0649 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.adview.delivery.badge.title": "\u0627\u0644\u062a\u0648\u0635\u064a\u0644",
                                "av.adview.delivery.badge.text": " \u062a\u0633\u0644\u0645 \u0647\u0630\u0627 \u0627\u0644\u0645\u0646\u062a\u0648\u062c \u0628\u062f\u0648\u0646 \u0627\u0644\u0627\u0646\u062a\u0642\u0627\u0644 \u0645\u0646 \u0645\u0646\u0632\u0644\u0643",
                                "av.adview.delivery.noPrice": "\u062b\u0645\u0646 \u063a\u064a\u0631 \u0645\u062d\u062f\u062f",
                                "av.adview.delivery.paymentOnDelivery": "\u0627\u0644\u062f\u0641\u0639 \u0639\u0646\u062f \u0627\u0644\u0627\u0633\u062a\u0644\u0627\u0645",
                                "av.adview.delivery.titleDetails": "\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u0637\u0644\u0628",
                                "av.adview.delivery.initialPrice": "\u062b\u0645\u0646 \u0627\u0644\u0645\u0646\u062a\u0648\u062c",
                                "av.adview.delivery.deliveryPrice": "\u062a\u0643\u0627\u0644\u064a\u0641 \u0627\u0644\u062a\u0648\u0635\u064a\u0644",
                                "av.adview.delivery.fromPrice": " \u0625\u0628\u062a\u062f\u0627\u0621\u064b \u0645\u0646 ",
                                "av.adview.delivery.order": "\u0627\u0644\u0637\u0644\u0628",
                                "av.offers.heading": "\u0627\u0644\u0639\u0631\u0648\u0636 \u0627\u0644\u062d\u0627\u0644\u064a\u0629",
                                "av.services.heading": "\u062e\u062f\u0645\u0627\u062a",
                                "av.adview.Kifal.adview.btn": "\u0623\u0631\u064a\u062f  \u062a\u0642\u064a\u064a\u0645 \u0647\u0630\u0647 \u0627\u0644\u0633\u064a\u0627\u0631\u0629",
                                "av.adview.Kifal.popup.text": "\u0627\u0641\u064a\u062a\u0648 \u064a\u0642\u062a\u0631\u062d \u0639\u0644\u064a\u0643\u0645 \u062e\u062f\u0645\u0629 \u062c\u062f\u064a\u062f\u0629 \u0644\u0641\u062d\u0635 \u0627\u0644\u062d\u0627\u0644\u0629 \u0627\u0644\u0645\u064a\u0643\u0627\u0646\u064a\u0643\u064a\u0629 \u0648 \u0627\u0644\u0625\u062f\u0627\u0631\u064a\u0629 \u0644\u0644\u0633\u064a\u0627\u0631\u0629 \u0642\u0628\u0644 \u0627\u0644\u0642\u064a\u0627\u0645 \u0628\u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u0634\u0631\u0627\u0621",
                                "av.adview.Kifal.popup.subTitle": "\u062b\u0645\u0646 \u0647\u0630\u0647 \u0627\u0644\u062e\u062f\u0645\u0629 \u0647\u0648 450 \u062f\u0631\u0647\u0645 \u0645\u0639 \u0625\u062d\u062a\u0633\u0627\u0628 \u0627\u0644\u0631\u0633\u0648\u0645 (\u062a\u064f\u062f\u0641\u0639 \u0639\u0646\u062f \u0627\u0644\u0641\u062d\u0635)",
                                "av.adview.Kifal.popup.textDownload": "\u0625\u0636\u063a\u0637\u0648\u0627 \u0647\u0646\u0627 \u0644\u0645\u0639\u0627\u064a\u0646\u0629 \u0645\u062b\u0627\u0644 \u0639\u0644\u0649 \u062a\u0642\u0631\u064a\u0631 \u0627\u0644\u062e\u0628\u0631",
                                "av.adview.Kifal.popup.titleSubmited": "\u0644\u0642\u062f \u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628\u0643\u0645, \u0633\u064a\u0642\u0648\u0645 \u0623\u062d\u062f \u0639\u0645\u0644\u0627\u0626\u0646\u0627 \u0628\u0631\u0628\u0637 \u0627\u0644\u0625\u062a\u0635\u0627\u0644 \u0645\u0639\u0643\u0645 \u0641\u064a \u0623\u0642\u0631\u0628 \u0648\u0642\u062a",
                                "av.listing.searchBox.filters.heading": "\u0627\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u062e\u0635\u0627\u0626\u0635",
                                "av.listing.searchBox.filters.moreFilters": "\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u062e\u0635\u0627\u0626\u0635",
                                "av.listing.searchBox.placeholder.keyword": "\u0627\u0628\u062d\u062b \u0641\u064a \u0623\u0641\u064a\u062a\u0648",
                                "av.listing.searchBox.extraDetails.instruction": "\u064a\u0645\u0643\u0646\u0643 \u062a\u062d\u062f\u064a\u062f \u0645\u0639\u064a\u0627\u0631 \u0648\u0627\u062d\u062f \u0623\u0648 \u0623\u0643\u062b\u0631.",
                                "av.listing.searchBox.placeholder.city": "\u0627\u062e\u062a\u0627\u0631 \u0627\u0644\u0645\u062f\u064a\u0646\u0629",
                                "av.listing.searchBox.placeholder.area": "\u0627\u0643\u062a\u0628 \u0627\u0644\u062d\u064a",
                                "av.listing.searchBox.placeholder.price.min": "\u0623\u0642\u0644 \u062b\u0645\u0646",
                                "av.listing.searchBox.placeholder.price.max": "\u0623\u0639\u0644\u0649 \u062b\u0645\u0646",
                                "av.listing.searchBox.placeholder.brand": "\u062d\u062f\u062f \u0627\u0644\u0646\u0648\u0639",
                                "av.listing.searchBox.placeholder.model": "\u0623\u0643\u062a\u0628 \u0627\u0644\u0645\u0648\u062f\u064a\u0644",
                                "av.listing.searchBox.placeholder.pfiscale": "\u0623\u0643\u062a\u0628 \u0627\u0644\u0642\u0648\u0629 \u0627\u0644\u062c\u0628\u0627\u0626\u064a\u0629",
                                "av.listing.searchBox.label.transaction": "\u0646\u0648\u0639 \u0627\u0644\u0625\u0639\u0644\u0627\u0646",
                                "av.listing.searchBox.placholder.all": "\u0643\u0644\u0651\u0634\u064a",
                                "av.listing.searchBox.searchSuggestions.inCategory": "\u0641\u064a {{categoryName}}",
                                "av.listing.searchBox.recentSearch.title": "\u0639\u0645\u0644\u064a\u0627\u062a \u0627\u0644\u0628\u062d\u062b \u0627\u0644\u0623\u062e\u064a\u0631\u0629",
                                "av.listing.searchBox.recentSearch.minPrice": "\u0623\u0643\u062b\u0631 \u0645\u0646 {{minPrice}} \u062f\u0631\u0647\u0645",
                                "av.listing.searchBox.recentSearch.maxPrice": "\u0623\u0642\u0644 \u0645\u0646 {{maxPrice}} \u062f\u0631\u0647\u0645",
                                "av.listing.searchBox.recentSearch.betweenPrice": "\u0628\u064a\u0646 {{minPrice}} \u0648 {{maxPrice}} \u062f\u0631\u0647\u0645",
                                "av.listing.searchSidebar.search": "\u0628\u062d\u062b",
                                "av.listing.highlighted.tag": "\u0625\u0639\u0644\u0627\u0646 \u0646\u062c\u0645",
                                "av.listing.premium.heading": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0645\u0645\u062a\u0627\u0632\u0629",
                                "av.listing.premium.tag": "\u0645\u0645\u062a\u0627\u0632",
                                "av.listing.layout.grid": "\u0628\u0637\u0627\u0642\u0629",
                                "av.listing.layout.list": "\u0642\u0627\u0626\u0645\u0629",
                                "av.listing.AllCategories": "\u062c\u0645\u064a\u0639 \u0627\u0644\u0641\u0626\u0627\u062a",
                                "av.listing.H1.Template": "{{category}} {{brand}} {{model}} {{pfiscale}} {{adTypeSlug}} \u0641\u064a {{area}} {{cityOrCountry}} {{allAdsCount}} {{adTypeLabel}}",
                                "av.listing.saveSearch": "\u062d\u0641\u0638 \u0646\u062a\u0627\u0626\u062c \u0627\u0644\u0628\u062d\u062b",
                                "av.listing.saveSearch.long": "\u0625\u062d\u0641\u0636 \u0647\u062f\u0627 \u0627\u0644\u0628\u062d\u062a",
                                "av.listing.saveSearch.toast.savedSearch": "\u062a\u0645 \u062d\u0641\u0638 \u0628\u062d\u062b\u0643",
                                "av.listing.saveSearch.toast.searchAlreadySaved": "\u062a\u0645 \u062d\u0641\u0638 \u0647\u0630\u0627 \u0627\u0644\u0628\u062d\u062b",
                                "av.listing.saveSearch.toast.error": "!\u0646\u0648\u0627\u062c\u0647 \u062d\u0627\u0644\u064a\u064b\u0627 \u0635\u0639\u0648\u0628\u0629 \u0641\u064a \u062d\u0641\u0638 \u0647\u0630\u0627 \u0627\u0644\u0628\u062d\u062b \u060c \u064a\u0631\u062c\u0649 \u0627\u0644\u0645\u062d\u0627\u0648\u0644\u0629 \u0645\u0631\u0629 \u0623\u062e\u0631\u0649 \u0644\u0627\u062d\u0642\u064b\u0627",
                                "av.listing.results.deliveryLabel": "\u0627\u0644\u062a\u0648\u0635\u064a\u0644",
                                "av.listing.categories.heading": "\u0627\u0643\u062a\u0634\u0641 \u0641\u0626\u0627\u062a\u0646\u0627",
                                "av.listing.popular-ads.title": "\u0631\u0627\u0626\u062c \u0639\u0644\u0649 \u0623\u0641\u064a\u0637\u0648",
                                "av.listing.extended.city": "\u0644\u0645 \u064a\u062a\u0645 \u0627\u0644\u0639\u062b\u0648\u0631 \u0639\u0644\u0649 \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u064a \u0627\u0644\u062d\u064a \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u060c \u0648\u0642\u062f \u062a\u0645 \u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0628\u062d\u062b \u0644\u064a\u0634\u0645\u0644 \u0627\u0644\u0645\u062f\u064a\u0646\u0629 \u0628\u0623\u0643\u0645\u0644\u0647\u0627.",
                                "av.listing.extended.region": "\u0644\u0645 \u064a\u062a\u0645 \u0627\u0644\u0639\u062b\u0648\u0631 \u0639\u0644\u0649 \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u064a \u0627\u0644\u0645\u062f\u064a\u0646\u0629 \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629\u060c \u0648\u0642\u062f \u062a\u0645 \u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0628\u062d\u062b \u0644\u064a\u0634\u0645\u0644 \u0627\u0644\u062c\u0647\u0629 \u0628\u0623\u0643\u0645\u0644\u0647\u0627.",
                                "av.listing.extended.country": "\u0644\u0645 \u064a\u062a\u0645 \u0627\u0644\u0639\u062b\u0648\u0631 \u0639\u0644\u0649 \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u064a \u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u060c \u0648\u0642\u062f \u062a\u0645 \u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0628\u062d\u062b \u0644\u064a\u0634\u0645\u0644 \u0627\u0644\u0645\u063a\u0631\u0628 \u0628\u0623\u0643\u0645\u0644\u0647",
                                "av.listing.extended.price": "\u0644\u0645 \u064a\u062a\u0645 \u0627\u0644\u0639\u062b\u0648\u0631 \u0639\u0644\u0649 \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0644\u0644\u0628\u062d\u062b \u0627\u0644\u0645\u062e\u062a\u0627\u0631\u0629\u060c \u0648\u0642\u062f \u062a\u0645 \u062a\u0648\u0633\u064a\u0639 \u0627\u0644\u0628\u062d\u062b",
                                "av.listing.seoLinks.similar.heading": "\u0639\u0645\u0644\u064a\u0627\u062a \u0627\u0644\u0628\u062d\u062b \u0627\u0644\u0645\u0645\u0627\u062b\u0644\u0629",
                                "av.listing.seoLinks.popular.heading": "\u0639\u0645\u0644\u064a\u0627\u062a \u0628\u062d\u062b \u0633\u0631\u064a\u0639\u0629",
                                "av.listing.seoLinks.popular.cities.heading": "\u0627\u0644\u0645\u062f\u0646 \u0627\u0644\u0643\u0628\u0631\u0649",
                                "av.listing.filter.hint.button": "\u0628\u062d\u062b \u0645\u062f\u0642\u0642",
                                "av.listing.filter.sideNav.title": "\u062a\u062f\u0642\u064a\u0642 \u0627\u0644\u0628\u062d\u062b",
                                "av.listing.filter.search.cta": "{{searchCountResult}} \u0625\u0639\u0644\u0627\u0646",
                                "av.listing.urgent": "\u0639\u0627\u062c\u0644",
                                "av.listing.promo": "\u0639\u0631\u0636 {{discount}}",
                                "av.listing.price.decreased.tooltip.label": "\u0627\u0644\u0633\u0639\u0631 \u0627\u0646\u062e\u0641\u0636",
                                "av.listing.price.increased.tooltip.label": "\u0627\u0644\u0633\u0639\u0631 \u0641\u064a \u0627\u0631\u062a\u0641\u0627\u0639",
                                "av.listing.verified.seller.tooltip.label": "\u0645\u0639\u062a\u0645\u062f",
                                "av.listing.vrd.heading": "\u0647\u0644 \u062a\u0628\u062d\u062b \u0639\u0646 \u0627\u064a\u062c\u0627\u0631 \u064a\u0648\u0645\u064a\u061f",
                                "av.listing.vrd.content": "\u0648\u062c\u062f\u0646\u0627 \u0644\u0643 {{count}} \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0641\u064a \u0641\u0626\u0629 \u0643\u0631\u0627\u0621 \u0644\u0644\u0639\u0637\u0644. \u0647\u0644 \u062a\u0631\u064a\u062f \u0631\u0624\u064a\u062a\u0647\u0645\u061f",
                                "av.listing.vrd.action": "\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a",
                                "av.listing.seo.title": "\u0627\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - \u0627\u0641\u064a\u062a\u0648",
                                "av.listing.seo.title.category": "{{category}} - \u0627\u0641\u064a\u062a\u0648 \u0627\u0644\u0645\u063a\u0631\u0628 | {{vertical}}",
                                "av.listing.seo.title.category.subcategory": "{{category}} {{subcategory}} - \u0627\u0641\u064a\u062a\u0648 \u0627\u0644\u0645\u063a\u0631\u0628 | {{vertical}}",
                                "av.listing.seo.title.keyword": "Avito - \u0625\u0639\u0644\u0627\u0646 {{results_number}} : {{keyword}}",
                                "av.listing.seo.title.keyword.category": "\u0627\u0643\u062a\u0634\u0641 {{results_number}} \u0625\u0639\u0644\u0627\u0646 {{keyword}} {{category}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.category.subcategory": "\u0627\u0643\u062a\u0634\u0641 {{results_number}} \u0625\u0639\u0644\u0627\u0646 {{keyword}} {{subcategory}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.location": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a {{keyword}} \u0628{{location}} - Avito",
                                "av.listing.seo.title.keyword.location.sublocation": " Avito - {{location}} {{sublocation}}\u0628 {{keyword}}",
                                "av.listing.seo.title.keyword.location.category": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a {{keyword}} {{category}} \u0628{{location}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.location.category.subcategory": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a {{keyword}} {{subcategory}} \u0628{{location}} - Avito | {{vertical}}",
                                "av.listing.seo.title.keyword.location.sublocation.category": "Avito - {{sublocation}}\u0628 {{category}} {{keyword}} | {{vertical}}",
                                "av.listing.seo.title.keyword.location.sublocation.category.subcategory": "Avito - {{location}}\u0628 {{subcategory}} {{keyword}} \u0625\u0639\u0644\u0627\u0646\u0627\u062a | {{vertical}}",
                                "av.listing.seo.title.location": "\u0627\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0628\u0627\u0644\u0642\u0631\u0628 \u0645\u0646\u0643 \u0641\u064a  {{location}} \u0627\u0644\u0645\u063a\u0631\u0628 - \u0627\u0641\u064a\u062a\u0648",
                                "av.listing.seo.title.location.category": " Avito - {{location}}\u0628 {{category}} | {{vertical}}",
                                "av.listing.seo.title.location.category.subcategory": " Avito - {{location}}\u0628 {{subcategory}} | {{vertical}}",
                                "av.listing.seo.title.location.sublocation": "\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a  \u0628{{sublocation}} {{location}} - Avito",
                                "av.listing.seo.title.location.sublocation.category": " Avito - {{sublocation}}\u0628 {{category}} | {{vertical}}",
                                "av.listing.seo.title.location.sublocation.category.subcategory": " Avito - {{location}} {{sublocation}}\u0628 {{subcategory}} | {{vertical}}",
                                "av.listing.seo.title.category.brandModel": "{{brand}}{{model}} - au Maroc | {{vertical}}",
                                "av.listing.seo.title.location.category.brandModel": "{{brand}}{{model}} - \xe0 {{location}} Maroc | {{vertical}}",
                                "av.listing.seo.title.location.sublocation.category.brandModel": "{{brand}}{{model}} - \xe0 {{sublocation}} {{location}} Maroc | {{vertical}}",
                                "av.listing.seo.title.keyword.location.sublocation.category.brandModel": "{{brand}}{{model}} - \xe0 {{sublocation}} {{location}} Maroc | {{vertical}}",
                                "av.listing.seo.title.keyword.location.category.brandModel": "{{brand}}{{model}} - \xe0 {{location}} Maroc | {{vertical}}",
                                "av.listing.seo.title.keyword.category.brandModel": "{{brand}}{{model}} - au Maroc | {{vertical}}",
                                "av.listing.seo.description": "Vendez, achetez et louez vos biens sur Avito \u2705 la platefotrme num\xe9ro 1 de vente et d'achat au Maroc : Voitures, T\xe9l\xe9phones, Appartements, Motos etc.",
                                "av.listing.seo.description.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{adTypeSlug}} au Maroc, sur Avito.ma \u2705 La plateforme num\xe9ro 1 de vente et d'achat des biens et services",
                                "av.listing.seo.description.category.subcategory": "Visitez {{results_number}} annonces dans la cat\xe9gorie {{subcategory}} {{adTypeSlug}} partout au Maroc sur Avito la premi\xe8re plateforme d'achat et vente en ligne",
                                "av.listing.seo.description.keyword": "D\xe9couvrez {{results_number}} annonces pour {{keyword}} au Maroc au meilleur prix. Avito \u2705 la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.seo.description.keyword.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{keyword}} {{adTypeSlug}} au Maroc au meilleur prix. Avito \u2705 la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.seo.description.keyword.category.subcategory": "D\xe9couvrez {{results_number}} annonces pour {{subcategory}} {{keyword}} {{adTypeSlug}} au Maroc au meilleur prix. Avito \u2705 la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.seo.description.keyword.location": "D\xe9couvrez {{results_number}} annonces pour {{keyword}} \xe0 {{location}} au meilleur prix. Avito \u2705 la plus grande plateforme de petites annonces au Maroc",
                                "av.listing.seo.description.keyword.location.sublocation": "D\xe9couvrez {{results_number}} annonces pour {{keyword}} \xe0 {{sublocation}} avec des prix attractifs. Avito \u2705 la premi\xe8re plateforme de vente et d'achat \xe0 {{location}}",
                                "av.listing.seo.description.keyword.location.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{keyword}} \xe0 {{location}} au meilleur prix. Avito \u2705 la plus grande plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.keyword.location.category.subcategory": "D\xe9couvrez {{results_number}} annonces pour {{subcategory}} {{keyword}} {{adTypeSlug}} \xe0 {{location}} au meilleur prix. Avito \u2705 la plus grande plateforme de vente et d'achat en ligne au Maroc",
                                "av.listing.seo.description.keyword.location.sublocation.category": "D\xe9couvrez {{results_number}} annonces pour {{category}} {{keyword}} {{adTypeSlug}} \xe0 {{sublocation}} au meilleur prix. Avito \u2705 la premi\xe8re plateforme de petites annonces \xe0 {{location}}",
                                "av.listing.seo.description.keyword.location.sublocation.category.subcategory": "D\xe9couvrez {{results_number}} annonces pour {{subcategory}} {{adTypeSlug}} {{keyword}} \xe0 {{sublocation}} au meilleur prix. Avito \u2705 la premi\xe8re plateforme de petites annonces \xe0 {{location}}",
                                "av.listing.seo.description.location": "Avito \u2705 la premi\xe8re plateforme de vente et d'achat en ligne au Maroc",
                                "av.listing.seo.description.location.category": "Avito vous propose {{results_number}} annonces dans la cat\xe9gorie {{category}} {{adTypeSlug}} disponibles \xe0 {{location}}. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.category.subcategory": "Avito a environ {{results_number}} annonces disponibles pour {{subcategory}} {{adTypeSlug}} \xe0 {{location}}. Avito \u2705 la plateforme num\xe9ro 1 de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.sublocation": "Avito.ma \u2705 la premi\xe8re plateforme de vente et d'achat \xe0 {{sublocation}} {{location}}",
                                "av.listing.seo.description.location.sublocation.category": "Avito vous propose {{results_number}} offres disponibles dans la cat\xe9gorie {{category}} {{adTypeSlug}} \xe0 {{sublocation}} {{location}}. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.sublocation.category.subcategory": "Avito vous propose {{results_number}} annonces en ligne dans la cat\xe9gorie {{subcategory}} {{adTypeSlug}} {{sublocation}}. Avito \u2705 la plateforme num\xe9ro 1 de vente et d'achat \xe0 {{location}}",
                                "av.listing.seo.description.with_keyword": "D\xe9couvrez {{results_number}} annonces concernant {{keyword}} {{adTypeSlug}} \xe0 {{location}} au meilleur prix sur Avito.ma \u2705",
                                "av.listing.seo.description.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles au Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles \xe0 {{location}} Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.location.sublocation.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles \xe0 {{sublocation}} {{location}} Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.keyword.location.sublocation.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles \xe0 {{sublocation}} {{location}} Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.keyword.location.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles \xe0 {{location}} Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.listing.seo.description.keyword.category.brandModel": "Avito vous propose {{results_number}} annonces {{brand}}{{model}} {{adTypeSlug}} disponibles au Maroc. Avito \u2705 la premi\xe8re plateforme de vente et d'achat au Maroc",
                                "av.messages.adinfo.title": "R\xe9sum\xe9 de l'annonce",
                                "av.messages.adinfo.localisation": "Localisation",
                                "av.messages.form.title": "Envoyer message \xe0 \xab {{sellerName}} \xbb",
                                "av.messages.form.email.placeholder": "exemple@domain.com",
                                "av.messages.form.description.placeholder": "Ecrivez votre message ici",
                                "av.messages.form.cv": "CV",
                                "av.messages.form.cv.caption": "(2.5Mo Max)",
                                "av.messages.form.cv.caption.optional": "(2.5Mo Max, facultatif)",
                                "av.messages.form.cv.placeholder": "Formats autoris\xe9s : pdf, jpg, jpeg, rtf, odt",
                                "av.messages.form.attachmentCTA": "Attacher votre CV",
                                "av.messages.form.error.emailExist": "{{email}} cet adress mail existe d\xe9j\xe0 ",
                                "av.messages.form.error.email.notRegitred": "Votre email {{email}} ne correspond \xe0 aucun compte. veuillez cr\xe9er un compte gratuitement en cliquant ici.",
                                "av.messages.form.error.signin": "veuillez vos connecter",
                                "av.messages.form.cta": "Envoyer votre message",
                                "av.messages.form.alert.title": "Attention :",
                                "av.messages.form.alert.text": "Il ne faut jamais envoyer de l\u2019argent par virement bancaire ou \xe0 travers les agences de transfert d\u2019argent lors de l\u2019achat des biens disponibles sur le site. Avito.ma n\u2019est pas garant des transactions et ne joue pas le r\xf4le d\u2019interm\xe9diaire.",
                                "av.messages.sent.title": "Votre message a bien \xe9t\xe9 envoy\xe9.",
                                "av.messages.sent.desc": "Si vous disposez d'un compte, connectez-vous pour acc\xe9der au chat et retrouver vos conversations.\nSinon, vos \xe9changes continuent par email.",
                                "av.messages.sent.cta.back": "Retour a l'annonce",
                                "av.listing.phone.seo.title": "{{filters}} \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.listing.phone.seo.title.location": "{{filters}} \u0641\u064a {{location}}",
                                "av.listing.phone.seo.title.location.sublocation": "{{filters}} \u0641\u064a {{sublocation}} {{location}}",
                                "av.listing.phone.seo.description": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0628\u0627\u0644\u0645\u063a\u0631\u0628. \ud83d\udcf1  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.phone.seo.description.location": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0628{{location}}. \ud83d\udcf1  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.phone.seo.description.location.sublocation": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0628{{sublocation}} {{location}}. \ud83d\udcf1  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.title": "{{filters}} \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.listing.cars.seo.title.minYear": "{{filters}} \u0623\u0648 \u0623\u0643\u062b\u0631 \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.listing.cars.seo.title.maxYear": "{{filters}} \u0623\u0648 \u0623\u0642\u0644 \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.listing.cars.seo.title.location": "{{filters}} \u0641\u064a {{location}}",
                                "av.listing.cars.seo.title.location.sublocation": "{{filters}} \u0641\u064a {{sublocation}} {{location}}",
                                "av.listing.cars.seo.title.location.minYear": "{{filters}} \u0623\u0648 \u0623\u0643\u062b\u0631 \u0641\u064a {{location}}",
                                "av.listing.cars.seo.title.location.maxYear": "{{filters}} \u0623\u0648 \u0623\u0642\u0644 \u0641\u064a {{location}}",
                                "av.listing.cars.seo.title.location.sublocation.minYear": "{{filters}} \u0623\u0648 \u0623\u0643\u062b\u0631 \u0641\u064a {{sublocation}} {{location}}",
                                "av.listing.cars.seo.title.location.sublocation.maxYear": "{{filters}} \u0623\u0648 \u0623\u0642\u0644 \u0641\u064a {{sublocation}} {{location}}",
                                "av.listing.cars.seo.description": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0628\u0627\u0644\u0645\u063a\u0631\u0628. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.description.minYear": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0623\u0648 \u0623\u0643\u062b\u0631 \u0628\u0627\u0644\u0645\u063a\u0631\u0628. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.description.maxYear": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0623\u0648 \u0623\u0642\u0644 \u0628\u0627\u0644\u0645\u063a\u0631\u0628. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.description.location": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0628{{location}}. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.description.location.sublocation": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0628{{sublocation}} {{location}}. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.description.location.minYear": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0623\u0648 \u0623\u0643\u062b\u0631 \u0628{{location}}. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.description.location.maxYear": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0623\u0648 \u0623\u0642\u0644 \u0628{{location}}. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.description.location.sublocation.minYear": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0623\u0648 \u0623\u0643\u062b\u0631 \u0628{{sublocation}} {{location}}. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.listing.cars.seo.description.location.sublocation.maxYear": "\u0627\u0643\u062a\u0634\u0641  {{resultsCount}} \u0625\u0639\u0644\u0627\u0646  {{filters}} \u0623\u0648 \u0623\u0642\u0644 \u0628{{sublocation}} {{location}}. \ud83d\ude97  \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628 - Avito",
                                "av.signup.cta": "\u0625\u0646\u0634\u0627\u0621 \u062d\u0633\u0627\u0628",
                                "av.signup.page.title": "\u0625\u0646\u0634\u0627\u0621 \u062d\u0633\u0627\u0628 Avito.ma",
                                "av.signup.phone_verification.page.subtitle": "\u0623\u062f\u062e\u0644 \u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641 \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643 \u0623\u062f\u0646\u0627\u0647",
                                "av.signup.form.page.subtitle": "\u0623\u062f\u062e\u0644 \u0627\u0644\u062a\u0641\u0627\u0635\u064a\u0644 \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643 \u0623\u062f\u0646\u0627\u0647",
                                "av.signup.city.placeholder": "\u0627\u062e\u062a\u0631 \u0645\u062f\u064a\u0646\u0629",
                                "av.signup.password.placeholder": "\u0627\u062e\u062a\u064a\u0627\u0631 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
                                "av.signup.password.tip": "(5 \u0623\u062d\u0631\u0641 \u0639\u0644\u0649 \u0627\u0644\u0623\u0642\u0644) \u0627\u062e\u062a\u0631 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u064a\u0635\u0639\u0628 \u062a\u062e\u0645\u064a\u0646\u0647\u0627.",
                                "av.signup.password.confirm": "\u062a\u0623\u0643\u064a\u062f \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631",
                                "av.signup.create.account.button": "\u0625\u0646\u0634\u0627\u0621 \u062d\u0633\u0627\u0628",
                                "av.signup.error.field.empty": "\u0627\u062e\u062a\u0631 \u0645\u062f\u064a\u0646\u0629 \u0645\u0646 \u0641\u0636\u0644\u0643",
                                "av.signup.shop.title": "\u0627\u0628\u062f\u0623 \u0645\u063a\u0627\u0645\u0631\u062a\u0643 \u0645\u0639 Avito Boutique \u0627\u0644\u064a\u0648\u0645!",
                                "av.signup.shop.category.label": "\u0641\u0626\u0629 \u0645\u062a\u062c\u0631\u0643\u061f",
                                "av.signup.shop.subscriptionType.label": "\u0645\u0627 \u0646\u0648\u0639 \u0627\u0644\u0627\u0634\u062a\u0631\u0627\u0643\u061f",
                                "av.signup.shop.request.title": "\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0637\u0644\u0628\u0643 \u0628\u0646\u062c\u0627\u062d",
                                "av.signup.shop.request.subTitle": "\u0633\u064a\u062a\u0635\u0644 \u0628\u0643 \u0623\u062d\u062f \u0627\u0644\u0648\u0643\u0644\u0627\u0621 \u062e\u0644\u0627\u0644 24 \u0633\u0627\u0639\u0629.",
                                "av.signup.create.shop.cta": "\u0625\u0641\u062a\u062d \u0645\u062a\u062c\u0631\u0643",
                                "av.shop.signup.cta": "\u0625\u0631\u0633\u0627\u0644",
                                "av.messaging.emptymessage.title": "Bienvenue sur votre messagerie !",
                                "av.messaging.emptymessage.description": "Simple et rapide, elle vous permet d'\xe9changer entre particulier La mise en relation s'effectue toujours depuis une annonce en cliquant sur \"Envoyer un message\".",
                                "av.messaging.channel.action.block": "Bloquer la conversation",
                                "av.messaging.channel.action.unBlock": "D\xe9bloquer la conversation",
                                "av.messaging.channel.action.delete": "Supprimer la conversation",
                                "av.messaging.attachment.errorMaxSize": "Votre fichier depasse la limite autoriser veuillez selectionner une fichier moind de 5 Mb",
                                "av.messaging.textarea.hide": "pour continuer a utiliser cette conversation veuillez s\xe9lectionner l option debloquer dans le sous menu en haut ",
                                "av.common.messaging.conversations": "Toutes les conversations",
                                "av.common.messaging.input.placeholder": "\xc9crivez votre message...",
                                "av.common.attachment.label": "Pi\xe9ce jointe",
                                "av.common.messaging.start.history": "D\xe9marrer la conversation",
                                "av.common.messaging.select": "Selectionner une Conversation",
                                "av.common.messaging.select.helper": "Essayez de s\xe9lectionner une conversation pour commencer la discussion",
                                "av.common.messaging.start.history.helper": "d\xe9marrer la conversation en posant des questions sur la disponibilit\xe9 de l\u2019article",
                                "av.homepage.popular-categories": "\u0627\u0644\u0641\u0626\u0627\u062a \u0627\u0644\u0634\u0627\u0626\u0639\u0629",
                                "av.homepage.introHighlight.title": "\u0623\u0648\u0644 \u0645\u0648\u0642\u0639 \u062f\u064a\u0627\u0644 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062c\u0627\u0646\u064a\u0629 \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.homepage.introHighlight.subTitle": "\u0644\u0652\u0642\u0627\u0648\u0627 \u0627\u0644\u0647\u0645\u0652\u0632\u064e\u0629 \u0641 {{count}} \u0625\u0639\u0644\u0627\u0646",
                                "av.homepage.newCars": "\u0633\u064a\u0627\u0631\u0627\u062a \u062c\u062f\u064a\u062f\u0629",
                                "av.homepage.popularCities": "\u0645\u062f\u0646 \u0645\u062a\u062f\u0627\u0648\u0644\u0629",
                                "av.homepage.popularSearch": "\u0623\u0643\u062b\u0631 \u0627\u0644\u0645\u0646\u062a\u062c\u0627\u062a \u0628\u062d\u062b\u0627\u064b",
                                "av.homepage.appBanner.title": "\u0628\u064a\u0639 \u0648 \u0634\u0631\u064a \u0641\u064a\u0646 \u0645\u0627 \u0643\u0646\u062a\u064a",
                                "av.homepage.appBanner.subTitle": "\u0642\u0645 \u0628\u062a\u0646\u0632\u064a\u0644 \u062a\u0637\u0628\u064a\u0642 Avito",
                                "av.homepage.appStats.percent1": "73%",
                                "av.homepage.appStats.text1": "\u0645\u0646 \u0627\u0644\u0633\u0644\u0639 \u0648 \u0627\u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a \u062a\u0628\u0627\u0639 \u0641\u064a \u0623\u0642\u0644 \u0645\u0646 3 \u0623\u064a\u0627\u0645",
                                "av.homepage.appStats.percent2": "92%",
                                "av.homepage.appStats.text2": "\u0645\u0646 \u0645\u0633\u062a\u0639\u0645\u0644\u064a\u0646\u0627 \u0631\u0627\u0636\u064a\u0646 \u0639\u0646 \u0627\u0644\u0645\u0648\u0642\u0639",
                                "av.homepage.viewmore.btn": "\u0631\u0624\u064a\u0629 \u0627\u0644\u0645\u0632\u064a\u062f",
                                "av.re.homepage.searchbox.buy.tab.title": "Ventes",
                                "av.re.homepage.searchbox.rental.tab.title": "Locations",
                                "av.re.homepage.searchbox.ImmoNeuf.tab.title": "Immo Neuf",
                                "av.re.homepage.searchbox.vacation.tab.title": "Location vacances",
                                "av.re.homepage.searchbox.colocation.tab.title": "Colocations",
                                "av.re.homepage.searches.popular_searches.title": "\u0639\u0645\u0644\u064a\u0627\u062a \u0627\u0644\u0628\u062d\u062b \u0627\u0644\u0634\u0627\u0626\u0639\u0629",
                                "av.re.homepage.searches.saved_searches.title": "\u0639\u0645\u0644\u064a\u0627\u062a \u0627\u0644\u0628\u062d\u062b \u0627\u0644\u0645\u062d\u0641\u0648\u0638\u0629",
                                "av.re.homepage.searches.saved_searches.login.title": "\u0642\u0645 \u0628\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644 \u0644\u0639\u0631\u0636 \u0642\u0627\u0626\u0645\u0629 \u0639\u0645\u0644\u064a\u0627\u062a \u0627\u0644\u0628\u062d\u062b \u0627\u0644\u0645\u062d\u0641\u0648\u0638\u0629",
                                "av.re.homepage.searches.saved_searches.cta": "\u0625\u062c\u0631\u0627\u0621 \u0628\u062d\u062b",
                                "av.re.homepage.services.slider_section.title": "\u062e\u062f\u0645\u0627\u062a\u0646\u0627 \u0627\u0644\u0639\u0642\u0627\u0631\u064a\u0629",
                                "av.re.homepage.services.immo_neuf.title": "\u0623\u0641\u064a\u062a\u0648 \u0644\u0644\u0639\u0642\u0627\u0631\u0627\u062a \u0627\u0644\u062c\u062f\u064a\u062f\u0629",
                                "av.re.homepage.services.immo_neuf.description": "\u0623\u0641\u064a\u062a\u0648 \u0644\u0644\u0639\u0642\u0627\u0631\u0627\u062a \u0627\u0644\u062c\u062f\u064a\u062f\u0629 \u0647\u064a \u0627\u0644\u0645\u0646\u0635\u0629 \u0631\u0642\u0645 1 \u0644\u0644\u0639\u0642\u0627\u0631\u0627\u062a \u0627\u0644\u062c\u062f\u064a\u062f\u0629 \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628\u060c \u062d\u064a\u062b \u062a\u0642\u062f\u0645 \u0623\u0643\u0628\u0631 \u062e\u064a\u0627\u0631 \u0645\u0646 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062a \u0644\u062a\u062d\u0642\u064a\u0642 \u0643\u0644 \u0627\u0644\u0623\u062d\u0644\u0627\u0645.",
                                "av.re.homepage.services.loan_simulator.title": "\u0645\u062d\u0627\u0643\u064a \u0627\u0644\u0627\u0626\u062a\u0645\u0627\u0646",
                                "av.re.homepage.services.loan_simulator.description": "\u0627\u062d\u0635\u0644 \u0639\u0644\u0649 \u062a\u0642\u062f\u064a\u0631 \u0633\u0631\u064a\u0639 \u0644\u0631\u0635\u064a\u062f\u0643 \u0628\u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u062c\u0647\u0627\u0632 \u0645\u062d\u0627\u0643\u0627\u0629 \u0623\u0641\u064a\u062a\u0648 \u0627\u0644\u0628\u0633\u064a\u0637 \u0648\u0627\u0644\u062f\u0642\u064a\u0642. \u062a\u062a\u064a\u062d \u0644\u0643 \u0647\u0630\u0647 \u0627\u0644\u062e\u062f\u0645\u0629 \u0627\u0644\u062d\u0635\u0631\u064a\u0629 \u062d\u0633\u0627\u0628 \u062f\u0641\u0639\u0627\u062a\u0643 \u0627\u0644\u0634\u0647\u0631\u064a\u0629 \u0648\u062a\u0642\u064a\u064a\u0645 \u062c\u062f\u0648\u0649 \u0627\u0644\u0642\u0631\u0636 \u0627\u0644\u062e\u0627\u0635 \u0628\u0643 \u0628\u0628\u0636\u0639 \u0646\u0642\u0631\u0627\u062a.",
                                "av.re.homepage.services.shops.title": "\u0648\u0643\u0644\u0627\u0621 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062a",
                                "av.re.homepage.services.shops.description": "\u0623\u0646\u0634\u0626 \u0645\u062a\u062c\u0631\u0643 \u0627\u0644\u0639\u0642\u0627\u0631\u064a \u0639\u0644\u0649 \u0623\u0641\u064a\u062a\u0648 \u0627\u0644\u0645\u063a\u0631\u0628 \u0648 \u0632\u062f \u0645\u0628\u064a\u0639\u0627\u062a\u0643! \u0642\u0645 \u0628\u0627\u0644\u062a\u0633\u062c\u064a\u0644 \u0648\u0646\u0634\u0631 \u0625\u0639\u0644\u0627\u0646\u0627\u062a\u0643 \u0628\u0633\u0647\u0648\u0644\u0629 \u0644\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0632\u0628\u0646\u0627\u0621 \u0627\u0643\u062b\u0631 \u064a\u0628\u062d\u062b\u0648\u0646 \u0639\u0646 \u0627\u0644\u0639\u0642\u0627\u0631\u0627\u062a.",
                                "av.re.homepage.services.boost.title": "\u062e\u062f\u0645\u0627\u062a \u0627\u0644\u062a\u0639\u0632\u064a\u0632 \u0644\u0644\u0623\u0641\u0631\u0627\u062f",
                                "av.re.homepage.services.boost.description": "\u0642\u0645 \u0628\u0632\u064a\u0627\u062f\u0629 \u0639\u062f\u062f \u0627\u0644\u0645\u0634\u0627\u0647\u062f\u0627\u062a \u0644\u0625\u0639\u0644\u0627\u0646\u0627\u062a\u0643 \u0645\u0646 \u062e\u0644\u0627\u0644 \u062e\u062f\u0645\u0627\u062a \u0627\u0644\u062a\u0639\u0632\u064a\u0632 \u0644\u0644\u0623\u0641\u0631\u0627\u062f. \u0642\u0645 \u0628\u0632\u064a\u0627\u062f\u0629 \u0641\u0631\u0635\u0643 \u0641\u064a \u0627\u0644\u0628\u064a\u0639 \u0623\u0648 \u0627\u0644\u0625\u064a\u062c\u0627\u0631 \u0645\u0646 \u062e\u0644\u0627\u0644 \u0631\u0641\u0639 \u0625\u0639\u0644\u0627\u0646\u0627\u062a\u0643 \u062a\u0644\u0642\u0627\u0626\u064a\u064b\u0627 \u0641\u064a \u0646\u062a\u0627\u0626\u062c \u0627\u0644\u0628\u062d\u062b\u060c \u0644\u062c\u0630\u0628 \u0627\u0644\u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0645\u0634\u062a\u0631\u064a\u0646 \u0623\u0648 \u0627\u0644\u0645\u0633\u062a\u0623\u062c\u0631\u064a\u0646 \u0627\u0644\u0645\u062d\u062a\u0645\u0644\u064a\u0646.",
                                "av.global.error.title": "erreur lors de connexion",
                                "av.global.error.description": "D\xe9sol\xe9. Un probl\xe8me est survenu. Veuillez r\xe9essayer ult\xe9rieurement.\n    Si le probl\xe8me persiste, veuillez consulter le site Web www.avito.ma/help ",
                                "av.shops.sort.date.title": "\u0631\u062a\u0628 \u062d\u0633\u0628 : \u0627\u0644\u062a\u0627\u0631\u064a\u062e",
                                "av.shops.sort.price.title": "\u0631\u062a\u0628 \u062d\u0633\u0628 : \u0627\u0644\u0633\u0639\u0631",
                                "av.shops.searchbox.heading": "\u0627\u0628\u062d\u062b \u0641\u064a \u0627\u0644\u0645\u062a\u062c\u0631 ",
                                "av.shops.listing.heading": "\u062c\u0645\u064a\u0639 \u0625\u0639\u0644\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u062a\u062c\u0631 {{name}} ({{count}})",
                                "av.shops.summary.heading": "\u0645\u062a\u062c\u0631 : ",
                                "av.shops.summary.website": "\u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a \u0644\u0644\u0645\u062a\u062c\u0631",
                                "av.shops.title.default": "Avito.ma | {{category}}  \u0628{{city}} - {{name}} \u0645\u062a\u062c\u0631",
                                "av.shops.description.default": " {{category}} \u0628{{city}} \u064a\u0642\u062f\u0645 \u0645\u062c\u0645\u0648\u0639\u0629 \u0648\u0627\u0633\u0639\u0629 \u0645\u0646 \u0627\u0644\u0645\u0646\u062a\u062c\u0627\u062a {{name}} \u0645\u062a\u062c\u0631",
                                "av.shops.listing.categoryCard.label": "\u0645\u062a\u0627\u062c\u0631",
                                "av.shops.listing.shopCard.article": "\u0625\u0639\u0644\u0627\u0646",
                                "av.shops.listing.shopCard.memberSince": "\u0639\u0636\u0648 \u0645\u0646\u0630 ",
                                "av.shops.listing.searchBox.keyword.placeholder": "\u0625\u0633\u0645 \u0627\u0644\u0645\u062a\u062c\u0631",
                                "av.shops.listing.categoryPanel.heading": "\u0641\u0626\u0627\u062a \u0627\u0644\u0645\u062a\u0627\u062c\u0631",
                                "av.shops.listing.categoryPanel.subtitle": "\u0627\u0639\u062b\u0631 \u0628\u0633\u0631\u0639\u0629 \u0639\u0644\u0649 \u0645\u062a\u062c\u0631\u0643 \u0627\u0644\u0645\u0641\u0636\u0644",
                                "av.shops.listing.shopCard.heading": " \u0645\u062a\u0627\u062c\u0631 ",
                                "av.shops.listing.title.default": "\u0645\u062a\u0627\u062c\u0631 {{category}} {{keyword}} {{city}} | \u0627\u0641\u064a\u062a\u0648 \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.shops.listing.description.default": "\u0627\u0643\u062a\u0634\u0641 {{count}} \u0625\u0639\u0644\u0627\u0646 \u0644\u0644\u0645\u062a\u0627\u062c\u0631 {{category}} {{keyword}} {{city}} |  \u0623\u06a2\u064a\u062a\u0648 \u0627\u0644\u0645\u0646\u0635\u0629 \u0627\u0644\u0623\u0648\u0644\u0649 \u0644\u0644\u0628\u064a\u0639 \u0648\u0627\u0644\u0634\u0631\u0627\u0621 \u0639\u0628\u0631 \u0627\u0644\u0625\u0646\u062a\u0631\u0646\u062a \u0641\u064a \u0627\u0644\u0645\u063a\u0631\u0628",
                                "av.shops.listing.banner.heading": " \u0645\u062a\u062c\u0631 AVITO \u064a\u0645\u0646\u062d\u0643\u0645 \u0627\u0644\u0639\u062f\u064a\u062f \u0645\u0646 \u0627\u0644\u0645\u0632\u0627\u064a\u0627 :",
                                "av.shops.listing.banner.openShop": "\u0641\u062a\u062d \u0645\u062a\u062c\u0631",
                                "av.shops.listing.banner.alreadyAMember": "\u0645\u0633\u062c\u0644 \u0645\u0646 \u0642\u0628\u0644 ?",
                                "av.shops.listing.banner.text1": "\u0623\u0633\u0639\u0627\u0631 \u0645\u0645\u064a\u0632\u0629 \u062e\u0627\u0635\u0629 \u0628\u0627\u0644\u0645\u062a\u0627\u062c\u0631 \u0627\u0644\u0645\u062d\u062a\u0631\u0641\u0629 \u0641\u0642\u0637",
                                "av.shops.listing.banner.text2": " \u0625\u062f\u0627\u0631\u0629 \u0628\u0633\u064a\u0637\u0629 \u0648 \u0633\u0647\u0644\u0629 \u0644\u0645\u062a\u062c\u0631\u0643\u0645 \u0648 \u0625\u0639\u0644\u0627\u0646\u0627\u062a\u0643\u0645",
                                "av.shops.listing.banner.text3": "\u0639\u0646\u0648\u0627\u0646 \u0641\u0631\u062f\u064a \u062e\u0627\u0635 \u0628\u0643\u0645",
                                "av.shops.listing.banner.text4": " \u0648\u0627\u062c\u0647\u0629 \u062e\u0627\u0635\u0629 \u0628\u0639\u0644\u0627\u0645\u062a\u0643\u0645 \u0627\u0644\u062a\u062c\u0627\u0631\u064a\u0629 \u0636\u0645\u0646 \u0644\u0627\u0626\u062d\u0629 \u0627\u0644\u0645\u062a\u0627\u062c\u0631 \u0627\u0644\u0645\u062d\u062a\u0631\u0641\u0629 \u0639\u0644\u0649 AVITO ",
                                "av.ecommerce.checkout.order.itemsInStock": "{{itemsLeft}} \u0645\u0646\u062a\u062c \u0645\u062a\u0648\u0641\u0631",
                                "av.ecommerce.checkout.order.itemsOutOfStock": "\u063a\u064a\u0631 \u0645\u062a\u0648\u0641\u0631 \u062d\u0627\u0644\u064a\u0627\u064b",
                                "av.ecommerce.checkout.order.subtotal": "\u0625\u062c\u0645\u0627\u0644\u064a \u0627\u0644\u0645\u0628\u0644\u063a",
                                "av.ecommerce.checkout.order.shipping": "\u062a\u0643\u0627\u0644\u064a\u0641 \u0627\u0644\u062a\u0648\u0635\u064a\u0644",
                                "av.ecommerce.checkout.order.total": "\u0627\u0644\u0645\u0628\u0644\u063a \u0627\u0644\u0625\u062c\u0645\u0627\u0644\u064a TTC",
                                "av.ecommerce.checkout.delivery.heading": "\u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u062a\u0648\u0635\u064a\u0644",
                                "av.ecommerce.checkout.delivery.subtitle": "\u0623\u0643\u0645\u0644 \u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u0634\u0631\u0627\u0621 \u0628\u062a\u0642\u062f\u064a\u0645 \u0645\u0639\u0644\u0648\u0645\u0627\u062a \u0627\u0644\u062a\u0648\u0635\u064a\u0644 \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643",
                                "av.ecommerce.checkout.delivery.name.label": "\u0627\u0644\u0625\u0633\u0645 \u0627\u0644\u0643\u0627\u0645\u0644",
                                "av.ecommerce.checkout.delivery.name.placeholder": "\u0627\u0644\u0625\u0633\u0645 \u0627\u0644\u0643\u0627\u0645\u0644",
                                "av.ecommerce.checkout.delivery.email.label": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.ecommerce.checkout.delivery.email.placeholder": "\u0627\u0644\u0628\u0631\u064a\u062f \u0627\u0644\u0625\u0644\u0643\u062a\u0631\u0648\u0646\u064a",
                                "av.ecommerce.checkout.delivery.phone.label": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.ecommerce.checkout.delivery.phone.placeholder": "\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.ecommerce.checkout.delivery.address.label": "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062a\u0633\u0644\u064a\u0645",
                                "av.ecommerce.checkout.delivery.address.placeholder": "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u062a\u0633\u0644\u064a\u0645",
                                "av.ecommerce.checkout.cta.pay": "\u0625\u0634\u062a\u0631\u064a",
                                "av.ecommerce.checkout.cta.order": "\u062a\u0623\u0643\u064a\u062f",
                                "av.ecommerce.adview.badge": "Achat en ligne",
                                "av.ecommerce.adview.cta": "\u0625\u0634\u062a\u0631\u064a \u0627\u0644\u0622\u0646",
                                "av.ecommerce.adview.shop.note": "\u0625\u0633\u062a\u062e\u062f\u0645 \u062d\u0633\u0627\u0628\u0643 \u0627\u0644\u062e\u0627\u0635 \u0644\u0625\u062c\u0631\u0627\u0621 \u0639\u0645\u0644\u064a\u0629 \u0627\u0644\u0634\u0631\u0627\u0621. ",
                                "av.ecommerce.adview.shop.note.login": "\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644",
                                "av.ecommerce.checkout.cod.success.heading": "\u0647\u0646\u064a\u0626\u0627 \u0644\u0642\u062f \u062a\u0645 \u062a\u0633\u062c\u064a\u0644 \u0637\u0644\u0628\u0643\u0645 \u0628\u0646\u062c\u0627\u062d",
                                "av.ecommerce.checkout.cod.success.subheading": "\u0634\u0643\u0631\u0627 \u0639\u0644\u0649 \u062b\u0642\u062a\u0643\u0645. \u0633\u062a\u062a\u0648\u0635\u0644\u0648\u0646 \u0628\u0637\u0644\u0628\u0643\u0645 \u0642\u0631\u064a\u0628\u064b\u0627",
                                "av.ecommerce.checkout.cod.success.primaryCta": "\u0627\u0644\u0631\u062c\u0648\u0639 \u0627\u0644\u0649 \u0644\u0627\u0626\u062d\u0629 \u0627\u0644\u0637\u0644\u0628\u0627\u062a",
                                "av.ecommerce.checkout.cod.success.secondaryCta": "\u0645\u0648\u0627\u0635\u0644\u0629 \u0627\u0644\u062a\u0633\u0648\u0642",
                                "av.ecommerce.checkout.delivery.rememberCoords": "\u0627\u062d\u0641\u0638 \u0628\u064a\u0627\u0646\u0627\u062a\u064a \u0641\u064a \u0627\u0644\u0645\u0631\u0629 \u0627\u0644\u0642\u0627\u062f\u0645\u0629",
                                "av.cotation.step": "\xc9tape {{stepText}}",
                                "av.cotation.lastStep": "\xc9tape finale",
                                "av.cotation.steps.nextButton.label": "Passer \xe0 l'\xe9tape suivante",
                                "av.cotation.steps.carParams.label": "Renseignez les informations de votre voiture",
                                "av.cotation.steps.carStatus.label": "Pr\xe9cisez l\u2019\xe9tat de votre voiture ( Optionel )",
                                "av.cotation.steps.userInfo.label": "Renseignez vos informations personnelles",
                                "av.cotation.params.brand.label": "Marque",
                                "av.cotation.params.model.label": "Mod\xe8le",
                                "av.cotation.params.fuelType.label": "Carburant",
                                "av.cotation.params.gearType.label": "Bo\xeete \xe0 vitesses",
                                "av.cotation.params.year.label": "Ann\xe9e - Phase",
                                "av.cotation.params.version.label": "Version",
                                "av.cotation.params.horsePower.label": "Puissance r\xe9elle",
                                "av.cotation.params.fiscalPower.label": "Puissance fiscale",
                                "av.cotation.params.origin.label": "Origine",
                                "av.cotation.params.mileage.label": "Kilom\xe9trage",
                                "av.cotation.params.optional": "( Optionel )",
                                "av.cotation.params.errorMessage": "Ce champs est obligatoire",
                                "av.cotation.params.placeholder": "S\xe9lectionner",
                                "av.cotation.carStatusParams.mechanicalCondition.label": "Quel est l'\xe9tat m\xe9canique de votre voiture?",
                                "av.cotation.carStatusParams.carBodyCondition.label": "Quel est l'\xe9tat de la carrosserie?",
                                "av.cotation.carStatusParams.warningLights.label": "Est ce qu'il ya des voyants d'alerte allum\xe9s sur votre tableau de bord?",
                                "av.cotation.carStatusParams.reason.label": "Je suis int\xe9ress\xe9 par: ",
                                "av.cotation.userInfosFields.name.label": "Nom complet",
                                "av.cotation.userInfosFields.name.placeholder": "Veuillez saisir votre nom et pr\xe9nom",
                                "av.cotation.userInfosFields.name.error": "Veuillez renseigner ce champ",
                                "av.cotation.userInfosFields.phone.label": "Num\xe9ro de t\xe9l\xe9phone",
                                "av.cotation.userInfosFields.phone.placeholder": "Veuillez saisir votre num\xe9ro de t\xe9l\xe9phone",
                                "av.cotation.userInfosFields.phone.error": "Saisissez un num\xe9ro de t\xe9l\xe9phone valide",
                                "av.cotation.userInfosFields.email.label": "Adresse Email",
                                "av.cotation.userInfosFields.email.placeholder": "Veuillez saisir votre adresse Email",
                                "av.cotation.userInfosFields.email.error": "Saisissez une adresse Email valide",
                                "av.cotation.userInfosFields.terms.wording": "J'accepte les ",
                                "av.cotation.userInfosFields.terms.link": "conditions g\xe9n\xe9rales d'utilisation",
                                "av.cotation.userInfosFields.terms.error": "Veuillez accepter les conditions d'utilisation",
                                "av.cotation.userInfosFields.reason.error": "Veuillez choisir une option",
                                "av.cotation.evaluations": "Mes estimations",
                                "av.cotation.landing.hero.heading": "Calculez la valeur de votre voiture avec la c\xf4te Avito",
                                "av.cotation.landing.hero.body": "Avito vous propose une estimation rapide, fiable et pr\xe9cise de votre voiture, remplissez les informations de votre voiture et recevez une estimation instantan\xe9e bas\xe9e sur le prix du march\xe9 automobile au Maroc.",
                                "av.cotation.common.evaluate": "Estimer votre voiture",
                                "av.cotation.common.howto": "Comment \xe7a marche",
                                "av.cotation.landing.hero.popularBrands": "\xc9VALUATION DES MARQUES POPULAIRES",
                                "av.cotation.evaluations.landing.onboarding.1.heading": "Calculez gratuitement votre C\xf4te occasion",
                                "av.cotation.evaluations.landing.onboarding.1.body": "Estimer pr\xe9cis\xe9ment son v\xe9hicule quand on vend, c'est fondamental. Savoir si le prix que l'on vous demande quand vous achetez est juste, c'est pr\xe9cieux avec la cote Avito vous aurez le juste prix march\xe9.",
                                "av.cotation.evaluations.landing.onboarding.2.heading": "Pourquoi la cote Avito",
                                "av.cotation.evaluations.landing.onboarding.2.body": "La valeur Avito est reconnu fiable par une majorit\xe9 de vendeurs et d'acheteurs. Des millions d'acheteurs consultent chaque mois nos platformes Avito& Moteur. La valeur Avito : Unique, Pr\xe9cise, Reconnue sur le march\xe9.",
                                "av.cotation.evaluations.landing.onboarding.3.heading": "Comment Estimer votre voiture",
                                "av.cotation.evaluations.landing.onboarding.3.body": "Ajoutez quelques d\xe9tails de base sur votre voiture d'occasion et recevez gratuitement la valeur de reprise de votre voiture en quelques minutes.",
                                "av.cotation.evaluations.landing.onboarding.premium.1.heading": "\xc9TAPE 1",
                                "av.cotation.evaluations.landing.onboarding.premium.1.body": "D\xe9marrer l'estimation en renseignant les informations suivantes afin d\u2019avoir une estimation fiable (marque, mod\xe8le, ann\xe9e, boite de vitesse, carburant, puissance fiscale...).",
                                "av.cotation.evaluations.landing.onboarding.premium.2.heading": "\xc9TAPE 2",
                                "av.cotation.evaluations.landing.onboarding.premium.2.body": "Renseigner l'\xe9tat de la voiture (carrosserie, m\xe9canique, les voyants du tableau de bord ).",
                                "av.cotation.evaluations.landing.onboarding.premium.3.heading": "\xc9TAPE 3",
                                "av.cotation.evaluations.landing.onboarding.premium.3.body": "Obtenez une estimation du prix du v\xe9hicule d\u2019occasion mais aussi sa valeur transaction, sa valeur annonce, son attractivit\xe9, son d\xe9lai de rotation et sa marge de n\xe9gociation.",
                                "av.cotation.landing.generic.text1": "Evaluez votre voiture en <span>2 minutes</span> et obtenez une premi\xe8re estimation gratuite",
                                "av.cotation.thankyou.heading": "F\xe9licitations!",
                                "av.cotation.thankyou.empty.heading": "Whoops!",
                                "av.cotation.thankyou.subheading": "L'estimation de votre voiture est compl\xe9t\xe9e",
                                "av.cotation.thankyou.limitReached.subheading": "Vous avez atteint votre limite de g\xe9n\xe9ration d'estimation",
                                "av.cotation.thankyou.limitReached.suggestion": "Merci de contacter le service client pour avoir plus d'informations",
                                "av.cotation.thankyou.empty.subheading": "Nous n'avons pas pu \xe9valuer votre voiture",
                                "av.cotation.thankyou.empty.suggestion": " Merci de v\xe9rifier les informations que vous avez saisies.",
                                "av.cotation.thankyou.email.body": "Nous vous avons envoy\xe9 l'estimation de votre voiture \xe0 l'adresse Email suivante:",
                                "av.cotation.thankyou.suggestion": "La fourchette de prix estim\xe9e est juste \xe0 titre indicatif, l'\xe9tat r\xe9el et les sp\xe9cifications suppl\xe9mentaires pourraient augmenter le prix de vente.",
                                "av.cotation.thankyou.resendEmail": "Renvoyer l'email",
                                "av.cotation.thankyou.emailSent": "Email envoy\xe9",
                                "av.cotation.thankyou.estimation.price": "Le prix de vente peut varier entre ",
                                "av.cotation.thankyou.estimation.price.and": " et ",
                                "av.cotation.thankyou.estimation.button": "Voir mes estimations",
                                "av.cotation.summary.heading": "Calcul du prix en cours",
                                "av.cotation.summary.email.body": "Merci de v\xe9rifier les informations de votre voiture avant de valider votre demande et passer \xe0 l\u2019\xe9tape finale.",
                                "av.cotation.summary.button.estimation": "Voir l\u2019estimation de ma voiture",
                                "av.cotation.summary.button.editInfos": "Modifiez les informations",
                                "av.cotation.estimations.heading": "Mes estimations",
                                "av.cotation.estimations.subheading": "Les valeurs des prix estim\xe9s sont uniquement \xe0 titre indicatif bas\xe9es sur les donn\xe9es du march\xe9 des voitures d'occasion au Maroc, pour vous donner une id\xe9e g\xe9n\xe9rale par rapport au prix du march\xe9. L'\xe9tat r\xe9el et les sp\xe9cifications suppl\xe9mentaires pourraient augmenter ou diminuer le prix de vente.",
                                "av.cotation.estimations.contactUs": "Contacter un Agent",
                                "av.cotation.estimations.limitReached": "Vous avez atteint votre limite d'\xe9valuations!",
                                "av.cotation.estimations.expiryDate": "Date d'expiration",
                                "av.cotation.estimations.seeMore": "Voir plus de d\xe9tails",
                                "av.cotation.estimations.contact.body": "Notre service client est disponible 7j/7 de 9h \xe0 20h sur le 0520428686",
                                "av.cotation.estimations.contact.number": "0520428686",
                                "av.cotation.estimations.contact.title": "Contacter un agent",
                                "av.cotation.estimations.expiry.title": "Date d'expiration",
                                "av.cotation.estimations.residualValue.title": "La valeur de r\xe9f\xe9rence",
                                "av.cotation.estimations.residualValue.body": "La valeur de r\xe9f\xe9rence est issue d\u2019un calcul sp\xe9cifique, l\u2019algorithme prend \xe0 la fois en compte le mod\xe8le, la date de mise en circulation et l\u2019\xe9tat de la voiture. Les donn\xe9es entr\xe9es par le vendeur sont ensuite compar\xe9es aux offres d\xe9j\xe0 en ligne et aux v\xe9hicules vendus pr\xe9c\xe9demment. Ainsi Avito auto pro fournit une estimation approximative de la c\xf4te du v\xe9hicule",
                                "av.cotation.estimations.adsValue.title": "La c\xf4te Avito",
                                "av.cotation.estimations.adsValue.body": "Une valeur de march\xe9 des derniers prix affiche\u0301s par les vendeurs sur nos plateformes (Avito& Moteur)",
                                "av.cotation.estimations.transactionValue.title": "La valeur de transaction",
                                "av.cotation.estimations.transactionValue.body": "L\u2019estimation du prix de vente re\u0301el pour un ve\u0301hicule, bas\xe9e sur l\u2019observation des valeurs de revente effectives et les transacations faites sur nos plateformes (Avito& Moteur)",
                                "av.cotation.estimations.margeOfNegoctiaition.title": "Marge de Negociation",
                                "av.cotation.estimations.margeOfNegoctiaition.body": " La marge de transaction attendue sur le prix de transaction",
                                "av.cotation.estimations.rotation.title": "D\xe9lai de Rotation",
                                "av.cotation.estimations.rotation.body": "D\xe9lai moyen de vente de votre voiture",
                                "av.cotation.estimations.attractiveness.title": "Attractivit\xe9 du Mod\xe8le",
                                "av.cotation.estimations.attractiveness.body": "Indice de liquidit\xe9 du mod\xe8le dans le march\xe9 automobile marocain dans les trois derniers mois.",
                                "av.cotation.estimations.newCarsPrice.title": "Prix du neuf",
                                "av.cotation.estimations.newCarsPrice.body": "Le prix catalogue, les caracte\u0301ristiques techniques, les e\u0301quipements de se\u0301rie et en option, issus du Re\u0301fe\u0301rentiel Avito Auto neuf",
                                "av.cotation.estimations.confidenceIndex.title": "Indice de confiance",
                                "av.cotation.estimations.confidenceIndex.body": "L'indice de confiance (1 \xe0 5) refl\xe9te la repr\xe9sentativit\xe9 des donn\xe9es et la taille de l'\xe9chantillon de v\xe9hicules permettant de calculer la cote Avito et de la pr\xe9cision des informations de votre v\xe9hicule.",
                                "av.cotation.estimations.great.title": "Agr\xe9able!",
                                "av.cotation.estimations.great.body": " Nous avons estim\xe9 la valeur de votre voiture!",
                                "av.cotation.login.heading": "Connexion",
                                "av.cotation.login.body": "\xc9conomisez plus de temps et recevez une estimation rapide et fiable.",
                                "av.cotation.login.email.label": "Adresse e-mail",
                                "av.cotation.login.email.placeholder": "Veuillez saisir votre adresse e-mail",
                                "av.cotation.login.email.error": "Saisissez une adresse e-mail valide",
                                "av.cotation.login.username.label": "Nom d'utilisateur",
                                "av.cotation.login.username.placeholder": "Veuillez saisir votre nom d'utilisateur",
                                "av.cotation.login.username.error": "Saisissez un nom d'utilisateur valide",
                                "av.cotation.login.password.label": "Mot de passe",
                                "av.cotation.login.password.placeholder": "Veuillez saisir votre mot de passe",
                                "av.cotation.login.password.error": "Saisissez un mot de passe valide",
                                "av.cotation.login.button": "Se connecter",
                                "av.cotation.login.error.retry": "Quelque chose ne va pas, veuillez r\xe9essayer plus tard.",
                                "av.cotation.login.error.unauthorized": "Vous n'\xeates pas autoris\xe9 \xe0 vous connecter! Merci de contacter le Service Client.",
                                "av.cotation.login.error.badCredentials": "Email et/ou mot de passe incorrect(s)",
                                "av.seller.center.product.status.active": "Produits actifs",
                                "av.seller.center.product.status.active.short": "Actif",
                                "av.seller.center.product.status.outOfStock": "Produits \xe9puis\xe9s",
                                "av.seller.center.product.status.outOfStock.short": "\xc9puis\xe9",
                                "av.seller.center.product.status.deactivated": "Produits d\xe9sactiv\xe9s",
                                "av.seller.center.product.status.deactivated.short": "D\xe9sactiv\xe9",
                                "av.seller.center.product.status.deleted": "Produits supprim\xe9s",
                                "av.seller.center.product.status.deleted.short": "Supprim\xe9",
                                "av.seller.center.order.status.pending.short": "En attente",
                                "av.seller.center.order.status.readyForDelivery": "Pr\xeat pour l'exp\xe9dition",
                                "av.seller.center.order.status.readyForDelivery.short": "Pr\xeat",
                                "av.seller.center.order.status.delivering": "Commandes en livraison",
                                "av.seller.center.order.status.delivering.short": "En livraison",
                                "av.seller.center.order.status.cancelled": "Commandes annul\xe9es",
                                "av.seller.center.order.status.cancelled.short": "Annul\xe9e",
                                "av.seller.center.order.status.returned.short": "Retourn\xe9e",
                                "av.seller.center.order.status.delivred": "Commandes livr\xe9es",
                                "av.seller.center.order.status.delivred.short": "Livr\xe9e",
                                "av.seller.center.payment.status.pending": "Commandes en attente",
                                "av.seller.center.payment.status.ongoing": "Commandes en cours",
                                "av.seller.center.payment.status.ongoing.short": "En cours",
                                "av.seller.center.payment.status.paid": "Commandes pay\xe9es",
                                "av.seller.center.payment.status.paid.short": "Pay\xe9e",
                                "av.seller.center.payment.status.refunded": "Commandes rembours\xe9es",
                                "av.seller.center.payment.status.refunded.short": "Rembours\xe9e",
                                "av.seller.center.headers.actions": "Actions",
                                "av.seller.center.product.preview": "Aper\xe7u",
                                "av.seller.center.product.ref": "R\xe9f#",
                                "av.seller.center.product.short": "Produit",
                                "av.seller.center.product.units": "Stock",
                                "av.seller.center.product.discount": "Remise",
                                "av.seller.center.product.status": "Statuts",
                                "av.seller.center.product.orders": "Commandes",
                                "av.seller.center.product.boost": "Pack de boost",
                                "av.seller.center.order.print": "Imprimer",
                                "av.seller.center.order.id": "Num\xe9ro de commande",
                                "av.seller.center.order.units": "N\xb0 d\u2019unit\xe9s",
                                "av.seller.center.order.date": "Date de commande",
                                "av.seller.center.order.paymentMethod": "Mode de paiement",
                                "av.seller.center.payment.commission": "Commission",
                                "av.seller.center.payment.status": "Statuts de paiement",
                                "av.seller.center.payment.orderStatus": "Statuts de commande",
                                "av.seller.center.my-products.mobile.text": "Pour traiter vos produits veuillez visiter la version desktop",
                                "av.seller.center.product.mobile.subText": "Commencez par trouver l'article qui correspond \xe0 vos besoins sur nos boutiques en ligne, et passez \xe0 la fonction de paiement instantan\xe9",
                                "av.seller.center.product.mobile.btn": "Voir mes commandes",
                                "av.seller.center.my-products.empty-state.text": "Vous n'avez pas de produit {{status}}",
                                "av.seller.center.my-products.empty-state.text.status.active": "ins\xe9r\xe9",
                                "av.seller.center.my-products.empty-state.text.status.outOfStock": "\xe9puis\xe9",
                                "av.seller.center.my-products.empty-state.text.status.deactivated": "d\xe9sactiv\xe9",
                                "av.seller.center.my-products.empty-state.text.status.deleted": "supprim\xe9",
                                "av.seller.center.my-products.empty-state.subText": 'Veuillez cliquer sur le bouton "Ajouter un produit" pour ins\xe9rer votre premier produit.',
                                "av.seller.center.my-orders.empty-state.text": "Vous n'avez pas de commande {{status}}",
                                "av.seller.center.my-orders.empty-state.text.status.pending": "en attente",
                                "av.seller.center.my-orders.empty-state.text.status.readyForDelivery": "pr\xeate pour l'exp\xe9dition",
                                "av.seller.center.my-orders.empty-state.text.status.delivering": "en livraison",
                                "av.seller.center.my-orders.empty-state.text.status.delivered": "livr\xe9e",
                                "av.seller.center.my-orders.empty-state.text.status.cancelled": "annul\xe9e",
                                "av.seller.center.my-payments.mobile.text": "Pour traiter vos paiements veuillez visiter la version desktop",
                                "av.seller.center.my-payments.empty-state.text": "Vous n'avez pas de {{paymentsStatus}}",
                                "av.seller.center.my-payments.empty-state.text.status.pending": "paiement en attente",
                                "av.seller.center.my-payments.empty-state.text.status.on-going": "paiement en cours",
                                "av.seller.center.my-payments.empty-state.text.status.payed": "paiement effectu\xe9",
                                "av.seller.center.my-payments.empty-state.text.status.refunded": "commande rembours\xe9e",
                                "av.seller.center.product.operations.searchbox.placeholder": "Que recherchez-vous ?",
                                "av.seller.center.product.operations.add.short": "Ajouter",
                                "av.seller.center.product.operations.add": "\u0623\u0636\u064a\u0641\u0648\u0627 \u0645\u0646\u062a\u0648\u062c\u0643\u0645",
                                "av.seller.center.product.operations.export": "Exporter",
                                "av.seller.center.product.operations.activate.success.title": "Produit activ\xe9",
                                "av.seller.center.product.operations.activate.success.text": "Vous pouvez le booster en allant sur Mom compte > produits actifs ou en cliquant ici",
                                "av.seller.center.product.operations.deactivate": "D\xe9sactiver",
                                "av.seller.center.product.operations.deactivate.success": "Produit d\xe9sactiv\xe9 avec success",
                                "av.seller.center.product.operations.delete.confirmation.text": "Vous ne pouvez effectuer aucune action sur ce produit si vous le supprimer.",
                                "av.seller.center.product.operations.delete.success": "Produit supprim\xe9 avec success",
                                "av.seller.center.product.operations.adjust.stock.success": "Nombre d'unit\xe9 ajust\xe9 avec success",
                                "av.seller.center.product.operations.apply.discount.success": "Remise appliqu\xe9e avec success",
                                "av.seller.center.order.operations.prepare": "Article est pr\xeat",
                                "av.seller.center.order.operations.prepare.success": "l'article est maintenant pr\xeat pour l'exp\xe9dition",
                                "av.seller.center.order.operations.cancel.success": "Commande annul\xe9e avec success",
                                "av.seller.center.order.operations.delete.confirmation.text": "Vous ne pouvez effectuer aucune action sur cette commande si vous la supprimer.",
                                "av.seller.center.order.operations.delete.success": "Commande supprim\xe9e avec success",
                                "av.seller.center.product.insert.sections.insert": "\u0623\u0636\u0641 \u0645\u0646\u062a\u062c\u064b\u0627",
                                "av.seller.center.product.insert.sections.general": "Informations g\xe9n\xe9rales",
                                "av.seller.center.product.insert.sections.details": "D\xe9tails du bien",
                                "av.seller.center.product.insert.fileds.category.label": "S\xe9lectionner la sous cat\xe9gorie",
                                "av.seller.center.product.insert.fileds.product.label": "Nom du produit",
                                "av.seller.center.product.insert.fileds.units.label": "Nombre d'unit\xe9s",
                                "av.seller.center.product.insert.fileds.price.label": "Prix unitaire",
                                "av.seller.center.product.insert.fileds.discount.label": "Remise",
                                "av.seller.center.product.insert.fileds.category.error.message": "Veuillez s\xe9lectionner la sous cat\xe9gorie",
                                "av.seller.center.product.insert.fileds.min.error.message": "Trop court, doit contenir au minimum {{min}} caract\xe8res.",
                                "av.seller.center.product.insert.fileds.max.error.message": "Trop long. doit contenir au maximum {{max}} caract\xe8res.",
                                "av.seller.center.product.insert.ctas.add": "Ajouter",
                                "av.seller.center.product.insert.ctas.return": "Retour",
                                "av.seller.center.product.edit": "\u062a\u0639\u062f\u064a\u0644 \u0627\u0644\u0645\u0646\u062a\u062c",
                                "av.seller.center.product.insert.success.subheading1": "Votre produit est ins\xe9r\xe9 avec succ\xe8s",
                                "av.seller.center.product.insert.success.subheading2": "Nous venons de vous envoyer un email de confirmation",
                                "av.seller.center.product.insert.success.helper": "Votre produit sera active dans quelque instants",
                                "av.adview.nc.lead.generation.modal.title": "\u0637\u0644\u0628 \u0627\u0644\u062a\u0648\u0627\u0635\u0644 \u0645\u0639  \u0627\u0644\u0645\u0639\u0644\u0646",
                                "av.adview.nc.lead.generation.modal.subtitle": "\u0627\u0644\u0645\u0631\u062c\u0648 \u0645\u0644\u0621 \u0627\u0644\u0627\u0633\u062a\u0645\u0627\u0631\u0629  \u0644\u0644\u062d\u0635\u0648\u0644 \u0639\u0644\u0649 \u0645\u0632\u064a\u062f \u0645\u0646 \u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062a",
                                "av.adview.nc.lead.generation.modal.form.name": "\u0627\u0644\u0625\u0633\u0645",
                                "av.adview.nc.lead.generation.modal.form.name.error": "\u0627\u0644\u0631\u062c\u0627\u0621 \u0625\u062f\u062e\u0627\u0644 \u0627\u0644\u0625\u0633\u0645 !",
                                "av.adview.nc.lead.generation.modal.form.phone": "\u0627\u0644\u0647\u0627\u062a\u0641",
                                "av.adview.nc.lead.generation.modal.form.phone.error": "\u0631\u0642\u0645 \u0647\u0627\u062a\u0641\u0643 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d!",
                                "av.adview.nc.lead.generation.modal.form.cgu.error": "\u064a\u0631\u062c\u0649 \u0642\u0628\u0648\u0644 \u0627\u0644\u0634\u0631\u0648\u0637 \u0648\u0627\u0644\u0623\u062d\u0643\u0627\u0645 \u0627\u0644\u0639\u0627\u0645\u0629 \u0644\u0644\u0627\u0633\u062a\u062e\u062f\u0627\u0645!",
                                "av.adview.nc.lead.generation.modal.form.success": "\u062a\u0645 \u0625\u0631\u0633\u0627\u0644 \u0627\u0644\u0637\u0644\u0628. \u0633\u0648\u0641 \u0646\u062a\u0635\u0644 \u0628\u0643 \u0641\u064a \u0623\u0642\u0631\u0628 \u0648\u0642\u062a \u0645\u0645\u0643\u0646",
                                "av.vertical.RE.homepage.our-promoters": "\u0645\u0646\u0639\u0634\u0648\u0646\u0627 \u0627\u0644\u0639\u0642\u0627\u0631\u064a\u0648\u0646",
                                "av.vertical.RE.homepage.our-agents": "\u0648\u0643\u0627\u0644\u0627\u062a \u0639\u0642\u0627\u0631\u064a\u0629",
                                "av.vertical.RE.homepage.hero.title": "\u0627\u062e\u062a\u064a\u0627\u0631\u0627\u062a \u0648\u0627\u0633\u0639\u0629 \u0641\u064a \u0627\u0644\u0639\u0642\u0627\u0631 \u0628\u0627\u0634 \u062a\u062d\u0642\u0642 \u0623\u062d\u0644\u0627\u0645\u0643",
                                "av.vertical.RE.homepage.searchbox.reset": "\u0645\u0633\u062d \u0627\u0644\u0641\u0644\u062a\u0631",
                                "av.vertical.RE.homepage.searchbox.propertyTypeLabel": "\u0627\u062e\u062a\u0631 \u0646\u0648\u0639 \u0627\u0644\u0639\u0642\u0627\u0631",
                                "av.vertical.RE.homepage.searchbox.villeLabel": "\u0627\u062e\u062a\u0631 \u0627\u0644\u0645\u062f\u064a\u0646\u0629",
                                "av.vertical.market": "\u0623\u0641\u064a\u062a\u0648  \u0645\u0627\u0631\u0643\u062a",
                                "av.vertical.vehicules": "\u0623\u0641\u064a\u062a\u0648  \u0644\u0644\u0639\u0631\u0628\u0627\u062a",
                                "av.vertical.immobilier": "\u0623\u0641\u064a\u062a\u0648 \u0644\u0644\u0639\u0642\u0627\u0631",
                                "av.vertical.entreprise": "\u0623\u0641\u064a\u062a\u0648  \u0644\u0644\u0634\u063a\u0644",
                                "av.vertical.market.short": "\u0645\u0627\u0631\u0643\u062a",
                                "av.vertical.vehicules.short": " \u0639\u0631\u0628\u0627\u062a",
                                "av.vertical.immobilier.short": "\u0639\u0642\u0627\u0631",
                                "av.vertical.entreprise.short": "\u0634\u063a\u0644 \u0648\u062e\u062f\u0645\u0627\u062a"
                            }
                        }).t,
                        lang: r.a.AR.CODE
                    }
                },
                s = (0, n.createContext)(i.fr)
        },
        73315: function(e, t, a) {
            "use strict";
            a.d(t, {
                ut: function() {
                    return d
                }
            });
            var n = a(59499),
                o = a(67294),
                r = a(93572),
                i = a(33728),
                s = a(51151),
                c = a(50216);
            a(85893);

            function u(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : u(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            s.Z;
            var d = function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                    a = (0, r.b)().getState().userProfile,
                    n = a.userId,
                    o = a.type,
                    s = a.email,
                    u = a.phone,
                    d = {
                        source: (0, i.eF)()
                    },
                    v = (0, i.tq)() ? "Mobile" : "Desktop";
                d.source = v, n && (d.user_id = Number(n)), o && (d.account_type = o), s && (d.email = s), u && (d.phone_number = u);
                try {
                    (0, c.R)(e, l(l({}, d), t))
                } catch (p) {
                    console.error("Error occured when tracking")
                }
            }
        },
        82361: function(e, t, a) {
            "use strict";
            a.d(t, {
                l: function() {
                    return o
                }
            });
            var n = a(42238),
                o = function(e) {
                    var t, a = n(e ? e.headers["user-agent"] || "" : navigator.userAgent),
                        o = null === a || void 0 === a || null === (t = a.device) || void 0 === t ? void 0 : t.type,
                        r = !1,
                        i = !1,
                        s = !1,
                        c = "";
                    switch (o) {
                        case "mobile":
                            r = !0, c = o;
                            break;
                        case "tablet":
                            i = !0, c = o;
                            break;
                        default:
                            s = !0, c = "desktop"
                    }
                    return {
                        isMobile: r,
                        isTablet: i,
                        isDesktop: s,
                        type: c,
                        userAgent: a
                    }
                }
        },
        33728: function(e, t, a) {
            "use strict";
            a.d(t, {
                C5: function() {
                    return n
                },
                eF: function() {
                    return r
                },
                sk: function() {
                    return o
                },
                tq: function() {
                    return i
                }
            });
            var n = !0,
                o = function() {
                    return !1
                },
                r = function() {
                    var e = "Desktop";
                    return n && window.innerWidth < 728 ? "Mobile" : e
                },
                i = function() {
                    return !!n && window.innerWidth < 728
                }
        },
        74324: function(e, t, a) {
            "use strict";
            a.d(t, {
                $Q: function() {
                    return R
                },
                $X: function() {
                    return N
                },
                BW: function() {
                    return S
                },
                Cw: function() {
                    return q
                },
                EM: function() {
                    return L
                },
                Ez: function() {
                    return D
                },
                HD: function() {
                    return C
                },
                Lt: function() {
                    return F
                },
                So: function() {
                    return A
                },
                Zg: function() {
                    return T
                },
                _T: function() {
                    return k
                },
                a5: function() {
                    return O
                },
                ap: function() {
                    return x
                },
                bQ: function() {
                    return V
                },
                dG: function() {
                    return P
                },
                eU: function() {
                    return z
                },
                hC: function() {
                    return I
                },
                lV: function() {
                    return E
                },
                mR: function() {
                    return b
                },
                mc: function() {
                    return w
                },
                oM: function() {
                    return f
                },
                oZ: function() {
                    return y
                },
                tT: function() {
                    return M
                },
                uX: function() {
                    return g
                },
                vN: function() {
                    return _
                },
                z6: function() {
                    return h
                },
                zW: function() {
                    return B
                }
            });
            var n = a(17674),
                o = a(59499),
                r = (a(87794), a(9494)),
                i = a(19598),
                s = a(43975),
                c = a(80925),
                u = (a(69449), a(16700)),
                l = a(35538),
                d = a(2849),
                v = a(33728);

            function p(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function m(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? p(Object(a), !0).forEach((function(t) {
                        (0, o.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : p(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var g = function(e) {
                    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1];
                    v.C5 && (window.location.href = e, window.location.pathname === e.split("#")[0] && t && window.location.reload(!0))
                },
                f = function(e) {
                    return "string" === typeof e ? e.replace(/<br>/gi, "\n") : ""
                };

            function h() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : c.DEFAULT_LANGUAGE;
                if (v.C5) {
                    (0, l.d8)(c.LANGUAGE_COOKIE_NAME, e);
                    var t = document.querySelector("html");
                    t.setAttribute("lang", e), t.setAttribute("dir", c.DIR_MAPPING[e])
                }
            }

            function y(e, t) {
                var a = null === e || void 0 === e ? void 0 : e.find((function(e) {
                    return (null === e || void 0 === e ? void 0 : e.key) === t
                }));
                return a ? a.value : null
            }

            function b(e, t) {
                var a = null === e || void 0 === e ? void 0 : e.find((function(e) {
                    return (null === e || void 0 === e ? void 0 : e.key) === t
                }));
                return a ? a.paramRawValue : null
            }

            function _(e, t) {
                var a = null === e || void 0 === e ? void 0 : e.find((function(e) {
                    return (null === e || void 0 === e ? void 0 : e.key) === t
                }));
                return a ? a.trackingValue : null
            }
            var A = function(e) {
                    return e ? new Date(e).getFullYear() : null
                },
                E = function(e) {
                    return "string" !== typeof e ? "" : e.toLowerCase().trim().replace(/["',/\\()\-: +]/g, "_")
                },
                S = function(e) {
                    return "string" !== typeof e ? "" : e.replace(/[_+]/g, " ")
                },
                R = function(e) {
                    try {
                        var t = e.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
                        return m(m({}, JSON.parse(decodeURIComponent((0, r.atob)(t).split("").map((function(e) {
                            return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2)
                        })).join("")))), {}, {
                            token: e
                        })
                    } catch (a) {
                        if (a) throw Error(a)
                    }
                };

            function C(e) {
                return "string" === typeof e && e.trim().length > 0
            }

            function D(e) {
                return C(e) ? e.replace(/[a-zA-Z]/, (function(e) {
                    return e.toUpperCase()
                })) : ""
            }

            function T(e) {
                var t, a, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "NFD";
                return C(String(e)) ? null === e || void 0 === e || null === (t = e.normalize(n)) || void 0 === t || null === (a = t.replace(/[\u0300-\u036f']/g, "")) || void 0 === a ? void 0 : a.toLowerCase() : ""
            }

            function P(e, t) {
                var a = e.label,
                    n = (0, i.nH)(T(a)),
                    o = (0, i.nH)(T(t));
                return n.includes(o)
            }

            function O(e) {
                var t, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return (null === e || void 0 === e ? void 0 : e.length) > 0 && "0" !== (null === (t = e[0]) || void 0 === t ? void 0 : t.value) ? null === e || void 0 === e ? void 0 : e.map((function(e) {
                    return null === e || void 0 === e ? void 0 : e.label
                })).join(", ") : a
            }
            var I = function(e) {
                    if (e) return Object.values(e).some(s.kK)
                },
                w = function(e, t) {
                    return "".concat(e).concat(-1 === e.indexOf("?") ? "?" : "&").concat(t)
                },
                L = function(e) {
                    return ["10000", "1000", "1010", "1020", "1050", "1060", "1080", "1090", "1090", "1200", "1300", "1400", "1500"].includes(String(e))
                },
                M = function(e) {
                    return ["20000", "2000", "2010", "2020", "2030", "2060", "2075", "2073", "2072", "2078", "2050", "2040", "2081", "2100"].includes(String(e))
                },
                x = function(e) {
                    var t = e.categoryId;
                    return String(t) === c.CAR_CATEGORY
                },
                N = function(e) {
                    return ["5000", "5010", "5080", "5030", "5050", "5060", "5040", "5070", "5090", "5020"].includes(String(e))
                },
                q = function(e, t) {
                    if ("object" !== typeof e) return null;
                    for (var a = {}, r = 0, i = Object.entries(t); r < i.length; r++) {
                        for (var s = (0, n.Z)(i[r], 2), c = s[0], u = s[1], l = c.split("."), d = e[l[0]], v = 1; v < l.length; v++) {
                            var p;
                            d = null === (p = d) || void 0 === p ? void 0 : p[l[v]]
                        }
                        var m = u.split(".");
                        m.length > 1 ? "object" === typeof a[m[0]] ? a[m[0]][m[1]] = d : a[m[0]] = (0, o.Z)({}, m[1], d) : a[m[0]] = d
                    }
                    return a
                };

            function k(e) {
                var t = e.categoryId;
                return L(t) ? "https://www.avito.ma/sp/immobilier/scripts/velw.min.js" : M(t) ? "https://www.avito.ma/sp/voitures/scripts/velw.min.js" : "https://www.avito.ma/sp/misc/scripts/velw.min.js"
            }
            var j = function(e) {
                    var t = e.vertical,
                        a = e.category,
                        n = e.subcategory,
                        o = e.lang;
                    return {
                        vertical_id: Number(null === t || void 0 === t ? void 0 : t.value) || null,
                        vertical_name: (null === t || void 0 === t ? void 0 : t.trackingName) || null,
                        category_id: Number(null === a || void 0 === a ? void 0 : a.value) || 0,
                        category_name: (null === a || void 0 === a ? void 0 : a.trackingName) || c.ALL_CATEGORIES_CONFIG.label[o],
                        subcategory_id: Number(null === n || void 0 === n ? void 0 : n.value) || null,
                        subcategory_name: (null === n || void 0 === n ? void 0 : n.trackingName) || ""
                    }
                },
                U = function(e, t) {
                    return {
                        vertical_name: (null === e || void 0 === e ? void 0 : e.trackingName) || c.ALL_CATEGORIES_CONFIG.label[t],
                        vertical_id: Number(null === e || void 0 === e ? void 0 : e.value) || 0,
                        category_id: null,
                        category_name: "",
                        subcategory_id: null,
                        subcategory_name: ""
                    }
                },
                V = function(e) {
                    var t, a = e.category,
                        n = e.type,
                        o = e.lang;
                    return (0, s.xb)(null === a || void 0 === a ? void 0 : a.parentPerAdType) ? null !== a && void 0 !== a && null !== (t = a.parent) && void 0 !== t && t.parent ? j({
                        vertical: a.parent.parent,
                        category: a.parent,
                        subcategory: a,
                        lang: o
                    }) : null !== a && void 0 !== a && a.parent ? j({
                        vertical: a.parent,
                        category: a,
                        subcategory: null,
                        lang: o
                    }) : U(a) : function(e, t, a) {
                        var n, o = null === (n = e.parentPerAdType) || void 0 === n ? void 0 : n[(null === t || void 0 === t ? void 0 : t.value) || "sell"];
                        return o ? j({
                            vertical: o.parent.parent,
                            category: o.parent,
                            subcategory: o,
                            lang: a
                        }) : U(e, a)
                    }(a, n, o)
                },
                z = function(e, t, a) {
                    return function(n) {
                        var o, r, i;
                        u.Z.error(t, {
                            error: null === n || void 0 === n || null === (o = n.toString) || void 0 === o ? void 0 : o.call(n),
                            variables: a
                        }), (0, d.n)((null === n || void 0 === n || null === (r = n.graphQLErrors) || void 0 === r || null === (i = r[0]) || void 0 === i ? void 0 : i.message) || e("av.common.error.wentWrong"), !0, "bottom-left")
                    }
                },
                B = function(e) {
                    return e.replace(/-([a-z])/g, (function(e, t) {
                        return t.toUpperCase()
                    }))
                };

            function F(e) {
                var t = R(e);
                return null !== t && void 0 !== t && t.sub || null !== t && void 0 !== t && t.accountId || null !== t && void 0 !== t && t.storeId ? {
                    sub: t.sub,
                    roles: t.roles,
                    name: t.name,
                    email: t.email,
                    allowedAccess: t.allowedAccess
                } : null
            }
        },
        61180: function(e, t, a) {
            "use strict";
            a.d(t, {
                IR: function() {
                    return y
                },
                Xm: function() {
                    return p
                },
                ZR: function() {
                    return h
                },
                Zj: function() {
                    return g
                },
                _b: function() {
                    return b
                },
                et: function() {
                    return v
                },
                qZ: function() {
                    return m
                },
                sW: function() {
                    return d
                },
                vn: function() {
                    return f
                }
            });
            var n = a(59499),
                o = a(23822),
                r = a(62107),
                i = a(76871),
                s = a(95271),
                c = a(80925);

            function u(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function l(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? u(Object(a), !0).forEach((function(t) {
                        (0, n.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : u(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }
            var d = {
                    PRODUCTS: {
                        NAME: "my-products",
                        TAB: "Mes produits",
                        LABEL: "av.common.seller.my-products",
                        PATH: "seller.my-products"
                    },
                    ORDERS: {
                        NAME: "my-orders",
                        TAB: "Mes commandes",
                        LABEL: "av.common.my-orders",
                        PATH: "seller.my-orders"
                    },
                    PAYMENTS: {
                        NAME: "my-payments",
                        TAB: "Mes paiements",
                        LABEL: "av.common.seller.my-payments",
                        PATH: "seller.my-payments"
                    },
                    SETTINGS: {
                        NAME: "settings",
                        TAB: "R\xe9glages",
                        LABEL: "av.common.settings.short",
                        PATH: "account.settings"
                    }
                },
                v = [{
                    icon: "Myproducts",
                    iconLine: "MyproductsLine",
                    label: d.PRODUCTS.LABEL,
                    text: d.PRODUCTS.NAME,
                    path: d.PRODUCTS.PATH,
                    tab: d.PRODUCTS.TAB
                }, {
                    icon: "CartFill",
                    iconLine: "CartLine",
                    label: d.ORDERS.LABEL,
                    text: d.ORDERS.NAME,
                    path: d.ORDERS.PATH,
                    tab: d.ORDERS.TAB
                }, {
                    icon: "Myorders",
                    iconLine: "MyordersLine",
                    label: d.PAYMENTS.LABEL,
                    text: d.PAYMENTS.NAME,
                    path: d.PAYMENTS.PATH,
                    tab: d.PAYMENTS.TAB
                }, {
                    icon: "Settings",
                    iconLine: "Settings3Line",
                    label: d.SETTINGS.LABEL,
                    text: d.SETTINGS.NAME,
                    path: d.SETTINGS.PATH,
                    tab: d.SETTINGS.TAB
                }],
                p = 8,
                m = function(e, t) {
                    var a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "header",
                        o = arguments.length > 3 ? arguments[3] : void 0,
                        r = arguments.length > 4 ? arguments[4] : void 0,
                        i = Object.keys(t);
                    return r && Object.keys(r).forEach((function(e) {
                        e === o && (i = i.filter((function(t) {
                            return !r[e].includes(t)
                        })))
                    })), i.reduce((function(o, r) {
                        return l(l({}, o), {}, (0, n.Z)({}, r, l(l({}, t[r]), {}, (0, n.Z)({}, a, e(t[r][a])))))
                    }), {})
                },
                g = function(e, t, a) {
                    var n = !(arguments.length > 3 && void 0 !== arguments[3]) || arguments[3];
                    return t.map((function(t) {
                        return l(l({}, t), {}, {
                            label: "".concat(e(t.label), " ").concat(n ? "" : "(".concat(null === a || void 0 === a ? void 0 : a[t.value], ")")),
                            stats: null === a || void 0 === a ? void 0 : a[t.value]
                        })
                    }))
                },
                f = function(e, t, a, o, r, i, s, c, u) {
                    var d, v;
                    return null === (d = t[a]) || void 0 === d || null === (v = d[o]) || void 0 === v ? void 0 : v.map((function(t) {
                        var a, o, d = i[t],
                            v = d.label,
                            p = d.noDisable,
                            m = void 0 !== p && p;
                        return l(l({}, i[t]), {}, (o = {
                            label: e(v)
                        }, (0, n.Z)(o, r, null === (a = s[t]) || void 0 === a ? void 0 : a.call(s, c)), (0, n.Z)(o, "disabled", !m && u), o))
                    }))
                },
                h = function(e) {
                    var t = e.items,
                        a = e.idKey,
                        n = e.dispatch;
                    return function(e) {
                        var o, r;
                        n((0, s.WR)({
                            element_name: "see_onsite",
                            page_name: "sku" === a ? c.PAGE_NAME.MY_PRODUCTS : c.PAGE_NAME.MY_ORDERS
                        }));
                        var u = null === t || void 0 === t || null === (o = t.filter((function(t) {
                            return t[a] === e
                        }))) || void 0 === o || null === (r = o[0]) || void 0 === r ? void 0 : r.listId;
                        u && window.open("".concat(i.baseUrl, "/vi/").concat(u, ".htm"))
                    }
                },
                y = function(e) {
                    return function() {
                        return o.Router.pushRoute((0, r.DW)({
                            key: "seller.my-orders",
                            lang: e
                        }))
                    }
                },
                b = function(e, t, a, i, s) {
                    var c = t.from,
                        u = t.to,
                        l = a.stateKey,
                        d = a.itemsKey,
                        v = a.idKey,
                        p = void 0 === v ? "id" : v,
                        m = a.itemId,
                        g = a.page,
                        f = a.pathKey,
                        h = s.updateItems,
                        y = s.updateItemsCountByStatus,
                        b = e[l],
                        _ = b[d][c],
                        A = b.counts,
                        E = A[c],
                        S = A[u],
                        R = e.page.lang,
                        C = null === _ || void 0 === _ ? void 0 : _.filter((function(e) {
                            return e[p] !== m
                        }));
                    if (0 === (null === C || void 0 === C ? void 0 : C.length) && g > 1) {
                        var D = g - 1;
                        o.Router.pushRoute("".concat((0, r.DW)({
                            key: f,
                            lang: R
                        }), "?status=").concat(c, "&page=").concat(D), {
                            shallow: !0
                        })
                    } else {
                        var T;
                        if (h) i(h((T = {
                            status: c
                        }, (0, n.Z)(T, d, C), (0, n.Z)(T, "count", E - 1), T)))
                    }
                    y && i(y({
                        status: u,
                        count: S + 1
                    }))
                }
        },
        50216: function(e, t, a) {
            "use strict";
            a.d(t, {
                R: function() {
                    return i
                }
            });
            var n = a(51151),
                o = a(77596),
                r = n.Z.broadcast,
                i = function e(t, a) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : r;
                    "undefined" !== typeof window[o.r] ? n(t, a) : setTimeout(e, 250, t, a)
                }
        },
        67954: function(e, t, a) {
            "use strict";
            a.d(t, {
                Z: function() {
                    return E
                }
            });
            var n = a(50029),
                o = a(59499),
                r = a(92777),
                i = a(82262),
                s = a(45959),
                c = a(72179),
                u = a(37247),
                l = a(87794),
                d = a.n(l),
                v = a(67294),
                p = a(90116),
                m = a(45217),
                g = (a(28500), a(27256));

            function f() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    t = arguments.length > 1 ? arguments[1] : void 0,
                    a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : g.Z,
                    n = function(e) {
                        return e
                    };
                return (0, m.MT)(t, e, n(m.md.apply(void 0, (0, p.Z)(a))))
            }
            var h = a(85893);

            function y(e, t) {
                var a = Object.keys(e);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(e);
                    t && (n = n.filter((function(t) {
                        return Object.getOwnPropertyDescriptor(e, t).enumerable
                    }))), a.push.apply(a, n)
                }
                return a
            }

            function b(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? y(Object(a), !0).forEach((function(t) {
                        (0, o.Z)(e, t, a[t])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : y(Object(a)).forEach((function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t))
                    }))
                }
                return e
            }

            function _(e) {
                var t = function() {
                    if ("undefined" === typeof Reflect || !Reflect.construct) return !1;
                    if (Reflect.construct.sham) return !1;
                    if ("function" === typeof Proxy) return !0;
                    try {
                        return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], (function() {}))), !0
                    } catch (e) {
                        return !1
                    }
                }();
                return function() {
                    var a, n = (0, u.Z)(e);
                    if (t) {
                        var o = (0, u.Z)(this).constructor;
                        a = Reflect.construct(n, arguments, o)
                    } else a = n.apply(this, arguments);
                    return (0, c.Z)(this, a)
                }
            }

            function A(e, t, a) {
                var n = arguments.length > 3 && void 0 !== arguments[3] && arguments[3];
                return window.__NEXT_REDUX_STORE__ && !n || (window.__NEXT_REDUX_STORE__ = f(e, t, a)), window.__NEXT_REDUX_STORE__
            }
            var E = function(e, t, a) {
                return function(o) {
                    var c = function(c) {
                        (0, s.Z)(l, c);
                        var u = _(l);

                        function l() {
                            return (0, r.Z)(this, l), u.apply(this, arguments)
                        }
                        return (0, i.Z)(l, [{
                            key: "render",
                            value: function() {
                                return (0, h.jsx)(o, b({}, this.props))
                            }
                        }], [{
                            key: "getInitialProps",
                            value: function() {
                                var r = (0, n.Z)(d().mark((function n(r) {
                                    var i, s;
                                    return d().wrap((function(n) {
                                        for (;;) switch (n.prev = n.next) {
                                            case 0:
                                                if (i = A({}, e, t, a), r.reduxStore = i, s = {}, !o.getInitialProps) {
                                                    n.next = 7;
                                                    break
                                                }
                                                return n.next = 6, o.getInitialProps(r);
                                            case 6:
                                                s = n.sent;
                                            case 7:
                                                return n.abrupt("return", b(b({}, s), {}, {
                                                    reduxStore: i,
                                                    initialReduxState: i.getState()
                                                }));
                                            case 8:
                                            case "end":
                                                return n.stop()
                                        }
                                    }), n)
                                })));
                                return function(e) {
                                    return r.apply(this, arguments)
                                }
                            }()
                        }, {
                            key: "getStore",
                            value: function(a) {
                                return A(a, e, t)
                            }
                        }]), l
                    }(v.Component);
                    return c
                }
            }
        }
    }
]);