import {
    a7 as e,
    em as t,
    en as a,
    eo as n,
    ep as r,
    eq as s,
    aW as i,
    er as o,
    bm as c,
    es as d,
    a8 as p,
    aU as l,
    D as u,
    u as h,
    et as m,
    cT as g,
    eu as v,
    ev as f,
    ew as _,
    ex as y,
    ey as I,
    ez as S,
    bq as C,
    eA as b,
    al as T,
    eB as E,
    eC as w,
    eD as k,
    eE as A,
    eF as N,
    eG as q,
    eH as O,
    eI as P,
    eJ as F,
    eK as U,
    eL as x,
    eM as L,
    eN as j,
    eO as D,
    eP as M,
    eQ as z,
    eR as G,
    eS as R,
    eT as V,
    eU as H,
    eV as B,
    eW as J,
    eX as Q,
    eY as W,
    eZ as Z,
    e_ as Y,
    e$ as K,
    f0 as X,
    f1 as $,
    f2 as ee,
    f3 as te,
    f4 as ae,
    f5 as ne,
    f6 as re,
    f7 as se,
    f8 as ie,
    f9 as oe,
    fa as ce,
    a2 as de,
    Y as pe,
    L as le,
    bQ as ue,
    O as he,
    cw as me,
    an as ge,
    aQ as ve,
    p as fe,
    m as _e,
    fb as ye,
    fc as Ie,
    y as Se,
    fd as Ce,
    A as be,
    aw as Te,
    aF as Ee,
    fe as we,
    S as ke,
    ff as Ae,
    fg as Ne,
    fh as qe,
    $ as Oe,
    aI as Pe,
    fi as Fe,
    bI as Ue,
    fj as xe,
    fk as Le,
    fl as je,
    i as De,
    aM as Me,
    x as ze,
    fm as Ge,
    P as Re,
    fn as Ve,
    fo as He,
    fp as Be,
    R as Je,
    C as Qe,
    I as We,
    ae as Ze,
    dZ as Ye,
    ao as Ke,
    s as Xe,
    cg as $e,
    V as et,
    aR as tt,
    fq as at,
    fr as nt,
    E as rt,
    f as st,
    a0 as it,
    fs as ot,
    ds as ct,
    ft as dt,
    fu as pt,
    fv as lt,
    a1 as ut,
    fw as ht,
    cE as mt,
    dm as gt,
    fx as vt,
    fy as ft,
    e as _t,
    fz as yt,
    T as It,
    fA as St,
    aJ as Ct,
    fB as bt,
    dq as Tt,
    dU as Et,
    af as wt,
    fC as kt,
    fD as At,
    fE as Nt,
    fF as qt,
    fG as Ot,
    dJ as Pt,
    fH as Ft,
    fI as Ut,
    U as xt,
    aS as Lt,
    B as jt,
    di as Dt,
    fJ as Mt,
    fK as zt,
    X as Gt,
    fL as Rt,
    w as Vt,
    fM as Ht,
    dS as Bt,
    fN as Jt,
    fO as Qt,
    fP as Wt,
    aA as Zt,
    fQ as Yt,
    fR as Kt,
    fS as Xt,
    K as $t,
    am as ea,
    fT as ta,
    fU as aa,
    fV as na,
    ec as ra,
    dz as sa,
    dW as ia,
    Q as oa,
    fW as ca,
    cz as da,
    aT as pa,
    fX as la,
    bu as ua,
    bF as ha,
    a3 as ma,
    fY as ga,
    fZ as va,
    f_ as fa
} from "./3.BD1ZN3cS.chunk.js";
import {
    m as _a,
    b as ya,
    f as Ia,
    n as Sa,
    O as Ca,
    e as ba,
    w as Ta,
    t as Ea,
    a as wa,
    j as ka,
    h as Aa,
    x as Na,
    v as qa
} from "./5.8dnJ5-bs.chunk.js";
import {
    bY as Oa,
    bZ as Pa,
    b_ as Fa,
    i as Ua,
    b$ as xa,
    f as La,
    g as ja,
    p as Da
} from "./2.D03LlXhc.chunk.js";
import {
    v as Ma,
    c as za,
    h as Ga,
    t as Ra,
    s as Va
} from "./1.0YlIgwiB.chunk.js";
import {
    j as Ha,
    e as Ba,
    k as Ja,
    i as Qa
} from "./6.CKlS54Ol.chunk.js";
import {
    p as Wa,
    a as Za,
    b as Ya,
    d as Ka,
    e as Xa,
    f as $a,
    g as en,
    h as tn,
    i as an,
    j as nn,
    t as rn,
    k as sn,
    l as on,
    m as cn,
    n as dn,
    c as pn
} from "./7.CK1t1i3G.chunk.js";
import {
    k as ln
} from "./4.C_rgEAoe.chunk.js";
import {
    i as un
} from "./9.qYTqns9Q.chunk.js";
import {
    l as hn,
    a as mn,
    g as gn,
    b as vn,
    c as fn,
    d as _n,
    e as yn,
    h as In,
    i as Sn,
    j as Cn,
    k as bn,
    f as Tn,
    m as En
} from "./10.CxXa92i0.chunk.js";
import "./13.Du4z9uvj.chunk.js";
import "./11.Gv78iMd6.chunk.js";
import "./12.DJPUQwQu.chunk.js";
import "./8.yej6kGWr.chunk.js";

function wn(e, t) {
    if (0 === e) {
        var a = !1;
        t(0, (function(e) {
            2 === e && (a = !0)
        })), a || t(2)
    }
}
const kn = (An = () => wn, e => (t, a) => {
    if (0 !== t) return;
    let n, r = !1;
    const s = (e, t) => {
            n(e, t)
        },
        i = (e, t) => {
            if (0 === e) return n = t, r ? void s(1) : void a(e, s);
            if (2 === e && t && !r) {
                r = !0;
                try {
                    An(t)(0, i)
                } catch (o) {
                    a(2, o)
                }
            } else a(e, t)
        };
    e(t, i)
});
var An, Nn = function() {};

function qn(e, t) {
    0 === e && t(0, Nn)
}

function On() {
    for (var e = arguments.length, t = new Array(e), a = 0; a < e; a++) t[a] = arguments[a];
    return function(e, a) {
        if (0 === e) {
            var n = !1;
            for (a(0, (function(e) {
                    2 === e && (n = !0, t.length = 0)
                })); 0 !== t.length;) a(1, t.shift());
            n || a(2)
        }
    }
}

function Pn(e, t) {
    return [e, t]
}

function Fn(e, t) {
    let a, n = Date.now() - 2 * e;
    const r = function() {
            return n = Date.now(), t(...arguments)
        },
        s = () => clearTimeout(a),
        i = function() {
            const t = Date.now();
            t - n >= e && (n = Date.now()), s();
            for (var i = arguments.length, o = new Array(i), c = 0; c < i; c++) o[c] = arguments[c];
            a = setTimeout(r, n - t + e, ...o)
        };
    return i.cancel = s, i
}
const Un = e => {
        const t = {};
        return "string" == typeof e.customId && (t.custom_id = e.customId), i(e.properties) && (t.properties = e.properties), t
    },
    xn = e => {
        switch (e.type) {
            case s:
                {
                    const t = { ...Un(e),
                        type: e.type,
                        text: e.text
                    };
                    return e.postback && (t.postback = {
                        id: e.postback.id,
                        thread_id: e.postback.threadId,
                        event_id: e.postback.eventId,
                        type: e.postback.type,
                        value: e.postback.value
                    }),
                    t
                }
            case r:
                return { ...Un(e),
                    type: e.type,
                    url: e.url,
                    alternative_text: e.alternativeText
                };
            case n:
                return { ...Un(e),
                    type: e.type,
                    form_id: e.formId,
                    fields: e.fields.map(e => {
                        switch (e.type) {
                            case "group_chooser":
                                {
                                    if (!e.answer) return e;
                                    const {
                                        groupId: t,
                                        ...a
                                    } = e.answer;
                                    return { ...e,
                                        answer: { ...a,
                                            group_id: t
                                        }
                                    }
                                }
                            default:
                                return e
                        }
                    })
                };
            case a:
                {
                    const t = { ...Un(e),
                        type: e.type,
                        text: e.text,
                        system_message_type: e.systemMessageType
                    };
                    return e.recipients && (t.recipients = e.recipients),
                    t
                }
            case t:
                {
                    const t = { ...Un(e),
                        type: e.type
                    };
                    return e.content && (t.content = e.content),
                    t
                }
        }
    },
    Ln = e => {
        let {
            active: t = !0,
            chat: a,
            continuous: n
        } = e;
        const r = {
            active: t,
            chat: {}
        };
        if ("boolean" == typeof n && (r.continuous = n), !a) return r;
        const {
            access: s,
            thread: i,
            properties: o
        } = a;
        return s && s.groupIds && (r.chat.access = {
            group_ids: s.groupIds
        }), o && (r.chat.properties = o), i && (r.chat.thread = (e => {
            const t = {},
                {
                    events: a,
                    properties: n
                } = e;
            return a && (t.events = a.map(xn)), n && (t.properties = n), t
        })(i)), r
    },
    jn = e => Ha(e).map(e => {
        let [t, a] = e;
        return {
            [t]: a
        }
    }),
    Dn = t => {
        const a = e(["avatar", "name", "email"], t);
        return t.sessionFields && (a.session_fields = jn(t.sessionFields)), a
    },
    Mn = e => ({
        type: "destroy",
        payload: {
            reason: e
        }
    }),
    zn = e => ({
        type: "pause_connection",
        payload: {
            reason: e
        }
    }),
    Gn = function(e) {
        return void 0 === e && (e = !1), {
            type: "prefetch_token",
            payload: {
                fresh: e
            }
        }
    },
    Rn = e => ({
        type: "reconnect",
        payload: {
            delay: e
        }
    }),
    Vn = (e, t, a) => ({
        type: "send_request",
        payload: {
            request: {
                action: e,
                payload: t
            },
            ...a && {
                source: a
            }
        }
    }),
    Hn = (e, t) => ({
        type: "set_chat_active",
        payload: {
            id: e,
            active: t
        }
    }),
    Bn = e => ({
        type: "set_self_id",
        payload: {
            id: e
        }
    });

function Jn(e) {
    let {
        message: t,
        code: a
    } = e;
    const n = new Error(t);
    return n.code = a, n
}
const Qn = e => e.connection.status,
    Wn = (e, t) => e.requests[t],
    Zn = e => e.users.self.id,
    Yn = (e, t) => {
        const a = e.chats[t];
        return !!a && a.active
    },
    Kn = e => "connected" === Qn(e),
    Xn = e => {
        var t;
        return {
            "x-region": null != (t = e.region) ? t : ""
        }
    },
    $n = e => (e => {
        const {
            region: t
        } = e;
        return "https://api" + (!t || "fra" !== t && "eu-west3" !== t ? "" : "-fra") + (e => {
            let {
                env: t
            } = e;
            return "production" === t ? "" : "." + t
        })(e) + ".livechatinc.com"
    })(e) + "/v3.5/customer",
    er = (e, t) => {
        let {
            id: a
        } = t;
        const {
            [a]: n, ...r
        } = e.requests;
        return { ...e,
            requests: r
        }
    },
    tr = (e, t) => ({ ...t,
        connection: { ...t.connection,
            status: e
        }
    });

function ar(e) {
    const t = Ua,
        a = Oa(),
        n = Pa((r = (e => {
            const {
                application: t = {},
                organizationId: a,
                groupId: n = null,
                env: r,
                page: s = null,
                region: i = null,
                referrer: o = null,
                uniqueGroups: c = !1,
                mobile: p = !1
            } = e;
            return {
                application: { ...t,
                    name: "chat_widget",
                    version: "23a998ddf812f42e31f88723b5aa6a0e3c5487af"
                },
                organizationId: a,
                env: r,
                groupId: n,
                chats: {},
                connection: {
                    status: "disconnected"
                },
                page: s,
                region: i,
                referrer: o,
                requests: {},
                users: {
                    self: {
                        id: null,
                        type: d
                    },
                    others: {}
                },
                uniqueGroups: c,
                mobile: p
            }
        })(e), c(r, {
            change_region: (e, t) => {
                let {
                    region: a
                } = t;
                return { ...e,
                    region: a
                }
            },
            destroy: e => tr("destroyed", e),
            login_success: e => tr("connected", e),
            pause_connection: e => tr("paused", e),
            request_failed: er,
            response_received: er,
            push_response_received: er,
            send_request: (e, t) => {
                let {
                    promise: a,
                    resolve: n,
                    reject: r,
                    id: s,
                    request: i
                } = t;
                return { ...e,
                    requests: { ...e.requests,
                        [s]: {
                            id: s,
                            promise: a,
                            resolve: n,
                            reject: r,
                            request: i
                        }
                    }
                }
            },
            set_chat_active: (e, t) => {
                let {
                    id: a,
                    active: n
                } = t;
                return { ...e,
                    chats: { ...e.chats,
                        [a]: { ...e.chats[a],
                            active: n
                        }
                    }
                }
            },
            set_self_id: (e, t) => ({ ...e,
                users: { ...e.users,
                    self: { ...e.users.self,
                        id: t.id
                    }
                }
            }),
            socket_disconnected: e => {
                const t = Qn(e);
                return { ...tr("disconnected" === t ? "disconnected" : "reconnecting", e),
                    requests: {}
                }
            },
            update_customer_page: (e, t) => ({ ...e,
                page: { ...e.page,
                    ...t
                }
            }),
            clear_sensitive_session_state: e => ({ ...e,
                chats: {},
                users: {
                    self: {
                        id: null,
                        type: d
                    },
                    others: {}
                },
                requests: {}
            }),
            identity_changed: e => e
        })), t(Fa(a)));
    var r;
    return n.addSideEffectsHandler = a.add, n
}
const nr = e => {
        let {
            env: t,
            organizationId: a,
            eventName: n
        } = e;
        return Promise.resolve()
    },
    rr = (e, t) => {
        t.payload.id = p(e.getState().requests);
        const {
            resolve: a,
            reject: n,
            promise: r
        } = l();
        return t.payload.promise = r, t.payload.resolve = a, t.payload.reject = n, e.dispatch(t), r
    },
    sr = e => {
        const {
            organizationId: t,
            groupId: a,
            uniqueGroups: n
        } = e.getState();
        return "side_storage_" + t + (n ? ":" + a : "")
    },
    ir = (e, t) => {
        const a = u(t),
            n = sr(e);
        return a.getItem(n).catch(Sa).then(e => JSON.parse(e || "{}")).catch(Sa)
    },
    or = (e, t) => {
        let {
            getState: a,
            dispatch: n
        } = e;
        const r = (e => e.requests)(a());
        n({
            type: "fail_all_requests",
            payload: {
                rejects: Object.keys(r).map(e => r[e].reject),
                reason: t
            }
        })
    },
    cr = (e, t, a) => {
        let {
            getState: n,
            dispatch: r
        } = e;
        const s = t.payload.id;
        r({
            type: "request_failed",
            payload: {
                id: s,
                reject: n().requests[s].reject,
                error: a
            }
        })
    },
    dr = (e, t, a) => rr(e, Vn(t, a, "login"));

function pr(e, t, a, n) {
    let r, s, i = null;
    const o = {
            min: 300,
            max: 6e4,
            jitter: .3
        },
        c = xa(o),
        d = xa({ ...o,
            min: 1e3
        });
    let p = c;
    const l = e => r.dispatch(Mn(e)),
        h = () => r.dispatch(Rn(p.duration())),
        m = () => Promise.all([e.getToken(), ir(r, n)]),
        _ = e => {
            let [t, a] = e;
            const s = Zn(r.getState());
            if (null === s) r.dispatch(Bn(t.entityId));
            else if (s !== t.entityId) return n && ((e, t) => {
                u(t).removeItem(sr(e)).catch(Sa)
            })(r, n), r.dispatch({
                type: "clear_sensitive_session_state"
            }), r.dispatch(Bn(t.entityId)), r.dispatch({
                type: "identity_changed",
                payload: {
                    previousId: s,
                    newId: t.entityId
                }
            }), [t, {}];
            return [t, a]
        },
        y = e => {
            let [a, n] = e;
            const s = r.getState(),
                {
                    application: o,
                    groupId: c,
                    page: d,
                    referrer: p,
                    mobile: l
                } = s,
                u = {
                    token: a.tokenType + " " + a.accessToken,
                    customer: "function" == typeof t ? Dn(t()) : {},
                    customer_side_storage: n,
                    is_mobile: l,
                    application: g(["name", "version"], o)
                };
            return u.c = (e => {
                let [t, a] = e;
                return Array.from("" + t + a).reduce((e, t) => e + t["tAedoCrahc".split("").reverse().join("")](0), 0) % 1024
            })((e => [e.organizationId, e.users.self.id])(s)), "number" == typeof c && (u.group_id = c), o.channelType && (u.application.channel_type = o.channelType), null !== d && (i = d, u.customer_page = d), null !== p && (u.referrer = p), Promise.race([dr(r, v, u), (h = 15e3, new Promise(e => {
                setTimeout(e, h)
            })).then(() => Promise.reject(Jn({
                message: "Request timed out.",
                code: "REQUEST_TIMEOUT"
            })))]);
            var h
        };
    return {
        sendLogin: t => {
            var a;
            r = t, null == (a = s) || a.cancel(), s = ((e, t, a) => {
                let [...n] = e, r = !1;
                const s = e => {
                    const i = n.shift();
                    Ca(() => i(e)).then(e => {
                        r || (n.length ? s(e) : t(e))
                    }, e => {
                        r || a(e)
                    })
                };
                return s(), {
                    cancel() {
                        r = !0
                    }
                }
            })([m, _, y], e => {
                s = null, c.reset(), d.reset(), p = c, (() => {
                    const {
                        page: e
                    } = r.getState();
                    i !== e && dr(r, f, e).catch(Sa), i = null
                })(), r.dispatch({
                    type: "login_success",
                    payload: e
                })
            }, t => {
                switch (s = null, t.code) {
                    case "AUTHENTICATION":
                        return e.getFreshToken(), void h();
                    case "CONNECTION_LOST":
                    case "MISDIRECTED_CONNECTION":
                    case "SDK_DESTROYED":
                        return;
                    case "SSO_IDENTITY_EXCEPTION":
                    case "SSO_OAUTH_EXCEPTION":
                        return "server_error" === t.message || "temporarily_unavailable" === t.message ? void h() : void l(t.message);
                    case "USERS_LIMIT_REACHED":
                        return void r.dispatch(zn(t.code.toLowerCase()));
                    case "CUSTOMER_BANNED":
                    case "WRONG_PRODUCT_VERSION":
                        return void l(t.code.toLowerCase());
                    case "SERVICE_TEMPORARILY_UNAVAILABLE":
                        return p = d, void h();
                    default:
                        return void h()
                }
            })
        },
        cancel: () => {
            var e;
            null == (e = s) || e.cancel()
        }
    }
}
const lr = {
        CONNECTION_LOST: "Connection lost.",
        MISDIRECTED_CONNECTION: "Connected to wrong region."
    },
    ur = (e, t) => {
        const a = e.getState();
        switch (t.type) {
            case "push_response_received":
            case "push_received":
                switch (t.payload.action) {
                    case S:
                        return void e.dispatch(Hn(t.payload.payload.chatId, !1));
                    case I:
                        return void e.dispatch(Hn(t.payload.payload.chat.id, !0));
                    default:
                        return
                }
            case "response_received":
                switch (t.payload.action) {
                    case y:
                        return void t.payload.payload.chatsSummary.filter(e => {
                            let {
                                id: t,
                                active: n
                            } = e;
                            return Yn(a, t) !== n
                        }).forEach(t => {
                            let {
                                id: a,
                                active: n
                            } = t;
                            e.dispatch(Hn(a, n))
                        });
                    default:
                        return
                }
        }
    },
    hr = (e, t) => {
        t.forEach(t => {
            if ("present" in t) {
                const {
                    present: a,
                    ...n
                } = t;
                e("user_data", n)
            } else if (t.type !== d) e("user_data", t);
            else {
                const {
                    statistics: a,
                    ...n
                } = t;
                e("user_data", n)
            }
        })
    },
    mr = (e, t, a) => {
        let {
            emit: n,
            store: r
        } = e, {
            payload: s
        } = t;
        switch (s.action) {
            case F:
                return s.payload.properties.lc2 && "queue_pos" in s.payload.properties.lc2 && n(U, {
                    chatId: s.payload.chatId,
                    threadId: s.payload.threadId,
                    queue: {
                        position: s.payload.properties.lc2.queue_pos,
                        waitTime: s.payload.properties.lc2.queue_waiting_time
                    }
                }), void n("thread_properties_updated", s.payload);
            case P:
                return void((e, t, a) => {
                    u(a).setItem(sr(e), JSON.stringify(t)).catch(Sa)
                })(r, s.payload.customer_side_storage, a);
            case _:
                switch (s.payload.reason) {
                    case "access_token_expired":
                        r.dispatch(Gn(!0)), r.dispatch(Rn(100)), n("disconnected", s.payload);
                        break;
                    case "customer_banned":
                    case "customer_temporarily_blocked":
                    case "license_not_found":
                    case "product_version_changed":
                    case "too_many_connections":
                    case "unsupported_version":
                    case "logged_out_remotely":
                        r.dispatch(Mn(s.payload.reason));
                        break;
                    case "misdirected_connection":
                        or(r, "MISDIRECTED_CONNECTION"), r.dispatch({
                            type: "change_region",
                            payload: s.payload.data
                        });
                        break;
                    case "service_temporarily_unavailable":
                    case "too_many_unauthorized_connections":
                        or(r, s.payload.reason.toUpperCase());
                        break;
                    default:
                        r.dispatch(Rn(100)), n("disconnected", s.payload)
                }
                return;
            case q:
                {
                    const [e] = s.payload.groups;
                    return void n("availability_updated", {
                        availability: O(e.status)
                    })
                }
            case I:
                return hr(n, s.payload.chat.users), void n(s.action, s.payload);
            case N:
                if (null === s.payload.event) return;
                return void n(s.action, s.payload);
            case A:
            case k:
            case w:
                return void n(s.action, s.payload);
            case E:
                return hr(n, [s.payload.user]), void n(s.action, s.payload);
            default:
                return void n(s.action, s.payload)
        }
    },
    gr = (e, t) => {
        let {
            emit: a
        } = e, {
            payload: n
        } = t;
        switch (n.action) {
            case S:
                return void n.resolve(L);
            case x:
                return hr(a, n.payload.users), void n.resolve(n.payload);
            case I:
                return hr(a, n.payload.chat.users), void n.resolve(n.payload);
            case N:
                return void n.resolve(n.payload.event);
            case y:
                return hr(a, n.payload.users), void n.resolve(n.payload);
            default:
                return void n.resolve(n.payload)
        }
    },
    vr = e => {
        let {
            auth: t,
            customerDataProvider: a,
            emitter: n,
            socket: r,
            licenseId: s,
            parentStorage: i,
            hasCustomIdentityProvider: o
        } = e;
        const {
            emit: c
        } = n, d = pr(t, a, 0, i);
        return (e, a) => {
            switch (e.type) {
                case "change_region":
                    return void r.reinitialize();
                case "check_goals":
                    return void((e, t, a) => t.getToken().then(t => {
                        const n = e.getState();
                        null === Zn(n) && e.dispatch(Bn(t.entityId));
                        const {
                            page: r
                        } = n;
                        if (!r || !r.url) return;
                        const s = Ba({
                                organization_id: n.organizationId,
                                ...Xn(n)
                            }),
                            i = {
                                session_fields: jn(a || {}),
                                group_id: n.groupId || 0,
                                page_url: r.url
                            };
                        return h($n(n) + "/action/" + m + "?" + s, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                                Authorization: t.tokenType + " " + t.accessToken
                            },
                            body: JSON.stringify(i)
                        }).then(() => {})
                    }))(a, t, e.payload.sessionFields).catch(Sa);
                case "destroy":
                    {
                        const {
                            payload: t
                        } = e;
                        switch (d.cancel(), r.destroy(), t.reason) {
                            case "manual":
                                or(a, "SDK_DESTROYED");
                                break;
                            case "customer_banned":
                            case "license_expired":
                            case "product_version_changed":
                            case "logged_out_remotely":
                                or(a, "CONNECTION_LOST"), c("disconnected", t);
                                break;
                            default:
                                c("disconnected", t)
                        }
                        return void n.off()
                    }
                case "fail_all_requests":
                    {
                        const {
                            reason: t,
                            rejects: a
                        } = e.payload,
                        n = {
                            message: lr[t],
                            code: t
                        };
                        return void a.forEach(e => {
                            e(Jn(n))
                        })
                    }
                case "login_success":
                    {
                        const {
                            dynamicConfig: t,
                            customer: a,
                            chats: n,
                            greeting: r,
                            availability: s
                        } = e.payload,
                        i = {
                            customer: a,
                            availability: s,
                            ...r && {
                                greeting: r
                            }
                        };
                        return Object.defineProperty(i, "__unsafeDynamicConfig", {
                            value: t
                        }),
                        Object.defineProperty(i, "__unsafeChats", {
                            value: n
                        }),
                        void c("connected", i)
                    }
                case "pause_connection":
                    {
                        const {
                            payload: t
                        } = e;
                        return r.disconnect(),
                        void("manual" !== t.reason && c("disconnected", t))
                    }
                case "prefetch_token":
                    return e.payload.fresh ? void t.getFreshToken().catch(Sa) : void t.hasToken().then(e => e ? t.getToken().then(e => {
                        let {
                            creationDate: a,
                            expiresIn: n
                        } = e;
                        if (!(a + n - Date.now() > 36e5)) return t.invalidate().then(t.getFreshToken)
                    }) : t.getToken()).catch(Sa);
                case "push_received":
                    return e.payload.action === _ || ur(a, e), void mr({
                        emit: c,
                        store: a
                    }, e, i);
                case "push_response_received":
                    return ur(a, e), void gr({
                        emit: c
                    }, e);
                case "reconnect":
                    return or(a, "CONNECTION_LOST"), void r.reconnect(e.payload.delay);
                case "request_failed":
                    {
                        const {
                            reject: t,
                            error: a
                        } = e.payload;
                        return void t(Jn(a))
                    }
                case "response_received":
                    return ur(a, e), void gr({
                        emit: c
                    }, e);
                case "send_request":
                    {
                        const t = a.getState();
                        if ((e => "destroyed" === Qn(e))(t)) return void cr(a, e, {
                            code: "SDK_DESTROYED",
                            message: "SDK destroyed."
                        });
                        if (!Kn(t) && "login" !== e.payload.source) return void cr(a, e, {
                            code: "NO_CONNECTION",
                            message: "No connection."
                        });
                        ((e, t, a) => {
                            let {
                                payload: {
                                    id: n,
                                    request: r
                                }
                            } = t;
                            const s = {
                                request_id: n,
                                ...r
                            };
                            switch (s.action) {
                                case v:
                                    {
                                        const t = [k, w],
                                            n = {
                                                3.5: C(b).filter(e => e !== _ && !T(e, t))
                                            };
                                        return a || (n[3.6] = t),
                                        void e.emit({ ...s,
                                            version: "3.5",
                                            payload: { ...s.payload,
                                                pushes: n
                                            }
                                        })
                                    }
                                default:
                                    e.emit(s)
                            }
                        })(r, e, o)
                    }
                    return;
                case "set_self_id":
                    return void c("customer_id", e.payload.id);
                case "socket_disconnected":
                    return void c("disconnected", {
                        reason: "connection_lost"
                    });
                case "socket_connected":
                    return void d.sendLogin(a);
                case "socket_recovered":
                    if (!Kn(a.getState())) return;
                    return void c("connection_recovered");
                case "socket_unstable":
                    if (!Kn(a.getState())) return;
                    return void c("connection_unstable");
                case "start_connection":
                    return r.connect(), void a.dispatch(Gn());
                case "update_customer_page":
                    if (!Kn(a.getState())) return;
                    return void rr(a, Vn(f, e.payload)).catch(Sa);
                case "identity_changed":
                    return void c("identity_changed", e.payload);
                default:
                    return
            }
        }
    },
    fr = function(e, t) {
        let {
            query: a = {}
        } = void 0 === t ? {} : t;
        const n = Ba(a),
            r = n ? e + "?" + n : e,
            s = ba(),
            i = xa({
                min: 1e3,
                max: 5e3,
                jitter: .5
            });
        let o, c = 3,
            d = null;
        const p = () => {
                c = 1, i.reset(), s.emit("connect")
            },
            l = () => {
                h(), g(), s.emit("disconnect")
            },
            u = e => {
                let {
                    data: t
                } = e;
                s.emit("message", t)
            },
            h = () => {
                var e;
                (clearTimeout(o), c = 3, d) && ((e = d).removeEventListener("open", p), e.removeEventListener("close", l), e.removeEventListener("message", u), d.close(), d = null)
            },
            m = () => {
                var e;
                c = 0, d = new WebSocket(r), (e = d).addEventListener("open", p), e.addEventListener("close", l), e.addEventListener("message", u)
            },
            g = function(e) {
                void 0 === e && (e = i.duration()), h(), 0 !== e ? o = setTimeout(m, e) : m()
            };
        return {
            connect() {
                if (3 !== c) throw new Error("Socket is already open or connecting.");
                clearTimeout(o), m()
            },
            destroy() {
                s.off(), h()
            },
            disconnect: h,
            reconnect: g,
            emit(e) {
                if (1 !== c) throw new Error("Socket is not connected.");
                d.send(e)
            },
            getReadyState: () => c,
            on: s.on,
            off: s.off
        }
    },
    _r = function(e, t) {
        let {
            query: a = {},
            emitter: n = ba()
        } = void 0 === t ? {} : t;
        const r = fr(e, {
                query: a
            }),
            s = (() => {
                let e, t = Sa;
                return {
                    cancel: () => {
                        clearTimeout(e), t = Sa
                    },
                    check() {
                        const a = l();
                        return t = a.resolve, e = setTimeout(() => {
                            const e = new Error("Timeout.");
                            e.code = "TIMEOUT", a.reject(e)
                        }, 2e3), a.promise
                    },
                    resolve() {
                        clearTimeout(e), t()
                    }
                }
            })(),
            i = () => 1 === r.getReadyState(),
            o = () => {
                s.cancel()
            };
        var c, d;
        return c = r, d = n, ["connect", "disconnect"].forEach(e => {
            c.on(e, t => {
                d.emit(e, t)
            })
        }), r.on("disconnect", o), r.on("message", e => {
            s.resolve();
            const t = JSON.parse(e);
            n.emit("message", t)
        }), "undefined" != typeof window && void 0 !== window.addEventListener && (window.addEventListener("online", () => {
            i() && s.check().then(() => {
                s.cancel(), n.emit("connection_recovered")
            }, e => {
                if (s.cancel(), "TIMEOUT" !== e.code) throw e;
                r.reconnect()
            })
        }), window.addEventListener("offline", () => {
            s.cancel(), i() && n.emit("connection_unstable")
        })), { ...r,
            destroy() {
                o(), r.destroy()
            },
            disconnect() {
                o(), r.disconnect()
            },
            reconnect(e) {
                o(), r.reconnect(e)
            },
            emit: e => {
                r.emit(JSON.stringify(e))
            },
            on: n.on,
            off: n.off
        }
    },
    yr = (e, t) => {
        const a = e.getState(),
            n = ($n(a) + "/rtm/ws").replace(/^https/, "wss");
        return _r(n, {
            query: {
                organization_id: a.organizationId,
                ...Xn(a)
            },
            emitter: t
        })
    },
    Ir = (e, t) => {
        const {
            dispatch: a
        } = e;
        return t.on("connect", () => {
            a({
                type: "socket_connected"
            })
        }), t.on("message", t => {
            if ("response" === t.type) {
                if (!t.success) return void((e, t) => {
                    let {
                        dispatch: a,
                        getState: n
                    } = e;
                    const {
                        request_id: r,
                        payload: s
                    } = t, {
                        reject: i
                    } = Wn(n(), r);
                    a({
                        type: "request_failed",
                        payload: {
                            id: r,
                            reject: i,
                            error: M(s.error)
                        }
                    })
                })(e, t);
                switch (t.action) {
                    case D:
                    case o:
                    case j:
                        return;
                    default:
                        return void((e, t) => {
                            let {
                                dispatch: a,
                                getState: n
                            } = e;
                            const {
                                request_id: r
                            } = t, {
                                promise: s,
                                resolve: i,
                                request: o
                            } = Wn(n(), r);
                            a({
                                type: "response_received",
                                payload: {
                                    id: r,
                                    promise: s,
                                    resolve: i,
                                    ...z({
                                        request: o,
                                        response: t
                                    })
                                }
                            })
                        })(e, t)
                }
            }
            if ("request_id" in t) switch (t.action) {
                case I:
                case N:
                    return void((e, t) => {
                        let {
                            dispatch: a,
                            getState: n
                        } = e;
                        const {
                            request_id: r
                        } = t, {
                            promise: s,
                            resolve: i
                        } = Wn(n(), r);
                        a({
                            type: "push_response_received",
                            payload: {
                                id: r,
                                promise: s,
                                resolve: i,
                                ...G(t)
                            }
                        })
                    })(e, t)
            }((e, t) => {
                const a = G(t);
                a && e.dispatch({
                    type: "push_received",
                    payload: a
                })
            })(e, t)
        }), t.on("disconnect", () => {
            or(e, "CONNECTION_LOST"), "connected" === Qn(e.getState()) && e.dispatch({
                type: "socket_disconnected"
            })
        }), t.on("connection_unstable", () => {
            a({
                type: "socket_unstable"
            })
        }), t.on("connection_recovered", () => {
            a({
                type: "socket_recovered"
            })
        }), t.off
    },
    Sr = function(e, t, a) {
        let {
            headers: n,
            method: r = "POST",
            onProgress: s,
            withCredentials: i = !1
        } = void 0 === a ? {} : a;
        const o = new XMLHttpRequest;
        return {
            promise: new Promise((a, c) => {
                "function" == typeof s && (o.upload.onprogress = e => {
                    s(e.loaded / e.total)
                }), o.onload = () => {
                    let e;
                    try {
                        e = JSON.parse(o.response)
                    } catch (n) {
                        e = o.response
                    }
                    if (o.status >= 200 && o.status < 300) return void a(e);
                    const t = new Error("Upload failed.");
                    t.code = "UPLOAD_FAILED", t.response = e, c(t)
                }, o.onerror = () => {
                    const e = new Error("Upload failed.");
                    e.code = "UPLOAD_FAILED", c(e)
                }, o.onabort = () => {
                    const e = new Error("Upload canceled.");
                    e.code = "UPLOAD_CANCELED", c(e)
                }, o.open(r, e), o.withCredentials = i, n && Object.keys(n).forEach(e => o.setRequestHeader(e, n[e])), o.send((e => {
                    const t = new FormData;
                    return Object.keys(e).forEach(a => t.append(a, e[a])), t
                })(t))
            }),
            cancel() {
                o.abort()
            }
        }
    },
    Cr = function(e, t) {
        void 0 === t && (t = 2);
        return (e / 1024 / 1024).toFixed(t) + " MB"
    },
    br = (e, t) => {
        let a, {
                auth: n,
                store: r
            } = e,
            {
                file: s,
                onProgress: i
            } = t,
            o = !1;
        return {
            promise: new Promise((e, t) => {
                (e => {
                    if (e.size > 10485760) throw Jn({
                        message: "The file is too big (max size is " + Cr(10485760) + ").",
                        code: "TOO_BIG_FILE"
                    })
                })(s);
                const c = r.getState(),
                    d = Ba({
                        organization_id: c.organizationId,
                        ...Xn(c)
                    }),
                    p = $n(c) + "/action/" + R + "?" + d,
                    l = {
                        file: s
                    };
                n.getToken().then(n => {
                    o ? t(new Error("Upload cancelled.")) : (a = Sr(p, l, {
                        headers: {
                            Authorization: n.tokenType + " " + n.accessToken
                        },
                        onProgress: i
                    }), a.promise.then(e, e => {
                        if (!e.response) return void t(e);
                        const {
                            type: a,
                            message: n
                        } = e.response.error;
                        t(Jn({
                            message: n,
                            code: a.toUpperCase()
                        }))
                    }))
                })
            }),
            cancel() {
                o || (o = !0, a && a.cancel())
            }
        }
    },
    Tr = function(t, a, n) {
        Ma(t);
        const {
            autoConnect: r = !0,
            customerDataProvider: s,
            identityProvider: i,
            parentStorage: c,
            ...d
        } = t, p = ar({ ...d,
            env: a
        }), l = ba(), u = (e => {
            const t = ba();
            let a = yr(e, t);
            return { ...Object.keys(a).reduce((e, t) => (e[t] = function() {
                    return a[t](...arguments)
                }, e), {}),
                reinitialize() {
                    a.disconnect(), a = yr(e, t), a.connect()
                }
            }
        })(p), h = "function" == typeof i, m = h ? i() : za(d, a, c);
        p.addSideEffectsHandler(vr({
            emitter: l,
            socket: u,
            auth: m,
            customerDataProvider: s,
            licenseId: n,
            parentStorage: c,
            hasCustomIdentityProvider: h
        })), Ir(p, u);
        const g = rr.bind(null, p),
            v = () => {
                p.dispatch({
                    type: "start_connection"
                })
            },
            f = Object.freeze({
                acceptGreeting(e) {
                    let {
                        greetingId: t,
                        uniqueId: a
                    } = e;
                    return g(Vn(J, {
                        greeting_id: t,
                        unique_id: a
                    }))
                },
                auth: m,
                cancelGreeting(e) {
                    let {
                        uniqueId: t
                    } = e;
                    return g(Vn(Q, {
                        unique_id: t
                    }))
                },
                cancelRate(e) {
                    const {
                        chatId: t,
                        properties: a = ["score"]
                    } = e;
                    return f.listThreads({
                        chatId: t
                    }).then(e => {
                        let {
                            threads: n
                        } = e;
                        if (!n.length) throw Jn({
                            message: 'There is no thread in "' + t + '".',
                            code: "MISSING_CHAT_THREAD"
                        });
                        return f.deleteThreadProperties({
                            chatId: t,
                            threadId: n[0].id,
                            properties: {
                                rating: a
                            }
                        })
                    })
                },
                connect: v,
                deactivateChat(e) {
                    let {
                        id: t
                    } = e;
                    return g(Vn(W, {
                        id: t
                    }))
                },
                deleteChatProperties(e) {
                    let {
                        id: t,
                        properties: a
                    } = e;
                    return g(Vn(Z, {
                        id: t,
                        properties: a
                    }))
                },
                deleteEventProperties(e) {
                    let {
                        chatId: t,
                        threadId: a,
                        eventId: n,
                        properties: r
                    } = e;
                    return g(Vn(Y, {
                        chat_id: t,
                        thread_id: a,
                        event_id: n,
                        properties: r
                    }))
                },
                deleteThreadProperties(e) {
                    let {
                        chatId: t,
                        threadId: a,
                        properties: n
                    } = e;
                    return g(Vn(K, {
                        chat_id: t,
                        thread_id: a,
                        properties: n
                    }))
                },
                destroy() {
                    p.dispatch(Mn("manual"))
                },
                disconnect() {
                    p.dispatch(zn("manual"))
                },
                getChat(e) {
                    let {
                        chatId: t,
                        threadId: a
                    } = e;
                    return g(Vn(x, {
                        chat_id: t,
                        thread_id: a
                    }))
                },
                getChatHistory(e) {
                    let {
                        chatId: t
                    } = e;
                    return ((e, t) => {
                        const a = {
                                status: "idle",
                                queuedTasks: [],
                                nextPageId: null
                            },
                            n = (r, s) => {
                                switch (a.status) {
                                    case "idle":
                                        return a.status = "fetching", void e.listThreads(a.nextPageId ? {
                                            chatId: t,
                                            pageId: a.nextPageId
                                        } : {
                                            chatId: t,
                                            minEventsCount: 25
                                        }).then(e => {
                                            let {
                                                threads: t,
                                                nextPageId: s
                                            } = e;
                                            a.nextPageId = s, a.nextPageId ? (a.status = "idle", r({
                                                value: {
                                                    threads: [...t].reverse()
                                                },
                                                done: !1
                                            })) : (a.status = "done", r({
                                                value: {
                                                    threads: [...t].reverse()
                                                },
                                                done: !0
                                            }));
                                            const i = a.queuedTasks.shift();
                                            i && n(i.resolve, i.reject)
                                        }, e => {
                                            const {
                                                queuedTasks: t
                                            } = a;
                                            a.status = "idle", a.queuedTasks = [], s(e), t.forEach(t => t.reject(e))
                                        });
                                    case "fetching":
                                        return void a.queuedTasks.push({
                                            resolve: r,
                                            reject: s
                                        });
                                    case "done":
                                        return void r({
                                            value: void 0,
                                            done: !0
                                        })
                                }
                            };
                        return {
                            next: () => new Promise(n)
                        }
                    })(f, t)
                },
                getCustomer: () => g(Vn(X, {})),
                getForm(e) {
                    let {
                        groupId: t,
                        type: a
                    } = e;
                    return g(Vn($, {
                        group_id: t,
                        type: a
                    }))
                },
                getPredictedAgent(e) {
                    void 0 === e && (e = {});
                    const {
                        groupId: t
                    } = e;
                    return g(Vn(ee, "number" == typeof t ? {
                        group_id: t
                    } : {}))
                },
                getUrlInfo(e) {
                    let {
                        url: t
                    } = e;
                    return g(Vn(te, {
                        url: t
                    }))
                },
                listChats: e => (void 0 === e && (e = {}), "limit" in e && "number" == typeof e.limit && e.limit > 25 ? Promise.reject(new Error("Specified limit is too high (max 25).")) : g(Vn(y, void 0 === e.pageId ? {
                    limit: e.limit || 10
                } : {
                    page_id: e.pageId
                }))),
                listGroupStatuses(e) {
                    let {
                        groupIds: t
                    } = void 0 === e ? {} : e;
                    return g(Vn(ae, t ? {
                        group_ids: t
                    } : {
                        all: !0
                    }))
                },
                listThreads: e => g(Vn(V, void 0 === e.pageId ? {
                    chat_id: e.chatId,
                    sort_order: e.sortOrder,
                    limit: e.limit,
                    min_events_count: e.minEventsCount
                } : {
                    chat_id: e.chatId,
                    page_id: e.pageId
                })),
                markEventsAsSeen(e) {
                    let {
                        chatId: t,
                        seenUpTo: a
                    } = e;
                    return g(Vn(ne, {
                        chat_id: t,
                        seen_up_to: a
                    }))
                },
                on: l.on,
                once: l.once,
                off: l.off,
                rateChat(e) {
                    const {
                        chatId: t,
                        rating: a
                    } = e;
                    return f.listThreads({
                        chatId: t
                    }).then(e => {
                        let {
                            threads: n
                        } = e;
                        if (!n.length) throw Jn({
                            message: 'There is no thread in "' + t + '".',
                            code: "MISSING_CHAT_THREAD"
                        });
                        return f.updateThreadProperties({
                            chatId: t,
                            threadId: n[0].id,
                            properties: {
                                rating: a
                            }
                        })
                    })
                },
                resumeChat: e => (nr({
                    env: a,
                    organizationId: t.organizationId,
                    eventName: "chat_started"
                }), g(Vn(D, (e => {
                    const t = Ln(e);
                    return { ...t,
                        chat: { ...t.chat,
                            id: e.chat.id
                        }
                    }
                })(e)))),
                sendEvent: e => g((e => {
                    let {
                        chatId: t,
                        event: a,
                        attachToLastThread: n
                    } = e;
                    const r = {
                        chat_id: t,
                        event: xn(a)
                    };
                    return n && (r.attach_to_last_thread = !0), Vn(o, r)
                })(e)),
                sendRichMessagePostback(e) {
                    let {
                        chatId: t,
                        threadId: a,
                        eventId: n,
                        postback: r
                    } = e;
                    return g(Vn(re, {
                        chat_id: t,
                        event_id: n,
                        thread_id: a,
                        postback: r
                    }))
                },
                setCustomerSessionFields(e) {
                    let {
                        sessionFields: t
                    } = e;
                    return g(Vn(H, {
                        session_fields: jn(t)
                    }))
                },
                setSneakPeek: e => {
                    let {
                        chatId: t,
                        sneakPeekText: a
                    } = e;
                    const n = p.getState();
                    Yn(n, t) && Kn(n) && g(Vn(se, {
                        chat_id: t,
                        sneak_peek_text: a
                    })).catch(Sa)
                },
                startChat: e => (void 0 === e && (e = {}), nr({
                    env: a,
                    organizationId: t.organizationId,
                    eventName: "chat_started"
                }), g(Vn(j, Ln(e)))),
                updateChatProperties(e) {
                    let {
                        id: t,
                        properties: a
                    } = e;
                    return g(Vn(ie, {
                        id: t,
                        properties: a
                    }))
                },
                updateCustomer: e => g(Vn(B, Dn(e))),
                updateCustomerPage(t) {
                    p.dispatch({
                        type: "update_customer_page",
                        payload: e(["title", "url"], t)
                    })
                },
                updateEventProperties(e) {
                    let {
                        chatId: t,
                        threadId: a,
                        eventId: n,
                        properties: r
                    } = e;
                    return g(Vn(oe, {
                        chat_id: t,
                        event_id: n,
                        thread_id: a,
                        properties: r
                    }))
                },
                updateThreadProperties(e) {
                    let {
                        chatId: t,
                        threadId: a,
                        properties: n
                    } = e;
                    return g(Vn(ce, {
                        chat_id: t,
                        thread_id: a,
                        properties: n
                    }))
                },
                uploadFile: e => br({
                    auth: m,
                    store: p
                }, e)
            });
        return r ? v() : p.dispatch({
            type: "check_goals",
            payload: {
                sessionFields: "function" == typeof s ? s().sessionFields : {}
            }
        }), f
    },
    Er = (e, t) => e.filter(e => e.serverName in t).map(e => ({
        type: e.type,
        label: e.label,
        value: e.options ? de(t[e.serverName]).map(t => pe(e => e.originalValue === t, e.options).label).join(", ") : t[e.serverName]
    })),
    wr = (e, t, a, n) => {
        e.emit("on_" + t + "_survey_submitted", {
            form_data: Er(a, n)
        })
    },
    kr = (e, t) => {
        e.emit("on_rating_comment_submitted", t)
    },
    Ar = (e, t) => {
        e.emit("on_rating_submitted", null === t ? "none" : t)
    },
    Nr = (e, t, a) => {
        e.emit("on_message", {
            text: t.properties.text,
            timestamp: a / 1e3,
            user_type: "visitor",
            visitor_name: e.getSessionUser().name
        })
    },
    qr = e => {
        const t = Object.keys(e);
        return Promise.all(C(e)).then(e => Ja(function(e, t, a) {
            return t.map((t, n) => e(t, a[n]))
        }(Pn, t, e)))
    },
    Or = e => e.replace(/index[0-9]*_/gi, ""),
    Pr = (e, t) => {
        const a = pe(e => "groupSelect" === e.meta, e);
        return Object.keys(t).reduce((n, r) => {
            const s = t[r];
            if ("rateComment" === r) return n.rateComment = s, n;
            if ("rating" === r) return n.rate = null === s ? s : Or(s), n;
            const i = pe(e => e.name === r, e),
                {
                    serverName: o
                } = i;
            return a && o && o === a.serverName && (n.choosenGroupIndex = t[a.name].match(/index([0-9]*)_/)[1], n.choosenGroup = parseInt(Or(s), 10)), i.options ? n.fields[o] = Ta(s) ? s.map(Or) : Or(s) : n.fields[o] = s, n
        }, {
            fields: {}
        })
    },
    Fr = "SET",
    Ur = (e, t) => "@@lc_privacy_policy:" + e + (he() && void 0 !== t ? ":" + t : ""),
    xr = e => e.fields.map(e => {
        switch (e.type) {
            case "question":
            case "textarea":
                {
                    const t = e.answer;
                    return t ? e.label + " " + t : e.label
                }
            case "radio":
            case "select":
                {
                    var t;
                    const a = null == (t = e.answer) ? void 0 : t.label;
                    return a ? e.label + " " + a : e.label
                }
            case "checkbox":
                {
                    var a;
                    const t = null == (a = e.answers) ? void 0 : a.map(e => e.label).join(", ");
                    return t ? e.label + " " + t : e.label
                }
            default:
                return ""
        }
    }).filter(Boolean).join("\n"),
    Lr = (e, t) => e.length ? e + "\n" + t : t,
    jr = (e, t, a) => {
        let {
            filledForm: n,
            groupId: r,
            organizationId: s,
            timeZone: i,
            page: o
        } = t;
        return e.getToken().then(e => {
            var t;
            const c = a.getApplicationState(),
                d = (e => {
                    const {
                        region: t
                    } = e;
                    return "https://api" + (t && "dal" !== t ? "-" + t : "") + ".livechatinc.com"
                })(c) + "/v2/tickets/new",
                p = (e => {
                    let {
                        fields: t,
                        customerId: a,
                        groupId: n,
                        organizationId: r,
                        timeZone: s,
                        page: i,
                        additionalInfo: o
                    } = e;
                    const c = {
                        organization_id: r,
                        ticket_message: "",
                        offline_message: "",
                        visitor_id: a,
                        requester: {},
                        ..."number" == typeof n && {
                            group: n
                        },
                        ...i && {
                            source: {
                                url: i
                            }
                        },
                        ...s && {
                            timezone: s
                        },
                        ...o && {
                            additional_info: {
                                reason: o.lastDisplayedReason,
                                displayed_at: o.lastDisplayedAt
                            }
                        }
                    };
                    return t.reduce((e, t) => {
                        switch (t.type) {
                            case "subject":
                                {
                                    const a = t.answer,
                                        n = a ? t.label + " " + a : t.label;
                                    return a && (e.subject = a),
                                    e.offline_message = Lr(e.offline_message, n),
                                    e
                                }
                            case "name":
                                {
                                    const a = t.answer,
                                        n = a ? t.label + " " + a : t.label;
                                    return a && (e.requester.name = a),
                                    e.offline_message = Lr(e.offline_message, n),
                                    e
                                }
                            case "email":
                                {
                                    const a = t.answer,
                                        n = a ? t.label + " " + a : t.label;
                                    return e.requester.mail = a,
                                    e.offline_message = Lr(e.offline_message, n),
                                    e
                                }
                            case "question":
                            case "textarea":
                                {
                                    const a = t.answer,
                                        n = a ? t.label + " " + a : t.label;
                                    return e.offline_message = Lr(e.offline_message, n),
                                    e.ticket_message = Lr(e.ticket_message, n),
                                    e
                                }
                            case "radio":
                            case "select":
                                {
                                    const a = t.answer && t.answer.label,
                                        n = a ? t.label + " " + a : t.label;
                                    return e.offline_message = Lr(e.offline_message, n),
                                    e.ticket_message = Lr(e.ticket_message, n),
                                    e
                                }
                            case "checkbox":
                                {
                                    const a = t.answers && t.answers.map(e => e.label).join(", "),
                                        n = a ? t.label + " " + a : t.label;
                                    return e.offline_message = Lr(e.offline_message, n),
                                    e.ticket_message = Lr(e.ticket_message, n),
                                    e
                                }
                            default:
                                return e
                        }
                    }, c)
                })({
                    fields: n.fields,
                    customerId: e.entityId,
                    groupId: r,
                    organizationId: s,
                    timeZone: i,
                    page: o,
                    additionalInfo: c.config.features.ticketForm.additionalInfo
                });
            return h(d, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "X-Region": null != (t = c.region) ? t : ""
                },
                body: JSON.stringify(p)
            }).then(e => {
                if (e.ok) return e.json().then(e => ({ ...e,
                    text: p.ticket_message
                }));
                if (400 === e.status || 422 === e.status) {
                    const t = e => {
                        if (!e || !e.errors) throw new Error;
                        const t = e.errors[0];
                        if ("incorrect requester structure" === Object.keys(t)[0]) {
                            const e = new Error(t["incorrect requester structure"][0]);
                            throw e.code = "VALIDATION", e
                        }
                        throw new Error
                    };
                    return e.json().then(t, t)
                }
                throw new Error
            })
        })
    },
    Dr = (e, t) => pn((() => {
        switch (t.code) {
            case "TOO_BIG_FILE":
                return e.localize("cannot_upload_a_file_over_10mb");
            case "VALIDATION":
                return "No active chat thread" === t.message ? e.localize("closed_chat_upload_failed") : e.localize("upload_failed");
            default:
                return e.localize("upload_failed")
        }
    })()),
    Mr = e => {
        const {
            properties: {
                rate: t,
                rateComment: a,
                queued: n
            }
        } = e.getChat(le), r = e.getView("Chat/queue");
        return {
            rate: t,
            rateComment: a,
            queue: n ? {
                position: r.numberInQueue,
                waitingTime: r.waitingTime
            } : null
        }
    };
let zr = {
    acceptingGreeting: !1,
    requestingPredictedWelcomeMessage: !1
};
const Gr = (t, a, n, r) => {
    const s = !a.getApplicationState("clientLimitExceeded") || !a.getApplicationState("embedded") || a.getApplicationState("actingAsDirectLink") || a.getApplicationState("isInCustomContainer"),
        i = ((e, t, a) => {
            let {
                organizationId: n,
                requestedGroup: r,
                group: s,
                region: i,
                uniqueGroups: o,
                autoConnect: c,
                mobile: d,
                identityProvider: p,
                parentStorage: l
            } = t;
            const u = e.getApplicationState("page"),
                h = {
                    organizationId: n,
                    clientId: "c5e4f61e1a6c3b1521b541bc5c5a2ac5",
                    mobile: d,
                    region: i,
                    page: g(["url", "title"], u),
                    referrer: u.referrer,
                    autoConnect: c,
                    application: {
                        channelType: zt(e)
                    },
                    uniqueGroups: o,
                    identityProvider: p,
                    customerDataProvider: () => {
                        const t = e.getSessionUser(),
                            a = {};
                        return t.name && (a.name = t.name), t.email && (a.email = t.email), t.properties && !Gt(t.properties) && (a.sessionFields = ln(t.properties).length <= Rt ? t.properties : Ja(Vt(t.properties).slice(0, Rt))), a
                    },
                    parentStorage: l
                };
            o ? h.groupId = s : null !== r && (h.groupId = r);
            return Tr(h, "production", a)
        })(a, { ...t,
            autoConnect: s
        }, r),
        o = {
            sdk: i,
            store: a
        };
    let c = null,
        d = {};
    !0 === n.__unsafeProperties.s && a.setApplicationState({
        s: !0
    }), n.prechatForm && a.updateView("Chat/prechat", Wa("prechat", n.prechatForm)), n.ticketForm && a.updateView("Chat/ticketForm", Za(n.ticketForm)), n.__unsafeProperties.group.chatBoosters && ve(a, n.__unsafeProperties.group.chatBoosters);
    const p = () => {
            "livechat" === a.getApplicationState("defaultWidget") && (Le(le, a) || a.getApplicationState().destroyed) && (je(a), a.updateView("minimized", {
                hidden: !0
            }))
        },
        l = () => {
            i.destroy(), a.setApplicationState({
                destroyed: !0
            }), p()
        },
        u = (e, t) => {
            Re(a) && !c && (c = t || In(o, {
                chatId: e
            }))
        },
        h = e => {
            const {
                id: t,
                active: n,
                group: r,
                thread: s,
                previousThread: i,
                agent: o,
                events: c,
                properties: d
            } = e, p = !!d.queue;
            if (u(t), c.forEach(k), Ht(a, {
                    id: t,
                    active: n,
                    thread: s,
                    previousThread: i,
                    group: r,
                    queued: p,
                    agent: o,
                    timestamp: d.timestamp
                }), Bt(a)) {
                const {
                    position: e,
                    waitingTime: t
                } = d.queue;
                a.updateView("Chat/queue", {
                    numberInQueue: e,
                    waitingTime: t
                })
            }
        },
        m = () => a.getChat(le).properties.lastThread,
        v = e => "good" === e ? 1 : "bad" === e ? 0 : null,
        f = e => i.rateChat({
            chatId: me(a),
            rating: Aa({
                comment: e.rateComment,
                score: v(e.rating)
            })
        }).then(() => {
            a.updateChat(le, {
                properties: Aa({
                    rate: e.rating,
                    rateComment: e.rateComment
                })
            })
        }, Sa),
        _ = e => i.cancelRate({
            chatId: me(a),
            properties: e
        }).then(() => {
            a.updateChat(le, {
                properties: e.reduce((e, t) => ("comment" === t ? e.rateComment = null : "score" === t && (e.rate = null), e), {})
            })
        }, Sa),
        y = () => gn(o, a.getApplicationState("group")).then(e => {
            e.enabled && (a.updateView("Chat/ticketForm", e.form), Nt(a, "groups_offline"))
        }),
        I = (e, t) => {
            const n = (e => {
                    const {
                        properties: {
                            rate: t,
                            rateComment: n
                        }
                    } = a.getChat(le), r = {
                        comment: "NOTHING",
                        score: "NOTHING"
                    };
                    e.rating !== t && (r.score = null === e.rating ? "CANCEL" : Fr);
                    const s = "string" == typeof e.rateComment && "" !== e.rateComment;
                    return n && !s || "CANCEL" === r.score && n ? r.comment = "CANCEL" : !s || n && e.rateComment === n || (r.comment = Fr), r
                })(t),
                {
                    testGroup: r
                } = e.getApplicationState();
            if ("NOTHING" === n.score && "NOTHING" === n.comment) return Promise.resolve(null);
            ht({
                testGroup: r,
                chatRating: "CANCEL" === n.score ? "canceled" : t.rating,
                chatRatingSource: "postchat"
            });
            const s = [];
            return n.score === Fr && n.comment === Fr ? (s.push(f(t)), Ar(e, t.rating), kr(e, t.rateComment)) : "CANCEL" === n.score && "CANCEL" === n.comment ? s.push(_(["comment", "score"])) : ("CANCEL" === n.score ? s.push(_(["score"])) : n.score === Fr && (s.push(f({
                rating: t.rating
            })), Ar(e, t.rating)), "CANCEL" === n.comment ? s.push(_(["comment"])) : n.comment === Fr && (s.push(f({
                rateComment: t.rateComment
            })), kr(e, t.rateComment))), Promise.all(s.map(e => e.catch(Sa)))
        },
        S = e => {
            const {
                availability: t,
                postponedGreeting: a
            } = e.getApplicationState();
            return "online" === t && a ? Promise.resolve().then(() => (e.setApplicationState({
                postponedGreeting: null
            }), zr.acceptingGreeting = !0, Cn(o, a).then(e => {
                zr.acceptingGreeting = !1, q(e)
            }, () => {
                zr.acceptingGreeting = !1
            }))) : Promise.resolve(null)
        },
        C = () => {
            const e = a.getChat(le).properties.group,
                t = a.getApplicationState("group");
            return "number" == typeof e ? e : t
        },
        b = t => {
            const n = sn(a, t);
            if (a.getSessionUser().serverId !== n.id) return a.getUser(n.id) ? (n.properties || Oe("no_parsed_user_properties", new Error, {
                meta: JSON.stringify({
                    user: t,
                    parsedUser: n
                })
            }), void(n.properties.isBot && a.updateUser(n.id, {
                properties: {
                    isBot: !0
                }
            }))) : void a.addUser(n);
            a.updateUser(a.getSessionUserId(), e(["name", "email", "properties"], n))
        },
        E = e => {
            const t = Mr(a),
                n = {};
            if ("rate" in e && t.rate !== e.rate && (n.rate = e.rate), "rateComment" in e && t.rateComment !== e.rateComment && (n.rateComment = e.rateComment), "timestamp" in e && t.timestamp !== e.timestamp && (n.timestamp = e.timestamp), "queue" in e && !Zt(t.queue, e.queue)) {
                const {
                    queue: t
                } = e, {
                    ended: r
                } = a.getChat(le).properties;
                !r && t ? ((e, t) => {
                    let {
                        thread: a,
                        numberInQueue: n,
                        waitingTime: r
                    } = t;
                    const s = {
                        active: !0,
                        properties: {
                            queued: !0
                        }
                    };
                    a && (s.properties.lastThread = a), e.updateChat(le, s), e.updateView("Chat/queue", {
                        numberInQueue: n,
                        waitingTime: r
                    })
                })(a, {
                    numberInQueue: t.position,
                    waitingTime: t.waitingTime
                }) : n.queued = !1
            }
            a.updateChat(le, {
                properties: n
            })
        },
        w = (e, t) => {
            "message" === e && a.getApplicationState("readyState") !== ma && ((e, t) => {
                const {
                    author: a,
                    timestamp: n,
                    properties: {
                        text: r
                    }
                } = e.getEvent(le, t), s = e.getUser(a), i = s.type, o = {
                    text: r,
                    timestamp: Math.floor(n / 1e3),
                    user_type: "agent" === i ? i : "visitor"
                };
                "agent" === i ? (o.agent_name = s.name, o.agent_login = s.id) : o.visitor_name = s.name, e.emit("on_message", o)
            })(a, t)
        },
        k = e => {
            Yt(a, le, e), w(e.properties.serverType, e.id)
        },
        A = e => {
            const t = an(a, e);
            if (!t) return;
            "form" !== t.type || t.properties.answered || "ask_for_email" !== t.properties.formId || (Math.random() < .01 && ge("ask_for_email_form_received", {}), a.hasEvent(le, Kt) && a.removeEvent(le, Kt));
            const n = Xt(a).find(e => e.properties.customId === t.properties.customId);
            n ? ((e, t) => {
                const n = t.seen;
                a.updateEvent(le, t.id, {
                    properties: { ...t.properties,
                        ...e.properties,
                        isPreview: !1
                    }
                }), a.setEventServerId(le, t.id, e.serverId), n && (ne = Math.max(ne, e.timestamp), re(ne)), w(e.properties.serverType, t.id)
            })(t, n) : k(t), De(a, "minimized") && a.emit("render-minimized")
        },
        N = fe(La(i, "greeting_accepted"), Ia(e => {
            var t;
            return e.uniqueId === (null == (t = a.getApplicationState("postponedGreeting")) || null == (t = t.event) || null == (t = t.properties) ? void 0 : t.uniqueId)
        }));
    fe(_a(La(i, "incoming_greeting"), fe(La(i, "connected"), Ia(e => "greeting" in e), _e(e => e.greeting))), Ia(e => ye(a) && e.isExitIntent && !e.accepted), Ie(e => {
        a.setApplicationState({
            postponedGreeting: $a(a, e)
        }), a.emit("register_exit_intent_listener")
    }), Se(() => La(a, "exit_intent_detected")), Ce(N), Ea(1), Ia(() => {
        const {
            mobile: e,
            availability: t
        } = a.getApplicationState(), {
            active: n
        } = a.getChat(le);
        return !e && !n && "online" === t
    }), Se(() => be(S(a))), Ia(() => "bar" !== $t(a) && ea(a)), wa(() => a.emit("apply_exit_intent_shade")));
    const q = e => {
            const {
                author: t,
                event: n
            } = e;
            b(t);
            const {
                serverId: r,
                properties: {
                    ended: s
                }
            } = a.getChat(le);
            s && He(a, le, {
                chatId: r
            });
            const i = Mt(a, le);
            i && a.removeEvent(le, i.id), mt("hideOnInit", a).enabled && a.setApplicationState({
                wasActivated: !0
            }), ta(a, n)
        },
        O = e => {
            if (!e.event.properties.isExitIntent && (a.getApplicationState("isExitIntentShadeDisplayed") && (a.setApplicationState({
                    isExitIntentShadeDisplayed: !1
                }), a.emit("remove_exit_intent_shade")), !zr.requestingPredictedWelcomeMessage))
                if (Et(a, "postchat")) a.setApplicationState({
                    postponedGreeting: e
                });
                else if (aa(le, a)) {
                if (!e.event.properties.accepted) return a.getApplicationState("greetingsMuted") && !De(a, "maximized") ? (a.updateChat(le, {
                    properties: {
                        mutedGreeting: e
                    }
                }), void q(e)) : (zr.acceptingGreeting = !0, Cn(o, e).then(e => {
                    zr.acceptingGreeting = !1, q(e)
                }, () => {
                    zr.acceptingGreeting = !1
                }));
                q(e)
            }
        },
        P = e => !!e && -1 !== e.indexOf(a.getApplicationState("group")),
        F = function(e) {
            let {
                withSystemMessage: t = !1,
                reason: n = "users_limit_reached"
            } = void 0 === e ? {} : e;
            if (a.setApplicationState({
                    limitReached: !0,
                    clientLimitExceededLifted: !1
                }), At(a), t) {
                const e = ra(a) ? "Sorry we couldn't connect you with an agent, but you can still leave us a ticket" : "Sorry, but we couldn't connect you with an agent. Try refreshing the page or come back later.";
                sa(a, le, {
                    text: e
                })
            }
            ra(a) && Nt(a, n)
        };
    i.on("thread_properties_deleted", e => {
        let {
            threadId: t,
            properties: n
        } = e;
        t === m() && "rating" in n && T("score", n.rating) && E({ ...Mr(a),
            rate: null
        })
    }), i.on("thread_properties_updated", e => {
        let {
            threadId: t,
            properties: n
        } = e;
        t === m() && "rating" in n && E({ ...Mr(a),
            ...Ya(n.rating)
        })
    }), i.on("queue_position_updated", e => {
        let {
            threadId: t,
            queue: n
        } = e;
        t === m() && E({ ...Mr(a),
            queue: Ka(n)
        })
    }), i.on("chat_transferred", e => {
        if (!("groupIds" in e.transferredTo)) return;
        const t = e.transferredTo.groupIds[0];
        a.updateChat(le, {
            properties: {
                group: t
            }
        }), e.queue && E({ ...Mr(a),
            queue: Ka(e.queue)
        })
    }), i.on("customer_updated", t => {
        const n = a.getSessionUserId();
        a.updateUser(n, e(["name", "email"], t)), t.sessionFields && a.setUserProperties(n, t.sessionFields), a.emit("customer_updated")
    }), i.on("event_properties_updated", e => {
        let {
            chatId: t,
            threadId: n,
            eventId: r,
            properties: s
        } = e;
        if (t === me(a) && n === m()) {
            if ("translation" in s) {
                const e = a.getEventByServerId(le, r);
                if (!e) return;
                a.updateEvent(le, e.id, {
                    properties: {
                        translation: Xa(s.translation)
                    }
                })
            }
            if ("bb9e5b2f1ab480e4a715977b7b1b4279" in s) {
                const e = a.getEventByServerId(le, r);
                if (!e) return;
                const n = s.bb9e5b2f1ab480e4a715977b7b1b4279.message_reaction;
                a.updateEvent(le, e.id, {
                    properties: {
                        reaction: n
                    }
                }), e.own && (a.getApplicationState("license") === Te || Math.random < .1) && ge("message_reaction_received", {
                    reaction: n,
                    messageType: e.type,
                    chatId: t
                }), n && a.emit("reaction_received", {
                    event: e
                })
            }
        }
    }), i.on("event_updated", e => {
        let {
            chatId: t,
            threadId: n,
            event: r
        } = e;
        if (t !== me(a) || n !== m()) return;
        if (!Ee("properties.lc2.welcome_message", r)) return;
        const s = a.getEventByServerId(le, r.id);
        r.authorId !== s.author && (a.setEventData(le, s.id, {
            author: r.authorId
        }), a.recalculateTimeline(le)), r.text !== s.properties.text && a.updateEvent(le, s.id, {
            properties: {
                text: r.text
            }
        })
    }), a.on("set_application_state", e => {
        let {
            pageFocused: t
        } = e;
        we(a) && t && (a.setConnectionState(ke), i.connect())
    }), i.on("disconnected", e => {
        let {
            reason: t
        } = e;
        switch (t) {
            case "access_denied":
            case "too_many_connections":
                return Oe(t), void l();
            case "customer_banned":
            case "license_not_found":
            case "unsupported_version":
            case "inactivity_timeout":
                return void(a.getApplicationState("pageFocused") || (a.setConnectionState(qe), i.disconnect()));
            case "users_limit_reached":
                return F({
                    withSystemMessage: !1
                }), a.setConnectionState(Ne), void J.then(() => {
                    U()
                });
            default:
                return "connection_timeout" === t && Math.random() <= .1 ? Ae("connection_timeout") : Math.random() <= 1e-4 && Ae("disconnected", {
                    reason: t
                }), void a.setConnectionState(ke)
        }
    }), i.on("user_added_to_chat", e => {
        let {
            chatId: t,
            user: n,
            present: r
        } = e;
        if (!r || t !== me(a) || a.getSessionUser().serverId === n.id) return;
        const s = Pe(le, a);
        s && s.id === n.id || (E({ ...Mr(a),
            queue: null
        }), Fe(a, n.id))
    }), i.on("user_removed_from_chat", e => {
        let {
            chatId: t,
            userId: n,
            reason: r
        } = e;
        if (t !== me(a)) return;
        a.removeParticipant(le, n);
        const s = a.getChat(le).properties.agentActivity;
        if ("thinking" === (null == s ? void 0 : s.type) && s.authorId === n && a.updateChat(le, {
                properties: {
                    agentActivity: null
                }
            }), a.getSessionUser().serverId === n) return;
        const i = Pe(le, a);
        i && i.id === n && "chat_deactivated" !== r && Fe(a, null)
    }), i.on("user_data", b), ((e, t) => {
        e.on("send_snapshot", a => {
            const {
                requestId: n,
                snapshot: r,
                screen: s
            } = a;
            t.uploadFile({
                file: new Blob([r], {
                    type: "text/plain;charset=utf-8"
                })
            }).promise.then(a => {
                t.sendEvent({
                    chatId: me(e),
                    event: {
                        type: "custom",
                        customId: "cyber-finger-snapshot-" + n,
                        content: {
                            url: a.url,
                            screen: s
                        }
                    }
                }), ge("snapshot_sent", {
                    chatId: me(e)
                })
            }).catch(Sa)
        })
    })(a, i), i.on("greeting_canceled", e => {
        let {
            uniqueId: t
        } = e;
        const n = a.getEvents(le),
            r = Ue(e => e.properties.uniqueId === t, n);
        r && xe(a, r.id)
    });
    const U = () => {
            Le(le, a) ? je(a) : a.getApplicationState("wasActivated") && De(a, "hidden") && Me(a, !0), a.setApplicationState({
                readyState: ze
            })
        },
        x = e => {
            let {
                group: t
            } = e;
            if (Qt(a)) return {};
            if (Pt(a)) {
                const {
                    properties: {
                        rate: e
                    }
                } = a.getChat(le);
                return e ? {} : {
                    postchatForm: Promise.resolve({
                        enabled: !0,
                        form: ia
                    })
                }
            }
            const n = Re(a) ? t : C();
            return {
                postchatForm: Sn(o, n).catch(() => ({
                    enabled: !1
                }))
            }
        },
        L = e => {
            let {
                active: t,
                chatId: n,
                lastThreadId: r,
                becameInactive: s
            } = e;
            if (Re(a)) return {
                fetchedHistory: yn(o, n)
            };
            if (s) {
                const e = a.getChat(le);
                return {
                    fetchedThread: bn(o, {
                        chatId: n,
                        threadId: e.properties.lastThread
                    })
                }
            }
            return t ? {
                fetchedThread: bn(o, {
                    chatId: n,
                    threadId: r
                })
            } : void 0
        },
        j = e => e.filter(e => {
            const t = a.hasEvent(le, e.id),
                n = !!e.properties.customId && a.hasEvent(le, e.properties.customId);
            return !(t || n || "form" === e.type && "ticket" === e.properties.formType)
        }),
        D = e => {
            j(e).forEach(k)
        },
        M = (e, t) => {
            let {
                eagerFetchingMode: n,
                group: r
            } = e, {
                thread: s,
                eventsSeenUpToMap: i
            } = t;
            if (!s) return;
            const {
                id: o,
                active: c,
                agent: d,
                events: p,
                properties: l
            } = s, u = a.getChat(le), h = !c && u.active, m = a.getLastEvent(le);
            Et(a, "postchat") && p.find(e => e.properties.answered && e.properties.formId === m.properties.formId) && pt(a), a.updateChat(le, {
                active: c,
                properties: {
                    ended: u.properties.ended,
                    lastThread: o,
                    group: r,
                    eventsSeenUpToMap: i,
                    ...h && {
                        ended: !0,
                        queued: !1,
                        agentActivity: null
                    }
                }
            }), c && Fe(a, d), E({
                rate: null,
                ...l,
                queue: c && "queue" in l ? l.queue : null,
                ...!n && !c && {
                    rate: null,
                    rateComment: null
                }
            }), D(p)
        },
        z = e => {
            null === oa(a, le) && a.updateChat(le, {
                properties: {
                    hasMoreHistory: e
                }
            })
        };
    i.on("connected", e => {
        let {
            __unsafeDynamicConfig: t,
            __unsafeChats: n,
            greeting: r,
            availability: s,
            customer: c
        } = e;
        clearTimeout(Q);
        const {
            limitReached: l
        } = a.getApplicationState();
        l && a.setApplicationState({
            limitReached: !1
        });
        const h = (e => {
            const t = a.getSessionUser(),
                n = {};
            return t.name && e.name !== t.name && (n.name = t.name), t.email && e.email !== t.email && (n.email = t.email), Gt(t.properties) || Zt(t.properties, e.sessionFields) || (n.sessionFields = Gt(e.sessionFields) ? t.properties : Ja(Vt(t.properties).reduce((t, a) => {
                let [n, r] = a;
                return n in e.sessionFields ? t : [].concat(t, [
                    [n, r]
                ])
            }, []))), Gt(n) ? null : n
        })(c);
        let g;
        h && (e => {
            let {
                customerData: t,
                usedSessionFieldsNumber: a
            } = e;
            const n = e => {
                i.updateCustomer(e).catch(e => Oe("update_customer_request_failed", e))
            };
            t.sessionFields ? Vt(t.sessionFields).slice(0, ca - a).reduce((e, t) => (Gt(e) || xt(e).length >= Rt ? e.push([t]) : xt(e).push(t), e), []).map(Ja).reduce((e, a, r) => e.then(() => n({ ...0 === r && t,
                sessionFields: a
            })), Promise.resolve()) : n(t)
        })({
            customerData: h,
            usedSessionFieldsNumber: ln(c.sessionFields || {}).length
        }), b(c), Ge(a), "boolean" != typeof a.getApplicationState().isReturning && a.setApplicationState({
            isReturning: c.statistics.visitsCount > 1
        }), a.setApplicationState({
            clientChatNumber: c.statistics.threadsCount || 0,
            clientVisitNumber: c.statistics.visitsCount || 0,
            clientLastVisitTimestamp: t.customer_data.last_visit_timestamp,
            clientPageViewsCount: c.statistics.pageViewsCount || 0
        }), d = {
            availability: s,
            greeting: ye(a) && r && $a(a, r)
        }, Promise.resolve().then(() => {
            if (!n.length) return;
            const [{
                id: e,
                active: r,
                hasUnreadEvents: s
            }] = n;
            Re(a) && a.setApplicationState({
                hasUnseenEvents: s
            });
            const i = !r && a.getChat(le).active;
            g = {
                active: r,
                chatId: e,
                becameInactive: i,
                dynamicConfig: t
            }, null === a.getChat(le).serverId && a.setChatServerId(le, e);
            const {
                eagerFetchingMode: c
            } = a.getApplicationState();
            return r || De(a, "maximized") || c ? hn(o) : void 0
        }).then(e => e ? (g.group = e.group, g.lastThreadId = e.lastThreadId, g.becameInactive ? qr({
            chatSummary: e,
            ...x(g),
            ...L(g)
        }) : (e.active, qr({
            chatSummary: e,
            ...L(g)
        }))) : qr({})).then(e => {
            const t = !!e.chatSummary && e.chatSummary.active,
                n = Boolean(d.greeting && !d.greeting.event.properties.isExitIntent);
            return t ? e : qr({ ...e,
                maximizedDecisionActions: Ua() ? Fa({
                    active: !1,
                    availability: d.availability,
                    connected: !0,
                    hasFakeAgentMessage: Ve(a, le) || n
                }) : null
            })
        }).then(e => {
            let {
                queueTemplate: t,
                chatSummary: n,
                postchatForm: r,
                maximizedDecisionActions: s,
                ...i
            } = e;
            const o = d;
            if (d = {}, t && a.setLocalization({
                    user_in_queue: t
                }), a.setApplicationState({
                    availability: o.availability
                }), !n) return s && pn(s), o.greeting ? O(o.greeting) : void 0;
            const c = {
                chatId: n.id,
                group: n.group,
                eagerFetchingMode: a.getApplicationState().eagerFetchingMode
            };
            a.setApplicationState({
                eagerFetchingMode: !0
            });
            const p = m() && n.lastThreadId !== m();
            if (Re(a)) {
                const {
                    fetchedHistory: e
                } = i;
                ((e, t) => {
                    const a = e.getChat(le).properties.lastThread;
                    return a && !t.some(e => {
                        let {
                            id: t
                        } = e;
                        return a === t
                    })
                })(a, e.threads) && Oe("threads_gap", null, {
                    meta: JSON.stringify({
                        stateLastThreadId: a.getChat(le).properties.lastThread,
                        fetchedThreads: e.threads.map(e => {
                            let {
                                id: t
                            } = e;
                            return t
                        })
                    })
                }), p && He(a, le, {
                    chatId: a.getChat(le).serverId
                }), ((e, t) => {
                    u(e.chatId, t.iterator), z(t.hasMore);
                    const n = Pt(a) ? Ft(a, t.threads) : t.threads,
                        [r, [s]] = (i = -1, [(o = n).slice(0, i), o.slice(i, o.length)]);
                    var i, o;
                    D(Ut(e => {
                        let {
                            events: t
                        } = e;
                        return t
                    }, r)), M(e, {
                        thread: s,
                        eventsSeenUpToMap: t.eventsSeenUpToMap
                    })
                })(c, e)
            } else i.fetchedThread && (p && n.active && He(a, le, {
                chatId: a.getChat(le).serverId
            }), M(c, i.fetchedThread));
            if (s && pn(s), !n.active)
                if (r && r.enabled) Be(a, r.form);
                else if (o.greeting) return O(o.greeting)
        }).then(() => {
            const e = a.getConnectionState() === Je;
            return a.setConnectionState(Qe), p(), a.getChat(le).active && De(a, "hidden") && Me(a, !0), e
        }).then(e => {
            const t = a.getChat(le),
                {
                    availability: n,
                    readyState: r
                } = a.getApplicationState();
            r !== ze && J.then(() => {
                U()
            }), e || !We(a) || !Ze(a) || t.active || "offline" !== n && !t.properties.ended || Ye(a)
        }).catch(e => {
            switch (d = {}, e.code) {
                case "CONNECTION_LOST":
                    return;
                case "REQUEST_TIMEOUT":
                case "MISSING_USER":
                    return i.disconnect(), void i.connect();
                case "INTERNAL":
                    return void Ke("connection_fetcher_internal_error");
                default:
                    return void Oe("connection_fetcher_error", e)
            }
        })
    }), Xe(n, a), "modern" === $e(a) && "Homescreen" === a.getCurrentView() && a.setCurrentView("Chat");
    const G = a.getApplicationState("defaultWidget");
    et(a) && "openwidget" !== G && (tt(a, e => gt(o.sdk.auth.getToken, e)), !a.getCurrentView() && at(a) && a.setCurrentView("Homescreen")), i.once("customer_id", e => nt(a, e)), i.on("identity_changed", e => {
        let {
            newId: t
        } = e;
        ((e, t) => {
            let {
                newId: a
            } = t;
            e.clearChatServerId(le), He(e, le, {
                forced: !0
            }), e.updateChat(le, {
                active: !1,
                properties: {
                    ended: !1,
                    queued: !1,
                    currentAgent: null
                }
            }), nt(e, a);
            const n = e.getSessionUserId();
            e.updateUser(n, {
                name: null,
                email: null
            }), e.setUserProperties(n, {});
            const r = {
                messageDraft: null,
                invitationHiddenIds: [],
                invitationDisplayedIds: [],
                greetingsMuted: !1,
                postponedGreeting: null
            };
            e.setApplicationState({
                hasUnseenEvents: !1,
                invitation: {
                    current: null,
                    hiddenIds: r.invitationHiddenIds,
                    displayedIds: r.invitationDisplayedIds
                },
                messageDraft: r.messageDraft,
                greetingsMuted: r.greetingsMuted,
                postponedGreeting: r.postponedGreeting,
                isReturning: !1,
                clientChatNumber: 0,
                clientVisitNumber: 0,
                clientLastVisitTimestamp: null,
                clientPageViewsCount: 0
            })
        })(a, {
            newId: t
        })
    });
    const R = rt(a, ze),
        V = e => fe(R, Se(e)),
        H = fe(st(a, e => Ga(e, "maximized")), Ia(Boolean), _e(() => ({
            type: "maximized"
        })), it),
        B = fe(st(a, () => a.getSessionUser().serverId), Ia(Boolean), Ea(1), ka),
        J = fe(st(a, e => e.localization), Ia(e => Object.keys(e).length > 1), Ea(1), ka);
    let Q;
    s ? (Math.random() <= .01 && "onLine" in navigator && (Q = setTimeout(() => {
        navigator.onLine && Ae("unsuccessful_first_connect")
    }, 3e4)), a.setApplicationState({
        clientLimitExceededLifted: !0
    })) : Promise.all([J, B]).then(e => {
        let [t] = e;
        var r;
        a.setLocalization(t), r = n.onlineGroupIds, a.setApplicationState({
            availability: P(r) ? "online" : "offline"
        }), a.setConnectionState(Ne), p(), U();
        const s = (o = document, _a(...["click", "touchstart"].map(e => ya(o, e))));
        var o;
        fe(_a(s, H), Ea(1), wa(() => {
            a.setApplicationState({
                clientLimitExceededLifted: !0
            }), i.connect()
        }))
    }), "ononline" in window && (i.on("connection_unstable", () => {
        a.setConnectionState(ke)
    }), i.on("connection_recovered", () => {
        a.setConnectionState(Qe)
    })), i.on("incoming_greeting", e => {
        if (!ye(a)) return;
        const t = $a(a, e);
        ot(a) ? O(t) : d.greeting = t
    }), i.on("availability_updated", e => {
        let {
            availability: t
        } = e;
        ot(a) ? a.setApplicationState({
            availability: t
        }) : d.availability = t
    }), i.on("events_marked_as_seen", e => {
        let {
            chatId: t,
            userId: n,
            seenUpTo: r
        } = e;
        if (t !== me(a)) return;
        a.updateChat(le, {
            properties: {
                eventsSeenUpToMap: { ...a.getChat(le).properties.eventsSeenUpToMap,
                    [n]: r
                }
            }
        });
        const s = new Date(r).getTime();
        (a.getSessionUser().serverId === n ? ct : dt)(le, s, a).forEach(e => {
            a.updateEvent(le, e.id, {
                seen: !0
            })
        })
    }), i.on("incoming_event", e => {
        let {
            chatId: t,
            event: n
        } = e;
        if (t !== me(a)) return;
        a.getChat(le).properties.lastThread !== n.threadId && a.updateChat(le, {
            properties: {
                lastThread: n.threadId
            }
        }), "postchat" === Ee("properties.lc2.form_type", n) && pt(a), lt(le, a) && Oe("received_event_during_chat_starting"), A(n)
    }), i.on("incoming_event_preview", e => {
        let {
            chatId: t,
            event: n,
            threadId: r
        } = e;
        t === me(a) && (e => {
            let {
                event: t
            } = e;
            const n = on(a, t),
                r = Xt(a).find(e => e.properties.customId === t.customId);
            if (r) return a.updateEvent(le, r.id, {
                properties: { ...r.properties,
                    ...n.properties
                }
            }), void na(a);
            Yt(a, le, n)
        })({
            event: n,
            threadId: r
        })
    }), i.on("chat_deactivated", e => {
        let {
            chatId: t
        } = e;
        t === me(a) && (() => {
            if (Jt(a), !Qt(a))
                if (Pt(a)) {
                    const {
                        properties: {
                            rate: e
                        }
                    } = a.getChat(le);
                    if (e) return;
                    Be(a, ia)
                } else Sn(o, C()).then(e => {
                    let {
                        enabled: t,
                        form: n
                    } = e;
                    t && Be(a, n)
                }, Sa)
        })()
    }), i.on("incoming_chat", e => {
        He(a, le, {
            chatId: e.chat.id
        });
        const t = en(a, e);
        h(t)
    });
    const W = (e, t) => {
            if (e !== me(a)) return !1;
            const n = Pe(le, a);
            return !!n && n.id === t
        },
        Z = () => 0 === Xt(a).length,
        Y = fe(La(i, "incoming_typing_indicator"), Ia(e => {
            if (!e.typingIndicator.isTyping || !W(e.chatId, e.typingIndicator.authorId)) return !1;
            const t = a.getChat(le).properties.agentActivity;
            return "thinking" !== (null == t ? void 0 : t.type)
        }), _e(() => ({
            type: "typing"
        }))),
        K = fe(La(i, "incoming_typing_indicator"), Ia(e => {
            if (e.typingIndicator.isTyping || !W(e.chatId, e.typingIndicator.authorId)) return !1;
            const t = a.getChat(le).properties.agentActivity;
            return "thinking" !== (null == t ? void 0 : t.type)
        }), Se(() => fe(Ra(Qa ? 0 : 200), _e(() => null)))),
        X = fe(La(i, "incoming_thinking_indicator"), Ia(e => W(e.chatId, e.authorId)), _e(e => ({
            type: "thinking",
            customId: e.customId,
            title: e.title,
            description: e.description,
            authorId: e.authorId
        }))),
        $ = fe(_a(La(i, "incoming_event"), La(i, "incoming_event_preview")), Ia(e => {
            let {
                chatId: t,
                event: n
            } = e;
            return t === me(a) && n.authorId !== a.getSessionUser().serverId && "system" !== n.authorId && W(t, n.authorId)
        }), _e(e => {
            let {
                event: t
            } = e;
            const n = a.getChat(le).properties.agentActivity;
            return "typing" === (null == n ? void 0 : n.type) ? null : "thinking" === (null == n ? void 0 : n.type) && n.customId ? t.customId === n.customId ? null : n : null
        }));
    fe(_a(fe(Y, Ia(() => !a.getApplicationState("messageDraft")), Ia(Z)), K, fe(X, Ia(Z)), $), Se(e => "typing" === (null == e ? void 0 : e.type) ? ((...e) => (t, a) => {
        if (0 !== t) return;
        const n = e.length;
        if (0 === n) return a(0, () => {}), void a(2);
        let r, s = 0;
        const i = (e, t) => {
            r(e, t)
        };
        ! function t() {
            s !== n ? e[s](0, (e, n) => {
                0 === e ? (r = n, 0 === s ? a(0, i) : r(1)) : 2 === e && n ? a(2, n) : 2 === e ? (s++, t()) : a(e, n)
            }) : a(2)
        }()
    })(On(e), fe(Ra(1e4), _e(() => null))) : On(e)), ut(), wa(e => {
        a.updateChat(le, {
            properties: {
                agentActivity: e
            }
        })
    }));
    const ee = () => {
        c.next().then(e => {
            let {
                value: t,
                done: n
            } = e;
            const r = a.getTimeline(le).length,
                s = t.filter(Boolean),
                i = j(Ut(e => e.events.map(e => ({ ...e,
                    seen: !0
                })), Pt(a) ? Ft(a, s) : s));
            i.length > 0 && a.addHistoryEvents(le, i);
            r !== a.getTimeline(le).length || n ? a.updateChat(le, {
                properties: {
                    loadingHistory: !1,
                    hasMoreHistory: !n
                }
            }) : ee()
        }, () => {
            a.updateChat(le, {
                properties: {
                    loadingHistory: !1
                }
            })
        })
    };
    fe(st(a, () => a.getChat(le).properties.loadingHistory), Ia(Boolean), wa(ee)), a.on("request_update_chat", e => {
        let {
            resolve: t,
            reject: n,
            meta: r,
            data: {
                properties: s = {},
                ...o
            }
        } = e;
        if (s.rateComment) {
            const {
                rateComment: e
            } = s;
            kr(a, e), i.rateChat({
                chatId: me(a),
                rating: {
                    comment: e
                }
            }).then(t, n)
        } else if (void 0 !== s.rate) {
            Ar(a, s.rate);
            const {
                testGroup: e
            } = a.getApplicationState();
            if (ht({
                    testGroup: e,
                    chatRating: null === s.rate ? "canceled" : s.rate,
                    chatRatingSource: (null == r ? void 0 : r.source) || "other"
                }), null === s.rate) return void i.cancelRate({
                chatId: me(a)
            }).then(() => {
                a.updateChat(le, {
                    properties: {
                        rateComment: null
                    }
                }), t()
            }, n);
            i.rateChat({
                chatId: me(a),
                rating: {
                    score: v(s.rate)
                }
            }).then(t, n)
        } else s.transcriptSentTo ? i.updateThreadProperties({
            chatId: me(a),
            threadId: m(),
            properties: {
                routing: {
                    transcript_email: s.transcriptSentTo
                }
            }
        }).then(t, n) : !1 === o.active && i.deactivateChat({
            id: me(a)
        }).then(t, n)
    });
    const te = e => "subject" === e.serverType ? "subject" : "name" === e.name ? "name" : "text" === e.type ? "question" : e.type,
        ae = (e, t) => {
            let {
                id: a,
                serverId: n,
                properties: {
                    formType: r,
                    formId: s,
                    fields: i
                }
            } = e;
            const o = Pr(i, t),
                c = o.fields,
                d = {
                    filledForm: {
                        type: "filled_form",
                        formId: s,
                        ...!n && {
                            customId: a
                        },
                        fields: i.filter(e => void 0 !== e.serverName && "rating" !== e.type && "information" !== e.type).map(e => {
                            if ("groupSelect" === e.meta) return {
                                type: "group_chooser",
                                id: e.serverName,
                                label: da(e.label),
                                answer: {
                                    id: String(o.choosenGroupIndex),
                                    groupId: o.choosenGroup,
                                    label: e.options[o.choosenGroupIndex].label
                                }
                            };
                            if ("confirm_subscription" === e.meta) {
                                const t = c[e.serverName];
                                return {
                                    type: "checkbox_for_email",
                                    id: e.serverName,
                                    label: e.options[0].label,
                                    answer: !!t && T(e.options[0].originalValue, t)
                                }
                            }
                            if (Ta(e.options)) {
                                const t = {
                                        type: te(e),
                                        id: e.serverName,
                                        label: da(e.label)
                                    },
                                    a = qa(e.serverName, c) ? de(c[e.serverName]) : [],
                                    n = e.options.filter(e => T(e.originalValue, a)).map(e => ({
                                        label: e.label,
                                        value: e.originalValue
                                    }));
                                if ("checkbox" === t.type) t.answers = n.map(e => {
                                    let {
                                        label: t,
                                        value: a
                                    } = e;
                                    return {
                                        label: t,
                                        id: a
                                    }
                                });
                                else if (n.length) {
                                    const e = n[0];
                                    t.answer = {
                                        id: e.value,
                                        label: e.label
                                    }
                                }
                                return t
                            }
                            return qa(e.serverName, c) ? {
                                type: te(e),
                                id: e.serverName,
                                label: da(e.label),
                                answer: c[e.serverName]
                            } : {
                                type: te(e),
                                id: e.serverName,
                                label: da(e.label)
                            }
                        }),
                        properties: { ...r && {
                                lc2: {
                                    form_type: r
                                }
                            }
                        }
                    }
                };
            return void 0 !== o.choosenGroup && (d.choosenGroup = o.choosenGroup), d
        };
    let ne = 0;
    const re = Fn(300, e => {
        const t = me(a),
            n = new Date(e).toISOString().replace(/Z$/, "999Z");
        t && i.markEventsAsSeen({
            chatId: t,
            seenUpTo: n
        }).catch(Sa)
    });
    a.on("request_update_event", e => {
        const t = a.getEvent(le, e.id);
        if (e.data.seen) {
            const n = t.properties.isPreview;
            e.resolve(), n || (ne = Math.max(ne, a.getEvent(le, e.id).timestamp), re(ne))
        } else if ("ticket" === t.properties.formType) {
            const {
                answers: s
            } = e.data.properties, {
                fields: i
            } = t.properties, {
                fields: c
            } = Pr(i, s), d = a.getApplicationState();
            let p = null,
                l = null,
                u = null;
            switch (mt("ticketForm", a).mode) {
                case "helpdesk":
                    {
                        var n;
                        const e = pa(),
                            a = tn({
                                hdLicenseID: null == (n = d.config.properties.license[e]) ? void 0 : n.hdLicenseID,
                                group: d.group,
                                pageUrl: d.page.url,
                                form: (r = t.properties, nn(rn(r))),
                                answers: c,
                                additionalInfo: d.config.features.ticketForm.additionalInfo
                            });p = gt(o.sdk.auth.getToken, a),
                        l = e => cn(e.id, a),
                        u = la;
                        break
                    }
                case "offline_message":
                    {
                        const {
                            filledForm: e
                        } = ae(t, s);p = ba({
                            customerStartingEvent: e,
                            group: d.group
                        }).then(e => (he(e), e)),
                        l = t => {
                            var a, n;
                            const r = pe(e => "subject" === e.type, e.fields);
                            return {
                                id: t.thread,
                                text: xr(e),
                                visitor: {
                                    name: (null == (a = pe(e => "name" === e.type, e.fields)) ? void 0 : a.answer) || null,
                                    email: (null == (n = pe(e => "email" === e.type, e.fields)) ? void 0 : n.answer) || null
                                },
                                ...(null == r ? void 0 : r.answer) && {
                                    subject: r.answer
                                }
                            }
                        },
                        u = (e, t, a) => {
                            a()
                        };
                        break
                    }
                default:
                    {
                        const {
                            filledForm: e
                        } = ae(t, s),
                        {
                            timeZone: n
                        } = (new Intl.DateTimeFormat).resolvedOptions();p = jr(o.sdk.auth, {
                            filledForm: e,
                            groupId: d.group,
                            organizationId: d.organizationId,
                            timeZone: "string" != typeof n || /^Etc\//.test(n) || -1 === n.indexOf("/") && "UTC" !== n ? null : n,
                            page: d.page.url
                        }, a),
                        l = t => {
                            var a, n;
                            const r = pe(e => "subject" === e.type, e.fields);
                            return {
                                id: t.id,
                                text: t.text,
                                visitor: {
                                    name: (null == (a = pe(e => "name" === e.type, e.fields)) ? void 0 : a.answer) || null,
                                    email: (null == (n = pe(e => "email" === e.type, e.fields)) ? void 0 : n.answer) || null
                                },
                                ...(null == r ? void 0 : r.answer) && {
                                    subject: r.answer
                                }
                            }
                        },
                        u = (e, t, a) => {
                            e && "VALIDATION" === e.code ? /name must be at most \d+ characters long/.test(e.message) ? a({
                                name: e.message
                            }) : "mail must be a valid e-mail address" !== e.message ? a() : a({
                                email: t("invalid_email")
                            }) : a()
                        };
                        break
                    }
            }
            p.then(n => {
                const {
                    fields: r
                } = t.properties;
                ((e, t, a, n) => {
                    let {
                        id: r,
                        text: s,
                        visitor: {
                            email: i,
                            name: o
                        },
                        subject: c
                    } = n;
                    const d = {
                        form_data: Er(t, a),
                        ticket_id: r,
                        text: s,
                        visitor_name: o,
                        visitor_email: i
                    };
                    c && (d.ticket_subject = c), e.emit("on_ticket_created", d)
                })(a, r, c, l(n)), e.resolve(), vt(a, e.id)
            }, t => {
                u(t, a.localize, e.reject)
            })
        } else if ("prechat" === t.properties.formType) {
            const {
                answers: n
            } = e.data.properties, {
                fields: r
            } = t.properties;
            ((e, t, a) => {
                wr(e, "prechat", t, a)
            })(a, r, Pr(r, n).fields);
            const {
                filledForm: s,
                choosenGroup: i
            } = ae(t, n), c = t => {
                switch (t.code) {
                    case "SERVICE_UNAVAILABLE":
                        return void F({
                            withSystemMessage: !0,
                            reason: "service_unavailable"
                        });
                    case "GROUPS_OFFLINE":
                        return void y().then(e.resolve, e.reject);
                    case "CUSTOMER_BANNED":
                    case "GROUP_NOT_FOUND":
                        return void l();
                    default:
                        e.reject()
                }
            }, d = () => ba({
                customerStartingEvent: s,
                agentFakeEvent: Mt(a, le),
                group: i
            }).then(e => {
                he(e)
            }).catch(e => c(e));
            if (void 0 !== i) return void mn(o, {
                groupId: i
            }).then(e => {
                if ("not_found" === e) {
                    const e = new Error('Group "' + i + '" not found (most likely it has been removed).');
                    throw e.code = "GROUP_NOT_FOUND", e
                }
                return e
            }).then(t => {
                const n = a.getApplicationState().group;
                a.setApplicationState({
                    group: i
                });
                if (!("online" === t)) return We(a) ? void d().then(() => {
                    a.setApplicationState({
                        availability: "offline"
                    })
                }, c) : void Promise.all([gn(o, i), n !== i && vn(o, {
                    groupId: i
                })].filter(Boolean)).then(e => {
                    let [t, n] = e;
                    t.enabled ? (_t(a, "ticketForm", n && {
                        mode: n
                    }), a.updateView("Chat/ticketForm", t.form)) : ft(a, "ticketForm"), a.setApplicationState({
                        availability: "offline"
                    })
                }, t => {
                    "CONNECTION_LOST" !== t.code ? l() : e.reject()
                });
                d().catch(c)
            }, t => {
                "CONNECTION_LOST" !== t.code ? l() : e.reject()
            });
            d()
        } else if ("postchat" === t.properties.formType) {
            const {
                answers: n
            } = e.data.properties, {
                fields: r
            } = t.properties;
            ((e, t, a) => {
                wr(e, "postchat", t, a)
            })(a, r, Pr(r, n).fields);
            const {
                filledForm: s
            } = ae(t, n);
            i.sendEvent({
                chatId: me(a),
                event: s,
                attachToLastThread: !0
            }).then(t => {
                e.resolve(), vt(a, e.id, an(a, t)), "rating" in n ? I(a, n).finally(() => S(a)) : S(a)
            }).catch(t => {
                if (t.message === yt) return He(a, le, {
                    forced: !0
                }), Fa(wn()).then(e => pn(e));
                e.reject()
            })
        } else if ("ask_for_email" === t.properties.formId) {
            const {
                answers: n
            } = e.data.properties, {
                filledForm: r
            } = ae(t, n);
            i.sendEvent({
                chatId: me(a),
                event: r,
                attachToLastThread: !0
            }).then(t => {
                e.resolve(), A(t)
            }).catch(() => e.reject())
        }
        var r
    }), a.on("request_customer_token", () => {
        o.sdk.auth.getToken().then(e => a.emit("customer_token_response", e)).catch(e => a.emit("customer_token_error", e))
    }), a.on("request_update_user", e => {
        let {
            resolve: t,
            id: n,
            data: {
                properties: r,
                ...s
            }
        } = e;
        if (a.getSessionUserId() === n) {
            if (ot(a)) {
                const e = Aa({
                    name: s.name,
                    email: s.email,
                    sessionFields: r
                });
                i.updateCustomer(e).catch(e => Oe("update_customer_request_failed", e))
            }
            t()
        }
    }), a.on("request_set_user_properties", e => {
        let {
            resolve: t,
            id: n,
            properties: r
        } = e;
        a.getSessionUserId() === n && (ot(a) && i.setCustomerSessionFields({
            sessionFields: r
        }).catch(Sa), t())
    });
    const se = (e, t) => {
            let {
                id: n,
                timestamp: r,
                threadId: s
            } = t;
            Nr(a, e, r), a.setEventServerId(le, e.id, n), a.updateEvent(le, e.id, {
                delivered: !0,
                serverTimestamp: r,
                thread: s
            })
        },
        ie = e => {
            a.updateEvent(le, e.id, {
                failed: !0
            })
        };
    a.on("send_file_events", () => {
        a.setApplicationState({
            isSendingFileEvents: !0
        });
        const e = [].concat(It(a));
        e.filter(e => e.properties.failed).forEach(e => a.updateEvent(le, e.id, {
            properties: {
                canceled: !0
            }
        }));
        const t = e.filter(e => {
            let {
                type: t,
                delivered: a,
                properties: {
                    canceled: n,
                    finished: r
                }
            } = e;
            return "file" === t && !a && !n && r
        }).map(e => i.sendEvent({
            chatId: me(a),
            event: {
                type: "file",
                customId: e.id,
                url: e.properties.serverUrl,
                alternativeText: e.properties.alternativeText
            }
        }).then(t => {
            a.updateEvent(le, e.id, {
                delivered: !0
            }), A(t), Promise.resolve().then(() => {
                "image" === e.properties.fileType && URL.revokeObjectURL(e.properties.url)
            });
            const n = e.properties.uploadSource;
            ("clipboard" === n || Math.random() < .1) && ge("file_upload_sent", {
                uploadSource: n
            })
        }));
        Promise.all(t).finally(() => {
            a.setApplicationState({
                isSendingFileEvents: !1
            })
        })
    });
    const oe = {};
    a.on("cancel_upload", e => {
        let {
            eventId: t
        } = e;
        const n = a.getEvent(le, t);
        a.updateEvent(le, t, {
            properties: {
                canceled: !0
            }
        }), oe[t] && oe[t].cancel(), Promise.resolve().then(() => {
            "image" === n.properties.fileType && URL.revokeObjectURL(n.properties.url)
        })
    }), a.on("add_message_reaction", e => {
        let {
            eventId: t,
            reaction: n
        } = e;
        const r = a.getEvent(le, t);
        i.updateEventProperties({
            chatId: me(a),
            threadId: r.thread,
            eventId: r.serverId,
            properties: {
                bb9e5b2f1ab480e4a715977b7b1b4279: {
                    message_reaction: n
                }
            }
        }), (a.getApplicationState("license") === Te || Math.random() < .1) && ge("message_reaction_sent", {
            reaction: n,
            messageType: r.type,
            chatId: me(a)
        })
    });
    const ce = e => {
            let {
                event: t,
                meta: n
            } = e;
            if ("file" === t.type) {
                const e = i.uploadFile({
                    file: n.file,
                    onProgress: e => a.updateEvent(le, t.id, {
                        properties: {
                            progress: e
                        }
                    })
                });
                return oe[t.id] = e, e.promise.then(e => {
                    let {
                        url: n
                    } = e;
                    a.updateEvent(le, t.id, {
                        properties: {
                            serverUrl: n,
                            finished: !0
                        }
                    })
                }, e => {
                    "UPLOAD_CANCELED" !== e.code && a.updateEvent(le, t.id, {
                        properties: {
                            failed: !0,
                            failReason: Dr(a, e)
                        }
                    })
                }).finally(() => {
                    delete oe[t.id]
                })
            }
            if (T(t.type, ["message", "emoji"])) return i.sendEvent({
                chatId: me(a),
                event: dn(a, t)
            }).then(e => {
                se(t, e)
            }, () => {
                ie(t)
            });
            if ("custom_system_message" === t.type) return i.sendEvent({
                chatId: me(a),
                event: dn(a, t)
            }).then(A, Sa);
            if ("rich_message_postback" === t.type) {
                const {
                    eventId: e,
                    postback: n
                } = t.properties;
                return i.sendRichMessagePostback({
                    chatId: me(a),
                    threadId: a.getEvent(le, e).thread,
                    eventId: e,
                    postback: n
                }).catch(Sa)
            }
            if ("url_preview" === t.type) {
                const e = i.getUrlInfo({
                    url: t.properties.url
                }).catch(() => null);
                return i.sendEvent({
                    chatId: me(a),
                    event: dn(a, t)
                }).then(n => {
                    se(t, n), e.then(e => {
                        const {
                            title: r,
                            description: s,
                            url: o,
                            imageUrl: c
                        } = e;
                        return a.updateEvent(le, t.id, {
                            properties: {
                                title: r,
                                description: s,
                                image: {
                                    url: c,
                                    link: o
                                }
                            }
                        }), i.updateEventProperties({
                            chatId: me(a),
                            threadId: n.thread,
                            eventId: n.id,
                            properties: {
                                url_details: {
                                    title: r,
                                    description: s,
                                    url: o,
                                    image_url: c,
                                    image_width: e.imageWidth,
                                    image_height: e.imageHeight
                                }
                            }
                        })
                    }).catch(Sa)
                }, () => {
                    ie(t)
                })
            }
        },
        he = e => {
            let {
                events: t,
                ...n
            } = e;
            const r = a.getSessionUser().id;
            t.forEach(e => {
                a.getEvent(le, e.id) ? e.author === r ? ((e, t) => {
                    const a = t.timestamp;
                    "message" === t.properties.serverType && Nr(e, t, a), e.setEventServerId(le, t.id, t.serverId);
                    const n = {
                        delivered: !0,
                        serverTimestamp: a,
                        thread: t.thread
                    };
                    "form" === t.type && (n.properties = {
                        answered: !0,
                        fields: t.properties.fields
                    }), e.updateEvent(le, t.id, n)
                })(a, e) : e.properties.welcomeMessage || e.properties.invitation ? ((e, t) => {
                    const a = Mt(e, le);
                    e.setEventServerId(le, a.id, t.serverId);
                    const n = a.author !== t.author;
                    n && e.setEventData(le, a.id, {
                        author: t.author
                    });
                    const r = {
                        delivered: !0,
                        thread: t.thread,
                        serverTimestamp: t.timestamp,
                        properties: {}
                    };
                    a.properties.text !== t.properties.text && (r.properties.text = t.properties.text), e.updateEvent(le, a.id, r), n && (Fe(e, t.author), e.recalculateTimeline(le))
                })(a, e) : k(e) : k(e)
            }), h({ ...n,
                events: []
            })
        },
        ba = e => (a.updateChat(le, {
            properties: {
                starting: !0
            }
        }), St(a), fn(o, e).catch(t => {
            if (t.message === yt) return He(a, le, {
                forced: !0
            }), ba(e);
            throw a.updateChat(le, {
                properties: {
                    starting: !1
                }
            }), t
        }));
    let Oa = [];
    const Pa = e => {
        if (lt(le, a)) return void Oa.push(e);
        const t = () => {
            ga(a) && va(a)
        };
        a.getChat(le).active ? e && ce(e).then(t) : ba({ ...e && {
                customerStartingEvent: e.event
            },
            agentFakeEvent: Mt(a, le)
        }).then(e => {
            he(e);
            const a = Oa;
            Oa = [], a.forEach(ce), t()
        }, t => {
            a.updateEvent(le, e.event.id, {
                failed: !0
            });
            const n = Oa;
            switch (Oa = [], n.forEach(e => {
                a.updateEvent(le, e.id, {
                    failed: !0
                })
            }), t.code) {
                case "SERVICE_UNAVAILABLE":
                    return void F({
                        withSystemMessage: !0,
                        reason: "service_unavailable"
                    });
                case "CUSTOMER_BANNED":
                    return void l();
                case "GROUPS_OFFLINE":
                    return void y();
                default:
                    return
            }
        })
    };
    a.on("start_thread", Pa), a.on("send_event", Pa), a.on("request_cancel_greeting", e => {
        De(a, "maximized") && Me(a), xe(a, e.id), i.cancelGreeting({
            uniqueId: e.properties.uniqueId
        }).catch(Sa)
    });
    const Fa = e => {
            let {
                active: t,
                availability: n,
                connected: r,
                hasFakeAgentMessage: s,
                startChatAgainPending: i,
                limitReached: c,
                hasMutedGreeting: d
            } = e;
            return Ca(() => c || t ? {
                type: "nothing"
            } : "offline" === n ? We(a) ? i && Ze(a) ? {
                type: "show_prechat"
            } : {
                type: "nothing"
            } : Ct(a) ? bt(a) ? {
                type: "nothing"
            } : {
                type: "show_ticket_form"
            } : {
                type: "hide_prechat_form"
            } : d ? {
                type: "accept_muted_greeting"
            } : s ? {
                type: "hide_ticket_form"
            } : Pe(le, a) && Ze(a) ? {
                type: "show_prechat"
            } : De(a, "maximized") ? !r || zr.acceptingGreeting ? {
                type: "nothing"
            } : (zr.requestingPredictedWelcomeMessage = !0, J.then(() => _n(o)).then(e => {
                let {
                    agent: t,
                    message: n,
                    groupHasQueue: r
                } = e;
                zr.requestingPredictedWelcomeMessage = !1;
                const s = [{
                    type: "hide_ticket_form"
                }, {
                    type: "predicted_welcome_message",
                    payload: {
                        agent: t,
                        message: n,
                        groupHasQueue: r
                    }
                }];
                return Ze(a) ? s.push({
                    type: "show_prechat"
                }) : i && t.isBot && s.push({
                    type: "start_chat"
                }), s
            }, e => {
                if (zr.requestingPredictedWelcomeMessage = !1, "offline" === a.getApplicationState("availability")) return {
                    type: "nothing"
                };
                switch (e.code) {
                    case "GROUP_OFFLINE":
                        return {
                            type: "nothing"
                        };
                    default:
                        return {
                            type: "panic"
                        }
                }
            })) : {
                type: "nothing"
            }).then(de)
        },
        Ua = () => {
            const e = a.getChat(le);
            return (!e.active || e.properties.queued) && !e.properties.starting && !e.properties.ended
        },
        xa = () => {
            a.updateView("minimized", {
                hidden: !1
            })
        };
    fe(H, wa(xa));
    const Ma = fe(st(a, e => e.application.destroyed), Ia(Boolean), Ea(1), it);
    fe(R, Ea(1), _e(() => {
        const e = ja(g(["organizationId", "group", "requestedGroup"], a.getApplicationState()));
        return [Tt("session") && window.sessionStorage.getItem(e), e]
    }), Ia(e => {
        let [t] = e;
        return Boolean(t)
    }), wa(e => {
        let [t, n] = e;
        (e => {
            let t;
            const n = m();
            try {
                t = JSON.parse(e)
            } catch (r) {
                return
            }
            t && n && t.forEach(e => {
                a.getEvent(le, e.id) || Yt(a, le, {
                    thread: n,
                    id: e.id,
                    type: "file",
                    own: !0,
                    author: a.getSessionUser().id,
                    delivered: !1,
                    failed: !1,
                    properties: e
                })
            })
        })(t), window.sessionStorage.removeItem(n)
    }));
    const [za, Ha] = fe(st(a, e => e.application.availability), Va(1), Na, _e(e => ({
        type: e
    })), (Ba = e => {
        let {
            type: t
        } = e;
        return "online" === t
    }, function(e) {
        return [Ia(Ba)(e), Ia((t = Ba, function(e) {
            return !t(e)
        }))(e)];
        var t
    }));
    var Ba;
    fe(V(() => Ha), Ia(Ua), wa(() => {
        !Et(a, "prechat") && We(a) && Ze(a) && "offline" === a.getApplicationState().availability && !a.getChat(le).active && Ye(a), Et(a, "prechat") && (At(a), We(a) && Ye(a)), p()
    })), fe(za, Ia(Ua), wa(() => {
        a.getView("minimized").hidden && xa(), !Ct(a) && ea(a) && De(a, "hidden") && !a.getApplicationState("isMinimizedForcefullyDisabled") && Me(a)
    })), fe(V(() => {
        if (!Ze(a)) return qn;
        const e = st(a, () => Et(a, "prechat"));
        return fe(_a(H, e), Ia(() => Et(a, "prechat")), Se(() => {
            const e = a.getLastEvent(le);
            return fe(be(((e, t) => {
                const a = ua(e => "groupSelect" === e.meta, t);
                if (-1 === a) return Promise.resolve(null);
                const n = t[a],
                    r = n.options.map(e => e.groupId);
                return r.length > 20 ? Promise.resolve(null) : En(e, {
                    groupIds: r
                }).then(e => ha(a, { ...n,
                    options: n.options.map(t => ({ ...t,
                        meta: {
                            online: "online" === e[t.groupId]
                        }
                    }))
                }, t))
            })(o, e.properties.fields)), kn)
        }))
    }), Ia(e => e && Et(a, "prechat")), wa(e => {
        const {
            id: t
        } = a.getLastEvent(le);
        return a.updateEvent(le, t, {
            properties: {
                fields: e
            }
        })
    }));
    const pn = e => e.forEach(e => {
            switch (e.type) {
                case "panic":
                    return void l();
                case "chat_activated":
                    return void he(e.payload);
                case "predicted_welcome_message":
                    {
                        const {
                            agent: t,
                            message: n,
                            groupHasQueue: r
                        } = e.payload;
                        return b(t),
                        Fe(a, t.id),
                        void(Ze(a) || (qt(a) || (k(n), a.updateChat(le, {
                            properties: {
                                fakeAgentMessageId: n.id
                            }
                        })), a.updateChat(le, {
                            properties: {
                                groupHasProbableQueue: r
                            }
                        })))
                    }
                case "show_ticket_form":
                    return e.payload && a.updateView("Chat/ticketForm", e.payload), void Nt(a, "offline");
                case "hide_prechat_form":
                    return void At(a);
                case "hide_ticket_form":
                    return void(Et(a, "ticket") && kt(a));
                case "show_prechat":
                    return void Ye(a);
                case "accept_muted_greeting":
                    return void(() => {
                        const e = a.getLastEvent(le),
                            {
                                mutedGreeting: t
                            } = a.getChat(le).properties;
                        a.updateEvent(le, e.id, {
                            seen: !0
                        }), zr.acceptingGreeting = !0, Cn(o, t).then(e => {
                            let {
                                event: t
                            } = e;
                            a.updateChat(le, {
                                properties: {
                                    mutedGreeting: void 0
                                }
                            }), Wt(a, t)
                        }, Sa).finally(() => {
                            zr.acceptingGreeting = !1
                        })
                    })();
                case "start_chat":
                    return void wt(a);
                default:
                    return
            }
        }),
        wn = () => {
            const e = a.getChat(le);
            return {
                active: e.active,
                availability: a.getApplicationState("availability"),
                connected: ot(a),
                hasFakeAgentMessage: Ve(a, le),
                startChatAgainPending: e.properties.startChatAgainPending,
                limitReached: a.getApplicationState("limitReached"),
                hasMutedGreeting: !!e.properties.mutedGreeting
            }
        };
    var An;
    fe(V(() => fe(st(a, () => a.getChat(le).properties.startChatAgainPending), Ia(Boolean))), Se(() => be(Fa(wn()))), wa(e => {
        He(a, le, {
            chatId: a.getChat(le).serverId
        }), pn(e)
    })), fe(_a(H, za, Ha), (An = R, function(e) {
        return function(t, a) {
            if (0 === t) {
                var n, r, s = !1;
                e(0, (function(e, t) {
                    0 === e && (n = t, An(0, (function(e, t) {
                        0 === e ? (r = t)(1) : 1 === e && (s = !0, r(2))
                    }))), 1 === e ? s ? a(1, t) : n(1) : a(e, t)
                }))
            }
        }
    }), Ia(() => Ua() && a.getApplicationState().eagerFetchingMode), Ot(() => be(Fa(wn()))), Ce(Ma), wa(pn)), fe(V(() => fe(H, Ia(() => !a.getApplicationState().eagerFetchingMode))), Se(() => {
        const e = a.getChat(le).serverId;
        return be(Promise.all([Fa(wn()), Re(a) && e && yn(o, e)].filter(Boolean)))
    }), Ce(Ma), wa(e => {
        let [t, n] = e;
        if (n) {
            u(a.getChat(le).serverId, n.iterator), z(n.hasMore);
            const e = Pt(a) ? Ft(a, n.threads) : n.threads,
                t = Ut(e => {
                    let {
                        events: t
                    } = e;
                    return t
                }, e).filter(e => !a.hasEvent(le, e.id));
            t.length > 0 && a.addHistoryEvents(le, t);
            const r = a.getChat(le).properties.previousThread,
                s = e.length ? xt(e).id : null,
                i = !(r && r === s);
            a.updateChat(le, {
                properties: {
                    eventsSeenUpToMap: n.eventsSeenUpToMap,
                    ...i && {
                        lastThread: s
                    }
                }
            })
        }
        a.setApplicationState({
            eagerFetchingMode: !0
        }), pn(t)
    })), fe(st(a, e => e.application.page), Va(1), Ce(Ma), wa(e => {
        let {
            url: t,
            title: a
        } = e;
        i.updateCustomerPage({
            url: t,
            title: a
        })
    }));
    const Nn = {
        indicatorNotAnimated: -1
    };
    fe(st(a, () => a.getUnseenCount(le) > 0), Ia(un), wa(() => {
        clearTimeout(Nn.indicatorNotAnimated), a.updateView("minimized", { ...a.getView("minimized"),
            animateUnseenEventIndicator: !0
        }), a.emit("render-minimized"), Nn.indicatorNotAnimated = setTimeout(() => {
            a.updateView("minimized", { ...a.getView("minimized"),
                animateUnseenEventIndicator: !1
            }), a.emit("render-minimized")
        }, 500)
    }));
    const Pn = Fn(fa, e => {
        i.setSneakPeek({
            chatId: me(a),
            sneakPeekText: e
        })
    });
    fe(st(a, e => e.application.messageDraft), ut(), Ia(() => a.getChat(le).active), wa(e => {
        "string" != typeof e ? Pn.cancel() : Pn(e)
    })), Lt(a) && fe(H, Ea(1), wa(() => {
        var e, t;
        const n = pa(),
            r = null == (e = a.getApplicationState("config").properties.license[n]) ? void 0 : e.hdLicenseID,
            s = null != (t = a.getApplicationState("group")) ? t : 0;
        Da(() => Tn(r, s), {
            retriesCount: Qa ? 2 : 10,
            minTime: Qa ? 100 : 1e3,
            maxTime: Qa ? 1e3 : 15e3
        }).then(e => {
            a.updateView("HelpdeskTicketForm", {
                helpdeskFormConfiguration: e,
                isLoading: !1
            })
        }, e => {
            a.updateView("HelpdeskTicketForm", {
                isLoading: !1,
                hasFetchingError: !0
            }), Oe("helpdesk_form_fetching_failed", e)
        })
    })), fe(st(a, () => a.getConnectionState()), Ia(e => e === ke), wa(() => {
        a.setApplicationState({
            disableSendingMessage: !0
        }), fe(_a(fe(Ra(Qa ? 500 : 8e3), _e(() => ({
            reason: "timeout"
        }))), fe(La(a, jt), _e(() => ({
            reason: "message_send_attempt"
        }))), fe(st(a, () => a.getConnectionState()), Ia(e => e !== ke), _e(() => ({
            reason: "connection_state_change"
        })))), Ea(1), wa(e => {
            let {
                reason: t
            } = e;
            a.setApplicationState({
                disableSendingMessage: !1
            }), a.getConnectionState() === ke && a.setConnectionState(Je), fe(st(a, () => a.getConnectionState()), Ia(e => e === Qe), Ea(1), wa(() => {
                Math.random() < .1 && ge("scheduled_reconnecting_ended", {
                    reason: t
                })
            }))
        }))
    })), fe(st(a, () => a.getConnectionState()), Ia(e => e === qe || e === Je), wa(() => {
        const e = Dt(a);
        e && !De(a, "maximized") && (a.removeEvent(le, e.id), setTimeout(() => a.emit("render-minimized"), 0))
    })), fe(st(a, e => e.application.privacyPolicyBannerState), Ia(e => "closing" !== e), ut(), wa(e => {
        const {
            organizationId: t,
            group: n
        } = a.getApplicationState();
        if ("unset" === e) {
            const e = ((e, t) => {
                try {
                    const a = ue.getItem(Ur(e, t));
                    return a ? JSON.parse(a) : {
                        hidden: !1
                    }
                } catch (a) {
                    return console.error("Error getting privacy policy state:", a), {
                        hidden: !1
                    }
                }
            })(t, n);
            a.setApplicationState({
                privacyPolicyBannerState: e.hidden ? "hidden" : "visible"
            })
        } else((e, t, a) => {
            ue.setItem(Ur(e, t), JSON.stringify(a))
        })(t, n, {
            hidden: "hidden" === e
        })
    }))
};
export {
    Gr as
    default
};