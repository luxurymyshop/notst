function n(n) {
    return function(t) {
        return function(i, e) {
            var o;
            0 === i && t(0, (function(t, i) {
                if (1 === t || 2 === t && void 0 === i) {
                    if (!o && 2 === t) return e(t, i);
                    o && clearTimeout(o), o = setTimeout((function() {
                        e(t, i), o = void 0
                    }), n)
                } else e(t, i)
            }))
        }
    }
}
export {
    n as d
};