function n(n) {
    return !!n
}
export {
    n as i
};