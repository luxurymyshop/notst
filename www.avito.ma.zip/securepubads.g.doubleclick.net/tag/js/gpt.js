(function(sttc) {
    var window = this;
    if (window.googletag && googletag.evalScripts) {
        googletag.evalScripts();
    }
    if (window.googletag && googletag._loaded_) return;
    var q, aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        ca = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        da = ca(this),
        ea = typeof Symbol === "function" && typeof Symbol("x") === "symbol",
        u = {},
        fa = {},
        v = function(a, b, c) {
            if (!c || a != null) {
                c = fa[b];
                if (c == null) return a[b];
                c = a[c];
                return c !== void 0 ? c : a[b]
            }
        },
        w = function(a, b, c) {
            if (b) a: {
                var d = a.split(".");a = d.length === 1;
                var e = d[0],
                    f;!a && e in u ? f = u : f = da;
                for (e = 0; e < d.length - 1; e++) {
                    var g = d[e];
                    if (!(g in f)) break a;
                    f = f[g]
                }
                d = d[d.length - 1];c = ea && c === "es6" ? f[d] : null;b = b(c);b != null && (a ? ba(u, d, {
                    configurable: !0,
                    writable: !0,
                    value: b
                }) : b !== c && (fa[d] === void 0 && (a = Math.random() * 1E9 >>> 0, fa[d] = ea ? da.Symbol(d) : "$jscp$" + a + "$" + d), ba(f, fa[d], {
                    configurable: !0,
                    writable: !0,
                    value: b
                })))
            }
        },
        ha;
    if (ea && typeof Object.setPrototypeOf == "function") ha = Object.setPrototypeOf;
    else {
        var ia;
        a: {
            var ja = {
                    a: !0
                },
                ka = {};
            try {
                ka.__proto__ = ja;
                ia = ka.a;
                break a
            } catch (a) {}
            ia = !1
        }
        ha = ia ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var la = ha,
        x = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (la) la(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.Kb = b.prototype
        },
        ma = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        y = function(a) {
            var b = typeof u.Symbol != "undefined" && v(u.Symbol, "iterator") && a[v(u.Symbol, "iterator")];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: ma(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        B = function(a) {
            if (!(a instanceof Array)) {
                a = y(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        oa = function(a) {
            return na(a, a)
        },
        na = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        C = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        pa = ea && typeof v(Object, "assign") == "function" ? v(Object, "assign") : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) C(d, e) && (a[e] = d[e])
            }
            return a
        };
    w("Object.assign", function(a) {
        return a || pa
    }, "es6");
    var qa = function() {
        for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
        return b
    };
    w("globalThis", function(a) {
        return a || da
    }, "es_2020");
    w("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.g = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.g
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    }, "es6");
    w("Symbol.iterator", function(a) {
        if (a) return a;
        a = (0, u.Symbol)("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return sa(ma(this))
            }
        });
        return a
    }, "es6");
    var sa = function(a) {
        a = {
            next: a
        };
        a[v(u.Symbol, "iterator")] = function() {
            return this
        };
        return a
    };
    w("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    }, "es6");
    w("WeakMap", function(a) {
        function b() {}

        function c(g) {
            var h = typeof g;
            return h === "object" && g !== null || h === "function"
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var g = Object.seal({}),
                        h = Object.seal({}),
                        k = new a([
                            [g, 2],
                            [h, 3]
                        ]);
                    if (k.get(g) != 2 || k.get(h) != 3) return !1;
                    k.delete(g);
                    k.set(h, 4);
                    return !k.has(g) && k.get(h) == 4
                } catch (m) {
                    return !1
                }
            }()) return a;
        var d = "$jscomp_hidden_" + Math.random(),
            e = 0,
            f = function(g) {
                this.g = (e += Math.random() + 1).toString();
                if (g) {
                    g = y(g);
                    for (var h; !(h = g.next()).done;) h = h.value, this.set(h[0], h[1])
                }
            };
        f.prototype.set = function(g, h) {
            if (!c(g)) throw Error("Invalid WeakMap key");
            if (!C(g, d)) {
                var k = new b;
                ba(g, d, {
                    value: k
                })
            }
            if (!C(g, d)) throw Error("WeakMap key fail: " + g);
            g[d][this.g] = h;
            return this
        };
        f.prototype.get = function(g) {
            return c(g) && C(g, d) ? g[d][this.g] : void 0
        };
        f.prototype.has = function(g) {
            return c(g) && C(g, d) && C(g[d], this.g)
        };
        f.prototype.delete = function(g) {
            return c(g) && C(g, d) && C(g[d], this.g) ? delete g[d][this.g] : !1
        };
        return f
    }, "es6");
    w("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !v(a.prototype, "entries") || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(y([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var m = v(k, "entries").call(k),
                        n = m.next();
                    if (n.done || n.value[0] != h || n.value[1] != "s") return !1;
                    n = m.next();
                    return n.done || n.value[0].x != 4 || n.value[1] != "t" || !m.next().done ? !1 : !0
                } catch (l) {
                    return !1
                }
            }()) return a;
        var b = new u.WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = y(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var m = d(this, h);
            m.list || (m.list = this[0][m.id] = []);
            m.entry ? m.entry.value = k : (m.entry = {
                next: this[1],
                H: this[1].H,
                head: this[1],
                key: h,
                value: k
            }, m.list.push(m.entry), this[1].H.next = m.entry, this[1].H = m.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.H.next = h.entry.next, h.entry.next.H = h.entry.H, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].H = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach = function(h, k) {
            for (var m = v(this, "entries").call(this), n; !(n = m.next()).done;) n = n.value, h.call(k, n[1], n[0], this)
        };
        c.prototype[v(u.Symbol, "iterator")] = v(c.prototype, "entries");
        var d = function(h, k) {
                var m = k && typeof k;
                m == "object" || m == "function" ? b.has(k) ? m = b.get(k) : (m = "" + ++g, b.set(k, m)) : m = "p_" + k;
                var n = h[0][m];
                if (n && C(h[0], m))
                    for (h = 0; h < n.length; h++) {
                        var l = n[h];
                        if (k !== k && l.key !== l.key || k === l.key) return {
                            id: m,
                            list: n,
                            index: h,
                            entry: l
                        }
                    }
                return {
                    id: m,
                    list: n,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, k) {
                var m = h[1];
                return sa(function() {
                    if (m) {
                        for (; m.head != h[1];) m = m.H;
                        for (; m.next != m.head;) return m = m.next, {
                            done: !1,
                            value: k(m)
                        };
                        m = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.H = h.next = h.head = h
            },
            g = 0;
        return c
    }, "es6");
    w("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !v(a.prototype, "entries") || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(y([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = v(d, "entries").call(d),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.g = new u.Map;
            if (c) {
                c = y(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.g.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.g.set(c, c);
            this.size = this.g.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.g.delete(c);
            this.size = this.g.size;
            return c
        };
        b.prototype.clear = function() {
            this.g.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.g.has(c)
        };
        b.prototype.entries = function() {
            return v(this.g, "entries").call(this.g)
        };
        b.prototype.values = function() {
            return v(this.g, "values").call(this.g)
        };
        b.prototype.keys = v(b.prototype, "values");
        b.prototype[v(u.Symbol, "iterator")] = v(b.prototype, "values");
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.g.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    }, "es6");
    w("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) C(b, d) && c.push(b[d]);
            return c
        }
    }, "es8");
    w("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    }, "es6");
    w("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || v(Object, "is").call(Object, f, b)) return !0
            }
            return !1
        }
    }, "es7");
    var ta = function(a, b, c) {
        if (a == null) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    w("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return ta(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    }, "es6");
    w("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof u.Symbol != "undefined" && v(u.Symbol, "iterator") && b[v(u.Symbol, "iterator")];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    }, "es6");
    w("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) C(b, d) && c.push([d, b[d]]);
            return c
        }
    }, "es8");
    w("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    }, "es6");
    w("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    }, "es6");
    w("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    }, "es6");
    w("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return v(Number, "isFinite").call(Number, b) ? b === Math.floor(b) : !1
        }
    }, "es6");
    w("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return v(Number, "isInteger").call(Number, b) && Math.abs(b) <= v(Number, "MAX_SAFE_INTEGER")
        }
    }, "es6");
    w("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = ta(this, b, "startsWith"),
                e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    }, "es6");
    var ua = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1,
            e = {
                next: function() {
                    if (!d && c < a.length) {
                        var f = c++;
                        return {
                            value: b(f, a[f]),
                            done: !1
                        }
                    }
                    d = !0;
                    return {
                        done: !0,
                        value: void 0
                    }
                }
            };
        e[v(u.Symbol, "iterator")] = function() {
            return e
        };
        return e
    };
    w("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return ua(this, function(b, c) {
                return [b, c]
            })
        }
    }, "es6");
    w("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    }, "es6");
    w("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    }, "es6");
    w("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return ua(this, function(b) {
                return b
            })
        }
    }, "es6");
    w("Array.prototype.values", function(a) {
        return a ? a : function() {
            return ua(this, function(b, c) {
                return c
            })
        }
    }, "es8");
    w("String.prototype.repeat", function(a) {
        return a ? a : function(b) {
            var c = ta(this, null, "repeat");
            if (b < 0 || b > 1342177279) throw new RangeError("Invalid count value");
            b |= 0;
            for (var d = ""; b;)
                if (b & 1 && (d += c), b >>>= 1) c += c;
            return d
        }
    }, "es6");
    w("String.prototype.padStart", function(a) {
        return a ? a : function(b, c) {
            var d = ta(this, null, "padStart");
            b -= d.length;
            c = c !== void 0 ? String(c) : " ";
            return (b > 0 && c ? v(c, "repeat").call(c, Math.ceil(b / c.length)).substring(0, b) : "") + d
        }
    }, "es8");
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var D = this || self,
        wa = function(a, b) {
            var c = va("CLOSURE_FLAGS");
            a = c && c[a];
            return a != null ? a : b
        },
        va = function(a) {
            a = a.split(".");
            for (var b = D, c = 0; c < a.length; c++)
                if (b = b[a[c]], b == null) return null;
            return b
        },
        xa = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        ya = function(a, b, c) {
            a = a.split(".");
            c = c || D;
            for (var d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        };

    function za(a) {
        D.setTimeout(function() {
            throw a;
        }, 0)
    };
    var Aa = function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };

    function Ba(a, b) {
        var c = 0;
        a = Aa(String(a)).split(".");
        b = Aa(String(b)).split(".");
        for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
            var f = a[e] || "",
                g = b[e] || "";
            do {
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                if (f[0].length == 0 && g[0].length == 0) break;
                c = Ca(f[1].length == 0 ? 0 : parseInt(f[1], 10), g[1].length == 0 ? 0 : parseInt(g[1], 10)) || Ca(f[2].length == 0, g[2].length == 0) || Ca(f[2], g[2]);
                f = f[3];
                g = g[3]
            } while (c == 0)
        }
        return c
    }

    function Ca(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
    var Da = wa(610401301, !1),
        Ea = wa(748402147, !0);
    var Fa, Ga = D.navigator;
    Fa = Ga ? Ga.userAgentData || null : null;

    function Ha(a) {
        if (!Da || !Fa) return !1;
        for (var b = 0; b < Fa.brands.length; b++) {
            var c = Fa.brands[b].brand;
            if (c && c.indexOf(a) != -1) return !0
        }
        return !1
    }

    function E(a) {
        var b;
        a: {
            if (b = D.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return b.indexOf(a) != -1
    };

    function Ia() {
        return Da ? !!Fa && Fa.brands.length > 0 : !1
    }

    function Ja() {
        return Ia() ? !1 : E("Opera")
    }

    function Ka() {
        return E("Firefox") || E("FxiOS")
    }

    function La() {
        return E("Safari") && !(Ma() || (Ia() ? 0 : E("Coast")) || Ja() || (Ia() ? 0 : E("Edge")) || (Ia() ? Ha("Microsoft Edge") : E("Edg/")) || (Ia() ? Ha("Opera") : E("OPR")) || Ka() || E("Silk") || E("Android"))
    }

    function Ma() {
        return Ia() ? Ha("Chromium") : (E("Chrome") || E("CriOS")) && !(Ia() ? 0 : E("Edge")) || E("Silk")
    };
    var Na = function(a, b) {
        return Array.prototype.map.call(a, b, void 0)
    };

    function Oa(a, b) {
        a: {
            for (var c = typeof a === "string" ? a.split("") : a, d = a.length - 1; d >= 0; d--)
                if (d in c && b.call(void 0, c[d], d, a)) {
                    b = d;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    };
    var Pa = function(a) {
        Pa[" "](a);
        return a
    };
    Pa[" "] = function() {};
    var Qa = null,
        Sa = function(a) {
            var b = [];
            Ra(a, function(c) {
                b.push(c)
            });
            return b
        },
        Ra = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var m = a.charAt(d++),
                        n = Qa[m];
                    if (n != null) return n;
                    if (!/^[\s\xa0]*$/.test(m)) throw Error("Unknown base64 encoding at char: " + m);
                }
                return k
            }
            Ta();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (h === 64 && e === -1) break;
                b(e << 2 | f >> 4);
                g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
            }
        },
        Ta = function() {
            if (!Qa) {
                Qa = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++)
                    for (var d = a.concat(b[c].split("")), e = 0; e < d.length; e++) {
                        var f = d[e];
                        Qa[f] === void 0 && (Qa[f] = e)
                    }
            }
        };

    function Ua(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var Va = void 0,
        Wa;

    function Xa(a) {
        if (Wa) throw Error("");
        Wa = function(b) {
            D.setTimeout(function() {
                a(b)
            }, 0)
        }
    }

    function Ya(a) {
        if (Wa) try {
            Wa(a)
        } catch (b) {
            throw b.cause = a, b;
        }
    }

    function Za(a) {
        a = Error(a);
        Ua(a, "warning");
        Ya(a);
        return a
    };
    var $a = typeof u.Symbol === "function" && typeof(0, u.Symbol)() === "symbol";

    function ab(a, b, c) {
        return typeof u.Symbol === "function" && typeof(0, u.Symbol)() === "symbol" ? (c === void 0 ? 0 : c) && u.Symbol.for && a ? u.Symbol.for(a) : a != null ? (0, u.Symbol)(a) : (0, u.Symbol)() : b
    }
    var bb = ab("jas", void 0, !0),
        eb = ab(void 0, "0di"),
        fb = ab(void 0, "1oa"),
        gb = ab(void 0, "0actk"),
        hb = ab("m_m", "Jb", !0);
    var ib = {
            eb: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        jb = Object.defineProperties,
        F = $a ? bb : "eb",
        kb, lb = [];
    G(lb, 7);
    kb = Object.freeze(lb);

    function mb(a, b) {
        $a || F in a || jb(a, ib);
        a[F] |= b
    }

    function G(a, b) {
        $a || F in a || jb(a, ib);
        a[F] = b
    }

    function nb(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function ob(a) {
        mb(a, 32);
        return a
    };

    function pb() {
        return typeof BigInt === "function"
    };
    var qb = {};

    function H(a, b) {
        return b === void 0 ? a.g !== rb && !!(2 & (a.i[F] | 0)) : !!(2 & b) && a.g !== rb
    }
    var rb = {};

    function sb(a, b) {
        if (typeof b !== "number" || b < 0 || b >= a.length) throw Error();
    }
    var tb = Object.freeze({}),
        ub = Object.freeze({});

    function vb(a) {
        var b = wb;
        if (!a) throw Error((typeof b === "function" ? b() : b) || String(a));
    }

    function xb(a) {
        a.Ib = !0;
        return a
    }
    var wb = void 0;
    var yb = xb(function(a) {
            return typeof a === "number"
        }),
        zb = xb(function(a) {
            return typeof a === "string"
        }),
        Ab = xb(function(a) {
            return typeof a === "boolean"
        });
    var Bb = typeof D.BigInt === "function" && typeof D.BigInt(0) === "bigint";

    function Cb(a) {
        var b = a;
        if (zb(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
        } else if (yb(b) && !v(Number, "isSafeInteger").call(Number, b)) throw Error(String(b));
        return Bb ? BigInt(a) : a = Ab(a) ? a ? "1" : "0" : zb(a) ? a.trim() || "0" : String(a)
    }
    var Ib = xb(function(a) {
            return Bb ? a >= Db && a <= Eb : a[0] === "-" ? Fb(a, Gb) : Fb(a, Hb)
        }),
        Gb = v(Number, "MIN_SAFE_INTEGER").toString(),
        Db = Bb ? BigInt(v(Number, "MIN_SAFE_INTEGER")) : void 0,
        Hb = v(Number, "MAX_SAFE_INTEGER").toString(),
        Eb = Bb ? BigInt(v(Number, "MAX_SAFE_INTEGER")) : void 0;

    function Fb(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    var I = 0,
        J = 0;

    function Jb(a) {
        var b = a >>> 0;
        I = b;
        J = (a - b) / 4294967296 >>> 0
    }

    function Kb(a) {
        if (a < 0) {
            Jb(-a);
            var b = y(Lb(I, J));
            a = b.next().value;
            b = b.next().value;
            I = a >>> 0;
            J = b >>> 0
        } else Jb(a)
    }

    function Mb(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else pb() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), c = b + Nb(c) + Nb(a));
        return c
    }

    function Nb(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function Ob() {
        var a = I,
            b = J;
        b & 2147483648 ? pb() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = y(Lb(a, b)), a = b.next().value, b = b.next().value, a = "-" + Mb(a, b)) : a = Mb(a, b);
        return a
    }

    function Lb(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function Pb(a) {
        return Array.prototype.slice.call(a)
    };

    function Qb(a, b) {
        throw Error(b === void 0 ? "unexpected value " + a + "!" : b);
    };
    var Rb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Sb = v(Number, "isSafeInteger"),
        Tb = v(Number, "isFinite"),
        Ub = v(Math, "trunc");

    function Vb(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function Wb(a) {
        if (typeof a !== "boolean") throw Error("Expected boolean but got " + xa(a) + ": " + a);
        return a
    }
    var Xb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Yb(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Tb(a);
            case "string":
                return Xb.test(a);
            default:
                return !1
        }
    }

    function Zb(a) {
        if (!Tb(a)) throw Za("enum");
        return a | 0
    }

    function $b(a) {
        return a == null ? a : Tb(a) ? a | 0 : void 0
    }

    function ac(a) {
        if (typeof a !== "number") throw Za("int32");
        if (!Tb(a)) throw Za("int32");
        return a | 0
    }

    function bc(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Tb(a) ? a | 0 : void 0
    }

    function cc(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Tb(a) ? a >>> 0 : void 0
    }

    function dc(a) {
        var b = 0;
        b = b === void 0 ? 0 : b;
        if (!Yb(a)) throw Za("int64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return ec(a);
                    case "bigint":
                        return String(Rb(64, a));
                    default:
                        return fc(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return hc(a);
                    case "bigint":
                        return Cb(Rb(64, a));
                    default:
                        return ic(a)
                }
            case 0:
                switch (c) {
                    case "string":
                        return ec(a);
                    case "bigint":
                        return Cb(Rb(64, a));
                    default:
                        return jc(a)
                }
            default:
                return Qb(b, "Unknown format requested type for int64")
        }
    }

    function kc(a) {
        return a == null ? a : dc(a)
    }

    function lc(a) {
        var b = a.length;
        if (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") return a;
        if (a.length < 16) Kb(Number(a));
        else if (pb()) a = BigInt(a), I = Number(a & BigInt(4294967295)) >>> 0, J = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            b = +(a[0] === "-");
            J = I = 0;
            for (var c = a.length, d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), J *= 1E6, I = I * 1E6 + d, I >= 4294967296 && (J += v(Math, "trunc").call(Math, I / 4294967296), J >>>= 0, I >>>= 0);
            b && (b = y(Lb(I, J)), a = b.next().value, b = b.next().value, I = a, J = b)
        }
        return Ob()
    }

    function jc(a) {
        a = Ub(a);
        if (!Sb(a)) {
            Kb(a);
            var b = I,
                c = J;
            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
            var d = c * 4294967296 + (b >>> 0);
            b = v(Number, "isSafeInteger").call(Number, d) ? d : Mb(b, c);
            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
        }
        return a
    }

    function fc(a) {
        a = Ub(a);
        Sb(a) ? a = String(a) : (Kb(a), a = Ob());
        return a
    }

    function ec(a) {
        var b = Ub(Number(a));
        if (Sb(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return lc(a)
    }

    function hc(a) {
        var b = Ub(Number(a));
        if (Sb(b)) return Cb(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return pb() ? Cb(Rb(64, BigInt(a))) : Cb(lc(a))
    }

    function ic(a) {
        return Sb(a) ? Cb(jc(a)) : Cb(fc(a))
    }

    function mc(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function nc(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function oc(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function pc(a, b, c, d) {
        if (a != null && a[hb] === qb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? b[eb] || (b[eb] = qc(b)) : new b : void 0;
        c = a[F] | 0;
        d = c | d & 32 | d & 2;
        d !== c && G(a, d);
        return new b(a)
    }

    function qc(a) {
        a = new a;
        mb(a.i, 34);
        return a
    };

    function rc(a) {
        return a
    };

    function sc(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            k = !1,
            m = !!(b & 64),
            n = m ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var l = g && a[g - 1];
            l != null && typeof l === "object" && l.constructor === Object ? (g--, h = g) : l = void 0;
            if (m && !(b & 128) && !e) {
                k = !0;
                var p;
                h = ((p = tc) != null ? p : rc)(h - n, n, a, l, void 0) + n
            }
        }
        b = void 0;
        for (e = 0; e < g; e++)
            if (p = a[e], p != null && (p = c(p, d)) != null)
                if (m && e >= h) {
                    var r = e - n,
                        t = void 0;
                    ((t = b) != null ? t : b = {})[r] = p
                } else f[e] = p;
        if (l)
            for (var z in l) Object.prototype.hasOwnProperty.call(l, z) && (a = l[z], a != null && (a = c(a, d)) != null && (g = +z, e = void 0, m && !v(Number, "isNaN").call(Number, g) && (e = g + n) < h ? f[e] = a : (g = void 0, ((g = b) != null ? g : b = {})[z] = a)));
        b && (k ? f.push(b) : f[h] = b);
        return f
    }

    function uc(a) {
        switch (typeof a) {
            case "number":
                return v(Number, "isFinite").call(Number, a) ? a : "" + a;
            case "bigint":
                return Ib(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    var b = a[F] | 0;
                    return a.length === 0 && b & 1 ? void 0 : sc(a, b, uc)
                }
                if (a != null && a[hb] === qb) return K(a);
                return
        }
        return a
    }
    var vc = typeof structuredClone != "undefined" ? structuredClone : function(a) {
            return sc(a, 0, uc)
        },
        tc;

    function K(a) {
        a = a.i;
        return sc(a, a[F] | 0, uc)
    };

    function L(a, b, c) {
        return wc(a, b, c, 2048)
    }

    function wc(a, b, c, d) {
        d = d === void 0 ? 0 : d;
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[F] | 0;
            if (Ea && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && xc();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && G(a, e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1,
                        h = c[g];
                    if (h != null && typeof h === "object" && h.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var k in h) Object.prototype.hasOwnProperty.call(h, k) && (f = +k, f < g && (c[f + b] = h[k], delete h[k]));
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    k = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (k > 1024) throw Error("spvt");
                    e = e & -16760833 | (k & 1023) << 14
                }
            }
        }
        G(a, e | 64 | d);
        return a
    }

    function xc() {
        if (Ea) throw Error("carr");
        if (gb != null) {
            var a;
            var b = (a = Va) != null ? a : Va = {};
            a = b[gb] || 0;
            a >= 5 || (b[gb] = a + 1, b = Error(), Ua(b, "incident"), Wa ? Ya(b) : za(b))
        }
    };

    function yc(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[F] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = zc(a, c, !1, b && !(c & 16)) : (mb(a, 34), c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[hb] === qb) return b = a.i, c = b[F] | 0, H(a, c) ? a : Ac(a, b, c) ? Bc(a, b) : zc(b, c)
    }

    function Bc(a, b, c) {
        a = new a.constructor(b);
        c && (a.g = rb);
        a.j = rb;
        return a
    }

    function zc(a, b, c, d) {
        d != null || (d = !!(34 & b));
        a = sc(a, b, yc, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        G(a, b);
        return a
    }

    function Cc(a) {
        var b = a.i,
            c = b[F] | 0;
        return H(a, c) ? Ac(a, b, c) ? Bc(a, b, !0) : new a.constructor(zc(b, c, !1)) : a
    }

    function Dc(a) {
        var b = a.i,
            c = b[F] | 0;
        return H(a, c) ? a : Ac(a, b, c) ? Bc(a, b) : new a.constructor(zc(b, c, !0))
    }

    function Ec(a) {
        if (a.g !== rb) return !1;
        var b = a.i;
        b = zc(b, b[F] | 0);
        mb(b, 2048);
        a.i = b;
        a.g = void 0;
        a.j = void 0;
        return !0
    }

    function Fc(a) {
        if (!Ec(a) && H(a, a.i[F] | 0)) throw Error();
    }

    function Gc(a, b) {
        b === void 0 && (b = a[F] | 0);
        b & 32 && !(b & 4096) && G(a, b | 4096)
    }

    function Ac(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (G(b, c | 2), a.g = rb, !0) : !1
    };
    var Hc = Cb(0),
        M = function(a, b, c, d) {
            a = Ic(a.i, b, c, d);
            if (a !== null) return a
        },
        Ic = function(a, b, c, d) {
            if (b === -1) return null;
            var e = b + (c ? 0 : -1),
                f = a.length - 1;
            if (!(f < 1 + (c ? 0 : -1))) {
                if (e >= f) {
                    var g = a[f];
                    if (g != null && typeof g === "object" && g.constructor === Object) {
                        c = g[b];
                        var h = !0
                    } else if (e === f) c = g;
                    else return
                } else c = a[e];
                if (d && c != null) {
                    d = d(c);
                    if (d == null) return d;
                    if (!v(Object, "is").call(Object, d, c)) return h ? g[b] = d : a[e] = d, d
                }
                return c
            }
        },
        O = function(a, b, c) {
            Fc(a);
            var d = a.i;
            N(d, d[F] | 0, b, c);
            return a
        };

    function N(a, b, c, d) {
        var e = c + -1,
            f = a.length - 1;
        if (f >= 0 && e >= f) {
            var g = a[f];
            if (g != null && typeof g === "object" && g.constructor === Object) return g[c] = d, b
        }
        if (e <= f) return a[e] = d, b;
        if (d !== void 0) {
            var h;
            f = ((h = b) != null ? h : b = a[F] | 0) >> 14 & 1023 || 536870912;
            c >= f ? d != null && (e = {}, a[f + -1] = (e[c] = d, e)) : a[e] = d
        }
        return b
    }
    var Kc = function(a, b, c) {
            a = a.i;
            return Jc(a, a[F] | 0, b, c) !== void 0
        },
        P = function(a) {
            return a === tb ? 2 : 4
        };

    function Lc(a, b, c, d, e) {
        var f = a.i,
            g = f[F] | 0;
        d = H(a, g) ? 1 : d;
        e = !!e || d === 3;
        d === 2 && Ec(a) && (f = a.i, g = f[F] | 0);
        a = Ic(f, b);
        a = Array.isArray(a) ? a : kb;
        var h = a === kb ? 7 : a[F] | 0,
            k = Mc(h, g);
        var m = 4 & k ? !1 : !0;
        if (m) {
            4 & k && (a = Pb(a), h = 0, k = Nc(k, g), g = N(f, g, b, a));
            for (var n = 0, l = 0; n < a.length; n++) {
                var p = c(a[n]);
                p != null && (a[l++] = p)
            }
            l < n && (a.length = l);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (G(a, k), 2 & k && Object.freeze(a));
        return a = Oc(a, k, f, g, b, d, m, e)
    }

    function Oc(a, b, c, d, e, f, g, h) {
        var k = b;
        f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? Pc(b) || (b |= !a.length || g && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== k && G(a, b), Object.freeze(a)) : (f === 2 && Pc(b) && (a = Pb(a), k = 0, b = Nc(b, d), d = N(c, d, e, a)), Pc(b) || (h || (b |= 16), b !== k && G(a, b)));
        2 & b || !(4096 & b || 16 & b) || Gc(c, d);
        return a
    }

    function Mc(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }

    function Pc(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Qc(a, b, c, d) {
        Fc(a);
        var e = a.i,
            f = e[F] | 0;
        if (c == null) return N(e, f, b), a;
        var g = c === kb ? 7 : c[F] | 0,
            h = g,
            k = Pc(g),
            m = k || Object.isFrozen(c);
        k || (g = 0);
        m || (c = Pb(c), h = 0, g = Nc(g, f), m = !1);
        g |= 5;
        var n;
        k = (n = nb(g)) != null ? n : 0;
        for (n = 0; n < c.length; n++) {
            var l = c[n],
                p = d(l, k);
            v(Object, "is").call(Object, l, p) || (m && (c = Pb(c), h = 0, g = Nc(g, f), m = !1), c[n] = p)
        }
        g !== h && (m && (c = Pb(c), g = Nc(g, f)), G(c, g));
        N(e, f, b, c);
        return a
    }

    function Rc(a, b, c, d) {
        Fc(a);
        var e = a.i;
        N(e, e[F] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }
    var Vc = function(a, b, c, d) {
            Fc(a);
            var e = a.i,
                f = e[F] | 0;
            if (d == null) {
                var g = Sc(e);
                if (Tc(g, e, f, c) === b) g.set(c, 0);
                else return a
            } else f = Uc(e, f, c, b);
            N(e, f, b, d);
            return a
        },
        Xc = function(a, b, c) {
            return Wc(a, b) === c ? c : -1
        },
        Wc = function(a, b) {
            a = a.i;
            return Tc(Sc(a), a, void 0, b)
        };

    function Sc(a) {
        if ($a) {
            var b;
            return (b = a[fb]) != null ? b : a[fb] = new u.Map
        }
        if (fb in a) return a[fb];
        b = new u.Map;
        Object.defineProperty(a, fb, {
            value: b
        });
        return b
    }

    function Uc(a, b, c, d) {
        var e = Sc(a),
            f = Tc(e, a, b, c);
        f !== d && (f && (b = N(a, b, f)), e.set(c, d));
        return b
    }

    function Tc(a, b, c, d) {
        var e = a.get(d);
        if (e != null) return e;
        for (var f = e = 0; f < d.length; f++) {
            var g = d[f];
            Ic(b, g) != null && (e !== 0 && (c = N(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }
    var Yc = function(a, b, c) {
        Fc(a);
        a = a.i;
        var d = a[F] | 0,
            e = Ic(a, c),
            f = void 0 === ub;
        b = pc(e, b, !f, d);
        if (!f || b) return b = Cc(b), e !== b && (d = N(a, d, c, b), Gc(a, d)), b
    };

    function Jc(a, b, c, d) {
        var e = !1;
        d = Ic(a, d, void 0, function(f) {
            var g = pc(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !H(d) && Gc(a, b), d
    }
    var Zc = function(a, b, c) {
            a = a.i;
            return Jc(a, a[F] | 0, b, c) || b[eb] || (b[eb] = qc(b))
        },
        Q = function(a, b, c) {
            var d = a.i,
                e = d[F] | 0;
            b = Jc(d, e, b, c);
            if (b == null) return b;
            e = d[F] | 0;
            if (!H(a, e)) {
                var f = Cc(b);
                f !== b && (Ec(a) && (d = a.i, e = d[F] | 0), b = f, e = N(d, e, c, b), Gc(d, e))
            }
            return b
        };

    function $c(a, b, c, d, e, f, g, h) {
        var k = H(a, c);
        f = k ? 1 : f;
        g = !!g || f === 3;
        k = h && !k;
        (f === 2 || k) && Ec(a) && (b = a.i, c = b[F] | 0);
        a = Ic(b, e);
        a = Array.isArray(a) ? a : kb;
        var m = a === kb ? 7 : a[F] | 0,
            n = Mc(m, c);
        if (h = !(4 & n)) {
            var l = a,
                p = c,
                r = !!(2 & n);
            r && (p |= 2);
            for (var t = !r, z = !0, A = 0, ra = 0; A < l.length; A++) {
                var cb = pc(l[A], d, !1, p);
                if (cb instanceof d) {
                    if (!r) {
                        var db = H(cb);
                        t && (t = !db);
                        z && (z = db)
                    }
                    l[ra++] = cb
                }
            }
            ra < A && (l.length = ra);
            n |= 4;
            n = z ? n & -4097 : n | 4096;
            n = t ? n | 8 : n & -9
        }
        n !== m && (G(a, n), 2 & n && Object.freeze(a));
        if (k && !(8 & n || !a.length && (f === 1 || (f !== 4 ? 0 : 2 & n || !(16 & n) && 32 & c)))) {
            Pc(n) && (a = Pb(a), n = Nc(n, c), c = N(b, c, e, a));
            d = a;
            k = n;
            for (m = 0; m < d.length; m++) l = d[m], n = Cc(l), l !== n && (d[m] = n);
            k |= 8;
            n = k = d.length ? k | 4096 : k & -4097;
            G(a, n)
        }
        return a = Oc(a, n, b, c, e, f, h, g)
    }
    var R = function(a, b, c, d) {
        var e = a.i;
        return $c(a, e, e[F] | 0, b, c, d, !1, !0)
    };

    function ad(a) {
        a == null && (a = void 0);
        return a
    }
    var bd = function(a, b, c) {
            c = ad(c);
            O(a, b, c);
            c && !H(c) && Gc(a.i);
            return a
        },
        cd = function(a, b, c, d) {
            d = ad(d);
            Vc(a, b, c, d);
            d && !H(d) && Gc(a.i);
            return a
        },
        dd = function(a, b, c) {
            Fc(a);
            var d = a.i,
                e = d[F] | 0;
            if (c == null) return N(d, e, b), a;
            for (var f = c === kb ? 7 : c[F] | 0, g = f, h = Pc(f), k = h || Object.isFrozen(c), m = !0, n = !0, l = 0; l < c.length; l++) {
                var p = c[l];
                h || (p = H(p), m && (m = !p), n && (n = p))
            }
            h || (f = m ? 13 : 5, f = n ? f & -4097 : f | 4096);
            k && f === g || (c = Pb(c), g = 0, f = Nc(f, e));
            f !== g && G(c, f);
            e = N(d, e, b, c);
            2 & f || !(4096 & f || 16 & f) || Gc(d, e);
            return a
        };

    function Nc(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function ed(a, b) {
        Fc(a);
        a = Lc(a, 4, oc, 2, !0);
        var c, d = (c = nb(a === kb ? 7 : a[F] | 0)) != null ? c : 0;
        if (Array.isArray(b)) {
            c = b.length;
            for (var e = 0; e < c; e++) a.push(mc(b[e], d))
        } else
            for (b = y(b), c = b.next(); !c.done; c = b.next()) a.push(mc(c.value, d))
    }
    var fd = function(a, b) {
            var c = c === void 0 ? !1 : c;
            a = M(a, b);
            a = a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0;
            return a != null ? a : c
        },
        gd = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = bc(M(a, b));
            return a != null ? a : c
        },
        hd = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = cc(M(a, b));
            return a != null ? a : c
        },
        id = function(a, b) {
            var c = c === void 0 ? Hc : c;
            a = M(a, b);
            b = typeof a;
            a = a == null ? a : b === "bigint" ? Cb(Rb(64, a)) : Yb(a) ? b === "string" ? hc(a) : ic(a) : void 0;
            return a != null ? a : c
        },
        jd = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = M(a, b, void 0, Vb);
            return a != null ? a : c
        },
        S = function(a, b) {
            var c = c === void 0 ? "" : c;
            var d;
            return (d = oc(M(a, b))) != null ? d : c
        },
        T = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = $b(M(a, b));
            return a != null ? a : c
        },
        kd = function(a, b, c) {
            a = Lc(a, b, bc, 3, !0);
            sb(a, c);
            return a[c]
        },
        ld = function(a, b, c) {
            return T(a, Xc(a, c, b))
        },
        md = function(a, b, c) {
            return Rc(a, b, c == null ? c : ac(c), 0)
        },
        nd = function(a, b, c) {
            return Rc(a, b, kc(c), "0")
        },
        od = function(a, b, c) {
            return Rc(a, b, nc(c), "")
        },
        pd = function(a, b, c) {
            return O(a, b, c == null ? c : Zb(c))
        },
        qd = function(a, b, c) {
            return Rc(a, b, c == null ? c : Zb(c), 0)
        },
        rd = function(a, b, c, d) {
            return Vc(a, b, c, d == null ? d : Zb(d))
        };
    var U = function(a, b, c) {
        this.i = L(a, b, c)
    };
    U.prototype.toJSON = function() {
        return K(this)
    };
    var sd = function(a) {
        return Dc(a)
    };
    U.prototype[hb] = qb;

    function td(a, b) {
        if (b == null) return new a;
        if (!Array.isArray(b)) throw Error();
        if (Object.isFrozen(b) || Object.isSealed(b) || !Object.isExtensible(b)) throw Error();
        return new a(ob(b))
    };

    function ud(a) {
        return function(b) {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(ob(b))
            }
            return b
        }
    };
    var vd = function(a) {
        this.i = L(a)
    };
    x(vd, U);
    var wd = function(a) {
        return S(a, 1)
    };
    var xd = function(a) {
        this.i = L(a)
    };
    x(xd, U);

    function yd(a) {
        var b = b === void 0 ? !1 : b;
        var c = c === void 0 ? D : c;
        for (var d = 0; c && d++ < 40;) {
            var e;
            if (!(e = b)) try {
                var f;
                if (f = !!c && c.location.href != null) b: {
                    try {
                        Pa(c.foo);
                        f = !0;
                        break b
                    } catch (h) {}
                    f = !1
                }
                e = f
            } catch (h) {
                e = !1
            }
            if (e && a(c)) break;
            a: {
                try {
                    var g = c.parent;
                    if (g && g != c) {
                        c = g;
                        break a
                    }
                } catch (h) {}
                c = null
            }
        }
    }

    function zd(a) {
        var b = a;
        yd(function(c) {
            b = c;
            return !1
        });
        return b
    };
    var Ad = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var Bd = function() {
        return Da && Fa ? !Fa.mobile && (E("iPad") || E("Android") || E("Silk")) : E("iPad") || E("Android") && !E("Mobile") || E("Silk")
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var Cd;

    function Dd() {
        Cd === void 0 && (Cd = null);
        return Cd
    };
    var Ed = function(a) {
        this.g = a
    };
    Ed.prototype.toString = function() {
        return this.g + ""
    };

    function Fd(a) {
        var b = Dd();
        a = b ? b.createScriptURL(a) : a;
        return new Ed(a)
    }

    function Gd(a) {
        if (a instanceof Ed) return a.g;
        throw Error("");
    };
    var Hd = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
    var Id = function(a) {
        this.g = a
    };
    Id.prototype.toString = function() {
        return this.g + ""
    };

    function Jd(a) {
        a = a === void 0 ? document : a;
        var b, c;
        a = (c = (b = a).querySelector) == null ? void 0 : c.call(b, "script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function Kd(a, b) {
        a.src = Gd(b);
        (b = Jd(a.ownerDocument)) && a.setAttribute("nonce", b)
    };
    var Ld = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" ");

    function Md(a, b) {
        var c = a.write;
        if (b instanceof Id) b = b.g;
        else throw Error("");
        c.call(a, b)
    };
    var Nd = Ad(function() {
        return (Da && Fa ? Fa.mobile : !Bd() && (E("iPod") || E("iPhone") || E("Android") || E("IEMobile"))) ? 2 : Bd() ? 1 : 0
    });

    function Od(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function Pd() {
        if (!u.globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            u.globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    var Qd, Rd = 64;

    function Sd() {
        try {
            return Qd != null || (Qd = new Uint32Array(64)), Rd >= 64 && (crypto.getRandomValues(Qd), Rd = 0), Qd[Rd++]
        } catch (a) {
            return Math.floor(Math.random() * 4294967296)
        }
    };

    function Td(a, b) {
        if (!yb(a.goog_pvsid)) try {
            var c = Sd() + (Sd() & 2097151) * 4294967296;
            Object.defineProperty(a, "goog_pvsid", {
                value: c,
                configurable: !1
            })
        } catch (d) {
            b.G({
                methodName: 784,
                I: d
            })
        }
        a = Number(a.goog_pvsid);
        (!a || a <= 0) && b.G({
            methodName: 784,
            I: Error("Invalid correlator, " + a)
        });
        return a || -1
    };

    function Ud(a, b) {
        a = Gd(a).toString();
        a = '<script src="' + Vd(a) + '"';
        if (b == null ? 0 : b.async) a += " async";
        (b == null ? void 0 : b.attributionSrc) !== void 0 && (a += ' attributionsrc="' + Vd(b.attributionSrc) + '"');
        if (b == null ? 0 : b.Va) a += ' custom-element="' + Vd(b.Va) + '"';
        if (b == null ? 0 : b.defer) a += " defer";
        if (b == null ? 0 : b.id) a += ' id="' + Vd(b.id) + '"';
        if (b == null ? 0 : b.nonce) a += ' nonce="' + Vd(b.nonce) + '"';
        if (b == null ? 0 : b.type) a += ' type="' + Vd(b.type) + '"';
        if (b == null ? 0 : b.Ha) a += ' crossorigin="' + Vd(b.Ha) + '"';
        b = a + ">\x3c/script>";
        b = (a = Dd()) ? a.createHTML(b) : b;
        return new Id(b)
    }

    function Vd(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    };

    function Wd(a) {
        var b = qa.apply(1, arguments);
        if (b.length === 0) return Fd(a[0]);
        for (var c = a[0], d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Fd(c)
    }

    function Xd(a, b) {
        a = Gd(a).toString();
        var c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return Yd(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function Yd(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(function(k) {
                return e(k, h)
            }) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = v(Object, "entries").call(Object, d));
        Array.isArray(d) ? d.forEach(function(g) {
            return e(g[1], g[0])
        }) : d.forEach(e);
        return Fd(a + b + c)
    };

    function Zd(a, b) {
        if (a.length && b.head) {
            a = y(a);
            for (var c = a.next(); !c.done; c = a.next())
                if ((c = c.value) && b.head) {
                    var d = $d("META");
                    b.head.appendChild(d);
                    d.httpEquiv = "origin-trial";
                    d.content = c
                }
        }
    }
    var ae = function(a) {
            return Td(a, {
                G: function() {}
            })
        },
        $d = function(a, b) {
            b = b === void 0 ? document : b;
            return b.createElement(String(a).toLowerCase())
        };

    function be(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    };
    var ce = {
        Db: 0,
        Cb: 1,
        zb: 2,
        tb: 3,
        Ab: 4,
        ub: 5,
        Bb: 6,
        xb: 7,
        yb: 8,
        sb: 9,
        wb: 10,
        Eb: 11
    };
    var de = {
        Gb: 0,
        Hb: 1,
        Fb: 2
    };
    var ee = function(a) {
        this.i = L(a)
    };
    x(ee, U);
    ee.prototype.getVersion = function() {
        return gd(this, 2)
    };

    function fe(a) {
        return Sa(a.length % 4 !== 0 ? a + "A" : a).map(function(b) {
            return (q = b.toString(2), v(q, "padStart")).call(q, 8, "0")
        }).join("")
    }

    function ge(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        return parseInt(a, 2)
    }

    function he(a) {
        if (!/^[0-1]+$/.test(a)) throw Error("Invalid input [" + a + "] not a bit string.");
        for (var b = [1, 2, 3, 5], c = 0, d = 0; d < a.length - 1; d++) b.length <= d && b.push(b[d - 1] + b[d - 2]), c += parseInt(a[d], 2) * b[d];
        return c
    };

    function ie(a) {
        var b = fe(a),
            c = ge(b.slice(0, 6));
        a = ge(b.slice(6, 12));
        var d = new ee;
        c = md(d, 1, c);
        a = md(c, 2, a);
        b = b.slice(12);
        c = ge(b.slice(0, 12));
        d = [];
        for (var e = b.slice(12).replace(/0+$/, ""), f = 0; f < c; f++) {
            if (e.length === 0) throw Error("Found " + f + " of " + c + " sections [" + d + "] but reached end of input [" + b + "]");
            var g = ge(e[0]) === 0;
            e = e.slice(1);
            var h = je(e, b),
                k = d.length === 0 ? 0 : d[d.length - 1];
            k = he(h) + k;
            e = e.slice(h.length);
            if (g) d.push(k);
            else {
                g = je(e, b);
                h = he(g);
                for (var m = 0; m <= h; m++) d.push(k + m);
                e = e.slice(g.length)
            }
        }
        if (e.length > 0) throw Error("Found " + c + " sections [" + d + "] but has remaining input [" + e + "], entire input [" + b + "]");
        return Qc(a, 3, d, ac)
    }

    function je(a, b) {
        var c = a.indexOf("11");
        if (c === -1) throw Error("Expected section bitstring but not found in [" + a + "] part of [" + b + "]");
        return a.slice(0, c + 2)
    };
    var ke = "a".charCodeAt(),
        le = be(ce),
        me = be(de);
    var ne = function(a) {
        this.i = L(a)
    };
    x(ne, U);
    var oe = function() {
            var a = new ne;
            return nd(a, 1, 0)
        },
        pe = function(a) {
            var b = Number;
            var c = c === void 0 ? "0" : c;
            var d = M(a, 1);
            var e = !0;
            e = e === void 0 ? !1 : e;
            var f = typeof d;
            d = d == null ? d : f === "bigint" ? String(Rb(64, d)) : Yb(d) ? f === "string" ? ec(d) : e ? fc(d) : jc(d) : void 0;
            b = b(d != null ? d : c);
            a = gd(a, 2);
            return new Date(b * 1E3 + a / 1E6)
        };
    var qe = function(a) {
            if (/[^01]/.test(a)) throw Error("Input bitstring " + a + " is malformed!");
            this.j = a;
            this.g = 0
        },
        te = function(a) {
            var b = V(a, 16);
            return !!V(a, 1) === !0 ? (a = re(a), a.forEach(function(c) {
                if (c > b) throw Error("ID " + c + " is past MaxVendorId " + b + "!");
            }), a) : se(a, b)
        },
        re = function(a) {
            for (var b = V(a, 12), c = []; b--;) {
                var d = !!V(a, 1) === !0,
                    e = V(a, 16);
                if (d)
                    for (d = V(a, 16); e <= d; e++) c.push(e);
                else c.push(e)
            }
            c.sort(function(f, g) {
                return f - g
            });
            return c
        },
        se = function(a, b, c) {
            for (var d = [], e = 0; e < b; e++)
                if (V(a, 1)) {
                    var f = e + 1;
                    if (c && c.indexOf(f) === -1) throw Error("ID: " + f + " is outside of allowed values!");
                    d.push(f)
                }
            return d
        },
        V = function(a, b) {
            if (a.g + b > a.j.length) throw Error("Requested length " + b + " is past end of string.");
            var c = a.j.substring(a.g, a.g + b);
            a.g += b;
            return parseInt(c, 2)
        };
    qe.prototype.skip = function(a) {
        this.g += a
    };
    var ve = function(a) {
            try {
                var b = Sa(a.split(".")[0]).map(function(d) {
                        return (q = d.toString(2), v(q, "padStart")).call(q, 8, "0")
                    }).join(""),
                    c = new qe(b);
                b = {};
                b.tcString = a;
                b.gdprApplies = !0;
                c.skip(78);
                b.cmpId = V(c, 12);
                b.cmpVersion = V(c, 12);
                c.skip(30);
                b.tcfPolicyVersion = V(c, 6);
                b.isServiceSpecific = !!V(c, 1);
                b.useNonStandardStacks = !!V(c, 1);
                b.specialFeatureOptins = ue(se(c, 12, me), me);
                b.purpose = {
                    consents: ue(se(c, 24, le), le),
                    legitimateInterests: ue(se(c, 24, le), le)
                };
                b.purposeOneTreatment = !!V(c, 1);
                b.publisherCC = String.fromCharCode(ke + V(c, 6)) + String.fromCharCode(ke + V(c, 6));
                b.vendor = {
                    consents: ue(te(c), null),
                    legitimateInterests: ue(te(c), null)
                };
                return b
            } catch (d) {
                return null
            }
        },
        ue = function(a, b) {
            var c = {};
            if (Array.isArray(b) && b.length !== 0) {
                b = y(b);
                for (var d = b.next(); !d.done; d = b.next()) d = d.value, c[d] = a.indexOf(d) !== -1
            } else
                for (a = y(a), b = a.next(); !b.done; b = a.next()) c[b.value] = !0;
            delete c[0];
            return c
        };
    var we = function(a) {
        this.i = L(a)
    };
    x(we, U);
    var xe = function(a, b) {
        var c = c === void 0 ? {} : c;
        this.error = a;
        this.meta = c;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror"
    };

    function ye(a, b, c, d) {
        d = d === void 0 ? !1 : d;
        a.google_image_requests || (a.google_image_requests = []);
        var e = $d("IMG", a.document);
        if (c) {
            var f = function() {
                if (c) {
                    var g = a.google_image_requests,
                        h = Array.prototype.indexOf.call(g, e, void 0);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", f, !1);
                typeof e.removeEventListener === "function" && e.removeEventListener("error", f, !1)
            };
            typeof e.addEventListener === "function" && e.addEventListener("load", f, !1);
            typeof e.addEventListener === "function" && e.addEventListener("error", f, !1)
        }
        d && (e.attributionSrc = "");
        e.src = b;
        a.google_image_requests.push(e)
    }

    function ze(a) {
        var b = b === void 0 ? !1 : b;
        var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=rcs_internal";
        Od(a, function(d, e) {
            if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d))
        });
        Ae(c, b)
    }

    function Ae(a, b) {
        var c = window;
        b = b === void 0 ? !1 : b;
        var d = d === void 0 ? !1 : d;
        c.fetch ? (b = {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }, d && (b.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? b.attributionReporting = {
            eventSourceEligible: "true",
            triggerEligible: "false"
        } : b.headers = {
            "Attribution-Reporting-Eligible": "event-source"
        }), c.fetch(a, b)) : ye(c, a, b === void 0 ? !1 : b, d === void 0 ? !1 : d)
    };

    function Be(a, b) {
        try {
            var c = function(d) {
                var e = {};
                return [(e[d.ba] = d.Z, e)]
            };
            return JSON.stringify([a.filter(function(d) {
                return d.S
            }).map(c), K(b), a.filter(function(d) {
                return !d.S
            }).map(c)])
        } catch (d) {
            return Ce(d, b), ""
        }
    }

    function Ce(a, b) {
        try {
            var c = a instanceof Error ? a : Error(String(a)),
                d = c.toString();
            c.name && d.indexOf(c.name) == -1 && (d += ": " + c.name);
            c.message && d.indexOf(c.message) == -1 && (d += ": " + c.message);
            if (c.stack) a: {
                var e = c.stack;a = d;
                try {
                    e.indexOf(a) == -1 && (e = a + "\n" + e);
                    for (var f; e != f;) f = e, e = e.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                    d = e.replace(RegExp("\n *", "g"), "\n");
                    break a
                } catch (g) {
                    d = a;
                    break a
                }
                d = void 0
            }
            ze({
                m: d,
                b: T(b, 1) || null,
                v: S(b, 2) || null
            })
        } catch (g) {}
    }
    var De = function(a, b, c) {
            this.N = c;
            c = new we;
            a = qd(c, 1, a);
            this.C = od(a, 2, b)
        },
        Ee = function(a) {
            if (a.N) {
                var b = a.C,
                    c = [],
                    d = c.concat,
                    e = u.Set,
                    f = [],
                    g = f.concat;
                var h = Lc(a.C, 3, bc, P());
                c = d.call(c, B(new e(g.call(f, B(h), B(a.N())))));
                Qc(b, 3, c, ac)
            }
            return Dc(a.C)
        };
    var Fe = function(a) {
        this.i = L(a)
    };
    x(Fe, U);
    var He = function(a, b) {
            return Vc(a, 3, Ge, b == null ? b : Wb(b))
        },
        Ge = [1, 2, 3];
    var Ie = function(a) {
        this.i = L(a)
    };
    x(Ie, U);
    var Ke = function(a, b) {
            return Vc(a, 2, Je, kc(b))
        },
        Je = [2, 4];
    var Le = function(a) {
        this.i = L(a)
    };
    x(Le, U);
    var Me = function(a) {
            var b = new Le;
            return od(b, 1, a)
        },
        Ne = function(a, b) {
            return bd(a, 3, b)
        },
        Oe = function(a, b) {
            var c = b;
            Fc(a);
            b = a.i;
            var d = $c(a, b, b[F] | 0, Fe, 4, 2, !0);
            c = c != null ? c : new Fe;
            d.push(c);
            var e = d === kb ? 7 : d[F] | 0,
                f = e;
            (c = H(c)) ? (e &= -9, d.length === 1 && (e &= -4097)) : e |= 4096;
            e !== f && G(d, e);
            c || Gc(b);
            return a
        };
    var Pe = function(a) {
        this.i = L(a)
    };
    x(Pe, U);
    var Qe = function(a) {
        this.i = L(a)
    };
    x(Qe, U);
    var Re = function(a, b) {
            return qd(a, 1, b)
        },
        Se = function(a, b) {
            return qd(a, 2, b)
        };
    var Te = function(a) {
        this.i = L(a)
    };
    x(Te, U);
    var Ue = [1, 2];
    var Ve = function(a) {
        this.i = L(a)
    };
    x(Ve, U);
    var We = function(a, b) {
            return bd(a, 1, b)
        },
        Xe = function(a, b) {
            return dd(a, 2, b)
        },
        Ye = function(a, b) {
            return Qc(a, 4, b, ac)
        },
        Ze = function(a, b) {
            return dd(a, 5, b)
        },
        $e = function(a, b) {
            return qd(a, 6, b)
        };
    var af = function(a) {
        this.i = L(a)
    };
    x(af, U);
    var bf = [1, 2, 3, 4, 6];
    var cf = function(a) {
        this.i = L(a)
    };
    x(cf, U);
    var df = function(a) {
        this.i = L(a)
    };
    x(df, U);
    var ef = [2, 3, 4];
    var ff = function(a) {
        this.i = L(a)
    };
    x(ff, U);
    var gf = [3, 4, 5],
        hf = [6, 7];
    var jf = function(a) {
        this.i = L(a)
    };
    x(jf, U);
    var kf = [4, 5];
    var lf = function(a) {
        this.i = L(a)
    };
    x(lf, U);
    lf.prototype.getTagSessionCorrelator = function() {
        return id(this, 2)
    };
    var nf = function(a) {
            var b = new lf;
            return cd(b, 4, mf, a)
        },
        mf = [4, 5, 7, 8, 9];
    var of = function(a) {
        this.i = L(a)
    };
    x( of , U);
    var pf = function(a) {
        this.i = L(a)
    };
    x(pf, U);
    var qf = [1, 2, 4, 5, 6, 9, 10, 11];
    var rf = function(a) {
        this.i = L(a)
    };
    x(rf, U);
    rf.prototype.getTagSessionCorrelator = function() {
        return id(this, 2)
    };
    rf.prototype.da = function(a) {
        return kd(this, 4, a)
    };
    var sf = function(a) {
        this.i = L(a)
    };
    x(sf, U);
    sf.prototype.ab = function() {
        return gd(this, 2)
    };
    sf.prototype.Za = function(a) {
        var b = Lc(this, 3, oc, 3, !0);
        sb(b, a);
        return b[a]
    };
    var tf = function(a) {
        this.i = L(a)
    };
    x(tf, U);
    var uf = function(a) {
        this.i = L(a)
    };
    x(uf, U);
    uf.prototype.getTagSessionCorrelator = function() {
        return id(this, 1)
    };
    uf.prototype.da = function(a) {
        return kd(this, 2, a)
    };
    var vf = function(a) {
        this.i = L(a)
    };
    x(vf, U);
    var wf = [1, 7],
        xf = [4, 6, 8];
    var zf = function(a) {
            this.g = a;
            this.ja = new yf(this.g)
        },
        yf = function(a) {
            this.g = a;
            this.ea = new Af(this.g)
        },
        Af = function(a) {
            this.g = a;
            this.outstream = new Bf;
            this.request = new Cf;
            this.threadYield = new Df;
            this.Ia = new Ef(this.g);
            this.cb = new Ff(this.g);
            this.gb = new Gf(this.g);
            this.mb = new Hf(this.g)
        },
        Ef = function(a) {
            this.g = a
        };
    Ef.prototype.J = function(a) {
        this.g.o(Ne(Oe(Me("av7Wxb"), He(new Fe, a.Ma)), Ke(new Ie, Math.round(a.K))))
    };
    var Ff = function(a) {
        this.g = a
    };
    Ff.prototype.J = function(a) {
        this.g.o(Ne(Oe(Oe(Me("JwITQ"), He(new Fe, a.oa)), He(new Fe, a.qa)), Ke(new Ie, Math.round(a.K))))
    };
    var Gf = function(a) {
        this.g = a
    };
    Gf.prototype.J = function(a) {
        this.g.o(Ne(Oe(Oe(Me("Pn3Upd"), He(new Fe, a.oa)), He(new Fe, a.qa)), Ke(new Ie, Math.round(a.K))))
    };
    var Hf = function(a) {
        this.g = a
    };
    Hf.prototype.J = function(a) {
        var b = this.g,
            c = b.o,
            d = Me("rkgGzc");
        var e = new Fe;
        e = Vc(e, 2, Ge, kc(a.source));
        d = Oe(d, e);
        e = new Fe;
        e = Vc(e, 2, Ge, kc(a.Ua));
        c.call(b, Ne(Oe(d, e), Ke(new Ie, Math.round(a.K))))
    };
    var Bf = function() {},
        Cf = function() {},
        Df = function() {},
        If = function() {
            De.apply(this, arguments);
            this.ga = new zf(this)
        };
    x(If, De);
    var Jf = function() {
        If.apply(this, arguments)
    };
    x(Jf, If);
    Jf.prototype.qb = function() {
        this.l.apply(this, B(qa.apply(0, arguments).map(function(a) {
            return {
                S: !0,
                ba: 2,
                Z: K(a)
            }
        })))
    };
    Jf.prototype.pb = function() {
        this.l.apply(this, B(qa.apply(0, arguments).map(function(a) {
            return {
                S: !0,
                ba: 29,
                Z: K(a)
            }
        })))
    };
    Jf.prototype.ha = function() {
        this.l.apply(this, B(qa.apply(0, arguments).map(function(a) {
            return {
                S: !0,
                ba: 4,
                Z: K(a)
            }
        })))
    };
    Jf.prototype.rb = function() {
        this.l.apply(this, B(qa.apply(0, arguments).map(function(a) {
            return {
                S: !0,
                ba: 15,
                Z: K(a)
            }
        })))
    };
    Jf.prototype.o = function() {
        this.l.apply(this, B(qa.apply(0, arguments).map(function(a) {
            return {
                S: !1,
                ba: 1,
                Z: K(a)
            }
        })))
    };

    function Kf(a, b) {
        if (u.globalThis.fetch) u.globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    };
    var Lf = function(a, b, c, d, e, f, g, h, k) {
        Jf.call(this, a, b, k);
        this.X = c;
        this.W = d;
        this.Y = e;
        this.U = f;
        this.V = g;
        this.L = h;
        this.g = [];
        this.j = null;
        this.O = !1
    };
    x(Lf, Jf);
    var Mf = function(a) {
        a.j !== null && (clearTimeout(a.j), a.j = null);
        if (a.g.length) {
            var b = Be(a.g, Ee(a));
            a.W(a.X + "?e=1", b);
            a.g = []
        }
    };
    Lf.prototype.l = function() {
        var a = qa.apply(0, arguments),
            b = this;
        try {
            this.V && Be(this.g.concat(a), Ee(this)).length >= 65536 && Mf(this), this.L && !this.O && (this.O = !0, this.L.g(function() {
                Mf(b)
            })), this.g.push.apply(this.g, B(a)), this.g.length >= this.U && Mf(this), this.g.length && this.j === null && (this.j = setTimeout(function() {
                Mf(b)
            }, this.Y))
        } catch (c) {
            Ce(c, Ee(this))
        }
    };
    var Nf = function(a, b, c, d, e, f, g) {
        Lf.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", Kf, c === void 0 ? 1E3 : c, d === void 0 ? 100 : d, (e === void 0 ? !1 : e) && !!u.globalThis.fetch, f, g)
    };
    x(Nf, Lf);
    var Of = function(a) {
            this.g = a;
            this.defaultValue = !1
        },
        Pf = function(a, b) {
            this.g = a;
            this.defaultValue = b === void 0 ? 0 : b
        };
    var Qf = new Pf(695925491, 20),
        Rf = new Of(45624259),
        Sf = new Pf(635239304, 100),
        Tf = new Of(662101539),
        Uf = new Pf(682056200, 100),
        Vf = new Pf(24),
        Wf = new function(a, b) {
            b = b === void 0 ? [] : b;
            this.g = a;
            this.defaultValue = b
        }(1934, ["AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "Amm8/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==", "A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A93bovR+QVXNx2/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9", "A1S5fojrAunSDrFbD8OfGmFHdRFZymSM/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9"]);
    var Xf = function(a) {
        this.i = L(a)
    };
    x(Xf, U);
    var Yf = function(a) {
        this.i = L(a)
    };
    x(Yf, U);
    var Zf = function(a) {
        this.i = L(a)
    };
    x(Zf, U);
    var $f = function(a) {
        this.i = L(a)
    };
    x($f, U);
    var ag = ud($f);
    var bg = function(a) {
        this.g = a || {
            cookie: ""
        }
    };
    bg.prototype.set = function(a, b, c) {
        var d = !1;
        if (typeof c === "object") {
            var e = c.sameSite;
            d = c.secure || !1;
            var f = c.domain || void 0;
            var g = c.path || void 0;
            var h = c.maxAge
        }
        if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
        if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
        h === void 0 && (h = -1);
        this.g.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (h < 0 ? "" : h == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + h * 1E3)).toUTCString()) + (d ? ";secure" : "") + (e != null ? ";samesite=" + e : "")
    };
    bg.prototype.get = function(a, b) {
        for (var c = a + "=", d = (this.g.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
            f = Aa(d[e]);
            if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
            if (f == a) return ""
        }
        return b
    };
    bg.prototype.isEmpty = function() {
        return !this.g.cookie
    };
    bg.prototype.clear = function() {
        for (var a = (this.g.cookie || "").split(";"), b = [], c = [], d, e, f = 0; f < a.length; f++) e = Aa(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
        for (a = b.length - 1; a >= 0; a--) c = b[a], this.get(c), this.set(c, "", {
            maxAge: 0,
            path: void 0,
            domain: void 0
        })
    };

    function cg(a) {
        a = dg(a);
        try {
            var b = a ? ag(a) : null
        } catch (c) {
            b = null
        }
        return b ? Q(b, Zf, 4) || null : null
    }

    function dg(a) {
        a = (new bg(a)).get("FCCDCF", "");
        if (a)
            if (v(a, "startsWith").call(a, "%")) try {
                var b = decodeURIComponent(a)
            } catch (c) {
                b = null
            } else b = a;
            else b = null;
        return b
    };
    be(ce).map(function(a) {
        return Number(a)
    });
    be(de).map(function(a) {
        return Number(a)
    });
    var eg = function(a) {
            this.g = a
        },
        gg = function(a) {
            a.__tcfapiPostMessageReady || fg(new eg(a))
        },
        fg = function(a) {
            a.j = function(b) {
                var c = typeof b.data === "string";
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__tcfapiCall;
                e && (e.command === "ping" || e.command === "addEventListener" || e.command === "removeEventListener") && (0, a.g.__tcfapi)(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__tcfapiReturn = e.command === "removeEventListener" ? {
                        success: f,
                        callId: e.callId
                    } : {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                    return f
                }, e.parameter)
            };
            a.g.addEventListener("message", a.j);
            a.g.__tcfapiPostMessageReady = !0
        };
    var hg = function(a) {
            this.g = a;
            this.j = null
        },
        jg = function(a) {
            a.__uspapiPostMessageReady || ig(new hg(a))
        },
        ig = function(a) {
            a.j = function(b) {
                var c = typeof b.data === "string";
                try {
                    var d = c ? JSON.parse(b.data) : b.data
                } catch (f) {
                    return
                }
                var e = d.__uspapiCall;
                e && e.command === "getUSPData" && a.g.__uspapi(e.command, e.version, function(f, g) {
                    var h = {};
                    h.__uspapiReturn = {
                        returnValue: f,
                        success: g,
                        callId: e.callId
                    };
                    f = c ? JSON.stringify(h) : h;
                    b.source && typeof b.source.postMessage === "function" && b.source.postMessage(f, b.origin);
                    return f
                })
            };
            a.g.addEventListener("message", a.j);
            a.g.__uspapiPostMessageReady = !0
        };
    var kg = function(a) {
        this.i = L(a)
    };
    x(kg, U);
    var lg = function(a) {
        this.i = L(a)
    };
    x(lg, U);
    var mg = ud(lg);

    function ng(a, b) {
        function c(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 4));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function d(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function e(l) {
            if (l.length < 12) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(8, 12));
            l = m(l);
            return "1" + p + l + "N"
        }

        function f(l) {
            if (l.length < 18) return null;
            var p = h(l.slice(0, 8));
            p = k(p);
            l = h(l.slice(12, 18));
            l = m(l);
            return "1" + p + l + "N"
        }

        function g(l) {
            if (l.length < 10) return null;
            var p = h(l.slice(0, 6));
            p = k(p);
            l = h(l.slice(6, 10));
            l = m(l);
            return "1" + p + l + "N"
        }

        function h(l) {
            for (var p = [], r = 0, t = 0; t < l.length / 2; t++) p.push(ge(l.slice(r, r + 2))), r += 2;
            return p
        }

        function k(l) {
            return l.every(function(p) {
                return p === 1
            }) ? "Y" : "N"
        }

        function m(l) {
            return l.some(function(p) {
                return p === 1
            }) ? "Y" : "N"
        }
        if (a.length === 0) return null;
        a = a.split(".");
        if (a.length > 2) return null;
        a = fe(a[0]);
        var n = ge(a.slice(0, 6));
        a = a.slice(6);
        if (n !== 1) return null;
        switch (b) {
            case 8:
                return c(a);
            case 10:
            case 12:
            case 9:
                return d(a);
            case 11:
                return e(a);
            case 7:
                return f(a);
            case 13:
                return g(a);
            default:
                return null
        }
    };

    function og(a, b) {
        var c = a.document,
            d = function() {
                if (!a.frames[b])
                    if (c.body) {
                        var e = $d("IFRAME", c);
                        e.style.display = "none";
                        e.style.width = "0px";
                        e.style.height = "0px";
                        e.style.border = "none";
                        e.style.zIndex = "-1000";
                        e.style.left = "-1000px";
                        e.style.top = "-1000px";
                        e.name = b;
                        c.body.appendChild(e)
                    } else a.setTimeout(d, 5)
            };
        d()
    };

    function pg(a) {
        if (a != null) return qg(a)
    }

    function qg(a) {
        return Ib(a) ? Number(a) : String(a)
    };
    var tg = function(a) {
            this.g = a;
            var b = dg(this.g.document);
            try {
                var c = b ? ag(b) : null
            } catch (e) {
                c = null
            }(b = c) ? (c = Q(b, Yf, 5) || null, b = R(b, Xf, 7, P()), b = rg(b != null ? b : []), c = {
                Ga: c,
                Ja: b
            }) : c = {
                Ga: null,
                Ja: null
            };
            b = c;
            c = sg(b.Ja);
            b = b.Ga;
            if (b != null && oc(M(b, 2)) != null && S(b, 2).length !== 0) {
                var d = Kc(b, ne, 1) ? Q(b, ne, 1) : oe();
                b = {
                    uspString: S(b, 2),
                    la: pe(d)
                }
            } else b = null;
            this.l = b && c ? c.la > b.la ? c.uspString : b.uspString : b ? b.uspString : c ? c.uspString : null;
            this.tcString = (c = cg(a.document)) && oc(M(c, 1)) != null ? S(c, 1) : null;
            this.j = (a = cg(a.document)) && oc(M(a, 2)) != null ? S(a, 2) : null
        },
        wg = function(a) {
            a === a.top && (a = new tg(a), ug(a), vg(a))
        },
        ug = function(a) {
            !a.l || a.g.__uspapi || a.g.frames.__uspapiLocator || (a.g.__uspapiManager = "fc", og(a.g, "__uspapiLocator"), ya("__uspapi", function(b, c, d) {
                typeof d === "function" && b === "getUSPData" && d({
                    version: 1,
                    uspString: a.l
                }, !0)
            }, a.g), jg(a.g))
        },
        rg = function(a) {
            a = v(a, "find").call(a, function(b) {
                return b && T(b, 1) === 13
            });
            if (a == null ? 0 : oc(M(a, 2)) != null) try {
                return mg(S(a, 2))
            } catch (b) {}
            return null
        },
        sg = function(a) {
            if (a == null || oc(M(a, 1)) == null || S(a, 1).length === 0 || R(a, kg, 2, P()).length === 0) return null;
            var b = S(a, 1);
            try {
                var c = ie(b.split("~")[0]);
                var d = v(b, "includes").call(b, "~") ? b.split("~").slice(1) : []
            } catch (e) {
                return null
            }
            a = R(a, kg, 2, P()).reduce(function(e, f) {
                var g = xg(e);
                g = id(g, 1);
                g = qg(g);
                var h = xg(f);
                h = id(h, 1);
                return g > qg(h) ? e : f
            });
            c = Lc(c, 3, bc, P()).indexOf(gd(a, 1));
            return c === -1 || c >= d.length ? null : {
                uspString: ng(d[c], gd(a, 1)),
                la: pe(xg(a))
            }
        },
        xg = function(a) {
            return Kc(a, ne, 2) ? Q(a, ne, 2) : oe()
        },
        vg = function(a) {
            !a.tcString || a.g.__tcfapi || a.g.frames.__tcfapiLocator || (a.g.__tcfapiManager = "fc", og(a.g, "__tcfapiLocator"), a.g.__tcfapiEventListeners = a.g.__tcfapiEventListeners || [], ya("__tcfapi", function(b, c, d, e) {
                if (typeof d === "function")
                    if (c && (c > 2.2 || c <= 1)) d(null, !1);
                    else switch (c = a.g.__tcfapiEventListeners, b) {
                        case "ping":
                            d({
                                gdprApplies: !0,
                                cmpLoaded: !0,
                                cmpStatus: "loaded",
                                displayStatus: "disabled",
                                apiVersion: "2.2",
                                cmpVersion: 2,
                                cmpId: 300
                            });
                            break;
                        case "addEventListener":
                            b = c.push(d) - 1;
                            a.tcString ? (e = ve(a.tcString), e.addtlConsent = a.j != null ? a.j : void 0, e.cmpStatus = "loaded", e.eventStatus = "tcloaded", b != null && (e.listenerId = b), b = e) : b = null;
                            d(b, !0);
                            break;
                        case "removeEventListener":
                            e !== void 0 && c[e] ? (c[e] = null, d(!0)) : d(!1);
                            break;
                        case "getInAppTCData":
                        case "getVendorList":
                            d(null, !1);
                            break;
                        case "getTCData":
                            d(null, !1)
                    }
            }, a.g), gg(a.g))
        };
    var yg = oa(["https://pagead2.googlesyndication.com/pagead/managed/dict/", "/gpt"]),
        zg = oa(["https://securepubads.g.doubleclick.net/pagead/managed/dict/", "/gpt"]);

    function Ag(a, b, c) {
        try {
            var d = a.createElement("link"),
                e, f;
            if (((e = d.relList) == null ? 0 : (f = e.supports) == null ? 0 : f.call(e, "compression-dictionary")) && Ma()) {
                if (b instanceof Ed) d.href = Gd(b).toString(), d.rel = "compression-dictionary";
                else {
                    if (Ld.indexOf("compression-dictionary") === -1) throw Error('TrustedResourceUrl href attribute required with rel="compression-dictionary"');
                    var g = Hd.test(b) ? b : void 0;
                    g !== void 0 && (d.href = g, d.rel = "compression-dictionary")
                }
                a.head.appendChild(d)
            }
        } catch (h) {
            c.G({
                methodName: 1296,
                I: h
            })
        }
    }

    function Bg(a, b) {
        return b ? Wd(yg, a) : Wd(zg, a)
    };
    var Cg = null;

    function Dg(a, b) {
        var c = R(a, ff, 2, P());
        if (!c.length) return Eg(a, b);
        a = T(a, 1);
        if (a === 1) {
            var d = Dg(c[0], b);
            return d.success ? {
                success: !0,
                value: !d.value
            } : d
        }
        c = Na(c, function(h) {
            return Dg(h, b)
        });
        switch (a) {
            case 2:
                var e;
                return (e = (d = v(c, "find").call(c, function(h) {
                    return h.success && !h.value
                })) != null ? d : v(c, "find").call(c, function(h) {
                    return !h.success
                })) != null ? e : {
                    success: !0,
                    value: !0
                };
            case 3:
                var f, g;
                return (g = (f = v(c, "find").call(c, function(h) {
                    return h.success && h.value
                })) != null ? f : v(c, "find").call(c, function(h) {
                    return !h.success
                })) != null ? g : {
                    success: !0,
                    value: !1
                };
            default:
                return {
                    success: !1,
                    B: 3
                }
        }
    }

    function Eg(a, b) {
        var c = Wc(a, gf);
        a: {
            switch (c) {
                case 3:
                    var d = ld(a, 3, gf);
                    break a;
                case 4:
                    d = ld(a, 4, gf);
                    break a;
                case 5:
                    d = ld(a, 5, gf);
                    break a
            }
            d = void 0
        }
        if (!d) return {
            success: !1,
            B: 2
        };
        b = (b = b[c]) && b[d];
        if (!b) return {
            success: !1,
            T: d,
            aa: c,
            B: 1
        };
        try {
            var e = b.apply;
            var f = Lc(a, 8, oc, P());
            var g = e.call(b, null, B(f))
        } catch (h) {
            return {
                success: !1,
                T: d,
                aa: c,
                B: 2
            }
        }
        e = T(a, 1);
        if (e === 4) return {
            success: !0,
            value: !!g
        };
        if (e === 5) return {
            success: !0,
            value: g != null
        };
        if (e === 12) a = S(a, Xc(a, hf, 7));
        else a: {
            switch (c) {
                case 4:
                    a = jd(a, Xc(a, hf, 6));
                    break a;
                case 5:
                    a = S(a, Xc(a, hf, 7));
                    break a
            }
            a = void 0
        }
        if (a == null) return {
            success: !1,
            T: d,
            aa: c,
            B: 3
        };
        if (e === 6) return {
            success: !0,
            value: g === a
        };
        if (e === 9) return {
            success: !0,
            value: g != null && Ba(String(g), a) === 0
        };
        if (g == null) return {
            success: !1,
            T: d,
            aa: c,
            B: 4
        };
        switch (e) {
            case 7:
                c = g < a;
                break;
            case 8:
                c = g > a;
                break;
            case 12:
                c = zb(a) && zb(g) && (new RegExp(a)).test(g);
                break;
            case 10:
                c = g != null && Ba(String(g), a) === -1;
                break;
            case 11:
                c = g != null && Ba(String(g), a) === 1;
                break;
            default:
                return {
                    success: !1,
                    B: 3
                }
        }
        return {
            success: !0,
            value: c
        }
    }

    function Fg(a, b) {
        return a ? b ? Dg(a, b) : {
            success: !1,
            B: 1
        } : {
            success: !0,
            value: !0
        }
    };
    var Gg = function(a) {
        this.i = L(a)
    };
    x(Gg, U);
    var Hg = function(a) {
        return Lc(a, 4, oc, P())
    };
    var Ig = function(a) {
        this.i = L(a)
    };
    x(Ig, U);
    Ig.prototype.getValue = function() {
        return Q(this, Gg, 2)
    };
    var Jg = function(a) {
        this.i = L(a)
    };
    x(Jg, U);
    var Kg = ud(Jg),
        Lg = [1, 2, 3, 6, 7, 8];
    var Mg = function(a, b, c) {
            var d = d === void 0 ? new Nf(6, "unknown", b) : d;
            this.C = a;
            this.o = c;
            this.j = d;
            this.g = [];
            this.l = a > 0 && Pd() < 1 / a
        },
        Og = function(a, b, c, d, e, f) {
            if (a.l) {
                var g = Se(Re(new Qe, b), c);
                b = $e(Xe(We(Ze(Ye(new Ve, d), e), g), a.g.slice()), f);
                b = nf(b);
                a.j.ha(Ng(a, b));
                if (f === 1 || f === 3 || f === 4 && !a.g.some(function(h) {
                        return T(h, 1) === T(g, 1) && T(h, 2) === c
                    })) a.g.push(g), a.g.length > 100 && a.g.shift()
            }
        },
        Pg = function(a, b, c, d) {
            if (a.l) {
                var e = new Pe;
                b = O(e, 1, b == null ? b : ac(b));
                c = O(b, 2, c == null ? c : ac(c));
                d = pd(c, 3, d);
                c = new lf;
                d = cd(c, 8, mf, d);
                a.j.ha(Ng(a, d))
            }
        },
        Qg = function(a, b, c, d, e) {
            if (a.l) {
                var f = new jf;
                b = bd(f, 1, b);
                c = pd(b, 2, c);
                d = O(c, 3, d == null ? d : ac(d));
                if (e.aa === void 0) rd(d, 4, kf, e.B);
                else switch (e.aa) {
                    case 3:
                        c = new df;
                        c = rd(c, 2, ef, e.T);
                        e = pd(c, 1, e.B);
                        cd(d, 5, kf, e);
                        break;
                    case 4:
                        c = new df;
                        c = rd(c, 3, ef, e.T);
                        e = pd(c, 1, e.B);
                        cd(d, 5, kf, e);
                        break;
                    case 5:
                        c = new df, c = rd(c, 4, ef, e.T), e = pd(c, 1, e.B), cd(d, 5, kf, e)
                }
                e = new lf;
                e = cd(e, 9, mf, d);
                a.j.ha(Ng(a, e))
            }
        },
        Ng = function(a, b) {
            var c = Date.now();
            c = v(Number, "isFinite").call(Number, c) ? Math.round(c) : 0;
            b = nd(b, 1, c);
            c = ae(window);
            b = nd(b, 2, c);
            return nd(b, 6, a.C)
        };
    var W = function(a) {
        var b = "na";
        if (a.na && a.hasOwnProperty(b)) return a.na;
        b = new a;
        return a.na = b
    };
    var Rg = function() {
        var a = {};
        this.A = (a[3] = {}, a[4] = {}, a[5] = {}, a)
    };
    var Sg = /^true$/.test("false");

    function Tg(a, b) {
        switch (b) {
            case 1:
                return ld(a, 1, Lg);
            case 2:
                return ld(a, 2, Lg);
            case 3:
                return ld(a, 3, Lg);
            case 6:
                return ld(a, 6, Lg);
            case 8:
                return ld(a, 8, Lg);
            default:
                return null
        }
    }

    function Ug(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return fd(a, 1);
            case 7:
                return S(a, 3);
            case 2:
                return jd(a, 2);
            case 3:
                return S(a, 3);
            case 6:
                return Hg(a);
            case 8:
                return Hg(a);
            default:
                return null
        }
    }
    var Vg = Ad(function() {
        if (!Sg) return {};
        try {
            var a = a === void 0 ? window : a;
            try {
                var b = a.sessionStorage.getItem("GGDFSSK")
            } catch (c) {
                b = null
            }
            if (b) return JSON.parse(b)
        } catch (c) {}
        return {}
    });

    function Wg(a, b, c, d) {
        var e = d = d === void 0 ? 0 : d,
            f, g;
        W(Xg).l[e] = (g = (f = W(Xg).l[e]) == null ? void 0 : f.add(b)) != null ? g : (new u.Set).add(b);
        e = Vg();
        if (e[b] != null) return e[b];
        b = Yg(d)[b];
        if (!b) return c;
        b = Kg(JSON.stringify(b));
        b = Zg(b);
        a = Ug(b, a);
        return a != null ? a : c
    }

    function Zg(a) {
        var b = W(Rg).A;
        if (b && Wc(a, Lg) !== 8) {
            var c = Oa(R(a, Ig, 5, P()), function(f) {
                f = Fg(Q(f, ff, 1), b);
                return f.success && f.value
            });
            if (c) {
                var d;
                return (d = c.getValue()) != null ? d : null
            }
        }
        var e;
        return (e = Q(a, Gg, 4)) != null ? e : null
    }
    var Xg = function() {
        this.j = {};
        this.o = [];
        this.l = {};
        this.g = new u.Map
    };

    function $g(a, b, c) {
        return !!Wg(1, a, b === void 0 ? !1 : b, c)
    }

    function ah(a, b, c) {
        b = b === void 0 ? 0 : b;
        a = Number(Wg(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function bh(a, b, c) {
        b = b === void 0 ? "" : b;
        a = Wg(3, a, b, c);
        return typeof a === "string" ? a : b
    }

    function ch(a, b, c) {
        b = b === void 0 ? [] : b;
        a = Wg(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function dh(a, b, c) {
        b = b === void 0 ? [] : b;
        a = Wg(8, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Yg(a) {
        return W(Xg).j[a] || (W(Xg).j[a] = {})
    }

    function eh(a, b) {
        var c = Yg(b);
        Od(a, function(d, e) {
            if (c[e]) {
                d = Kg(JSON.stringify(d));
                var f = Xc(d, Lg, 8);
                if ($b(M(d, f)) != null) {
                    var g = Kg(JSON.stringify(c[e]));
                    f = Yc(d, Gg, 4);
                    g = Hg(Zc(g, Gg, 4));
                    ed(f, g)
                }
                c[e] = K(d)
            } else c[e] = d
        })
    }

    function fh(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        var f = [],
            g = [];
        b = y(b);
        for (var h = b.next(); !h.done; h = b.next()) {
            h = h.value;
            for (var k = Yg(h), m = y(a), n = m.next(); !n.done; n = m.next()) {
                n = n.value;
                var l = Wc(n, Lg),
                    p = Tg(n, l);
                if (p) {
                    var r = void 0,
                        t = void 0,
                        z = void 0;
                    var A = (r = (z = W(Xg).g.get(h)) == null ? void 0 : (t = z.get(p)) == null ? void 0 : t.slice(0)) != null ? r : [];
                    a: {
                        r = p;t = l;z = new af;
                        switch (t) {
                            case 1:
                                rd(z, 1, bf, r);
                                break;
                            case 2:
                                rd(z, 2, bf, r);
                                break;
                            case 3:
                                rd(z, 3, bf, r);
                                break;
                            case 6:
                                rd(z, 4, bf, r);
                                break;
                            case 8:
                                rd(z, 6, bf, r);
                                break;
                            default:
                                A = void 0;
                                break a
                        }
                        Qc(z, 5, A, ac);A = z
                    }
                    if (r = A) t = void 0, r = !((t = W(Xg).l[h]) == null || !t.has(p));
                    r && f.push(A);
                    if (l === 8 && k[p]) A = Kg(JSON.stringify(k[p])), l = Yc(n, Gg, 4), A = Hg(Zc(A, Gg, 4)), ed(l, A);
                    else {
                        if (l = A) r = void 0, l = !((r = W(Xg).g.get(h)) == null || !r.has(p));
                        l && g.push(A)
                    }
                    e || (l = p, A = h, r = d, t = W(Xg), t.g.has(A) || t.g.set(A, new u.Map), t.g.get(A).has(l) || t.g.get(A).set(l, []), r && t.g.get(A).get(l).push(r));
                    k[p] = K(n)
                }
            }
        }
        if (f.length || g.length) a = d != null ? d : void 0, c.l && c.o && (d = new cf, f = dd(d, 2, f), g = dd(f, 3, g), a && md(g, 1, a), f = new lf, g = cd(f, 7, mf, g), c.j.ha(Ng(c, g)))
    }

    function gh(a, b) {
        b = Yg(b);
        a = y(a);
        for (var c = a.next(); !c.done; c = a.next()) {
            c = c.value;
            var d = Kg(JSON.stringify(c)),
                e = Wc(d, Lg);
            (d = Tg(d, e)) && (b[d] || (b[d] = c))
        }
    }

    function hh() {
        return v(Object, "keys").call(Object, W(Xg).j).map(function(a) {
            return Number(a)
        })
    }

    function ih(a) {
        (q = W(Xg).o, v(q, "includes")).call(q, a) || eh(Yg(4), a)
    };

    function X(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function Y(a, b, c) {
        return b[a] || c
    }

    function jh(a) {
        X(5, $g, a);
        X(6, ah, a);
        X(7, bh, a);
        X(8, ch, a);
        X(17, dh, a);
        X(13, gh, a);
        X(15, ih, a)
    }

    function kh(a) {
        X(4, function(b) {
            W(Rg).A = b
        }, a);
        X(9, function(b, c) {
            var d = W(Rg);
            d.A[3][b] == null && (d.A[3][b] = c)
        }, a);
        X(10, function(b, c) {
            var d = W(Rg);
            d.A[4][b] == null && (d.A[4][b] = c)
        }, a);
        X(11, function(b, c) {
            var d = W(Rg);
            d.A[5][b] == null && (d.A[5][b] = c)
        }, a);
        X(14, function(b) {
            for (var c = W(Rg), d = y([3, 4, 5]), e = d.next(); !e.done; e = d.next()) e = e.value, v(Object, "assign").call(Object, c.A[e], b[e])
        }, a)
    }

    function lh(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };
    var mh = function() {};
    mh.prototype.g = function() {};
    mh.prototype.j = function() {};
    mh.prototype.l = function() {
        return []
    };
    var nh = function(a, b, c) {
        a.j = function(d, e) {
            Y(2, b, function() {
                return []
            })(d, c, e)
        };
        a.l = function(d) {
            return Y(3, b, function() {
                return []
            })(d != null ? d : c)
        };
        a.g = function(d) {
            Y(16, b, function() {})(d, c)
        }
    };

    function oh(a) {
        W(mh).g(a)
    }

    function ph(a) {
        return W(mh).l(a)
    };

    function qh(a, b) {
        try {
            var c = a.split(".");
            a = D;
            for (var d = 0, e; a != null && d < c.length; d++) e = a, a = a[c[d]], typeof a === "function" && (a = e[c[d]]());
            var f = a;
            if (typeof f === b) return f
        } catch (g) {}
    }
    var rh = {},
        sh = {},
        th = {},
        uh = {},
        vh = (uh[3] = (rh[8] = function(a) {
            try {
                return va(a) != null
            } catch (b) {}
        }, rh[9] = function(a) {
            try {
                var b = va(a)
            } catch (c) {
                return
            }
            if (a = typeof b === "function") b = b && b.toString && b.toString(), a = typeof b === "string" && b.indexOf("[native code]") != -1;
            return a
        }, rh[10] = function() {
            return window === window.top
        }, rh[6] = function(a, b) {
            b = ph(b ? Number(b) : void 0);
            return Array.prototype.indexOf.call(b, Number(a), void 0) >= 0
        }, rh[27] = function(a) {
            a = qh(a, "boolean");
            return a !== void 0 ? a : void 0
        }, rh[60] = function(a) {
            try {
                return !!D.document.querySelector(a)
            } catch (b) {}
        }, rh[80] = function(a) {
            try {
                return !!D.matchMedia(a).matches
            } catch (b) {}
        }, rh[69] = function(a) {
            var b = D.document;
            b = b === void 0 ? document : b;
            var c;
            return !((c = b.featurePolicy) == null || !(q = c.features(), v(q, "includes")).call(q, a))
        }, rh[70] = function(a) {
            var b = D.document;
            b = b === void 0 ? document : b;
            var c;
            return !((c = b.featurePolicy) == null || !(q = c.allowedFeatures(), v(q, "includes")).call(q, a))
        }, rh[79] = function(a) {
            var b = D.navigator;
            b = b === void 0 ? navigator : b;
            try {
                var c, d;
                var e = !!((c = b.protectedAudience) == null ? 0 : (d = c.queryFeatureSupport) == null ? 0 : d.call(c, a))
            } catch (f) {
                e = !1
            }
            return e
        }, rh), uh[4] = (sh[3] = function() {
            return Nd()
        }, sh[6] = function(a) {
            a = qh(a, "number");
            return a !== void 0 ? a : void 0
        }, sh), uh[5] = (th[2] = function() {
            return window.location.href
        }, th[3] = function() {
            try {
                return window.top.location.hash
            } catch (a) {
                return ""
            }
        }, th[4] = function(a) {
            a = qh(a, "string");
            return a !== void 0 ? a : void 0
        }, th[12] = function(a) {
            try {
                var b = qh(a, "string");
                if (b !== void 0) return atob(b)
            } catch (c) {}
        }, th), uh);

    function wh() {
        var a = a === void 0 ? D : a;
        return a.ggeac || (a.ggeac = {})
    };
    var xh = function(a) {
        this.i = L(a)
    };
    x(xh, U);
    xh.prototype.getId = function() {
        return gd(this, 1)
    };
    var yh = function(a) {
        this.i = L(a)
    };
    x(yh, U);
    var zh = function(a) {
        return R(a, xh, 2, P())
    };
    var Ah = function(a) {
        this.i = L(a)
    };
    x(Ah, U);
    var Bh = function(a) {
        this.i = L(a)
    };
    x(Bh, U);
    var Ch = function(a) {
        this.i = L(a)
    };
    x(Ch, U);

    function Dh(a) {
        var b = {};
        return Eh((b[0] = new u.Map, b[1] = new u.Map, b[2] = new u.Map, b), a)
    }

    function Eh(a, b) {
        for (var c = new u.Map, d = y(v(a[1], "entries").call(a[1])), e = d.next(); !e.done; e = d.next()) {
            var f = y(e.value);
            e = f.next().value;
            f = f.next().value;
            f = f[f.length - 1];
            c.set(e, f.Sa + f.Na * f.Oa)
        }
        b = y(b);
        for (d = b.next(); !d.done; d = b.next())
            for (d = d.value, e = R(d, yh, 2, P()), e = y(e), f = e.next(); !f.done; f = e.next())
                if (f = f.value, zh(f).length !== 0) {
                    var g = hd(f, 8);
                    if (T(f, 4) && !T(f, 13) && !T(f, 14)) {
                        var h = void 0;
                        g = (h = c.get(T(f, 4))) != null ? h : 0;
                        h = hd(f, 1) * zh(f).length;
                        c.set(T(f, 4), g + h)
                    }
                    h = [];
                    for (var k = 0; k < zh(f).length; k++) {
                        var m = {
                            Sa: g,
                            Na: hd(f, 1),
                            Oa: zh(f).length,
                            ib: k,
                            ca: T(d, 1),
                            ia: f,
                            F: zh(f)[k]
                        };
                        h.push(m)
                    }
                    Fh(a[2], T(f, 10), h) || Fh(a[1], T(f, 4), h) || Fh(a[0], zh(f)[0].getId(), h)
                }
        return a
    }

    function Fh(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        var d;
        (d = a.get(b)).push.apply(d, B(c));
        return !0
    };
    var Gh = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$"),
        Hh = function(a) {
            return a ? decodeURI(a) : a
        },
        Ih = /#|$/,
        Jh = function(a, b) {
            var c = a.search(Ih);
            a: {
                var d = 0;
                for (var e = b.length;
                    (d = a.indexOf(b, d)) >= 0 && d < c;) {
                    var f = a.charCodeAt(d - 1);
                    if (f == 38 || f == 63)
                        if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                    d += e + 1
                }
                d = -1
            }
            if (d < 0) return null;
            e = a.indexOf("&", d);
            if (e < 0 || e > c) e = c;
            d += b.length + 1;
            return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
        };

    function Kh(a) {
        var b = a.length;
        if (b === 0) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };

    function Lh() {
        var a = ae(window);
        a = a === void 0 ? Pd() : a;
        return function(b) {
            return Kh(b + " + " + a) % 1E3
        }
    };
    var Mh = [12, 13, 20],
        Nh = function(a, b, c, d) {
            d = d === void 0 ? {} : d;
            var e = d.ma === void 0 ? !1 : d.ma;
            d = d.ob === void 0 ? [] : d.ob;
            this.R = a;
            this.u = c;
            this.o = {};
            this.ma = e;
            a = {};
            this.g = (a[b] = [], a[4] = [], a);
            this.j = {};
            this.l = {};
            var f = f === void 0 ? window : f;
            if (Cg === null) {
                Cg = "";
                try {
                    b = "";
                    try {
                        b = f.top.location.hash
                    } catch (h) {
                        b = f.location.hash
                    }
                    if (b) {
                        var g = b.match(/\bdeid=([\d,]+)/);
                        Cg = g ? g[1] : ""
                    }
                } catch (h) {}
            }
            if (f = Cg)
                for (f = y(f.split(",") || []), g = f.next(); !g.done; g = f.next())(g = Number(g.value)) && (this.j[g] = !0);
            d = y(d);
            for (f = d.next(); !f.done; f = d.next()) this.j[f.value] = !0
        },
        Qh = function(a, b, c, d) {
            var e = [],
                f;
            if (f = b !== 9) a.o[b] ? f = !0 : (a.o[b] = !0, f = !1);
            if (f) return Og(a.u, b, c, e, [], 4), e;
            f = v(Mh, "includes").call(Mh, b);
            for (var g = [], h = [], k = y([0, 1, 2]), m = k.next(); !m.done; m = k.next()) {
                m = m.value;
                for (var n = y(v(a.R[m], "entries").call(a.R[m])), l = n.next(); !l.done; l = n.next()) {
                    var p = y(l.value);
                    l = p.next().value;
                    p = p.next().value;
                    var r = l,
                        t = p;
                    l = new Te;
                    p = t.filter(function(db) {
                        return db.ca === b && a.j[db.F.getId()] && Oh(a, db)
                    });
                    if (p.length)
                        for (l = y(p), p = l.next(); !p.done; p = l.next()) h.push(p.value.F);
                    else if (!a.ma) {
                        p = void 0;
                        m === 2 ? (p = d[1], rd(l, 2, Ue, r)) : p = d[0];
                        var z = void 0,
                            A = void 0;
                        p = (A = (z = p) == null ? void 0 : z(String(r))) != null ? A : m === 2 && T(t[0].ia, 11) === 1 ? void 0 : d[0](String(r));
                        if (p !== void 0) {
                            r = y(t);
                            for (t = r.next(); !t.done; t = r.next())
                                if (t = t.value, t.ca === b) {
                                    z = p - t.Sa;
                                    var ra = t;
                                    A = ra.Na;
                                    var cb = ra.Oa;
                                    ra = ra.ib;
                                    z < 0 || z >= A * cb || z % cb !== ra || !Oh(a, t) || (z = T(t.ia, 13), z !== 0 && z !== void 0 && (A = a.l[String(z)], A !== void 0 && A !== t.F.getId() ? Pg(a.u, a.l[String(z)], t.F.getId(), z) : a.l[String(z)] = t.F.getId()), h.push(t.F))
                                }
                            Wc(l, Ue) !== 0 && (md(l, 3, p), g.push(l))
                        }
                    }
                }
            }
            d = y(h);
            for (h = d.next(); !h.done; h = d.next()) h = h.value, k = h.getId(), e.push(k), Ph(a, k, f ? 4 : c), fh(R(h, Jg, 2, P()), f ? hh() : [c], a.u, k);
            Og(a.u, b, c, e, g, 1);
            return e
        },
        Ph = function(a, b, c) {
            a.g[c] || (a.g[c] = []);
            a = a.g[c];
            v(a, "includes").call(a, b) || a.push(b)
        },
        Oh = function(a, b) {
            var c = W(Rg).A,
                d = Fg(Q(b.ia, ff, 3), c);
            if (!d.success) return Qg(a.u, Q(b.ia, ff, 3), b.ca, b.F.getId(), d), !1;
            if (!d.value) return !1;
            c = Fg(Q(b.F, ff, 3), c);
            return c.success ? c.value ? !0 : !1 : (Qg(a.u, Q(b.F, ff, 3), b.ca, b.F.getId(), c), !1)
        },
        Rh = function(a, b) {
            b = b.map(function(c) {
                return new Ah(c)
            }).filter(function(c) {
                return !v(Mh, "includes").call(Mh, T(c, 1))
            });
            a.R = Eh(a.R, b)
        },
        Sh = function(a, b) {
            X(1, function(c) {
                a.j[c] = !0
            }, b);
            X(2, function(c, d, e) {
                return Qh(a, c, d, e)
            }, b);
            X(3, function(c) {
                return (a.g[c] || []).concat(a.g[4])
            }, b);
            X(12, function(c) {
                return void Rh(a, c)
            }, b);
            X(16, function(c, d) {
                return void Ph(a, c, d)
            }, b)
        };
    var Th = function() {
        var a = {};
        this.g = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.j = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.L = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.l = function(b, c) {
            return a[b] != null ? a[b] : c
        };
        this.C = function(b, c) {
            return a[b] != null ? c.concat(a[b]) : c
        };
        this.o = function() {}
    };

    function Uh(a) {
        return W(Th).j(a.g, a.defaultValue)
    };
    var Vh = function() {
            this.g = function() {}
        },
        Wh = function(a, b) {
            a.g = Y(14, b, function() {})
        };

    function Xh(a) {
        W(Vh).g(a)
    };
    var Yh, Zh, $h, ai, bi, ci;

    function di(a) {
        var b = a.Ya;
        var c = a.A;
        var d = a.config;
        var e = a.Ta === void 0 ? wh() : a.Ta;
        var f = a.Fa === void 0 ? 0 : a.Fa;
        var g = a.u === void 0 ? new Mg((ai = pg((Yh = Q(b, Bh, 5)) == null ? void 0 : id(Yh, 2))) != null ? ai : 0, (bi = pg((Zh = Q(b, Bh, 5)) == null ? void 0 : id(Zh, 4))) != null ? bi : 0, (ci = ($h = Q(b, Bh, 5)) == null ? void 0 : fd($h, 3)) != null ? ci : !1) : a.u;
        a = a.R === void 0 ? Dh(R(b, Ah, 2, P(tb))) : a.R;
        e.hasOwnProperty("init-done") ? (Y(12, e, function() {})(R(b, Ah, 2, P()).map(function(h) {
            return K(h)
        })), Y(13, e, function() {})(R(b, Jg, 1, P()).map(function(h) {
            return K(h)
        }), f), c && Y(14, e, function() {})(c), ei(f, e)) : (Sh(new Nh(a, f, g, d), e), jh(e), kh(e), lh(e), ei(f, e), fh(R(b, Jg, 1, P(tb)), [f], g, void 0, !0), Sg = Sg || !(!d || !d.pa), Xh(vh), c && Xh(c))
    }

    function ei(a, b) {
        var c = b = b === void 0 ? wh() : b;
        nh(W(mh), c, a);
        fi(b, a);
        a = b;
        Wh(W(Vh), a);
        W(Th).o()
    }

    function fi(a, b) {
        var c = W(Th);
        c.g = function(d, e) {
            return Y(5, a, function() {
                return !1
            })(d, e, b)
        };
        c.j = function(d, e) {
            return Y(6, a, function() {
                return 0
            })(d, e, b)
        };
        c.L = function(d, e) {
            return Y(7, a, function() {
                return ""
            })(d, e, b)
        };
        c.l = function(d, e) {
            return Y(8, a, function() {
                return []
            })(d, e, b)
        };
        c.C = function(d, e) {
            return Y(17, a, function() {
                return []
            })(d, e, b)
        };
        c.o = function() {
            Y(15, a, function() {})(b)
        }
    };
    var gi = oa(["https://pagead2.googlesyndication.com/pagead/js/err_rep.js"]),
        hi = function() {
            var a = a === void 0 ? "jserror" : a;
            var b = b === void 0 ? .01 : b;
            var c = c === void 0 ? Wd(gi) : c;
            this.g = a;
            this.l = b;
            this.j = c
        };
    var ii = function() {
        var a;
        this.P = a = a === void 0 ? {
            jb: Sd() + (Sd() & 2097151) * 4294967296,
            Wa: v(Number, "MAX_SAFE_INTEGER")
        } : a
    };

    function ji(a, b) {
        return b > 0 && a.jb * b <= a.Wa
    };
    var ki = function(a) {
        this.i = L(a)
    };
    x(ki, U);
    var li = function(a) {
            return fd(a, 1)
        },
        mi = function(a) {
            return fd(a, 2)
        };

    function ni(a) {
        a = a === void 0 ? D : a;
        return (a = a.performance) && a.now ? a.now() : null
    };

    function oi(a, b) {
        b = b.google_js_reporting_queue = b.google_js_reporting_queue || [];
        b.length < 2048 && b.push(a)
    }

    function pi(a, b) {
        var c = ni(b);
        c && oi({
            label: a,
            type: 9,
            value: c
        }, b)
    }

    function qi(a, b, c) {
        var d = !1;
        d = d === void 0 ? !1 : d;
        var e = window,
            f = typeof queueMicrotask !== "undefined";
        return function() {
            var g = qa.apply(0, arguments);
            d && f && queueMicrotask(function() {
                e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1;
                e.google_rum_task_id_counter += 1
            });
            var h = ni(),
                k = 3;
            try {
                var m = b.apply(this, g)
            } catch (n) {
                k = 13;
                if (!c) throw n;
                c(a, n)
            } finally {
                e.google_measure_js_timing && h && oi(v(Object, "assign").call(Object, {}, {
                    label: a.toString(),
                    value: h,
                    duration: (ni() || 0) - h,
                    type: k
                }, d && f && {
                    taskId: e.google_rum_task_id_counter = e.google_rum_task_id_counter || 1
                }), e)
            }
            return m
        }
    }

    function ri(a, b) {
        return qi(a, b, function(c, d) {
            var e = new hi;
            var f = f === void 0 ? e.l : f;
            var g = g === void 0 ? e.g : g;
            Math.random() > f || (d.error && d.meta && d.id || (d = new xe(d, {
                context: c,
                id: g
            })), D.google_js_errors = D.google_js_errors || [], D.google_js_errors.push(d), D.error_rep_loaded || (f = D.document, c = $d("SCRIPT", f), Kd(c, e.j), (e = f.getElementsByTagName("script")[0]) && e.parentNode && e.parentNode.insertBefore(c, e), D.error_rep_loaded = !0))
        })
    };

    function Z(a, b) {
        return b == null ? "&" + a + "=null" : "&" + a + "=" + Math.floor(b)
    }

    function si(a, b) {
        return "&" + a + "=" + b.toFixed(3)
    }

    function ti() {
        var a = new u.Set;
        var b = window.googletag;
        b = (b == null ? 0 : b.apiReady) ? b : void 0;
        try {
            if (!b) return a;
            for (var c = b.pubads(), d = y(c.getSlots()), e = d.next(); !e.done; e = d.next()) a.add(e.value.getSlotId().getDomId())
        } catch (f) {}
        return a
    }

    function ui(a) {
        a = a.id;
        return a != null && (ti().has(a) || v(a, "startsWith").call(a, "google_ads_iframe_") || v(a, "startsWith").call(a, "aswift"))
    }

    function vi(a, b, c) {
        if (!a.sources) return !1;
        switch (wi(a)) {
            case 2:
                var d = xi(a);
                if (d) return c.some(function(f) {
                    return yi(d, f)
                });
                break;
            case 1:
                var e = zi(a);
                if (e) return b.some(function(f) {
                    return yi(e, f)
                })
        }
        return !1
    }

    function wi(a) {
        if (!a.sources) return 0;
        a = a.sources.filter(function(b) {
            return b.previousRect && b.currentRect
        });
        if (a.length >= 1) {
            a = a[0];
            if (a.previousRect.top < a.currentRect.top) return 2;
            if (a.previousRect.top > a.currentRect.top) return 1
        }
        return 0
    }

    function zi(a) {
        return Ai(a, function(b) {
            return b.currentRect
        })
    }

    function xi(a) {
        return Ai(a, function(b) {
            return b.previousRect
        })
    }

    function Ai(a, b) {
        return a.sources.reduce(function(c, d) {
            d = b(d);
            return c ? d && d.width * d.height !== 0 ? d.top < c.top ? d : c : c : d
        }, null)
    }

    function yi(a, b) {
        var c = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        a = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        return c <= 0 || a <= 0 ? !1 : c * a * 100 / ((b.right - b.left) * (b.bottom - b.top)) >= 50
    }
    var Bi = function() {
            this.l = this.j = this.X = this.V = this.N = 0;
            this.Ba = this.ya = Number.NEGATIVE_INFINITY;
            this.g = [];
            this.O = {};
            this.va = 0;
            this.W = Infinity;
            this.ta = this.wa = this.xa = this.za = this.Ea = this.C = this.Da = this.ka = this.o = 0;
            this.ua = !1;
            this.Y = this.U = this.L = 0;
            this.u = null;
            this.Aa = !1;
            this.sa = function() {};
            var a = document.querySelector("[data-google-query-id]");
            this.Ca = a ? a.getAttribute("data-google-query-id") : null
        },
        Ci, Di, Gi = function() {
            var a = new Bi;
            if (W(Th).g(Tf.g, Tf.defaultValue)) {
                var b = window;
                if (!b.google_plmetrics && window.PerformanceObserver) {
                    b.google_plmetrics = !0;
                    b = y(["layout-shift", "largest-contentful-paint", "first-input", "longtask", "event"]);
                    for (var c = b.next(); !c.done; c = b.next()) {
                        c = c.value;
                        var d = {
                            type: c,
                            buffered: !0
                        };
                        c === "event" && (d.durationThreshold = 40);
                        Ei(a).observe(d)
                    }
                    Fi(a)
                }
            }
        },
        Ei = function(a) {
            a.u || (a.u = new PerformanceObserver(ri(640, function(b) {
                Hi(a, b)
            })));
            return a.u
        },
        Fi = function(a) {
            var b = ri(641, function() {
                    var d = document;
                    if (d.prerendering) d = 3;
                    else {
                        var e;
                        d = (e = {
                            visible: 1,
                            hidden: 2,
                            prerender: 3,
                            preview: 4,
                            unloaded: 5,
                            "": 0
                        }[d.visibilityState || d.webkitVisibilityState || d.mozVisibilityState || ""]) != null ? e : 0
                    }
                    d === 2 && Ii(a)
                }),
                c = ri(641, function() {
                    return void Ii(a)
                });
            document.addEventListener("visibilitychange", b);
            document.addEventListener("pagehide", c);
            a.sa = function() {
                document.removeEventListener("visibilitychange", b);
                document.removeEventListener("pagehide", c);
                Ei(a).disconnect()
            }
        },
        Ii = function(a) {
            if (!a.Aa) {
                a.Aa = !0;
                Ei(a).takeRecords();
                var b = "https://pagead2.googlesyndication.com/pagead/gen_204?id=plmetrics";
                window.LayoutShift && (b += si("cls", a.N), b += si("mls", a.V), b += Z("nls", a.X), window.LayoutShiftAttribution && (b += si("cas", a.C), b += Z("nas", a.za), b += si("was", a.Ea)), b += si("wls", a.ka), b += si("tls", a.Da));
                window.LargestContentfulPaint && (b += Z("lcp", a.xa), b += Z("lcps", a.wa));
                window.PerformanceEventTiming && a.ua && (b += Z("fid", a.ta));
                window.PerformanceLongTaskTiming && (b += Z("cbt", a.L), b += Z("mbt", a.U), b += Z("nlt", a.Y));
                for (var c = 0, d = y(document.getElementsByTagName("iframe")), e = d.next(); !e.done; e = d.next()) ui(e.value) && c++;
                b += Z("nif", c);
                c = window.google_unique_id;
                b += Z("ifi", typeof c === "number" ? c : 0);
                c = ph();
                b += "&eid=" + encodeURIComponent(c.join());
                b += "&top=" + (D === D.top ? 1 : 0);
                b += a.Ca ? "&qqid=" + encodeURIComponent(a.Ca) : Z("pvsid", ae(D));
                window.googletag && (b += "&gpt=1");
                c = Math.min(a.g.length - 1, Math.floor((a.u ? a.va : performance.interactionCount || 0) / 50));
                c >= 0 && (c = a.g[c].latency, c >= 0 && (b += Z("inp", c)));
                window.fetch(b, {
                    keepalive: !0,
                    credentials: "include",
                    redirect: "follow",
                    method: "get",
                    mode: "no-cors"
                });
                a.sa()
            }
        },
        Ji = function(a, b, c, d) {
            if (!b.hadRecentInput) {
                a.N += Number(b.value);
                Number(b.value) > a.V && (a.V = Number(b.value));
                a.X += 1;
                if (c = vi(b, c, d)) a.C += b.value, a.za++;
                if (b.startTime - a.ya > 5E3 || b.startTime - a.Ba > 1E3) a.ya = b.startTime, a.j = 0, a.l = 0;
                a.Ba = b.startTime;
                a.j += b.value;
                c && (a.l += b.value);
                a.j > a.ka && (a.ka = a.j, a.Ea = a.l, a.Da = b.startTime + b.duration)
            }
        },
        Hi = function(a, b) {
            var c = Ci !== window.scrollX || Di !== window.scrollY ? [] : Ki,
                d = Li();
            b = y(b.getEntries());
            for (var e = b.next(), f = {}; !e.done; f = {
                    D: void 0
                }, e = b.next()) switch (f.D = e.value, e = f.D.entryType, e) {
                case "layout-shift":
                    Ji(a, f.D, c, d);
                    break;
                case "largest-contentful-paint":
                    f = f.D;
                    a.xa = Math.floor(f.renderTime || f.loadTime);
                    a.wa = f.size;
                    break;
                case "first-input":
                    e = f.D;
                    a.ta = Number((e.processingStart - e.startTime).toFixed(3));
                    a.ua = !0;
                    a.g.some(function(g) {
                        return function(h) {
                            return v(h, "entries").some(function(k) {
                                return g.D.duration === k.duration && g.D.startTime === k.startTime
                            })
                        }
                    }(f)) || Mi(a, f.D);
                    break;
                case "longtask":
                    f = Math.max(0, f.D.duration - 50);
                    a.L += f;
                    a.U = Math.max(a.U, f);
                    a.Y += 1;
                    break;
                case "event":
                    Mi(a, f.D);
                    break;
                default:
                    Qb(e)
            }
        },
        Mi = function(a, b) {
            Ni(a, b);
            var c = a.g[a.g.length - 1],
                d = a.O[b.interactionId];
            if (d || a.g.length < 10 || b.duration > c.latency) d ? (v(d, "entries").push(b), d.latency = Math.max(d.latency, b.duration)) : (b = {
                id: b.interactionId,
                latency: b.duration,
                entries: [b]
            }, a.O[b.id] = b, a.g.push(b)), a.g.sort(function(e, f) {
                return f.latency - e.latency
            }), a.g.splice(10).forEach(function(e) {
                delete a.O[e.id]
            })
        },
        Ni = function(a, b) {
            b.interactionId && (a.W = Math.min(a.W, b.interactionId), a.o = Math.max(a.o, b.interactionId), a.va = a.o ? (a.o - a.W) / 7 + 1 : 0)
        },
        Li = function() {
            var a = v(Array, "from").call(Array, document.getElementsByTagName("iframe")).filter(ui),
                b = [].concat(B(ti())).map(function(c) {
                    return document.getElementById(c)
                }).filter(function(c) {
                    return c !== null
                });
            Ci = window.scrollX;
            Di = window.scrollY;
            return Ki = [].concat(B(a), B(b)).map(function(c) {
                return c.getBoundingClientRect()
            })
        },
        Ki = [];
    var Oi = function(a) {
        this.i = L(a)
    };
    x(Oi, U);
    Oi.prototype.getVersion = function() {
        return S(this, 2)
    };
    var Pi = function(a) {
        this.i = L(a)
    };
    x(Pi, U);
    var Qi = function(a, b) {
            return O(a, 2, nc(b))
        },
        Ri = function(a, b) {
            return O(a, 3, nc(b))
        },
        Si = function(a, b) {
            return O(a, 4, nc(b))
        },
        Ti = function(a, b) {
            return O(a, 5, nc(b))
        },
        Ui = function(a, b) {
            return O(a, 9, nc(b))
        },
        Vi = function(a, b) {
            return dd(a, 10, b)
        },
        Wi = function(a, b) {
            return O(a, 11, b == null ? b : Wb(b))
        },
        Xi = function(a, b) {
            return O(a, 1, nc(b))
        },
        Yi = function(a, b) {
            return O(a, 7, b == null ? b : Wb(b))
        };
    var Zi = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function $i(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function aj(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function bj(a) {
        if (!aj(a)) return null;
        var b = $i(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(Zi).then(function(c) {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function cj(a) {
        var b;
        return Wi(Vi(Ti(Qi(Xi(Si(Yi(Ui(Ri(new Pi, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var d = new Oi;
            d = O(d, 1, nc(c.brand));
            return O(d, 2, nc(c.version))
        })) || []), a.wow64 || !1)
    }

    function dj(a) {
        var b, c;
        return (c = (b = bj(a)) == null ? void 0 : b.then(function(d) {
            return cj(d)
        })) != null ? c : null
    };
    var ej = function(a) {
        this.i = L(a)
    };
    x(ej, U);
    var fj = function(a) {
        this.i = L(a)
    };
    x(fj, U);
    var gj = function(a) {
        var b = new fj;
        return bd(b, 1, a)
    };

    function hj(a, b, c) {
        try {
            vb(!b._b_);
            var d = {
                d: K(a.data),
                p: a.kb
            };
            b._b_ = d
        } catch (e) {
            c.G({
                methodName: 1298,
                I: e
            })
        }
    };
    var ij = function(a, b, c) {
        this.g = a;
        this.M = b;
        this.j = c
    };
    ij.prototype.G = function(a) {
        var b = ji(this.M.P, 1E3),
            c = Uh(Qf),
            d = ji(this.M.P, c);
        if (b || d) {
            var e = this.j,
                f = e.Qa,
                g = e.Pa,
                h = e.Ka,
                k = e.da,
                m = e.ab;
            e = e.Za;
            k = k();
            var n = a.I;
            try {
                var l = zb(n == null ? void 0 : n.name) ? n.name : "Unknown error"
            } catch (z) {
                l = "e.name threw"
            }
            try {
                var p = zb(n == null ? void 0 : n.message) ? n.message : "Caught " + n
            } catch (z) {
                p = "e.message threw"
            }
            try {
                var r = zb(n == null ? void 0 : n.stack) ? n.stack : Error().stack;
                var t = r ? r.split(/\n\s*/) : []
            } catch (z) {
                t = ["e.stack threw"]
            }
            r = t;
            t = new vf;
            t = nd(t, 5, 1E3);
            n = new tf;
            a = qd(n, 1, a.methodName);
            a = od(a, 2, l);
            a = od(a, 3, p);
            a = Qc(a, 4, r, mc);
            a = Dc(a);
            a = cd(t, 1, wf, a);
            l = new uf;
            f = nd(l, 1, f);
            f = Qc(f, 2, k, ac);
            g = od(f, 3, g);
            g = Dc(g);
            g = bd(a, 2, g);
            g = Dc(g);
            g = Cc(g);
            f = new sf;
            h = od(f, 1, h);
            m = m == null ? void 0 : m();
            m = md(h, 2, m);
            e = e == null ? void 0 : e();
            e = Qc(m, 3, e, mc);
            e = Dc(e);
            e = cd(g, 4, xf, e);
            b && this.g.qb(e);
            if (d) {
                nd(e, 5, c);
                a: {
                    Fc(e);
                    if (void 0 === ub) {
                        if (Xc(e, wf, 1) !== 1) {
                            b = void 0;
                            break a
                        }
                    } else Uc(e.i, void 0, wf, 1);b = Yc(e, tf, 1)
                }
                b != null && O(b, 4);
                this.g.pb(e)
            }
        }
    };

    function jj(a) {
        var b = {};
        b = (b[0] = Lh(), b);
        W(mh).j(a, b)
    };
    var kj = {},
        lj = (kj[253] = !1, kj[246] = [], kj[150] = "", kj[263] = !1, kj[36] = /^true$/.test("false"), kj[172] = null, kj[260] = void 0, kj[251] = null, kj),
        mj = function() {
            this.g = !1
        };

    function nj(a) {
        W(mj).g = !0;
        return lj[a]
    }

    function oj(a, b) {
        W(mj).g = !0;
        lj[a] = b
    };
    var pj = /^(?:https?:)?\/\/(?:www\.googletagservices\.com|securepubads\.g\.doubleclick\.net|(pagead2\.googlesyndication\.com))(\/tag\/js\/gpt(?:_[a-z]+)*\.js)/;

    function qj(a) {
        var b = a.La;
        var c = a.hb;
        var d = a.Ra;
        var e = a.fb;
        var f = a.Xa;
        var g = a.bb;
        var h = b ? !pj.test(b.src) : !0;
        a = {};
        b = {};
        var k = {};
        return k[3] = (a[3] = function() {
            return !h
        }, a[59] = function() {
            var m = qa.apply(0, arguments),
                n = v(m, "includes"),
                l = String,
                p;
            var r = r === void 0 ? window : r;
            var t;
            r = (t = (p = Hh(r.location.href.match(Gh)[3] || null)) == null ? void 0 : p.split(".")) != null ? t : [];
            p = r.length < 2 ? null : (q = ["uk", "br", "nz", "mx"], v(q, "includes")).call(q, r[r.length - 1]) ? r.length < 3 ? null : Kh(r.splice(r.length - 3).join(".")) : Kh(r.splice(r.length - 2).join("."));
            return n.call(m, l(p))
        }, a[74] = function() {
            return v(qa.apply(0, arguments), "includes").call(qa.apply(0, arguments), String(Kh(window.location.href)))
        }, a[61] = function() {
            return e
        }, a[63] = function() {
            return e || g === ".google.ch"
        }, a[73] = function(m) {
            return v(d, "includes").call(d, Number(m))
        }, a), k[4] = (b[1] = function() {
            return f
        }, b[13] = function() {
            return c
        }, b), k[5] = {}, k
    };

    function rj(a, b) {
        if (W(Th).g(Rf.g, Rf.defaultValue)) {
            var c = function(d) {
                d.data != null && d.data !== "" || d.origin.indexOf("android-app://") !== 0 || (b(), a.removeEventListener("message", c))
            };
            a.addEventListener("message", c)
        }
    };

    function sj(a) {
        return !(a == null || !a.src) && Hh(a.src.match(Gh)[3] || null) === "pagead2.googlesyndication.com"
    };
    var tj = oa(["https://pagead2.googlesyndication.com/pagead/managed/js/gpt/", "/pubads_impl.js"]),
        uj = oa(["https://securepubads.g.doubleclick.net/pagead/managed/js/gpt/", "/pubads_impl.js"]);

    function vj(a) {
        a = sj(a) ? Wd(tj, "m202510220101") : Wd(uj, "m202510220101");
        var b = Uh(Vf);
        return b ? Xd(a, new u.Map([
            ["cb", b]
        ])) : a
    };

    function wj(a, b) {
        var c = nj(246);
        c = vc(c);
        c = td(Ch, c);
        if (!R(c, Jg, 1, P()).length && R(a, Jg, 1, P()).length) {
            var d = R(a, Jg, 1, P());
            dd(c, 1, d)
        }!R(c, Ah, 2, P()).length && R(a, Ah, 2, P()).length && (d = R(a, Ah, 2, P()), dd(c, 2, d));
        !Kc(c, Bh, 5) && Kc(a, Bh, 5) && (a = Q(a, Bh, 5), bd(c, 5, a));
        oj(246, K(c));
        di({
            Ya: c,
            A: qj(b),
            Fa: 2,
            config: {
                pa: b.pa
            }
        });
        b.Ra.forEach(oh)
    };
    var xj = function(a, b, c) {
        ij.call(this, a, b, c);
        this.j = c
    };
    x(xj, ij);
    var yj = oa(["https://pagead2.googlesyndication.com/pagead/ppub_config"]),
        zj = oa(["https://securepubads.g.doubleclick.net/pagead/ppub_config"]);

    function Aj(a, b, c, d, e) {
        a = a.location.host;
        var f = Jh(b.src, "domain");
        b = Jh(b.src, "network-code");
        if (a || f || b) {
            var g = new u.Map;
            a && g.set("ippd", a);
            f && g.set("pppd", f);
            b && g.set("pppnc", b);
            a = g
        } else a = void 0;
        a ? (c = c ? Wd(yj) : Wd(zj), c = Xd(c, a), Bj(c, d, e)) : e(new u.globalThis.Error("no provided or inferred data"))
    }

    function Bj(a, b, c) {
        u.globalThis.fetch(a.toString(), {
            method: "GET",
            credentials: "omit"
        }).then(function(d) {
            d.status < 300 ? (pi("13", window), d.status === 204 ? b("") : d.text().then(function(e) {
                b(e)
            })) : c(new u.globalThis.Error("resp:" + d.status))
        }).catch(function(d) {
            d instanceof Error ? c(new u.globalThis.Error(d.message)) : c(new u.globalThis.Error("fetch error: " + d))
        })
    };
    var Cj = function(a, b, c) {
            this.M = a;
            this.ra = b;
            this.fa = c;
            this.g = []
        },
        Gj = function(a, b, c, d, e) {
            var f = e == null ? void 0 : wd(Zc(e, vd, 1));
            (f == null ? 0 : f.length) && v(b.location.hostname, "includes").call(b.location.hostname, f) ? (Dj(a), Ej(a, {
                lb: e
            })) : (q = ["http:", "https:"], v(q, "includes")).call(q, b.location.protocol) ? c ? (Dj(a), Aj(zd(b), c, d, function(g) {
                return void Ej(a, {
                    nb: g
                })
            }, function(g) {
                Ej(a, {
                    error: g
                })
            })) : Fj(a, 5) : Fj(a, 4)
        },
        Dj = function(a) {
            nj(260);
            oj(260, function(b) {
                a.j !== void 0 || a.l ? b(a.j, a.l) : a.g.push(b)
            })
        },
        Ej = function(a, b) {
            var c = b.nb;
            var d = b.lb;
            b = b.error;
            a.j = c != null ? c : d == null ? void 0 : JSON.stringify(K(d));
            a.l = b;
            d = y(a.g);
            for (var e = d.next(); !e.done; e = d.next()) e = e.value, e(a.j, a.l);
            a.g.length = 0;
            Fj(a, b ? 6 : c ? 3 : 2)
        },
        Fj = function(a, b) {
            var c = Uh(Uf);
            ji(a.M.P, c) && a.ra.ga.ja.ea.mb.J({
                K: c,
                source: b,
                Ua: !E("Android") || Ma() || Ka() || Ja() || E("Silk") ? Ma() ? 2 : (Ia() ? 0 : E("Edge")) ? 3 : Ka() ? 4 : (Ia() ? 0 : E("Trident") || E("MSIE")) ? 5 : !E("iPad") && !E("iPhone") || La() || Ma() || (Ia() ? 0 : E("Coast")) || Ka() || !E("AppleWebKit") ? Ja() ? 6 : La() ? 7 : E("Silk") ? 8 : 0 : 9 : 1
            });
            a = a.fa;
            var d = Uh(Uf);
            if (ji(a.M.P, d)) {
                var e = a.j,
                    f = e.Ka,
                    g = e.da;
                c = e.Pa;
                e = e.Qa;
                var h = new rf;
                e = nd(h, 2, e);
                f = od(e, 3, f);
                e = Math;
                h = e.trunc;
                a: {
                    if (u.globalThis.performance) {
                        var k = performance.timeOrigin + performance.now();
                        if (v(Number, "isFinite").call(Number, k) && k > 0) break a
                    }
                    k = Date.now();k = v(Number, "isFinite").call(Number, k) && k > 0 ? k : 0
                }
                f = nd(f, 1, h.call(e, k));
                g = g();
                g = Qc(f, 4, g, ac);
                d = nd(g, 5, d);
                c = od(d, 6, c);
                d = new pf;
                g = new of ;
                b = pd(g, 1, b);
                b = Dc(b);
                b = cd(d, 10, qf, b);
                b = Dc(b);
                b = bd(c, 7, b);
                b = Dc(b);
                a.g.rb(b)
            }
        };
    var Hj = function(a) {
            return function(b) {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("Expected jspb data to be an array, got " + xa(b) + ": " + b);
                mb(b, 34);
                return new a(b)
            }
        }(ej),
        Ij = function(a) {
            return function() {
                return a[eb] || (a[eb] = qc(a))
            }
        }(ej);

    function Jj(a, b) {
        try {
            var c = wb;
            if (!zb(a)) {
                var d, e, f = (e = (d = typeof c === "function" ? c() : c) == null ? void 0 : d.concat("\n")) != null ? e : "";
                throw Error(f + String(a));
            }
            return Hj(a)
        } catch (g) {
            return b.G({
                methodName: 838,
                I: g
            }), Ij()
        }
    };

    function Kj() {
        var a;
        return (a = D.googletag) != null ? a : D.googletag = {
            cmd: []
        }
    }

    function Lj(a, b) {
        var c = Kj();
        c.hasOwnProperty(a) || (c[a] = b)
    };

    function Mj() {
        var a = sttc,
            b = Nj(),
            c = b.M,
            d = b.ra,
            e = b.fa;
        if (fetch) {
            ji(c.P, 1E3) && d.ga.ja.ea.Ia.J({
                K: 1E3,
                Ma: !0
            });
            Xa(function(A) {
                e.G({
                    methodName: 1189,
                    I: A
                })
            });
            b = Kj();
            a = Jj(a, e);
            vb(!W(mj).g);
            v(Object, "assign").call(Object, lj, b._vars_);
            b._vars_ = lj;
            a && (fd(a, 3) && oj(36, !0), S(a, 6) && oj(150, S(a, 6)), mi(Zc(a, ki, 13)) && oj(263, !0));
            var f = Zc(a, Ch, 1),
                g = {
                    fb: li(Zc(a, ki, 13)),
                    hb: gd(a, 2),
                    Ra: Lc(a, 10, bc, P()),
                    Xa: gd(a, 7),
                    bb: S(a, 6),
                    pa: fd(a, 4)
                },
                h = Q(a, xd, 9),
                k = window,
                m = k.document;
            Lj("_loaded_", !0);
            Lj("cmd", []);
            var n, l = (n = Oj(m)) != null ? n : Pj(m);
            Qj(f, k, v(Object, "assign").call(Object, {}, {
                La: l
            }, g));
            try {
                Gi()
            } catch (A) {}
            pi("1", k);
            n = vj(l);
            f = (l == null ? void 0 : l.crossOrigin) === "anonymous";
            g = Uh(Sf);
            if (ji(c.P, g)) {
                var p = d.ga.ja.ea;
                p.gb.J({
                    K: g,
                    oa: (l == null ? void 0 : l.crossOrigin) === "anonymous",
                    qa: sj(l)
                });
                p.cb.J({
                    K: g,
                    oa: f,
                    qa: Hh(n.toString().match(Gh)[3] || null) === "pagead2.googlesyndication.com"
                })
            }
            var r = !1;
            hj({
                data: sd(gj(a)),
                kb: function() {
                    return r
                }
            }, b, e);
            if (!Rj(m)) {
                g = "gpt-impl-" + Math.random();
                try {
                    Md(m, Ud(n, {
                        id: g,
                        nonce: Jd(document),
                        Ha: f ? "anonymous" : void 0
                    }))
                } catch (A) {}
                m.getElementById(g) && (b._loadStarted_ = !0)
            }
            if (!b._loadStarted_) {
                g = $d("SCRIPT");
                Kd(g, n);
                g.async = !0;
                f && (g.crossOrigin = "anonymous");
                n = m.body;
                f = m.documentElement;
                var t, z;
                ((z = (t = m.head) != null ? t : n) != null ? z : f).appendChild(g);
                b._loadStarted_ = !0
            }
            if (k === k.top) try {
                wg(k, Zc(a, ki, 13))
            } catch (A) {
                e.G({
                    methodName: 1209,
                    I: A
                })
            }
            Gj(new Cj(c, d, e), k, l, sj(l), h);
            rj(k, function() {
                r = !0
            });
            S(a, 14) && Ag(k.document, Bg(S(a, 14), sj(l)), e)
        } else d.ga.ja.ea.Ia.J({
            K: 1,
            Ma: !1
        })
    }

    function Nj() {
        var a = ae(window),
            b = new ii,
            c = new Nf(11, "m202510220101", 1E3);
        return {
            ra: c,
            M: b,
            fa: new xj(c, b, {
                Qa: a,
                Pa: window.document.URL,
                Ka: "m202510220101",
                da: ph
            })
        }
    }

    function Oj(a) {
        return (a = a.currentScript) ? a : null
    }

    function Pj(a) {
        var b;
        a = y((b = a.scripts) != null ? b : []);
        for (b = a.next(); !b.done; b = a.next())
            if (b = b.value, v(b.src, "includes").call(b.src, "/tag/js/gpt")) return b;
        return null
    }

    function Qj(a, b, c) {
        oj(172, c.La);
        wj(a, c);
        jj(12);
        jj(5);
        (a = dj(b)) && a.then(function(d) {
            return void oj(251, JSON.stringify(K(d)))
        });
        Zd(W(Th).l(Wf.g, Wf.defaultValue), b.document)
    }

    function Rj(a) {
        var b = Oj(a);
        return a.readyState === "complete" || a.readyState === "loaded" || !(b == null || !b.async)
    };
    try {
        Mj()
    } catch (a) {
        try {
            Nj().fa.G({
                methodName: 420,
                I: a
            })
        } catch (b) {}
    };
}).call(this, "[[[[799624373,null,null,[]],[772510493,null,null,[1]],[null,7,null,[null,0.1]],[null,null,null,[],[[[4,null,83],[null,null,null,[\"1 bidderRequests.bids bidder userIdAsEids.source\",\"2 bidderRequests.bids.userIdAsEids source provider\",\"3 bidderRequests.bids bidder ortb2Imp.ext.tid?\",\"5 bidderRequests.bids bidder mediaTypes.banner\",\"6 bidderRequests.bids bidder mediaTypes.native?\",\"7 bidderRequests.bids bidder mediaTypes.video\",\"8 bidderRequests.bids bidder ortb2Imp.ext.gpid?\",\"9 bidderRequests.bids bidder ortb2.site.content.data.segment?\",\"10 bidderRequests.bids bidder ortb2.site.page\",\"11 bidderRequests.bids bidder ortb2.user.data.segment?\",\"12 bidderRequests.bids bidder ortb2.user.data.ext.segtax?\",\"13 bidsReceived adId creativeId\",\"14 bidderRequests.bids.userIdAsEids source uids.ext.provider\",\"15 bidderRequests.bids.userIdAsEids source uids.atype\",\"16 bidderRequests.bids.userIdAsEids source uids.length\",\"17 bidsReceived adId ttl\",\"18 bidsReceived adId meta.primaryCatId\",\"19 bidsReceived adId meta.secondaryCatIds\",\"26 bidderRequests.bids bidder transactionId\",\"27 bidderRequests.bids.userIdAsEids source mm\",\"28 bidderRequests.bids.userIdAsEids source matcher\",\"29 bidderRequests.bids.userIdAsEids source inserter\"]]]],657770675],[null,659575329,null,null,[[[4,null,83],[null,1]]]],[null,612427114,null,null,[[[4,null,83],[null,100]]]],[null,663827948,null,[null,-1]],[null,659579380,null,[null,-1],[[[4,null,83],[null,5000]]]],[null,659579379,null,[null,-1],[[[4,null,83],[null,60000]]]],[null,null,null,[null,null,null,[\"1 dbm\/(ad|clkk)\"]],[[[4,null,83],[null,null,null,[\"1 dbm\/(ad|clkk)\",\"2 (adsrvr|adserver)\\\\.org\/bid\/\",\"3 criteo.com\/(delivery|[a-z]+\/auction)\",\"4 yahoo.com\/bw\/[a-z]+\/imp\/\",\"5 (adnxs|adnxs-simple).com\/it\",\"6 amazon-adsystem.com\/[a-z\/]+\/impb\"]]]],655300591],[null,643045660,null,null,[[[4,null,83],[null,1]]]],[null,741624914,null,[null,100]],[741624915,null,null,[1]],[null,612427113,null,[null,128]],[null,699982590,null,null,[[[4,null,83],[null,128]]]],[null,720326000,null,[null,1]],[null,749055567,null,[null,100]],[null,732179314,null,[null,10]],[45681222,null,null,[1]],[768109354,null,null,[1]],[null,578655462,null,[null,1000]],[698519058,null,null,[1]],[667794963,null,null,[]],[736254283,null,null,[1]],[697841467,null,null,[1]],[null,704895900,null,[null,1000]],[null,770246397,null,[null,1000]],[null,797753679,null,[null,40]],[null,797753680,null,[null,160]],[null,797753681,null,[null,600]],[null,797753678,null,[null,20]],[null,815871886,null,[null,0.8]],[null,625028672,null,[null,100]],[null,629733890,null,[null,1000]],[null,695925491,null,[null,20]],[null,null,null,[],null,489560439],[null,null,null,[],null,505762507],[null,1921,null,[null,72]],[null,1920,null,[null,12]],[null,426169222,null,[null,1000]],[null,377289019,null,[null,10000]],[null,750987462,null,[null,10000]],[null,529,null,[null,20]],[null,573282293,null,[null,0.01]],[null,684553008,null,[null,100]],[776685356,null,null,[]],[45624259,null,null,[],[[[4,null,59,null,null,null,null,[\"2452487976\"]],[1]]]],[45627954,null,null,[1]],[45646888,null,null,[]],[45622305,null,null,[1]],[null,447000223,null,[null,0.01]],[360245597,null,null,[1]],[null,716359135,null,[null,10]],[null,716359138,null,[null,50]],[null,716359132,null,[null,100]],[null,716359134,null,[null,1000]],[null,716359137,null,[null,0.25]],[null,716359136,null,[null,10]],[null,716359133,null,[null,5]],[797429200,null,null,[1]],[null,729624435,null,[null,10000]],[null,794150638,null,[null,5000]],[null,729624436,null,[null,500]],[null,550718589,null,[null,250],[[[3,[[4,null,15,null,null,null,null,[\"22814497764\"]],[4,null,15,null,null,null,null,[\"6581\"]],[4,null,15,null,null,null,null,[\"18190176\"]],[4,null,15,null,null,null,null,[\"21881754602\"]],[4,null,15,null,null,null,null,[\"6782\"]],[4,null,15,null,null,null,null,[\"309565630\"]],[4,null,15,null,null,null,null,[\"22306534072\"]],[4,null,15,null,null,null,null,[\"7229\"]],[4,null,15,null,null,null,null,[\"28253241\"]],[4,null,15,null,null,null,null,[\"1254144\"]],[4,null,15,null,null,null,null,[\"21732118914\"]],[4,null,15,null,null,null,null,[\"5441\"]],[4,null,15,null,null,null,null,[\"162717810\"]],[4,null,15,null,null,null,null,[\"51912183\"]],[4,null,15,null,null,null,null,[\"23202586\"]],[4,null,15,null,null,null,null,[\"44520695\"]],[4,null,15,null,null,null,null,[\"1030006\"]],[4,null,15,null,null,null,null,[\"21830601346\"]],[4,null,15,null,null,null,null,[\"23081961\"]],[4,null,15,null,null,null,null,[\"21880406607\"]],[4,null,15,null,null,null,null,[\"93656639\"]],[4,null,15,null,null,null,null,[\"1020351\"]],[4,null,15,null,null,null,null,[\"5931321\"]],[4,null,15,null,null,null,null,[\"3355436\"]],[4,null,15,null,null,null,null,[\"22106840220\"]],[4,null,15,null,null,null,null,[\"22875833199\"]],[4,null,15,null,null,null,null,[\"32866417\"]],[4,null,15,null,null,null,null,[\"8095840\"]],[4,null,15,null,null,null,null,[\"71161633\"]],[4,null,15,null,null,null,null,[\"22668755367\"]],[4,null,15,null,null,null,null,[\"6177\"]],[4,null,15,null,null,null,null,[\"147246189\"]],[4,null,15,null,null,null,null,[\"22152718\"]],[4,null,15,null,null,null,null,[\"21751243814\"]],[4,null,15,null,null,null,null,[\"22013536576\"]],[4,null,15,null,null,null,null,[\"4444\"]],[4,null,15,null,null,null,null,[\"44890869\"]],[4,null,15,null,null,null,null,[\"248415179\"]],[4,null,15,null,null,null,null,[\"5293\"]],[4,null,15,null,null,null,null,[\"21675937462\"]],[4,null,15,null,null,null,null,[\"21726375739\"]],[4,null,15,null,null,null,null,[\"1002212\"]],[4,null,15,null,null,null,null,[\"6718395\"]]]],[null,500]]]],[null,575880738,null,[null,10]],[null,586681283,null,[null,100]],[null,45679761,null,[null,30000]],[706016261,null,null,[1]],[null,732179799,null,[null,250]],[null,745376890,null,[null,1]],[null,745376891,null,[null,2]],[null,820769768,null,[null,1440]],[null,635239304,null,[null,100]],[801020663,null,null,[]],[801020662,null,null,[]],[788110566,null,null,[]],[null,740510593,null,[null,0.5]],[null,618260805,null,[null,10]],[752401957,null,null,null,[[[1,[[4,null,59,null,null,null,null,[\"473346114\"]]]],[1]]]],[null,532520346,null,[null,30]],[814245513,null,null,[1]],[799688208,null,null,[1]],[null,723123766,null,[null,100]],[null,735866756,null,[null,100]],[45690337,null,null,[1]],[761958081,null,null,[1]],[null,758860411,null,[null,60]],[null,751161866,null,[null,30000]],[null,630428304,null,[null,100]],[730909248,null,null,null,[[[1,[[4,null,59,null,null,null,null,[\"473346114\"]]]],[1]]]],[746075837,null,null,[]],[null,624264750,null,[null,-1]],[759731353,null,null,[1]],[607106222,null,null,[1]],[800936592,null,null,[1]],[800126423,null,null,[1]],[null,398776877,null,[null,60000]],[null,374201269,null,[null,60000]],[null,371364213,null,[null,60000]],[null,682056200,null,[null,100]],[null,376149757,null,[null,0.0025]],[570764855,null,null,[1]],[null,null,579921177,[null,null,\"control_1\\\\.\\\\d\"]],[null,570764854,null,[null,50]],[578725095,null,null,[1]],[791241077,null,null,[1]],[684149381,null,null,[1]],[377936516,null,null,[1]],[null,599575765,null,[null,1000]],[null,null,2,[null,null,\"1-0-45\"]],[null,707091695,null,[null,100]],[null,626653285,null,[null,1000]],[null,626653286,null,[null,2]],[null,642407444,null,[null,10]],[715057423,null,null,[1]],[null,741215712,null,[null,100]],[807860121,null,null,[1]],[799548229,null,null,[1]],[738482525,null,null,[1]],[null,506394061,null,[null,100]],[null,733365673,null,[null,2],[[[4,null,59,null,null,null,null,[\"1282204929\"]],[null,1]]]],[null,null,null,[null,null,null,[\"95335247\"]],null,631604025],[null,694630217,null,[null,670]],[null,783316493,null,[null,4000]],[783316492,null,null,[1]],[null,null,null,[],null,489],[811042160,null,null,[1]],[null,754057781,null,null,[[[6,null,null,3,null,2],[null,2]]]],[392065905,null,null,null,[[[3,[[4,null,68],[4,null,83]]],[1]]]],[null,360245595,null,[null,500]],[null,762520832,null,[null,1000]],[null,715129739,null,[null,30]],[null,681088477,null,[null,100]],[676934885,null,null,[1],[[[4,null,59,null,null,null,null,[\"4214592683\",\"3186860772\",\"2930824068\",\"4127372480\",\"3985777170\",\"2998550476\",\"1946945953\",\"2901923877\",\"1931583037\",\"733037847\",\"287365726\",\"396735883\",\"2445204049\"]],[]]]],[776823724,null,null,[]],[751082905,null,null,[1]],[800545335,null,null,[1]],[788470829,null,null,[1]],[703102329,null,null,[1]],[703102335,null,null,[1]],[703102334,null,null,[1]],[703102333,null,null,[1]],[703102330,null,null,[1]],[703102332,null,null,[1]],[555237688,null,null,[],[[[2,[[4,null,70,null,null,null,null,[\"browsing-topics\"]],[1,[[4,null,27,null,null,null,null,[\"isSecureContext\"]]]]]],[1]]]],[555237686,null,null,[]],[null,638742197,null,[null,500]],[null,514795754,null,[null,2]],[null,697023992,null,[null,500]],[null,null,null,[null,null,null,[\"679602798\",\"965728666\",\"3786422334\",\"4071951799\"]],null,603422363],[590730356,null,null,null,[[[12,null,null,null,4,null,\"Chrome\\\\\/((?!1[0-1]\\\\d)(?!12[0-3])\\\\d{3,})\",[\"navigator.userAgent\"]],[1]]]],[564724551,null,null,null,[[[12,null,null,null,4,null,\"Chrome\\\\\/((?!10\\\\d)(?!11[0-6])\\\\d{3,})\",[\"navigator.userAgent\"]],[1]]]],[null,596918936,null,[null,500]],[null,607730666,null,[null,10]],[616896918,null,null,[1]],[767691923,null,null,[1]],[null,null,null,[null,null,null,[\"AlK2UR5SkAlj8jjdEc9p3F3xuFYlF6LYjAML3EOqw1g26eCwWPjdmecULvBH5MVPoqKYrOfPhYVL71xAXI1IBQoAAAB8eyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"Amm8\/NmvvQfhwCib6I7ZsmUxiSCfOxWxHayJwyU1r3gRIItzr7bNQid6O8ZYaE1GSQTa69WwhPC9flq\/oYkRBwsAAACCeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiV2ViVmlld1hSZXF1ZXN0ZWRXaXRoRGVwcmVjYXRpb24iLCJleHBpcnkiOjE3NTgwNjcxOTksImlzU3ViZG9tYWluIjp0cnVlfQ==\",\"A9nrunKdU5m96PSN1XsSGr3qOP0lvPFUB2AiAylCDlN5DTl17uDFkpQuHj1AFtgWLxpLaiBZuhrtb2WOu7ofHwEAAACKeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A93bovR+QVXNx2\/38qDbmeYYf1wdte9EO37K9eMq3r+541qo0byhYU899BhPB7Cv9QqD7wIbR1B6OAc9kEfYCA4AAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\",\"A1S5fojrAunSDrFbD8OfGmFHdRFZymSM\/1ss3G+NEttCLfHkXvlcF6LGLH8Mo5PakLO1sCASXU1\/gQf6XGuTBgwAAACQeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXRhZ3NlcnZpY2VzLmNvbTo0NDMiLCJmZWF0dXJlIjoiQUlQcm9tcHRBUElNdWx0aW1vZGFsSW5wdXQiLCJleHBpcnkiOjE3NzQzMTA0MDAsImlzU3ViZG9tYWluIjp0cnVlLCJpc1RoaXJkUGFydHkiOnRydWV9\"]],null,1934],[485990406,null,null,[]]],[[3,[[null,[[1337,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]],[84,null,null,[1]],[188,null,null,[1]]]]]],[10,[[31088080],[31088081]]],[470,[[83321072],[83321073]],null,136],[10,[[83321442],[83321443]],null,136],[10,[[83322116],[83322117]],null,136],[10,[[95370931],[95370932,[[null,788997299,null,[null,2]]]],[95371304,[[null,788997299,null,[null,1]]]],[95375280,[[785049535,null,null,[1]],[null,788997299,null,[null,2]]]]]],[10,[[95375383],[95375384],[95375389]]],[null,[[676982960],[676982998]]]]],[12,[[10,[[31061690],[31061691,[[83,null,null,[1]],[84,null,null,[1]]]]],null,59],[40,[[95340252],[95340253,[[662101537,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5],[40,[[95340254],[95340255,[[662101539,null,null,[1]]]]],[4,null,9,null,null,null,null,[\"LayoutShift\"]],71,null,null,null,800,null,null,null,null,null,5]]],[13,[[500,[[31061692],[31061693,[[77,null,null,[1]],[78,null,null,[1]],[80,null,null,[1]],[76,null,null,[1]]]]],[4,null,6,null,null,null,null,[\"31061691\",\"4\"]]]]],[5,[[10,[[31067420],[31067421,[[360245597,null,null,[]]]]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69],[1000,[[31084129,null,[2,[[2,[[8,null,null,1,null,-1],[7,null,null,1,null,10]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[1000,[[31084130,null,[2,[[2,[[8,null,null,1,null,9],[7,null,null,1,null,20]]],[4,null,3]]]]],null,80,null,null,null,null,null,null,null,null,4],[50,[[31085776],[31085777,[[45624259,null,null,[1]]]]],null,114],[100,[[31086814],[31086815,[[null,665058368,null,[null,1]]]]]],[null,[[31093082],[31093083,[[767688524,null,null,[1]]]]]],[10,[[31093611],[31093612,[[760666257,null,null,[1]],[null,758465301,null,[null,10]]]]]],[10,[[31094265],[31094266,[[794152180,null,null,[1]]]]]],[10,[[31094859,null,[2,[[6,null,null,3,null,2],[3,[[4,null,59,null,null,null,null,[\"4266216755\"]],[4,null,59,null,null,null,null,[\"2873384857\"]],[4,null,59,null,null,null,null,[\"534638854\"]],[4,null,59,null,null,null,null,[\"3453837838\"]],[4,null,59,null,null,null,null,[\"209085618\"]],[4,null,59,null,null,null,null,[\"1755614695\"]],[4,null,59,null,null,null,null,[\"2629955493\"]],[4,null,59,null,null,null,null,[\"209085618\"]],[4,null,59,null,null,null,null,[\"787328721\"]],[4,null,59,null,null,null,null,[\"2777520706\"]]]]]]],[31094860,[[null,null,null,[null,null,null,[\"\/21707781519\/ls-mweb\/ls_mweb_hp\",\"\/1211\/br.terra.homepage\/home360\/ancora\",\"\/1211\/br.terra.news\/brasil.articles\/ancora\",\"\/34616581\/m.20minutos.es\/home\/portada\/Sticky\",\"85406138\/Mobile_HP_Anchor\",\"\/15748617,22365852633\/Loteriasdominicanascom\/Loteriasdominicanascom-Mobile-pushup\",\"\/8804\/uol\/home\/320x50_footer\",\"\/424397508\/dailymail.uk\/dm_dmhome_homehp\/sticky_banner_monews\",\"\/424397508\/dailymail.uk\/dm_dmnews_newsart\/sticky_banner\",\"\/15748617,22365852633\/Loteriasdominicanascom\/Loteriasdominicanascom-Mobile-pushup\",\"\/35821442\/gazzetta.it\/homepage\/TopLeft\",\"\/138855687\/nacional-spo\/portada\"]],null,771226568]],[2,[[6,null,null,3,null,2],[3,[[4,null,59,null,null,null,null,[\"4266216755\"]],[4,null,59,null,null,null,null,[\"2873384857\"]],[4,null,59,null,null,null,null,[\"534638854\"]],[4,null,59,null,null,null,null,[\"3453837838\"]],[4,null,59,null,null,null,null,[\"209085618\"]],[4,null,59,null,null,null,null,[\"1755614695\"]],[4,null,59,null,null,null,null,[\"2629955493\"]],[4,null,59,null,null,null,null,[\"209085618\"]],[4,null,59,null,null,null,null,[\"787328721\"]],[4,null,59,null,null,null,null,[\"2777520706\"]]]]]]],[31094861,[[null,null,null,[null,null,null,[\"\/21707781519\/ls-mweb\/ls_mweb_hp\",\"\/1211\/br.terra.homepage\/home360\/ancora\",\"\/1211\/br.terra.news\/brasil.articles\/ancora\",\"\/34616581\/m.20minutos.es\/home\/portada\/Sticky\",\"85406138\/Mobile_HP_Anchor\",\"\/15748617,22365852633\/Loteriasdominicanascom\/Loteriasdominicanascom-Mobile-pushup\",\"\/8804\/uol\/home\/320x50_footer\",\"\/424397508\/dailymail.uk\/dm_dmhome_homehp\/sticky_banner_monews\",\"\/424397508\/dailymail.uk\/dm_dmnews_newsart\/sticky_banner\",\"\/15748617,22365852633\/Loteriasdominicanascom\/Loteriasdominicanascom-Mobile-pushup\",\"\/35821442\/gazzetta.it\/homepage\/TopLeft\",\"\/138855687\/nacional-spo\/portada\"]],null,771226568]],[2,[[6,null,null,3,null,2],[3,[[4,null,59,null,null,null,null,[\"4266216755\"]],[4,null,59,null,null,null,null,[\"2873384857\"]],[4,null,59,null,null,null,null,[\"534638854\"]],[4,null,59,null,null,null,null,[\"3453837838\"]],[4,null,59,null,null,null,null,[\"209085618\"]],[4,null,59,null,null,null,null,[\"1755614695\"]],[4,null,59,null,null,null,null,[\"2629955493\"]],[4,null,59,null,null,null,null,[\"209085618\"]],[4,null,59,null,null,null,null,[\"787328721\"]],[4,null,59,null,null,null,null,[\"2777520706\"]]]]]]]],null,149],[50,[[31095007],[31095008,[[785453655,null,null,[1]]]]]],[10,[[31095009],[31095010,[[792252173,null,null,[1]]]]]],[10,[[31095130],[31095131,[[null,625028672,null,[null,50]],[null,629733890,null,[null,10]]]],[31095132,[[null,625028672,null,[null,250]],[null,629733890,null,[null,10]]]],[31095133,[[null,625028672,null,[null,500]],[null,629733890,null,[null,10]]]],[31095134,[[null,625028672,null,[null,5000]],[null,629733890,null,[null,10]]]]]],[100,[[31095155],[31095156,[[813899658,null,null,[1]]]]]],[10,[[31095205],[31095206,[[748362437,null,null,[1]]]]]],[50,[[31095250],[31095251,[[null,815871886,null,[null,0.01]]]],[31095252,[[null,815871886,null,[null,0.33]]]],[31095253,[[null,815871886,null,[null,0.5]]]]]],[10,[[31095309],[31095310,[[null,null,null,[null,null,null,[\"topics\",\"nt\",\"psd\",\"tps\",\"htps\",\"td\",\"eig\",\"eigir\",\"tan\",\"tdf\"]],null,489],[570764855,null,null,[]],[506738118,null,null,[1]],[399705355,null,null,[1]],[485990406,null,null,[1]],[555237688,null,null,[1]],[555237686,null,null,[1]]]],[95375630,[[558225291,null,null,[1]]]],[95375631,[[555237688,null,null,[1]],[555237686,null,null,[1]]]],[95375632,[[399705355,null,null,[1]],[485990406,null,null,[1]]]]]],[100,[[31095341],[31095342,[[null,812862060,null,[null,1000]]]]]],[1000,[[31095393,[[null,24,null,[null,31095393]]],[6,null,null,13,null,31095393]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31095394,[[null,24,null,[null,31095394]]],[6,null,null,13,null,31095394]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31095425,[[null,24,null,[null,31095425]]],[6,null,null,13,null,31095425]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1000,[[31095426,[[null,24,null,[null,31095426]]],[6,null,null,13,null,31095426]]],[4,null,3],1,null,null,null,null,null,null,null,null,3],[1,[[31095431],[31095432,[[null,784887894,null,[null,1]]]]]],[1,[[31095436],[31095437,[[710738456,null,null,[1]]]]]],[1,[[95371083],[95371084,[[788110566,null,null,[1]]]],[95371085,[[801020662,null,null,[1]],[788110566,null,null,[1]]]],[95371086,[[801020663,null,null,[1]],[801020662,null,null,[1]],[788110566,null,null,[1]]]]],null,154],[50,[[95372981],[95372982,[[801020662,null,null,[1]],[788110566,null,null,[1]]]]],null,154],[10,[[95375804],[95375805]],[3,[[4,null,8,null,null,null,null,[\"gmaSdk.getQueryInfo\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaQueryInfo.postMessage\"]],[4,null,8,null,null,null,null,[\"webkit.messageHandlers.getGmaSig.postMessage\"]]]],69]]],[9,[[1000,[[31083577]],[4,null,13,null,null,null,null,[\"cxbbhbxm\",\"hzwxrfqd\"]]],[1000,[[31091121,null,[4,null,13,null,null,null,null,[\"zxcvbnms\"]]]],null,141,null,null,null,null,null,null,null,null,33],[1000,[[31091122,[[45681222,null,null,[1]]],[4,null,13,null,null,null,null,[\"qwrtplkj\"]]]],null,141,null,null,null,null,null,null,null,null,33]]],[2,[[10,[[31084489],[31084490]],null,null,null,null,32,null,null,142,1],[1000,[[31084739,[[null,612427114,null,[null,100]]]]],[4,null,6,null,null,null,null,[\"31065645\",\"2\"]]],[10,[[31084865],[31084866]],null,null,null,null,35,null,null,166,1],[1000,[[31087377,null,[2,[[4,null,86],[4,null,6,null,null,null,null,[\"31065644\",\"2\"]]]]]],null,131,null,null,null,null,null,null,null,null,28],[1000,[[31087378,null,[2,[[4,null,86],[4,null,6,null,null,null,null,[\"31065645\",\"2\"]]]]]],null,131,null,null,null,null,null,null,null,null,28],[1000,[[31087490,null,[2,[[1,[[4,null,86]]],[4,null,6,null,null,null,null,[\"31065644\",\"2\"]]]]]],null,131,null,null,null,null,null,null,null,null,28],[1000,[[31087491,null,[2,[[1,[[4,null,86]]],[4,null,6,null,null,null,null,[\"31065645\",\"2\"]]]]]],null,131,null,null,null,null,null,null,null,null,28],[10,[[31092998],[31093000,[[725693774,null,null,[1]]]],[31094359,[[729624434,null,null,[1]],[null,794664882,null,[null,0.5]],[797954106,null,null,[1]]]],[31094360,[[729624434,null,null,[1]],[725693774,null,null,[1]],[null,794664882,null,[null,0.5]],[797954106,null,null,[1]]]],[31094395,[[775698922,null,null,[1]],[729624434,null,null,[1]],[null,794664882,null,[null,0.5]],[797954106,null,null,[1]]]],[31094396,[[775698922,null,null,[1]],[725693774,null,null,[1]]]],[31094397,[[775698922,null,null,[1]],[729624434,null,null,[1]],[725693774,null,null,[1]],[null,794664882,null,[null,0.5]],[797954106,null,null,[1]]]],[31095433,[[775698922,null,null,[1]],[811047177,null,null,[1]]]],[95367712,[[775698922,null,null,[1]]]],[95374405,[[801009316,null,null,[1]]]],[95375278,[[775698922,null,null,[1]],[801009316,null,null,[1]]]]],null,null,null,null,null,null,null,198,1],[800,[[31093004,[[775698922,null,null,[1]],[729624434,null,null,[1]],[725693774,null,null,[1]],[null,794664882,null,[null,0.5]],[797954106,null,null,[1]]],[3,[[2,[[4,null,15,null,null,null,null,[\"6032\"]],[6,null,null,3,null,2],[1,[[4,null,59,null,null,null,null,[\"2004189832\"]]]]]],[4,null,15,null,null,null,null,[\"1012355\"]],[4,null,15,null,null,null,null,[\"9528481\"]],[4,null,15,null,null,null,null,[\"151127700\"]],[4,null,15,null,null,null,null,[\"8448570\"]],[4,null,15,null,null,null,null,[\"5302\"]],[4,null,15,null,null,null,null,[\"7811748\"]],[4,null,15,null,null,null,null,[\"138855687\"]],[4,null,15,null,null,null,null,[\"99287527\"]],[4,null,15,null,null,null,null,[\"19024548\"]],[4,null,15,null,null,null,null,[\"22897154128\"]]]]]],null,null,null,null,null,200,null,198,1],[70,[[31093009,[[775698922,null,null,[1]],[729624434,null,null,[1]],[725693774,null,null,[1]],[null,794664882,null,[null,0.5]],[797954106,null,null,[1]]],[3,[[2,[[4,null,15,null,null,null,null,[\"6032\"]],[3,[[6,null,null,3,null,2],[1,[[4,null,59,null,null,null,null,[\"2004189832\"]]]]]]]],[4,null,15,null,null,null,null,[\"1012355\"]],[4,null,15,null,null,null,null,[\"9528481\"]],[4,null,15,null,null,null,null,[\"151127700\"]],[4,null,15,null,null,null,null,[\"8448570\"]],[4,null,15,null,null,null,null,[\"5302\"]],[4,null,15,null,null,null,null,[\"7811748\"]],[4,null,15,null,null,null,null,[\"138855687\"]],[4,null,15,null,null,null,null,[\"99287527\"]],[4,null,15,null,null,null,null,[\"19024548\"]],[4,null,15,null,null,null,null,[\"22897154128\"]]]]]],null,null,null,null,null,130,null,198,1],[10,[[31093114,[[775698922,null,null,[]],[729624434,null,null,[]],[725693774,null,null,[]],[null,794664882,null,[null,0.5]],[797954106,null,null,[1]]],[3,[[2,[[4,null,15,null,null,null,null,[\"6032\"]],[3,[[6,null,null,3,null,2],[1,[[4,null,59,null,null,null,null,[\"2004189832\"]]]]]]]],[4,null,15,null,null,null,null,[\"1012355\"]],[4,null,15,null,null,null,null,[\"9528481\"]],[4,null,15,null,null,null,null,[\"151127700\"]],[4,null,15,null,null,null,null,[\"8448570\"]],[4,null,15,null,null,null,null,[\"5302\"]],[4,null,15,null,null,null,null,[\"7811748\"]],[4,null,15,null,null,null,null,[\"138855687\"]],[4,null,15,null,null,null,null,[\"99287527\"]],[4,null,15,null,null,null,null,[\"19024548\"]],[4,null,15,null,null,null,null,[\"22897154128\"]]]]]],null,null,null,null,null,110,null,198,1],[10,[[31093115,[[775698922,null,null,[1]],[729624434,null,null,[1]],[725693774,null,null,[1]],[null,794664882,null,[null,0.5]],[797954106,null,null,[1]]],[3,[[2,[[4,null,15,null,null,null,null,[\"6032\"]],[3,[[6,null,null,3,null,2],[1,[[4,null,59,null,null,null,null,[\"2004189832\"]]]]]]]],[4,null,15,null,null,null,null,[\"1012355\"]],[4,null,15,null,null,null,null,[\"9528481\"]],[4,null,15,null,null,null,null,[\"151127700\"]],[4,null,15,null,null,null,null,[\"8448570\"]],[4,null,15,null,null,null,null,[\"5302\"]],[4,null,15,null,null,null,null,[\"7811748\"]],[4,null,15,null,null,null,null,[\"138855687\"]],[4,null,15,null,null,null,null,[\"99287527\"]],[4,null,15,null,null,null,null,[\"19024548\"]],[4,null,15,null,null,null,null,[\"22897154128\"]]]]]],null,null,null,null,null,120,null,198,1],[20,[[95357665],[95357666],[95357667],[95357668],[95357669],[95357670]],[4,null,89],null,null,null,37,780,null,166,1],[1,[[95365417,null,[4,null,92,null,null,null,null,[\"userId\"]]]]],[1,[[95365418,null,[4,null,92,null,null,null,null,[\"chromeAiRtdProvider\"]]]]],[10,[[95368453],[95368454,[[786014078,null,null,[1]]]],[95368455,[[786014079,null,null,[1]]]]],null,null,null,null,null,null,null,219,1],[100,[[95369066],[95369067,[[45712479,null,null,[1]]]]],null,null,null,null,null,500,null,222]]],[27,[[50,[[31090502,null,[2,[[4,null,59,null,null,null,null,[\"1282204929\",\"2762681000\",\"1201683087\",\"1405537016\",\"1184328227\",\"3766824835\",\"107843290\",\"2849015825\",\"2285744699\",\"125820391\",\"1242812256\",\"2369380032\",\"3013643711\",\"77481481\",\"2269399977\",\"3906315807\",\"2791111070\",\"2128463204\",\"3298531905\",\"2399173495\",\"3986628766\",\"149255127\",\"896865192\",\"643747965\",\"1028035958\"]],[8,null,null,17,null,0]]]],[31090503,[[728394046,null,null,[1]]],[2,[[4,null,59,null,null,null,null,[\"1282204929\",\"2762681000\",\"1201683087\",\"1405537016\",\"1184328227\",\"3766824835\",\"107843290\",\"2849015825\",\"2285744699\",\"125820391\",\"1242812256\",\"2369380032\",\"3013643711\",\"77481481\",\"2269399977\",\"3906315807\",\"2791111070\",\"2128463204\",\"3298531905\",\"2399173495\",\"3986628766\",\"149255127\",\"896865192\",\"643747965\",\"1028035958\"]],[8,null,null,17,null,0]]]]]]]],[4,[[null,[[44714449,[[null,7,null,[null,1]]]],[676982961,[[null,7,null,[null,0.4]],[212,null,null,[1]]]],[676982996,[[null,7,null,[null,1]]]]],null,78]]]],null,null,[null,1000,1,1000]],31095425,null,null,null,\".google.co.ma\",352,null,[[\"avito.ma\",null,\"https:\/\/www.avito.ma\/\",null,null,[\"170737076\",\"21849154601\",\"22059416475\",\"22466671215\",\"23328537\",\"58092247\",\"7103\"]],[[[\"58092247\",null,2]]],[],null,null,[[\"58092247\",[[\"adserver.org\",null,1],[\"mygaruID\",null,1],[\"openx.net\",null,1],[\"rubiconproject.com\",null,1],[\"pubcid.org\",null,1],[\"liveintent.com\",null,1],[\"liveintent.triplelift.com\",null,1],[\"intentiq.com\",null,1],[\"yahoo.com\",null,1],[\"intimatemerger.com\",null,1],[\"utiq.com\",null,1],[\"liveintent.sovrn.com\",null,1],[\"bidswitch.net\",null,1],[\"liveramp.com\",null,1],[\"uidapi.com\",null,1],[\"esp.pubmatic.com\",null,1],[\"liveintent.indexexchange.com\",null,1],[\"audigent.com\",null,1],[\"crwdcntrl.net\",null,1],[\"id5-sync.com\",null,1],[\"ceeid.eu\",null,1],[\"euid.eu\",null,1],[\"justtag.com\",null,1],[\"pubmatic.com\",null,1],[\"epsilon.com\",null,1],[\"google.com\",null,1]]]],null,[[[\"170737076\",1],[\"178427750\",1],[\"21849154601\",1],[\"22059416475\",1],[\"22466671215\",1],[\"23328537\",1],[\"363074998\",1],[\"58092247\",1],[\"7103\",0],[\"92748959\",1]]],[[[\"170737076\",1],[\"178427750\",1],[\"21849154601\",1],[\"22059416475\",1],[\"22466671215\",1],[\"23328537\",1],[\"363074998\",1],[\"58092247\",1],[\"7103\",1],[\"92748959\",1]]],null,[[12616,1761340800],[23809,1761342000],[24510,1761343200],[5269,1761344400]],[1]],null,null,null,[0,0,0],\"m202510140101\"]")