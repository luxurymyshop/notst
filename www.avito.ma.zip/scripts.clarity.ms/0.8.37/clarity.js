/* clarity-js v0.8.37: https://github.com/microsoft/clarity (License: MIT) */ ! function() {
    "use strict";
    var t = Object.freeze({
            __proto__: null,
            get add() {
                return Va
            },
            get get() {
                return ar
            },
            get getId() {
                return Fa
            },
            get getNode() {
                return er
            },
            get getValue() {
                return nr
            },
            get has() {
                return ir
            },
            get hashText() {
                return tr
            },
            get iframe() {
                return Ga
            },
            get iframeContent() {
                return Ka
            },
            get lookup() {
                return rr
            },
            get parse() {
                return Ua
            },
            get removeIFrame() {
                return Za
            },
            get sameorigin() {
                return Ja
            },
            get start() {
                return za
            },
            get stop() {
                return Ha
            },
            get update() {
                return Ba
            },
            get updates() {
                return or
            }
        }),
        e = Object.freeze({
            __proto__: null,
            get queue() {
                return $r
            },
            get start() {
                return Qr
            },
            get stop() {
                return ti
            },
            get track() {
                return Fr
            }
        }),
        n = Object.freeze({
            __proto__: null,
            get data() {
                return Ci
            },
            get start() {
                return Di
            },
            get stop() {
                return Ri
            },
            get upgrade() {
                return Pi
            }
        }),
        a = Object.freeze({
            __proto__: null,
            get check() {
                return ji
            },
            get compute() {
                return Li
            },
            get data() {
                return Ii
            },
            get start() {
                return Yi
            },
            get stop() {
                return Wi
            },
            get trigger() {
                return Xi
            }
        }),
        r = Object.freeze({
            __proto__: null,
            get compute() {
                return Bi
            },
            get data() {
                return zi
            },
            get log() {
                return Vi
            },
            get reset() {
                return Ji
            },
            get start() {
                return Ui
            },
            get stop() {
                return Fi
            },
            get updates() {
                return Hi
            }
        }),
        i = Object.freeze({
            __proto__: null,
            get callback() {
                return lo
            },
            get callbacks() {
                return Ki
            },
            get clear() {
                return so
            },
            get consent() {
                return io
            },
            get consentv2() {
                return oo
            },
            get data() {
                return Gi
            },
            get electron() {
                return Zi
            },
            get id() {
                return ro
            },
            get metadata() {
                return ao
            },
            get save() {
                return fo
            },
            get shortid() {
                return vo
            },
            get start() {
                return eo
            },
            get stop() {
                return no
            }
        }),
        o = Object.freeze({
            __proto__: null,
            get data() {
                return ko
            },
            get envelope() {
                return To
            },
            get start() {
                return Oo
            },
            get stop() {
                return Eo
            }
        }),
        u = {
            projectId: null,
            delay: 1e3,
            lean: !1,
            lite: !1,
            track: !0,
            content: !0,
            drop: [],
            mask: [],
            unmask: [],
            regions: [],
            cookies: [],
            fraud: !0,
            checksum: [],
            report: null,
            upload: null,
            fallback: null,
            upgrade: null,
            action: null,
            dob: null,
            delayDom: !1,
            throttleDom: !0,
            conversions: !1,
            includeSubdomains: !0
        };

    function c(t) {
        return window.Zone && "__symbol__" in window.Zone ? window.Zone.__symbol__(t) : t
    }
    var s = 0;

    function l() {
        return performance.now() + performance.timeOrigin
    }

    function d(t) {
        void 0 === t && (t = null);
        var e = 0 === s ? l() : s,
            n = t && t.timeStamp > 0 ? t.timeStamp : performance.now(),
            a = t && t.view ? t.view.performance.timeOrigin : performance.timeOrigin;
        return Math.max(Math.round(n + a - e), 0)
    }
    var f = "0.8.37";

    function p(t, e) {
        void 0 === e && (e = null);
        for (var n, a = 5381, r = a, i = 0; i < t.length; i += 2) {
            if (a = (a << 5) + a ^ t.charCodeAt(i), i + 1 < t.length) r = (r << 5) + r ^ t.charCodeAt(i + 1)
        }
        return n = Math.abs(a + 11579 * r), (e ? n % Math.pow(2, e) : n).toString(36)
    }
    var h = /\S/gi,
        v = 255,
        g = !0,
        m = null,
        y = null,
        b = null;

    function w(t, e, n, a, r) {
        if (void 0 === a && (a = !1), t) {
            if ("input" == e && ("checkbox" === r || "radio" === r)) return t;
            switch (n) {
                case 0:
                    return t;
                case 1:
                    switch (e) {
                        case "*T":
                        case "value":
                        case "placeholder":
                        case "click":
                            return function(t) {
                                var e = -1,
                                    n = 0,
                                    a = !1,
                                    r = !1,
                                    i = !1,
                                    o = null;
                                _();
                                for (var u = 0; u < t.length; u++) {
                                    var c = t.charCodeAt(u);
                                    if (a = a || c >= 48 && c <= 57, r = r || 64 === c, i = 9 === c || 10 === c || 13 === c || 32 === c, 0 === u || u === t.length - 1 || i) {
                                        if (a || r) {
                                            null === o && (o = t.split(""));
                                            var s = t.substring(e + 1, i ? u : u + 1);
                                            s = g && null !== b ? s.match(b) ? s : E(s, "▪", "▫") : O(s), o.splice(e + 1 - n, s.length, s), n += s.length - 1
                                        }
                                        i && (a = !1, r = !1, e = u)
                                    }
                                }
                                return o ? o.join("") : t
                            }(t);
                        case "input":
                        case "change":
                            return T(t)
                    }
                    return t;
                case 2:
                case 3:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? k(t) : O(t);
                        case "src":
                        case "srcset":
                        case "title":
                        case "alt":
                            return 3 === n ? "src" === e && (null == t ? void 0 : t.startsWith("blob:")) ? "blob:" : "" : t;
                        case "value":
                        case "click":
                        case "input":
                        case "change":
                            return T(t);
                        case "placeholder":
                            return O(t)
                    }
                    break;
                case 4:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return a ? k(t) : O(t);
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                            return ""
                    }
                    break;
                case 5:
                    switch (e) {
                        case "*T":
                        case "data-":
                            return E(t, "▪", "▫");
                        case "value":
                        case "input":
                        case "click":
                        case "change":
                            return Array(5).join("•");
                        case "checksum":
                        case "src":
                        case "srcset":
                        case "alt":
                        case "title":
                            return ""
                    }
            }
        }
        return t
    }

    function S(t, e, n) {
        void 0 === e && (e = !1), void 0 === n && (n = !1);
        var a = t;
        if (e) a = "".concat("https://").concat("Electron");
        else {
            var r = u.drop;
            if (r && r.length > 0 && t && t.indexOf("?") > 0) {
                var i = t.split("?"),
                    o = i[0],
                    c = i[1];
                a = o + "?" + c.split("&").map((function(t) {
                    return r.some((function(e) {
                        return 0 === t.indexOf("".concat(e, "="))
                    })) ? "".concat(t.split("=")[0], "=").concat("*na*") : t
                })).join("&")
            }
        }
        return n && (a = a.substring(0, v)), a
    }

    function k(t) {
        var e = t.trim();
        if (e.length > 0) {
            var n = e[0],
                a = t.indexOf(n),
                r = t.substr(0, a),
                i = t.substr(a + e.length);
            return "".concat(r).concat(e.length.toString(36)).concat(i)
        }
        return t
    }

    function O(t) {
        return t.replace(h, "•")
    }

    function E(t, e, n) {
        return _(), t ? t.replace(y, e).replace(m, n) : t
    }

    function T(t) {
        for (var e = 5 * (Math.floor(t.length / 5) + 1), n = "", a = 0; a < e; a++) n += a > 0 && a % 5 == 0 ? " " : "•";
        return n
    }

    function _() {
        if (g && null === m) try {
            m = new RegExp("\\p{N}", "gu"), y = new RegExp("\\p{L}", "gu"), b = new RegExp("\\p{Sc}", "gu")
        } catch (t) {
            g = !1
        }
    }
    var N = null,
        M = null,
        x = !1;

    function I() {
        x && (N = {
            time: d(),
            event: 4,
            data: {
                visible: M.visible,
                docWidth: M.docWidth,
                docHeight: M.docHeight,
                screenWidth: M.screenWidth,
                screenHeight: M.screenHeight,
                scrollX: M.scrollX,
                scrollY: M.scrollY,
                pointerX: M.pointerX,
                pointerY: M.pointerY,
                activityTime: M.activityTime,
                scrollTime: M.scrollTime,
                pointerTime: M.pointerTime,
                moveX: M.moveX,
                moveY: M.moveY,
                moveTime: M.moveTime,
                downX: M.downX,
                downY: M.downY,
                downTime: M.downTime,
                upX: M.upX,
                upY: M.upY,
                upTime: M.upTime,
                pointerPrevX: M.pointerPrevX,
                pointerPrevY: M.pointerPrevY,
                pointerPrevTime: M.pointerPrevTime
            }
        }), M = M || {
            visible: 1,
            docWidth: 0,
            docHeight: 0,
            screenWidth: 0,
            screenHeight: 0,
            scrollX: 0,
            scrollY: 0,
            pointerX: 0,
            pointerY: 0,
            activityTime: 0,
            scrollTime: 0,
            pointerTime: void 0,
            moveX: void 0,
            moveY: void 0,
            moveTime: void 0,
            downX: void 0,
            downY: void 0,
            downTime: void 0,
            upX: void 0,
            upY: void 0,
            upTime: void 0,
            pointerPrevX: void 0,
            pointerPrevY: void 0,
            pointerPrevTime: void 0
        }
    }

    function C(t, e, n, a) {
        switch (t) {
            case 8:
                M.docWidth = e, M.docHeight = n;
                break;
            case 11:
                M.screenWidth = e, M.screenHeight = n;
                break;
            case 10:
                M.scrollX = e, M.scrollY = n, M.scrollTime = a;
                break;
            case 12:
                M.moveX = e, M.moveY = n, M.moveTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            case 13:
                M.downX = e, M.downY = n, M.downTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            case 14:
                M.upX = e, M.upY = n, M.upTime = a, M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a;
                break;
            default:
                M.pointerPrevX = M.pointerX, M.pointerPrevY = M.pointerY, M.pointerPrevTime = M.pointerTime, M.pointerX = e, M.pointerY = n, M.pointerTime = a
        }
        x = !0
    }

    function D(t) {
        M.activityTime = t
    }

    function P(t, e) {
        M.visible = e, M.visible || D(t), x = !0
    }

    function R() {
        x && Ai(4)
    }
    var A = Object.freeze({
            __proto__: null,
            activity: D,
            compute: R,
            reset: I,
            start: function() {
                x = !1, I()
            },
            get state() {
                return N
            },
            stop: function() {
                I()
            },
            track: C,
            visibility: P
        }),
        Y = null,
        j = !0;

    function X() {
        var t, e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics;
        if (null == e ? void 0 : e.getConsentState) {
            var n = e.getConsentState("analytics_storage");
            oo(function(t) {
                var e = {
                    ad_Storage: 1 === t.ad_Storage ? "granted" : "denied",
                    analytics_Storage: 1 === t.analytics_Storage ? "granted" : "denied"
                };
                return e
            }({
                ad_Storage: e.getConsentState("ad_storage"),
                analytics_Storage: n
            }), 2)
        }
    }

    function L(t) {
        z(t.analytics_Storage ? 1 : 0), Y = t
    }

    function W() {
        z(2)
    }

    function z(t) {
        Vi(36, t.toString())
    }

    function H(t) {
        Y = t, Ai(47)
    }

    function q() {
        j && (Ai(47), j = !1)
    }
    var U = Object.freeze({
            __proto__: null,
            compute: q,
            config: L,
            consent: W,
            get data() {
                return Y
            },
            start: function() {
                var t, e;
                j = !0, (null === (e = null === (t = window.google_tag_data) || void 0 === t ? void 0 : t.ics) || void 0 === e ? void 0 : e.addListener) && window.google_tag_data.ics.addListener(["ad_storage", "analytics_storage"], X)
            },
            stop: function() {
                j = !0
            },
            trackConsentv2: H
        }),
        F = null;

    function V(t, e) {
        Vo() && t && "string" == typeof t && t.length < 255 && (F = e && "string" == typeof e && e.length < 255 ? {
            key: t,
            value: e
        } : {
            value: t
        }, Ai(24))
    }
    var B, J = null,
        G = null;

    function K(t) {
        t in J || (J[t] = 0), t in G || (G[t] = 0), J[t]++, G[t]++
    }

    function Z(t, e) {
        null !== e && (t in J || (J[t] = 0), t in G || (G[t] = 0), J[t] += e, G[t] += e)
    }

    function Q(t, e) {
        null !== e && !1 === isNaN(e) && (t in J || (J[t] = 0), (e > J[t] || 0 === J[t]) && (G[t] = e, J[t] = e))
    }

    function $(t, e, n) {
        return window.setTimeout(Mo(t), e, n)
    }

    function tt(t) {
        return window.clearTimeout(t)
    }
    var et = 0,
        nt = 0,
        at = null;

    function rt() {
        at && tt(at), at = $(it, nt), et = d()
    }

    function it() {
        var t = d();
        B = {
            gap: t - et
        }, Ai(25), B.gap < 3e5 ? at = $(it, nt) : qo && (V("clarity", "suspend"), mu(), ["mousemove", "touchstart"].forEach((function(t) {
            return Io(document, t, Bo)
        })), ["resize", "scroll", "pageshow"].forEach((function(t) {
            return Io(window, t, Bo)
        })))
    }
    var ot = Object.freeze({
            __proto__: null,
            get data() {
                return B
            },
            reset: rt,
            start: function() {
                nt = 6e4, et = 0
            },
            stop: function() {
                tt(at), et = 0, nt = 0
            }
        }),
        ut = null;

    function ct(t, e) {
        if (t in ut) {
            var n = ut[t],
                a = n[n.length - 1];
            e - a[0] > 100 ? ut[t].push([e, 0]) : a[1] = e - a[0]
        } else ut[t] = [
            [e, 0]
        ]
    }

    function st() {
        Ai(36)
    }

    function lt() {
        ut = {}
    }
    var dt = Object.freeze({
        __proto__: null,
        compute: st,
        get data() {
            return ut
        },
        reset: lt,
        start: function() {
            ut = {}
        },
        stop: function() {
            ut = {}
        },
        track: ct
    });

    function ft(t, e, n, a) {
        return new(n || (n = Promise))((function(r, i) {
            function o(t) {
                try {
                    c(a.next(t))
                } catch (t) {
                    i(t)
                }
            }

            function u(t) {
                try {
                    c(a.throw(t))
                } catch (t) {
                    i(t)
                }
            }

            function c(t) {
                var e;
                t.done ? r(t.value) : (e = t.value, e instanceof n ? e : new n((function(t) {
                    t(e)
                }))).then(o, u)
            }
            c((a = a.apply(t, e || [])).next())
        }))
    }

    function pt(t, e) {
        var n, a, r, i, o = {
            label: 0,
            sent: function() {
                if (1 & r[0]) throw r[1];
                return r[1]
            },
            trys: [],
            ops: []
        };
        return i = {
            next: u(0),
            throw: u(1),
            return: u(2)
        }, "function" == typeof Symbol && (i[Symbol.iterator] = function() {
            return this
        }), i;

        function u(u) {
            return function(c) {
                return function(u) {
                    if (n) throw new TypeError("Generator is already executing.");
                    for (; i && (i = 0, u[0] && (o = 0)), o;) try {
                        if (n = 1, a && (r = 2 & u[0] ? a.return : u[0] ? a.throw || ((r = a.return) && r.call(a), 0) : a.next) && !(r = r.call(a, u[1])).done) return r;
                        switch (a = 0, r && (u = [2 & u[0], r.value]), u[0]) {
                            case 0:
                            case 1:
                                r = u;
                                break;
                            case 4:
                                return o.label++, {
                                    value: u[1],
                                    done: !1
                                };
                            case 5:
                                o.label++, a = u[1], u = [0];
                                continue;
                            case 7:
                                u = o.ops.pop(), o.trys.pop();
                                continue;
                            default:
                                if (!(r = o.trys, (r = r.length > 0 && r[r.length - 1]) || 6 !== u[0] && 2 !== u[0])) {
                                    o = 0;
                                    continue
                                }
                                if (3 === u[0] && (!r || u[1] > r[0] && u[1] < r[3])) {
                                    o.label = u[1];
                                    break
                                }
                                if (6 === u[0] && o.label < r[1]) {
                                    o.label = r[1], r = u;
                                    break
                                }
                                if (r && o.label < r[2]) {
                                    o.label = r[2], o.ops.push(u);
                                    break
                                }
                                r[2] && o.ops.pop(), o.trys.pop();
                                continue
                        }
                        u = e.call(t, o)
                    } catch (t) {
                        u = [6, t], a = 0
                    } finally {
                        n = r = 0
                    }
                    if (5 & u[0]) throw u[1];
                    return {
                        value: u[0] ? u[1] : void 0,
                        done: !0
                    }
                }([u, c])
            }
        }
    }
    var ht = "CompressionStream" in window;

    function vt(t) {
        return ft(this, void 0, void 0, (function() {
            var e, n;
            return pt(this, (function(a) {
                switch (a.label) {
                    case 0:
                        return a.trys.push([0, 3, , 4]), ht ? (e = new ReadableStream({
                            start: function(e) {
                                return ft(this, void 0, void 0, (function() {
                                    return pt(this, (function(n) {
                                        return e.enqueue(t), e.close(), [2]
                                    }))
                                }))
                            }
                        }).pipeThrough(new TextEncoderStream).pipeThrough(new window.CompressionStream("gzip")), n = Uint8Array.bind, [4, gt(e)]) : [3, 2];
                    case 1:
                        return [2, new(n.apply(Uint8Array, [void 0, a.sent()]))];
                    case 2:
                        return [3, 4];
                    case 3:
                        return a.sent(), [3, 4];
                    case 4:
                        return [2, null]
                }
            }))
        }))
    }

    function gt(t) {
        return ft(this, void 0, void 0, (function() {
            var e, n, a, r, i;
            return pt(this, (function(o) {
                switch (o.label) {
                    case 0:
                        e = t.getReader(), n = [], a = !1, r = [], o.label = 1;
                    case 1:
                        return a ? [3, 3] : [4, e.read()];
                    case 2:
                        return i = o.sent(), a = i.done, r = i.value, a ? [2, n] : (n.push.apply(n, r), [3, 1]);
                    case 3:
                        return [2, n]
                }
            }))
        }))
    }
    var mt = null;

    function yt(t, e) {
        wt(t, "string" == typeof e ? [e] : e)
    }

    function bt(t, e, n, a) {
        return void 0 === e && (e = null), void 0 === n && (n = null), void 0 === a && (a = null), ft(this, void 0, void 0, (function() {
            var r, i;
            return pt(this, (function(o) {
                switch (o.label) {
                    case 0:
                        return i = {}, [4, Ot(t)];
                    case 1:
                        return i.userId = o.sent(), i.userHint = a || ((u = t) && u.length >= 5 ? "".concat(u.substring(0, 2)).concat(E(u.substring(2), "*", "*")) : E(u, "*", "*")), wt("userId", [(r = i).userId]), wt("userHint", [r.userHint]), wt("userType", [Et(t)]), e && (wt("sessionId", [e]), r.sessionId = e), n && (wt("pageId", [n]), r.pageId = n), [2, r]
                }
                var u
            }))
        }))
    }

    function wt(t, e) {
        if (Vo() && t && e && "string" == typeof t && t.length < 255) {
            for (var n = (t in mt ? mt[t] : []), a = 0; a < e.length; a++) "string" == typeof e[a] && e[a].length < 255 && n.push(e[a]);
            mt[t] = n
        }
    }

    function St() {
        Ai(34)
    }

    function kt() {
        mt = {}
    }

    function Ot(t) {
        return ft(this, void 0, void 0, (function() {
            var e;
            return pt(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return n.trys.push([0, 4, , 5]), crypto && t ? [4, crypto.subtle.digest("SHA-256", (new TextEncoder).encode(t))] : [3, 2];
                    case 1:
                        return e = n.sent(), [2, Array.prototype.map.call(new Uint8Array(e), (function(t) {
                            return ("00" + t.toString(16)).slice(-2)
                        })).join("")];
                    case 2:
                        return [2, ""];
                    case 3:
                        return [3, 5];
                    case 4:
                        return n.sent(), [2, ""];
                    case 5:
                        return [2]
                }
            }))
        }))
    }

    function Et(t) {
        return t && t.indexOf("@") > 0 ? "email" : "string"
    }
    var Tt = Object.freeze({
            __proto__: null,
            compute: St,
            get data() {
                return mt
            },
            identify: bt,
            reset: kt,
            set: yt,
            start: function() {
                kt()
            },
            stop: function() {
                kt()
            }
        }),
        _t = {},
        Nt = new Set,
        Mt = {},
        xt = {},
        It = {},
        Ct = {};

    function Dt(t) {
        try {
            var e = t && t.length > 0 ? t.split(/ (.*)/) : [""],
                n = e[0].split(/\|(.*)/),
                a = parseInt(n[0]),
                r = n.length > 1 ? n[1] : "",
                i = e.length > 1 ? JSON.parse(e[1]) : {};
            for (var o in Mt[a] = {}, xt[a] = {}, It[a] = {}, Ct[a] = r, i) {
                var u = parseInt(o),
                    c = i[o],
                    s = 2;
                switch (c.startsWith("~") ? s = 0 : c.startsWith("!") && (s = 4), s) {
                    case 0:
                        var l = c.slice(1);
                        Mt[a][u] = jt(l);
                        break;
                    case 2:
                        xt[a][u] = c;
                        break;
                    case 4:
                        var d = c.slice(1);
                        It[a][u] = d
                }
            }
        } catch (t) {
            di(8, 1, t ? t.name : null)
        }
    }

    function Pt(t) {
        return JSON.parse(JSON.stringify(t))
    }

    function Rt() {
        try {
            for (var t in Mt) {
                var e = parseInt(t);
                if ("" == Ct[e] || document.querySelector(Ct[e])) {
                    var n = Mt[e];
                    for (var a in n) {
                        var r = parseInt(a),
                            i = (m = Xt(Pt(n[r]))) ? JSON.stringify(m).slice(0, 1e4) : m;
                        i && Yt(e, r, i)
                    }
                    var o = xt[e];
                    for (var u in o) {
                        var c = !1,
                            s = parseInt(u),
                            l = o[s];
                        l.startsWith("@") && (c = !0, l = l.slice(1));
                        var d = document.querySelectorAll(l);
                        if (d) {
                            var f = Array.from(d).map((function(t) {
                                return t.textContent
                            })).join("<SEP>");
                            Yt(e, s, (c ? p(f).trim() : f).slice(0, 1e4))
                        }
                    }
                    var h = It[e];
                    for (var v in h) {
                        var g = parseInt(v);
                        Yt(e, g, tr(h[g]).trim().slice(0, 1e4))
                    }
                }
            }
            Nt.size > 0 && Ai(40)
        } catch (t) {
            di(5, 1, t ? t.name : null)
        }
        var m
    }

    function At() {
        Nt.clear()
    }

    function Yt(t, e, n) {
        var a, r = !1;
        t in _t || (_t[t] = {}, r = !0), a = It[t], 0 == Object.keys(a).length || e in _t[t] && _t[t][e] == n || (r = !0), _t[t][e] = n, r && Nt.add(t)
    }

    function jt(t) {
        for (var e = [], n = t.split("."); n.length > 0;) {
            var a = n.shift(),
                r = a.indexOf("["),
                i = a.indexOf("{"),
                o = a.indexOf("}");
            e.push({
                name: r > 0 ? a.slice(0, r) : i > 0 ? a.slice(0, i) : a,
                type: r > 0 ? 1 : i > 0 ? 2 : 3,
                condition: i > 0 ? a.slice(i + 1, o) : null
            })
        }
        return e
    }

    function Xt(t, e) {
        if (void 0 === e && (e = window), 0 == t.length) return e;
        var n, a = t.shift();
        if (e && e[a.name]) {
            var r = e[a.name];
            if (1 !== a.type && Lt(r, a.condition)) n = Xt(t, r);
            else if (Array.isArray(r)) {
                for (var i = [], o = 0, u = r; o < u.length; o++) {
                    var c = u[o];
                    if (Lt(c, a.condition)) {
                        var s = Xt(t, c);
                        s && i.push(s)
                    }
                }
                n = i
            }
            return n
        }
        return null
    }

    function Lt(t, e) {
        if (e) {
            var n = e.split(":");
            return n.length > 1 ? t[n[0]] == n[1] : t[n[0]]
        }
        return !0
    }
    var Wt = null;

    function zt(t) {
        try {
            if (!Wt) return;
            var e = function(t) {
                try {
                    return JSON.parse(t)
                } catch (t) {
                    return []
                }
            }(t);
            e.forEach((function(t) {
                Wt(t)
            }))
        } catch (t) {}
    }
    var Ht = [A, r, Tt, a, dt, U, i, o, e, ot, n, Object.freeze({
        __proto__: null,
        clone: Pt,
        compute: Rt,
        data: _t,
        keys: Nt,
        reset: At,
        start: function() {
            At()
        },
        stop: function() {
            At()
        },
        trigger: Dt,
        update: Yt
    })];

    function qt() {
        J = {}, G = {}, K(5), Ht.forEach((function(t) {
            return Mo(t.start)()
        }))
    }

    function Ut() {
        Ht.slice().reverse().forEach((function(t) {
            return Mo(t.stop)()
        })), J = {}, G = {}
    }

    function Ft() {
        St(), R(), Bi(), Ai(0), st(), Li(), Rt(), q()
    }
    var Vt, Bt = [];

    function Jt(t, e, n) {
        u.fraud && null !== t && n && n.length >= 5 && (Vt = {
            id: t,
            target: e,
            checksum: p(n, 28)
        }, Bt.indexOf(Vt.checksum) < 0 && (Bt.push(Vt.checksum), ci(41)))
    }
    var Gt = [];

    function Kt(t) {
        var e = Or(t);
        if (e) {
            var n = e.value,
                a = n && n.length >= 5 && u.fraud && -1 === "password,secret,pass,social,ssn,code,hidden".indexOf(e.type) ? p(n, 28) : "";
            Gt.push({
                time: d(t),
                event: 42,
                data: {
                    target: Or(t),
                    type: e.type,
                    value: n,
                    checksum: a
                }
            }), bi(Tr.bind(this, 42))
        }
    }

    function Zt() {
        Gt = []
    }

    function Qt(t) {
        var e = {
            x: 0,
            y: 0
        };
        if (t && t.offsetParent)
            do {
                var n = t.offsetParent,
                    a = null === n ? Ga(t.ownerDocument) : null;
                e.x += t.offsetLeft, e.y += t.offsetTop, t = a || n
            } while (t);
        return e
    }
    var $t = ["input", "textarea", "radio", "button", "canvas", "select"],
        te = [];

    function ee(t, e, n) {
        var a = Ga(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = Qt(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        var c = Or(n),
            s = function(t) {
                for (; t && t !== document;) {
                    if (t.nodeType === Node.ELEMENT_NODE) {
                        var e = t;
                        if ("A" === e.tagName) return e
                    }
                    t = t.parentNode
                }
                return null
            }(c),
            l = function(t) {
                var e = null,
                    n = document.documentElement;
                if ("function" == typeof t.getBoundingClientRect) {
                    var a = t.getBoundingClientRect();
                    a && a.width > 0 && a.height > 0 && (e = {
                        x: Math.floor(a.left + ("pageXOffset" in window ? window.pageXOffset : n.scrollLeft)),
                        y: Math.floor(a.top + ("pageYOffset" in window ? window.pageYOffset : n.scrollTop)),
                        w: Math.floor(a.width),
                        h: Math.floor(a.height)
                    })
                }
                return e
            }(c);
        0 === n.detail && l && (i = Math.round(l.x + l.w / 2), o = Math.round(l.y + l.h / 2));
        var f = l ? Math.max(Math.floor((i - l.x) / l.w * 32767), 0) : 0,
            p = l ? Math.max(Math.floor((o - l.y) / l.h * 32767), 0) : 0;
        if (null !== i && null !== o) {
            var h = function(t) {
                var e = null,
                    n = !1;
                if (t) {
                    var a = t.textContent || String(t.value || "") || t.alt;
                    if (a) {
                        var r = a.replace(/\s+/g, " ").trim();
                        n = (e = r.substring(0, 25)).length === r.length
                    }
                }
                return {
                    text: e,
                    isFullText: n ? 1 : 0
                }
            }(c);
            te.push({
                time: d(n),
                event: t,
                data: {
                    target: c,
                    x: i,
                    y: o,
                    eX: f,
                    eY: p,
                    button: n.button,
                    reaction: ne(c),
                    context: ae(s),
                    text: h.text,
                    link: s ? s.href : null,
                    hash: null,
                    trust: n.isTrusted ? 1 : 0,
                    isFullText: h.isFullText
                }
            }), bi(Tr.bind(this, t))
        }
    }

    function ne(t) {
        if (t.nodeType === Node.ELEMENT_NODE) {
            var e = t.tagName.toLowerCase();
            if ($t.indexOf(e) >= 0) return 0
        }
        return 1
    }

    function ae(t) {
        if (t && t.hasAttribute("target")) switch (t.getAttribute("target")) {
            case "_blank":
                return 1;
            case "_parent":
                return 2;
            case "_top":
                return 3
        }
        return 0
    }

    function re() {
        te = []
    }
    var ie = [];

    function oe(t, e) {
        ie.push({
            time: d(e),
            event: 38,
            data: {
                target: Or(e),
                action: t
            }
        }), bi(Tr.bind(this, 38))
    }

    function ue() {
        ie = []
    }
    var ce = null,
        se = [];

    function le(t) {
        var e = Or(t),
            n = ar(e);
        if (e && e.type && n) {
            var a = e.value,
                r = e.type;
            switch (e.type) {
                case "radio":
                case "checkbox":
                    a = e.checked ? "true" : "false"
            }
            var i = {
                target: e,
                value: a,
                type: r,
                trust: t.isTrusted ? 1 : 0
            };
            se.length > 0 && se[se.length - 1].data.target === i.target && se.pop(), se.push({
                time: d(t),
                event: 27,
                data: i
            }), tt(ce), ce = $(de, 1e3, 27)
        }
    }

    function de(t) {
        bi(Tr.bind(this, t))
    }

    function fe() {
        se = []
    }
    var pe, he = [],
        ve = null,
        ge = !1,
        me = 0,
        ye = new Set;

    function be(t, e, n) {
        var a = Ga(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = "pageX" in n ? Math.round(n.pageX) : "clientX" in n ? Math.round(n.clientX + r.scrollLeft) : null,
            o = "pageY" in n ? Math.round(n.pageY) : "clientY" in n ? Math.round(n.clientY + r.scrollTop) : null;
        if (a) {
            var u = Qt(a);
            i = i ? i + Math.round(u.x) : i, o = o ? o + Math.round(u.y) : o
        }
        null !== i && null !== o && Se({
            time: d(n),
            event: t,
            data: {
                target: Or(n),
                x: i,
                y: o
            }
        })
    }

    function we(t, e, n) {
        var a = Ga(e),
            r = a && a.contentDocument ? a.contentDocument.documentElement : document.documentElement,
            i = n.changedTouches,
            o = d(n);
        if (i)
            for (var u = 0; u < i.length; u++) {
                var c = i[u],
                    s = "clientX" in c ? Math.round(c.clientX + r.scrollLeft) : null,
                    l = "clientY" in c ? Math.round(c.clientY + r.scrollTop) : null;
                s = s && a ? s + Math.round(a.offsetLeft) : s, l = l && a ? l + Math.round(a.offsetTop) : l;
                var f = "identifier" in c ? c.identifier : void 0;
                switch (t) {
                    case 17:
                        0 === ye.size && (ge = !0, me = f), ye.add(f);
                        break;
                    case 18:
                    case 20:
                        ye.delete(f)
                }
                var p = ge && me === f;
                null !== s && null !== l && Se({
                    time: o,
                    event: t,
                    data: {
                        target: Or(n),
                        x: s,
                        y: l,
                        id: f,
                        isPrimary: p
                    }
                }), 20 !== t && 18 !== t || me === f && (ge = !1)
            }
    }

    function Se(t) {
        switch (t.event) {
            case 12:
            case 15:
            case 19:
                var e = he.length,
                    n = e > 1 ? he[e - 2] : null;
                n && function(t, e) {
                    var n = t.data.x - e.data.x,
                        a = t.data.y - e.data.y,
                        r = Math.sqrt(n * n + a * a),
                        i = e.time - t.time,
                        o = e.data.target === t.data.target,
                        u = void 0 === e.data.id || e.data.id === t.data.id;
                    return e.event === t.event && o && r < 20 && i < 25 && u
                }(n, t) && he.pop(), he.push(t), tt(ve), ve = $(ke, 500, t.event);
                break;
            default:
                he.push(t), ke(t.event)
        }
    }

    function ke(t) {
        bi(Tr.bind(this, t))
    }

    function Oe() {
        he = []
    }

    function Ee(t, e) {
        var n = 0,
            a = null,
            r = null;

        function i() {
            for (var i = this, o = [], u = 0; u < arguments.length; u++) o[u] = arguments[u];
            var c = performance.now(),
                s = c - n;
            if (0 !== n && s < e) {
                if (r = o, a) return;
                a = setTimeout((function() {
                    n = performance.now(), t.apply(i, r), r = null, a = null
                }), e - s)
            } else n = c, t.apply(this, o)
        }
        return i.cleanup = function() {
            a && (clearTimeout(a), a = null, r = null)
        }, i
    }
    var Te = null,
        _e = !1,
        Ne = Ee(Me, 500);

    function Me() {
        var t = document.documentElement;
        pe = {
            width: t && "clientWidth" in t ? Math.min(t.clientWidth, window.innerWidth) : window.innerWidth,
            height: t && "clientHeight" in t ? Math.min(t.clientHeight, window.innerHeight) : window.innerHeight
        }, _e ? (tt(Te), Te = $(xe, 500, 11)) : (Tr(11), _e = !0)
    }

    function xe(t) {
        bi(Tr.bind(this, t))
    }

    function Ie() {
        pe = null, tt(Te), Ne.cleanup()
    }
    var Ce = [],
        De = null,
        Pe = null,
        Re = null;

    function Ae(t) {
        void 0 === t && (t = null);
        var e = window,
            n = document.documentElement,
            a = t ? Or(t) : n;
        if (a) {
            if (a && a.nodeType === Node.DOCUMENT_NODE) {
                var r = Ga(a);
                e = r ? r.contentWindow : e, a = n = a.documentElement
            }
            var i = a === n && "pageXOffset" in e ? Math.round(e.pageXOffset) : Math.round(a.scrollLeft),
                o = a === n && "pageYOffset" in e ? Math.round(e.pageYOffset) : Math.round(a.scrollTop),
                u = window.innerWidth,
                c = window.innerHeight,
                s = u / 3,
                l = u > c ? .15 * c : .2 * c,
                f = c - l,
                p = je(s, l),
                h = je(s, f),
                v = {
                    time: d(t),
                    event: 10,
                    data: {
                        target: a,
                        x: i,
                        y: o,
                        top: p,
                        bottom: h
                    }
                };
            if (null === t && 0 === i && 0 === o || null === i || null === o) return De = p, void(Pe = h);
            var g = Ce.length,
                m = g > 1 ? Ce[g - 2] : null;
            m && function(t, e) {
                var n = t.data.x - e.data.x,
                    a = t.data.y - e.data.y;
                return n * n + a * a < 400 && e.time - t.time < 50
            }(m, v) && Ce.pop(), Ce.push(v), tt(Re), Re = $(Xe, 500, 10)
        }
    }
    var Ye = Ee(Ae, 25);

    function je(t, e) {
        var n, a, r;
        return "caretPositionFromPoint" in document ? r = null === (n = document.caretPositionFromPoint(t, e)) || void 0 === n ? void 0 : n.offsetNode : "caretRangeFromPoint" in document && (r = null === (a = document.caretRangeFromPoint(t, e)) || void 0 === a ? void 0 : a.startContainer), r || (r = document.elementFromPoint(t, e)), r && r.nodeType === Node.TEXT_NODE && (r = r.parentNode), r
    }

    function Xe(t) {
        bi(Tr.bind(this, t))
    }

    function Le() {
        var t, e;
        if (De) {
            var n = Er(De, null);
            Vi(31, null === (t = null == n ? void 0 : n.hash) || void 0 === t ? void 0 : t.join("."))
        }
        if (Pe) {
            var a = Er(Pe, null);
            Vi(32, null === (e = null == a ? void 0 : a.hash) || void 0 === e ? void 0 : e.join("."))
        }
    }
    var We = null,
        ze = null,
        He = null;

    function qe(t) {
        var e = (t.nodeType === Node.DOCUMENT_NODE ? t : document).getSelection();
        if (null !== e && !(null === e.anchorNode && null === e.focusNode || e.anchorNode === e.focusNode && e.anchorOffset === e.focusOffset)) {
            var n = We.start ? We.start : null;
            null !== ze && null !== We.start && n !== e.anchorNode && (tt(He), Ue(21)), We = {
                start: e.anchorNode,
                startOffset: e.anchorOffset,
                end: e.focusNode,
                endOffset: e.focusOffset
            }, ze = e, tt(He), He = $(Ue, 500, 21)
        }
    }

    function Ue(t) {
        bi(Tr.bind(this, t))
    }

    function Fe() {
        ze = null, We = {
            start: 0,
            startOffset: 0,
            end: 0,
            endOffset: 0
        }
    }
    var Ve, Be, Je, Ge = [];

    function Ke(t) {
        Ge.push({
            time: d(t),
            event: 39,
            data: {
                target: Or(t)
            }
        }), bi(Tr.bind(this, 39))
    }

    function Ze() {
        Ge = []
    }

    function Qe(t) {
        Ve = {
            name: t.type,
            persisted: t.persisted ? 1 : 0
        }, Tr(26, d(t)), mu()
    }

    function $e() {
        Ve = null
    }

    function tn(t) {
        if (void 0 === t && (t = null), "visibilityState" in document) {
            var e = "visible" === document.visibilityState ? 1 : 0;
            Be = {
                visible: e
            }, Tr(28, d(t))
        }
    }

    function en() {
        Be = null
    }

    function nn() {
        Je = null
    }

    function an(t) {
        Je = {
            focused: t
        }, Tr(50)
    }

    function rn(t) {
        ! function(t) {
            var e = Ga(t);
            Io(e ? e.contentWindow : t === document ? window : t, "scroll", Ye, !0)
        }(t), t.nodeType === Node.DOCUMENT_NODE && (function(t) {
            Io(t, "click", ee.bind(this, 9, t), !0), Io(t, "contextmenu", ee.bind(this, 48, t), !0)
        }(t), function(t) {
            Io(t, "cut", oe.bind(this, 0), !0), Io(t, "copy", oe.bind(this, 1), !0), Io(t, "paste", oe.bind(this, 2), !0)
        }(t), function(t) {
            Io(t, "mousedown", be.bind(this, 13, t), !0), Io(t, "mouseup", be.bind(this, 14, t), !0), Io(t, "mousemove", be.bind(this, 12, t), !0), Io(t, "wheel", be.bind(this, 15, t), !0), Io(t, "dblclick", be.bind(this, 16, t), !0), Io(t, "touchstart", we.bind(this, 17, t), !0), Io(t, "touchend", we.bind(this, 18, t), !0), Io(t, "touchmove", we.bind(this, 19, t), !0), Io(t, "touchcancel", we.bind(this, 20, t), !0)
        }(t), function(t) {
            Io(t, "input", le, !0)
        }(t), function(t) {
            Io(t, "selectstart", qe.bind(this, t), !0), Io(t, "selectionchange", qe.bind(this, t), !0)
        }(t), function(t) {
            Io(t, "change", Kt, !0)
        }(t), function(t) {
            Io(t, "submit", Ke, !0)
        }(t))
    }
    var on = Object.freeze({
        __proto__: null,
        observe: rn,
        start: function() {
            _r = [], Mr(), re(), ue(), Oe(), fe(), _e = !1, Io(window, "resize", Ne), Me(), Io(document, "visibilitychange", tn), tn(), Io(window, "focus", (function() {
                return an(1)
            })), Io(window, "blur", (function() {
                return an(0)
            })), Ce = [], Ae(), Fe(), Zt(), Ze(), Io(window, "pagehide", Qe)
        },
        stop: function() {
            _r = [], Mr(), re(), ue(), tt(ve), he.length > 0 && ke(he[he.length - 1].event), tt(ce), fe(), Ie(), en(), nn(), tt(Re), Ye.cleanup(), Ce = [], De = null, Pe = null, Fe(), tt(He), Zt(), Ze(), $e()
        }
    });

    function un(t) {
        for (var e = [], n = {}, a = 0, r = null, i = 0; i < t.length; i++)
            if ("string" == typeof t[i]) {
                var o = t[i],
                    u = n[o] || -1;
                u >= 0 ? r ? r.push(u) : (r = [u], e.push(r), a++) : (r = null, e.push(o), n[o] = a++)
            } else r = null, e.push(t[i]), a++;
        return e
    }
    var cn = [],
        sn = [],
        ln = "claritySheetId",
        dn = {},
        fn = {},
        pn = [],
        hn = [];

    function vn(t) {
        u.lean && u.lite || null == t || (t.clarityOverrides = t.clarityOverrides || {}, t.CSSStyleSheet && t.CSSStyleSheet.prototype && (void 0 === t.clarityOverrides.replace && (t.clarityOverrides.replace = t.CSSStyleSheet.prototype.replace, t.CSSStyleSheet.prototype.replace = function() {
            return Vo() && hn.indexOf(this[ln]) > -1 && bn(d(), this[ln], 1, arguments[0]), t.clarityOverrides.replace.apply(this, arguments)
        }), void 0 === t.clarityOverrides.replaceSync && (t.clarityOverrides.replaceSync = t.CSSStyleSheet.prototype.replaceSync, t.CSSStyleSheet.prototype.replaceSync = function() {
            return Vo() && hn.indexOf(this[ln]) > -1 && bn(d(), this[ln], 2, arguments[0]), t.clarityOverrides.replaceSync.apply(this, arguments)
        })))
    }

    function gn() {
        vn(window)
    }

    function mn(t, e) {
        if ((!u.lean || !u.lite) && (-1 === pn.indexOf(t) && (pn.push(t), t.defaultView && vn(t.defaultView)), e = e || d(), null == t ? void 0 : t.adoptedStyleSheets)) {
            for (var n = [], a = 0, r = t.adoptedStyleSheets; a < r.length; a++) {
                var i = r[a];
                i[ln] && -1 !== hn.indexOf(i[ln]) || (i[ln] = vo(), hn.push(i[ln]), bn(e, i[ln], 0), bn(e, i[ln], 2, wa(i))), n.push(i[ln])
            }
            var o = Fa(t, !0);
            dn[o] || (dn[o] = []),
                function(t, e) {
                    if (t.length !== e.length) return !1;
                    return t.every((function(t, n) {
                        return t === e[n]
                    }))
                }(n, dn[o]) || (! function(t, e, n, a) {
                    sn.push({
                        time: t,
                        event: 45,
                        data: {
                            id: e,
                            operation: n,
                            newIds: a
                        }
                    }), Ln(45)
                }(e, t == document ? -1 : Fa(t), 3, n), dn[o] = n, fn[o] = e)
        }
    }

    function yn() {
        sn = [], cn = []
    }

    function bn(t, e, n, a) {
        cn.push({
            time: t,
            event: 46,
            data: {
                id: e,
                operation: n,
                cssRules: a
            }
        }), Ln(46)
    }
    var wn = [],
        Sn = null,
        kn = null,
        On = null,
        En = null,
        Tn = null,
        _n = null,
        Nn = "clarityAnimationId",
        Mn = "clarityOperationCount",
        xn = 20;

    function In() {
        wn = []
    }

    function Cn(t, e, n, a, r, i, o) {
        wn.push({
            time: t,
            event: 44,
            data: {
                id: e,
                operation: n,
                keyFrames: a,
                timing: r,
                targetId: i,
                timeline: o
            }
        }), Ln(44)
    }

    function Dn(t, e) {
        null === t && (t = Animation.prototype[e], Animation.prototype[e] = function() {
            return Pn(this, e), t.apply(this, arguments)
        })
    }

    function Pn(t, e) {
        if (Vo()) {
            var n = t.effect,
                a = (null == n ? void 0 : n.target) ? Fa(n.target) : null;
            if (null !== a && n.getKeyframes && n.getTiming) {
                if (!t[Nn]) {
                    t[Nn] = vo(), t[Mn] = 0;
                    var r = n.getKeyframes(),
                        i = n.getTiming();
                    Cn(d(), t[Nn], 0, JSON.stringify(r), JSON.stringify(i), a)
                }
                if (t[Mn]++ < xn) {
                    var o = null;
                    switch (e) {
                        case "play":
                            o = 1;
                            break;
                        case "pause":
                            o = 2;
                            break;
                        case "cancel":
                            o = 3;
                            break;
                        case "finish":
                            o = 4;
                            break;
                        case "commitStyles":
                            o = 5
                    }
                    o && Cn(d(), t[Nn], o)
                }
            }
        }
    }
    var Rn, An = [],
        Yn = new Set;

    function jn(t) {
        Yn.has(t) || (Yn.add(t), An.push(t), bi(Ln.bind(this, 51)))
    }

    function Xn() {
        An.length = 0
    }

    function Ln(t, e, n) {
        return void 0 === e && (e = null), void 0 === n && (n = null), ft(this, void 0, void 0, (function() {
            var a, r, i, o, c, s, l, f, p, h, v, g, m, y, b, S, k, O, E, T, _, N, M, x, I, P, R, A, Y, j, X, L;
            return pt(this, (function(W) {
                switch (W.label) {
                    case 0:
                        switch (a = n || d(), r = [a, t], t) {
                            case 8:
                                return [3, 1];
                            case 7:
                                return [3, 2];
                            case 45:
                            case 46:
                                return [3, 3];
                            case 44:
                                return [3, 4];
                            case 5:
                            case 6:
                                return [3, 5];
                            case 51:
                                return [3, 12]
                        }
                        return [3, 13];
                    case 1:
                        return i = Rn, r.push(i.width), r.push(i.height), C(t, i.width, i.height), $r(r), [3, 13];
                    case 2:
                        for (o = 0, c = lr; o < c.length; o++) s = c[o], (r = [s.time, 7]).push(s.data.id), r.push(s.data.interaction), r.push(s.data.visibility), r.push(s.data.name), $r(r, !1);
                        return kr(), [3, 13];
                    case 3:
                        for (l = 0, f = sn; l < f.length; l++) m = f[l], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.newIds), $r(r);
                        for (p = 0, h = cn; p < h.length; p++) m = h[p], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.cssRules), $r(r, !1);
                        return yn(), [3, 13];
                    case 4:
                        for (v = 0, g = wn; v < g.length; v++) m = g[v], (r = [m.time, m.event]).push(m.data.id), r.push(m.data.operation), r.push(m.data.keyFrames), r.push(m.data.timing), r.push(m.data.timeline), r.push(m.data.targetId), $r(r);
                        return In(), [3, 13];
                    case 5:
                        if (2 === Si(e)) return [3, 13];
                        if (!((y = or()).length > 0)) return [3, 11];
                        b = 0, S = y, W.label = 6;
                    case 6:
                        return b < S.length ? (k = S[b], 0 !== (O = Si(e)) ? [3, 8] : [4, Ei(e)]) : [3, 10];
                    case 7:
                        O = W.sent(), W.label = 8;
                    case 8:
                        if (2 === O) return [3, 10];
                        for (E = k.data, T = k.metadata.active, _ = k.metadata.suspend, N = k.metadata.privacy, M = function(t) {
                                var e = t.metadata.privacy;
                                return "*T" === t.data.tag && !(0 === e || 1 === e)
                            }(k), x = 0, I = T ? ["tag", "attributes", "value"] : ["tag"]; x < I.length; x++)
                            if (E[P = I[x]] || "" === E[P]) switch (P) {
                                case "tag":
                                    R = Wn(k), A = M ? -1 : 1, r.push(k.id * A), k.parent && T && (r.push(k.parent), k.previous && r.push(k.previous)), r.push(_ ? "*M" : E[P]), R && 2 === R.length && r.push("".concat("#").concat(zn(R[0]), ".").concat(zn(R[1])));
                                    break;
                                case "attributes":
                                    for (Y in E[P]) void 0 !== E[P][Y] && r.push(Hn(Y, E[P][Y], N));
                                    break;
                                case "value":
                                    Jt(k.metadata.fraud, k.id, E[P]), r.push(w(E[P], E.tag, N, M))
                            }
                        W.label = 9;
                    case 9:
                        return b++, [3, 6];
                    case 10:
                        6 === t && D(a), $r(un(r), !u.lean), W.label = 11;
                    case 11:
                        return [3, 13];
                    case 12:
                        for (j = 0, X = An; j < X.length; j++) L = X[j], $r([a, 51, L]);
                        return Xn(), [3, 13];
                    case 13:
                        return [2]
                }
            }))
        }))
    }

    function Wn(t) {
        if (null !== t.metadata.size && 0 === t.metadata.size.length) {
            var e = er(t.id);
            if (e) return [Math.floor(100 * e.offsetWidth), Math.floor(100 * e.offsetHeight)]
        }
        return t.metadata.size
    }

    function zn(t) {
        return t.toString(36)
    }

    function Hn(t, e, n) {
        return "".concat(t, "=").concat(w(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }

    function qn() {
        Rn = null
    }

    function Un() {
        var t = document.body,
            e = document.documentElement,
            n = t ? t.clientWidth : null,
            a = t ? t.scrollWidth : null,
            r = t ? t.offsetWidth : null,
            i = e ? e.clientWidth : null,
            o = e ? e.scrollWidth : null,
            u = e ? e.offsetWidth : null,
            c = Math.max(n, a, r, i, o, u),
            s = t ? t.clientHeight : null,
            l = t ? t.scrollHeight : null,
            d = t ? t.offsetHeight : null,
            f = e ? e.clientHeight : null,
            p = e ? e.scrollHeight : null,
            h = e ? e.offsetHeight : null,
            v = Math.max(s, l, d, f, p, h);
        null !== Rn && c === Rn.width && v === Rn.height || null === c || null === v || (Rn = {
            width: c,
            height: v
        }, Ln(8))
    }

    function Fn(t, e, n, a) {
        return ft(this, void 0, void 0, (function() {
            var r, i, o, u, c;
            return pt(this, (function(s) {
                switch (s.label) {
                    case 0:
                        r = [t], s.label = 1;
                    case 1:
                        if (!(r.length > 0)) return [3, 4];
                        for (i = r.shift(), o = i.firstChild; o;) r.push(o), o = o.nextSibling;
                        return 0 !== (u = Si(e)) ? [3, 3] : [4, Ei(e)];
                    case 2:
                        u = s.sent(), s.label = 3;
                    case 3:
                        return 2 === u ? [3, 4] : ((c = ga(i, n, a)) && r.push(c), [3, 1]);
                    case 4:
                        return [2]
                }
            }))
        }))
    }
    var Vn = new Set,
        Bn = [],
        Jn = {},
        Gn = [],
        Kn = null,
        Zn = null,
        Qn = null,
        $n = {},
        ta = new WeakMap,
        ea = ["data-google-query-id", "data-load-complete", "data-google-container-id"];

    function na() {
        Vn = new Set, Gn = [], Kn = null, Qn = 0, $n = {}, ta = new WeakMap, la(window)
    }

    function aa(t) {
        var e = d();
        ct(6, e), Bn.push({
            time: e,
            mutations: t
        }), bi(ia, 1).then((function() {
            $(Un), Mo(yr)()
        }))
    }

    function ra(t, e, n, a) {
        return ft(this, void 0, void 0, (function() {
            var r, i, o;
            return pt(this, (function(c) {
                switch (c.label) {
                    case 0:
                        return 0 !== (r = Si(t)) ? [3, 2] : [4, Ei(t)];
                    case 1:
                        r = c.sent(), c.label = 2;
                    case 2:
                        if (2 === r) return [2];
                        switch (i = e.target, o = u.throttleDom ? function(t, e, n, a) {
                            var r = t.target ? ar(t.target.parentNode) : null;
                            if (r && "HTML" !== r.data.tag) {
                                var i = a > Qn,
                                    o = ar(t.target),
                                    u = o && o.selector ? o.selector.join() : t.target.nodeName,
                                    c = [r.selector ? r.selector.join() : "", u, t.attributeName, oa(t.addedNodes), oa(t.removedNodes)].join();
                                $n[c] = c in $n ? $n[c] : [0, n];
                                var s = $n[c];
                                if (!1 === i && s[0] >= 10 && ua(s[2], 2, e, a), s[0] = i ? s[1] === n ? s[0] : s[0] + 1 : 1, s[1] = n, s[0] >= 10) return s[2] = t.removedNodes, n > a + 3e3 ? t.type : (Jn[c] = {
                                    mutation: t,
                                    timestamp: a
                                }, "throttle")
                            }
                            return t.type
                        }(e, t, n, a) : e.type, o && i && i.ownerDocument && Ua(i.ownerDocument), o && i && i.nodeType == Node.DOCUMENT_FRAGMENT_NODE && i.host && Ua(i), o) {
                            case "attributes":
                                ea.indexOf(e.attributeName) < 0 && ga(i, 3, a);
                                break;
                            case "characterData":
                                ga(i, 4, a);
                                break;
                            case "childList":
                                ua(e.addedNodes, 1, t, a), ua(e.removedNodes, 2, t, a)
                        }
                        return [2]
                }
            }))
        }))
    }

    function ia() {
        return ft(this, void 0, void 0, (function() {
            var t, e, n, a, r, i, o, u, c, s, l;
            return pt(this, (function(f) {
                switch (f.label) {
                    case 0:
                        ki(t = {
                            id: ro(),
                            cost: 3
                        }), f.label = 1;
                    case 1:
                        if (!(Bn.length > 0)) return [3, 7];
                        e = Bn.shift(), n = d(), a = 0, r = e.mutations, f.label = 2;
                    case 2:
                        return a < r.length ? (i = r[a], [4, ra(t, i, n, e.time)]) : [3, 5];
                    case 3:
                        f.sent(), f.label = 4;
                    case 4:
                        return a++, [3, 2];
                    case 5:
                        return [4, Ln(6, t, e.time)];
                    case 6:
                        return f.sent(), [3, 1];
                    case 7:
                        o = !1, u = 0, c = Object.keys(Jn), f.label = 8;
                    case 8:
                        return u < c.length ? (s = c[u], l = Jn[s], delete Jn[s], [4, ra(t, l.mutation, d(), l.timestamp)]) : [3, 11];
                    case 9:
                        f.sent(), o = !0, f.label = 10;
                    case 10:
                        return u++, [3, 8];
                    case 11:
                        return Object.keys(Jn).length > 0 && function() {
                            Zn && tt(Zn);
                            Zn = $((function() {
                                bi(ia, 1)
                            }), 33)
                        }(), 0 === Object.keys(Jn).length && o ? [4, Ln(6, t, d())] : [3, 13];
                    case 12:
                        f.sent(), f.label = 13;
                    case 13:
                        return function() {
                            var t = d();
                            Object.keys($n).length > 1e4 && ($n = {}, K(38));
                            for (var e = 0, n = Object.keys($n); e < n.length; e++) {
                                var a = n[e];
                                t > $n[a][1] + 3e4 && delete $n[a]
                            }
                        }(), Oi(t), [2]
                }
            }))
        }))
    }

    function oa(t) {
        for (var e = [], n = 0; t && n < t.length; n++) e.push(t[n].nodeName);
        return e.join()
    }

    function ua(t, e, n, a) {
        return ft(this, void 0, void 0, (function() {
            var r, i, o, u;
            return pt(this, (function(c) {
                switch (c.label) {
                    case 0:
                        r = t ? t.length : 0, i = 0, c.label = 1;
                    case 1:
                        return i < r ? (o = t[i], 1 !== e ? [3, 2] : (Fn(o, n, e, a), [3, 5])) : [3, 6];
                    case 2:
                        return 0 !== (u = Si(n)) ? [3, 4] : [4, Ei(n)];
                    case 3:
                        u = c.sent(), c.label = 4;
                    case 4:
                        if (2 === u) return [3, 6];
                        ga(o, e, a), c.label = 5;
                    case 5:
                        return i++, [3, 1];
                    case 6:
                        return [2]
                }
            }))
        }))
    }

    function ca(t) {
        return Gn.indexOf(t) < 0 && Gn.push(t), Kn && tt(Kn), Kn = $((function() {
            ! function() {
                for (var t = 0, e = Gn; t < e.length; t++) {
                    var n = e[t];
                    if (n) {
                        var a = n.nodeType === Node.DOCUMENT_FRAGMENT_NODE;
                        if (a && ir(n)) continue;
                        sa(n, a ? "childList" : "characterData")
                    }
                }
                Gn = []
            }()
        }), 33), t
    }

    function sa(t, e) {
        Mo(aa)([{
            addedNodes: [t],
            attributeName: null,
            attributeNamespace: null,
            nextSibling: null,
            oldValue: null,
            previousSibling: null,
            removedNodes: [],
            target: t,
            type: e
        }])
    }

    function la(t) {
        if (null != t && (t.clarityOverrides = t.clarityOverrides || {}, void 0 === t.clarityOverrides.InsertRule && (t.clarityOverrides.InsertRule = t.CSSStyleSheet.prototype.insertRule, t.CSSStyleSheet.prototype.insertRule = function() {
                return Vo() && ca(this.ownerNode), t.clarityOverrides.InsertRule.apply(this, arguments)
            }), "CSSMediaRule" in t && void 0 === t.clarityOverrides.MediaInsertRule && (t.clarityOverrides.MediaInsertRule = t.CSSMediaRule.prototype.insertRule, t.CSSMediaRule.prototype.insertRule = function() {
                return Vo() && ca(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaInsertRule.apply(this, arguments)
            }), void 0 === t.clarityOverrides.DeleteRule && (t.clarityOverrides.DeleteRule = t.CSSStyleSheet.prototype.deleteRule, t.CSSStyleSheet.prototype.deleteRule = function() {
                return Vo() && ca(this.ownerNode), t.clarityOverrides.DeleteRule.apply(this, arguments)
            }), "CSSMediaRule" in t && void 0 === t.clarityOverrides.MediaDeleteRule && (t.clarityOverrides.MediaDeleteRule = t.CSSMediaRule.prototype.deleteRule, t.CSSMediaRule.prototype.deleteRule = function() {
                return Vo() && ca(this.parentStyleSheet.ownerNode), t.clarityOverrides.MediaDeleteRule.apply(this, arguments)
            }), void 0 === t.clarityOverrides.AttachShadow)) {
            t.clarityOverrides.AttachShadow = t.Element.prototype.attachShadow;
            try {
                t.Element.prototype.attachShadow = function() {
                    return Vo() ? ca(t.clarityOverrides.AttachShadow.apply(this, arguments)) : t.clarityOverrides.AttachShadow.apply(this, arguments)
                }
            } catch (e) {
                t.clarityOverrides.AttachShadow = null
            }
        }
    }
    var da = /[^0-9\.]/g;

    function fa(t) {
        for (var e = 0, n = Object.keys(t); e < n.length; e++) {
            var a = n[e],
                r = t[a];
            if ("@type" === a && "string" == typeof r) switch (r = (r = r.toLowerCase()).indexOf("article") >= 0 || r.indexOf("posting") >= 0 ? "article" : r) {
                case "article":
                case "recipe":
                    Vi(5, t[a]), Vi(8, t.creator), Vi(18, t.headline);
                    break;
                case "product":
                    Vi(5, t[a]), Vi(10, t.name), Vi(12, t.sku), t.brand && Vi(6, t.brand.name);
                    break;
                case "aggregaterating":
                    t.ratingValue && (Q(11, pa(t.ratingValue, 100)), Q(18, pa(t.bestRating)), Q(19, pa(t.worstRating))), Q(12, pa(t.ratingCount)), Q(17, pa(t.reviewCount));
                    break;
                case "offer":
                    Vi(7, t.availability), Vi(14, t.itemCondition), Vi(13, t.priceCurrency), Vi(12, t.sku), Q(13, pa(t.price));
                    break;
                case "brand":
                    Vi(6, t.name)
            }
            null !== r && "object" == typeof r && fa(r)
        }
    }

    function pa(t, e) {
        if (void 0 === e && (e = 1), null !== t) switch (typeof t) {
            case "number":
                return Math.round(t * e);
            case "string":
                return Math.round(parseFloat(t.replace(da, "")) * e)
        }
        return null
    }
    var ha = ["title", "alt", "onload", "onfocus", "onerror", "data-drupal-form-submit-last", "aria-label"],
        va = /[\r\n]+/g;

    function ga(e, n, a) {
        var r, i = null;
        if (2 === n && !1 === ir(e)) return i;
        0 !== n && e.nodeType === Node.TEXT_NODE && e.parentElement && "STYLE" === e.parentElement.tagName && (e = e.parentNode);
        var o = !1 === ir(e) ? "add" : "update",
            u = e.parentElement ? e.parentElement : null,
            c = e.ownerDocument !== document;
        switch (e.nodeType) {
            case Node.DOCUMENT_TYPE_NODE:
                u = c && e.parentNode ? Ga(e.parentNode) : u;
                var s = e,
                    l = {
                        tag: (c ? "iframe:" : "") + "*D",
                        attributes: {
                            name: s.name ? s.name : "HTML",
                            publicId: s.publicId,
                            systemId: s.systemId
                        }
                    };
                t[o](e, u, l, n);
                break;
            case Node.DOCUMENT_NODE:
                e === document && Ua(document), mn(e, a), ma(e);
                break;
            case Node.DOCUMENT_FRAGMENT_NODE:
                var d = e;
                if (d.host) {
                    if (Ua(d), "function" === typeof d.constructor && d.constructor.toString().indexOf("[native code]") >= 0) {
                        ma(d);
                        var f = {
                            tag: "*S",
                            attributes: {
                                style: ""
                            }
                        };
                        t[o](e, d.host, f, n)
                    } else t[o](e, d.host, {
                        tag: "*P",
                        attributes: {}
                    }, n);
                    mn(e, a)
                }
                break;
            case Node.TEXT_NODE:
                if (u = u || e.parentNode, "update" === o || u && ir(u) && "STYLE" !== u.tagName && "NOSCRIPT" !== u.tagName) {
                    var p = {
                        tag: "*T",
                        value: e.nodeValue
                    };
                    t[o](e, u, p, n)
                }
                break;
            case Node.ELEMENT_NODE:
                var h = e,
                    v = h.tagName,
                    g = function(t) {
                        var e = {},
                            n = t.attributes;
                        if (n && n.length > 0)
                            for (var a = 0; a < n.length; a++) {
                                var r = n[a].name;
                                ha.indexOf(r) < 0 && (e[r] = n[a].value)
                            }
                        "INPUT" === t.tagName && !("value" in e) && t.value && (e.value = t.value);
                        return e
                    }(h);
                switch (u = e.parentElement ? e.parentElement : e.parentNode ? e.parentNode : null, "http://www.w3.org/2000/svg" === h.namespaceURI && (v = "svg:" + v), v) {
                    case "HTML":
                        u = c && u ? Ga(u) : u;
                        var m = {
                            tag: (c ? "iframe:" : "") + v,
                            attributes: g
                        };
                        t[o](e, u, m, n);
                        break;
                    case "SCRIPT":
                        if ("type" in g && "application/ld+json" === g.type) try {
                            fa(JSON.parse(h.text.replace(va, "")))
                        } catch (t) {}
                        break;
                    case "NOSCRIPT":
                        var y = {
                            tag: v,
                            attributes: {},
                            value: ""
                        };
                        t[o](e, u, y, n);
                        break;
                    case "META":
                        var b = "property" in g ? "property" : "name" in g ? "name" : null;
                        if (b && "content" in g) {
                            var w = g.content;
                            switch (g[b]) {
                                case "og:title":
                                    Vi(20, w);
                                    break;
                                case "og:type":
                                    Vi(19, w);
                                    break;
                                case "generator":
                                    Vi(21, w)
                            }
                        }
                        break;
                    case "HEAD":
                        var S = {
                                tag: v,
                                attributes: g
                            },
                            k = c && (null === (r = e.ownerDocument) || void 0 === r ? void 0 : r.location) ? e.ownerDocument.location : location;
                        S.attributes["*B"] = k.protocol + "//" + k.host + k.pathname, t[o](e, u, S, n);
                        break;
                    case "BASE":
                        var O = ar(e.parentElement);
                        if (O) {
                            var E = document.createElement("a");
                            E.href = g.href, O.data.attributes["*B"] = E.protocol + "//" + E.host + E.pathname
                        }
                        break;
                    case "STYLE":
                        var T = {
                            tag: v,
                            attributes: g,
                            value: ba(h)
                        };
                        t[o](e, u, T, n);
                        break;
                    case "IFRAME":
                        var _ = e,
                            N = {
                                tag: v,
                                attributes: g
                            };
                        Ja(_) && (! function(t) {
                            !1 === ir(t) && Io(t, "load", sa.bind(this, t, "childList"), !0)
                        }(_), N.attributes["*O"] = "true", _.contentDocument && _.contentWindow && "loading" !== _.contentDocument.readyState && (i = _.contentDocument)), 2 === n && ya(_), t[o](e, u, N, n);
                        break;
                    case "LINK":
                        if (Zi && "stylesheet" === g.rel) {
                            for (var M in Object.keys(document.styleSheets)) {
                                var x = document.styleSheets[M];
                                if (x.ownerNode == h) {
                                    var I = {
                                        tag: "STYLE",
                                        attributes: g,
                                        value: wa(x)
                                    };
                                    t[o](e, u, I, n);
                                    break
                                }
                            }
                            break
                        }
                        var C = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, C, n);
                        break;
                    case "VIDEO":
                    case "AUDIO":
                    case "SOURCE":
                        "src" in g && g.src.startsWith("data:") && (g.src = "");
                        var D = {
                            tag: v,
                            attributes: g
                        };
                        t[o](e, u, D, n);
                        break;
                    default:
                        ! function(t) {
                            var e;
                            (null === (e = window.customElements) || void 0 === e ? void 0 : e.get) && window.customElements.get(t) && jn(t)
                        }(h.localName);
                        var P = {
                            tag: v,
                            attributes: g
                        };
                        h.shadowRoot && (i = h.shadowRoot), t[o](e, u, P, n)
                }
        }
        return i
    }

    function ma(t) {
        ir(t) || Po(t) || (! function(t) {
            try {
                var e = c("MutationObserver"),
                    n = e in window ? new window[e](Mo(aa)) : null;
                n && (n.observe(t, {
                    attributes: !0,
                    childList: !0,
                    characterData: !0,
                    subtree: !0
                }), ta.set(t, n), Vn.add(n)), t.defaultView && la(t.defaultView)
            } catch (t) {
                di(2, 0, t ? t.name : null)
            }
        }(t), rn(t))
    }

    function ya(t) {
        Do(t);
        var e, n, a = Ka(t) || {},
            r = a.doc,
            i = void 0 === r ? null : r,
            o = a.win,
            u = void 0 === o ? null : o;
        u && Do(u), i && (Do(i), e = i, (n = ta.get(e)) && (n.disconnect(), Vn.delete(n), ta.delete(e)), Za(t, i))
    }

    function ba(t) {
        var e = t.textContent ? t.textContent.trim() : "",
            n = t.dataset ? Object.keys(t.dataset).length : 0;
        return (0 === e.length || n > 0 || t.id.length > 0) && (e = wa(t.sheet)), e
    }

    function wa(t) {
        var e = "",
            n = null;
        try {
            n = t ? t.cssRules : []
        } catch (t) {
            if (di(1, 1, t ? t.name : null), t && "SecurityError" !== t.name) throw t
        }
        if (null !== n)
            for (var a = 0; a < n.length; a++) e += n[a].cssText;
        return e
    }
    var Sa = "load,active,fixed,visible,focus,show,collaps,animat".split(","),
        ka = {};

    function Oa(t, e) {
        var n = t.attributes,
            a = t.prefix ? t.prefix[e] : null,
            r = 0 === e ? "".concat("~").concat(t.position - 1) : ":nth-of-type(".concat(t.position, ")");
        switch (t.tag) {
            case "STYLE":
            case "TITLE":
            case "LINK":
            case "META":
            case "*T":
            case "*D":
                return "";
            case "HTML":
                return "HTML";
            default:
                if (null === a) return "";
                a = "".concat(a).concat(">"), t.tag = 0 === t.tag.indexOf("svg:") ? t.tag.substr("svg:".length) : t.tag;
                var i = "".concat(a).concat(t.tag).concat(r),
                    o = "id" in n && n.id.length > 0 ? n.id : null,
                    u = "BODY" !== t.tag && "class" in n && n.class.length > 0 ? n.class.trim().split(/\s+/).filter((function(t) {
                        return Ea(t)
                    })).join(".") : null;
                if (u && u.length > 0)
                    if (0 === e) {
                        var c = "".concat(function(t) {
                            for (var e = t.split(">"), n = 0; n < e.length; n++) {
                                var a = e[n].indexOf("~"),
                                    r = e[n].indexOf(".");
                                e[n] = e[n].substring(0, r > 0 ? r : a > 0 ? a : e[n].length)
                            }
                            return e.join(">")
                        }(a)).concat(t.tag).concat(".").concat(u);
                        c in ka || (ka[c] = []), ka[c].indexOf(t.id) < 0 && ka[c].push(t.id), i = "".concat(c).concat("~").concat(ka[c].indexOf(t.id))
                    } else i = "".concat(a).concat(t.tag, ".").concat(u).concat(r);
                return i = o && Ea(o) ? "".concat(function(t) {
                    var e = t.lastIndexOf("*S"),
                        n = t.lastIndexOf("".concat("iframe:").concat("HTML")),
                        a = Math.max(e, n);
                    if (a < 0) return "";
                    return t.substring(0, t.indexOf(">", a) + 1)
                }(a)).concat("#").concat(o) : i, i
        }
    }

    function Ea(t) {
        if (!t) return !1;
        if (Sa.some((function(e) {
                return t.toLowerCase().indexOf(e) >= 0
            }))) return !1;
        for (var e = 0; e < t.length; e++) {
            var n = t.charCodeAt(e);
            if (n >= 48 && n <= 57) return !1
        }
        return !0
    }
    var Ta = 1,
        _a = null,
        Na = [],
        Ma = [],
        xa = {},
        Ia = [],
        Ca = [],
        Da = [],
        Pa = [],
        Ra = [],
        Aa = [],
        Ya = null,
        ja = null,
        Xa = null,
        La = null,
        Wa = null;

    function za() {
        qa(), Ua(document, !0)
    }

    function Ha() {
        qa()
    }

    function qa() {
        Ta = 1, Na = [], Ma = [], xa = {}, Ia = [], Ca = [], Da = "address,password,contact".split(","), Pa = "password,secret,pass,social,ssn,code,hidden".split(","), Ra = "radio,checkbox,range,button,reset,submit".split(","), Aa = "INPUT,SELECT,TEXTAREA".split(","), _a = new Map, Ya = new WeakMap, ja = new WeakMap, Xa = new WeakMap, La = new WeakMap, Wa = new WeakMap, ka = {}
    }

    function Ua(t, e) {
        void 0 === e && (e = !1);
        try {
            e && u.unmask.forEach((function(t) {
                return t.indexOf("!") < 0 ? Ca.push(t) : Ia.push(t.substr(1))
            })), "querySelectorAll" in t && (u.regions.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return gr(t, "".concat(e[0]))
                }))
            })), u.mask.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return La.set(t, 3)
                }))
            })), u.checksum.forEach((function(e) {
                return t.querySelectorAll(e[1]).forEach((function(t) {
                    return Wa.set(t, e[0])
                }))
            })), Ca.forEach((function(e) {
                return t.querySelectorAll(e).forEach((function(t) {
                    return La.set(t, 0)
                }))
            })))
        } catch (t) {
            di(5, 1, t ? t.name : null)
        }
    }

    function Fa(t, e) {
        if (void 0 === e && (e = !1), null === t) return null;
        var n = Ya.get(t);
        return !n && e && (n = Ta++, Ya.set(t, n)), n || null
    }

    function Va(t, e, n, a) {
        var r = e ? Fa(e) : null;
        if (e && r || null != t.host || t.nodeType === Node.DOCUMENT_TYPE_NODE) {
            var i = Fa(t, !0),
                o = cr(t),
                c = null,
                s = mr(t) ? i : null,
                l = Wa.has(t) ? Wa.get(t) : null,
                d = u.content ? 1 : 3;
            r >= 0 && Na[r] && ((c = Na[r]).children.push(i), s = null === s ? c.region : s, l = null === l ? c.metadata.fraud : l, d = c.metadata.privacy), n.attributes && "data-clarity-region" in n.attributes && (gr(t, n.attributes["data-clarity-region"]), s = i), _a.set(i, t), Na[i] = {
                    id: i,
                    parent: r,
                    previous: o,
                    children: [],
                    data: n,
                    selector: null,
                    hash: null,
                    region: s,
                    metadata: {
                        active: !0,
                        suspend: !1,
                        privacy: d,
                        position: null,
                        fraud: l,
                        size: null
                    }
                },
                function(t, e, n) {
                    var a, r = e.data,
                        i = e.metadata,
                        o = i.privacy,
                        u = r.attributes || {},
                        c = r.tag.toUpperCase();
                    switch (!0) {
                        case Aa.indexOf(c) >= 0:
                            var s = u.type,
                                l = "",
                                d = ["class", "style"];
                            Object.keys(u).filter((function(t) {
                                return !d.includes(t)
                            })).forEach((function(t) {
                                return l += u[t].toLowerCase()
                            }));
                            var f = Pa.some((function(t) {
                                return l.indexOf(t) >= 0
                            }));
                            i.privacy = "INPUT" === c && Ra.indexOf(s) >= 0 ? o : f ? 4 : 2;
                            break;
                        case "data-clarity-mask" in u:
                            i.privacy = 3;
                            break;
                        case "data-clarity-unmask" in u:
                            i.privacy = 0;
                            break;
                        case La.has(t):
                            i.privacy = La.get(t);
                            break;
                        case Wa.has(t):
                            i.privacy = 2;
                            break;
                        case "*T" === c:
                            var p = n && n.data ? n.data.tag : "",
                                h = n && n.selector ? n.selector[1] : "",
                                v = ["STYLE", "TITLE", "svg:style"];
                            i.privacy = v.includes(p) || Ia.some((function(t) {
                                return h.indexOf(t) >= 0
                            })) ? 0 : o;
                            break;
                        case 1 === o:
                            i.privacy = function(t, e, n) {
                                if (t && e.some((function(e) {
                                        return t.indexOf(e) >= 0
                                    }))) return 2;
                                return n.privacy
                            }(u.class, Da, i);
                            break;
                        case "IMG" === c:
                            (null === (a = u.src) || void 0 === a ? void 0 : a.startsWith("blob:")) && (i.privacy = 3)
                    }
                }(t, Na[i], c), $a(Na[i]),
                function(t) {
                    if ("IMG" === t.data.tag && 3 === t.metadata.privacy) {
                        var e = er(t.id);
                        !e || e.complete && 0 !== e.naturalWidth || Io(e, "load", (function() {
                            e.setAttribute("data-clarity-loaded", "".concat(vo()))
                        })), t.metadata.size = []
                    }
                }(Na[i]), sr(i, a)
        }
    }

    function Ba(t, e, n, a) {
        var r = Fa(t),
            i = e ? Fa(e) : null,
            o = cr(t),
            u = !1,
            c = !1;
        if (r in Na) {
            var s = Na[r];
            if (s.metadata.active = !0, s.previous !== o && (u = !0, s.previous = o), s.parent !== i) {
                u = !0;
                var l = s.parent;
                if (s.parent = i, null !== i && i >= 0) {
                    var d = null === o ? 0 : Na[i].children.indexOf(o) + 1;
                    Na[i].children.splice(d, 0, r), s.region = mr(t) ? r : Na[i].region
                } else ! function(t, e) {
                    if (t in Na) {
                        var n = Na[t];
                        n.metadata.active = !1, n.parent = null, sr(t, e), ur(t)
                    }
                }(r, a);
                if (null !== l && l >= 0) {
                    var f = Na[l].children.indexOf(r);
                    f >= 0 && Na[l].children.splice(f, 1)
                }
                c = !0
            }
            for (var p in n) Qa(s.data, n, p) && (u = !0, s.data[p] = n[p]);
            $a(s), sr(r, a, u, c)
        }
    }

    function Ja(t) {
        var e = !1;
        if (t.nodeType === Node.ELEMENT_NODE && "IFRAME" === t.tagName) {
            var n = t;
            try {
                n.contentDocument && (ja.set(n.contentDocument, n), Xa.set(n, {
                    doc: n.contentDocument,
                    win: n.contentWindow
                }), e = !0)
            } catch (t) {}
        }
        return e
    }

    function Ga(t) {
        var e = t.nodeType === Node.DOCUMENT_NODE ? t : null;
        return e && ja.has(e) ? ja.get(e) : null
    }

    function Ka(t) {
        return Xa.has(t) ? Xa.get(t) : null
    }

    function Za(t, e) {
        Xa.delete(t), ja.delete(e)
    }

    function Qa(t, e, n) {
        if ("object" == typeof t[n] && "object" == typeof e[n]) {
            for (var a in t[n])
                if (t[n][a] !== e[n][a]) return !0;
            for (var a in e[n])
                if (e[n][a] !== t[n][a]) return !0;
            return !1
        }
        return t[n] !== e[n]
    }

    function $a(t) {
        var e = t.parent && t.parent in Na ? Na[t.parent] : null,
            n = e ? e.selector : null,
            a = t.data,
            r = function(t, e) {
                e.metadata.position = 1;
                for (var n = t ? t.children.indexOf(e.id) : -1; n-- > 0;) {
                    var a = Na[t.children[n]];
                    if (e.data.tag === a.data.tag) {
                        e.metadata.position = a.metadata.position + 1;
                        break
                    }
                }
                return e.metadata.position
            }(e, t),
            i = {
                id: t.id,
                tag: a.tag,
                prefix: n,
                position: r,
                attributes: a.attributes
            };
        t.selector = [Oa(i, 0), Oa(i, 1)], t.hash = t.selector.map((function(t) {
            return t ? p(t) : null
        })), t.hash.forEach((function(e) {
            return xa[e] = t.id
        }))
    }

    function tr(t) {
        var e = er(rr(t));
        return null !== e && null !== e.textContent ? e.textContent.substr(0, 25) : ""
    }

    function er(t) {
        return _a.has(t) ? _a.get(t) : null
    }

    function nr(t) {
        return t in Na ? Na[t] : null
    }

    function ar(t) {
        var e = Fa(t);
        return e in Na ? Na[e] : null
    }

    function rr(t) {
        return t in xa ? xa[t] : null
    }

    function ir(t) {
        return _a.has(Fa(t))
    }

    function or() {
        for (var t = [], e = 0, n = Ma; e < n.length; e++) {
            var a = n[e];
            a in Na && t.push(Na[a])
        }
        return Ma = [], t
    }

    function ur(t) {
        var e = _a.get(t);
        if ((null == e ? void 0 : e.nodeType) !== Node.DOCUMENT_FRAGMENT_NODE) {
            if (e && (null == e ? void 0 : e.nodeType) === Node.ELEMENT_NODE && "IFRAME" === e.tagName) ya(e);
            _a.delete(t);
            var n = t in Na ? Na[t] : null;
            if (n && n.children)
                for (var a = 0, r = n.children; a < r.length; a++) {
                    ur(r[a])
                }
        }
    }

    function cr(t) {
        for (var e = null; null === e && t.previousSibling;) e = Fa(t.previousSibling), t = t.previousSibling;
        return e
    }

    function sr(t, e, n, a) {
        if (void 0 === n && (n = !0), void 0 === a && (a = !1), !u.lean || !u.lite) {
            var r = Ma.indexOf(t);
            r >= 0 && 1 === e && a ? (Ma.splice(r, 1), Ma.push(t)) : -1 === r && n && Ma.push(t)
        }
    }
    var lr = [],
        dr = null,
        fr = {},
        pr = [],
        hr = !1,
        vr = null;

    function gr(t, e) {
        !1 === dr.has(t) && (dr.set(t, e), (vr = null === vr && hr ? new IntersectionObserver(br, {
            threshold: [0, .05, .1, .2, .3, .4, .5, .6, .7, .8, .9, 1]
        }) : vr) && t && t.nodeType === Node.ELEMENT_NODE && vr.observe(t))
    }

    function mr(t) {
        return dr && dr.has(t)
    }

    function yr() {
        for (var t = [], e = 0, n = pr; e < n.length; e++) {
            var a = n[e],
                r = Fa(a.node);
            r ? (a.state.data.id = r, fr[r] = a.state.data, lr.push(a.state)) : t.push(a)
        }
        pr = t, lr.length > 0 && Ln(7)
    }

    function br(t) {
        for (var e = 0, n = t; e < n.length; e++) {
            var a = n[e],
                r = a.target,
                i = a.boundingClientRect,
                o = a.intersectionRect,
                u = a.rootBounds;
            if (dr.has(r) && i.width + i.height > 0 && u && u.width > 0 && u.height > 0) {
                var c = r ? Fa(r) : null,
                    s = c in fr ? fr[c] : {
                        id: c,
                        name: dr.get(r),
                        interaction: 16,
                        visibility: 0
                    },
                    l = (o ? o.width * o.height * 1 / (u.width * u.height) : 0) > .05 || a.intersectionRatio > .8,
                    d = (l || 10 == s.visibility) && Math.abs(i.top) + u.height > i.height;
                wr(r, s, s.interaction, d ? 13 : l ? 10 : 0), s.visibility >= 13 && vr && vr.unobserve(r)
            }
        }
        lr.length > 0 && Ln(7)
    }

    function wr(t, e, n, a) {
        var r = n > e.interaction || a > e.visibility;
        e.interaction = n > e.interaction ? n : e.interaction, e.visibility = a > e.visibility ? a : e.visibility, e.id ? (e.id in fr && r || !(e.id in fr)) && (fr[e.id] = e, lr.push(Sr(e))) : pr.push({
            node: t,
            state: Sr(e)
        })
    }

    function Sr(t) {
        return {
            time: d(),
            data: {
                id: t.id,
                interaction: t.interaction,
                visibility: t.visibility,
                name: t.name
            }
        }
    }

    function kr() {
        lr = []
    }

    function Or(t) {
        var e = t.composed && t.composedPath ? t.composedPath() : null,
            n = e && e.length > 0 ? e[0] : t.target;
        return Qn = d() + 3e3, n && n.nodeType === Node.DOCUMENT_NODE ? n.documentElement : n
    }

    function Er(t, e, n) {
        void 0 === n && (n = null);
        var a = {
            id: 0,
            hash: null,
            privacy: 2
        };
        if (t) {
            var r = ar(t);
            if (null !== r) {
                var i = r.metadata;
                a.id = r.id, a.hash = r.hash, a.privacy = i.privacy, r.region && function(t, e) {
                    var n = er(t),
                        a = t in fr ? fr[t] : {
                            id: t,
                            visibility: 0,
                            interaction: 16,
                            name: dr.get(n)
                        },
                        r = 16;
                    switch (e) {
                        case 9:
                            r = 20;
                            break;
                        case 27:
                            r = 30
                    }
                    wr(n, a, r, a.visibility)
                }(r.region, e), i.fraud && Jt(i.fraud, r.id, n || r.data.value)
            }
        }
        return a
    }

    function Tr(t, e) {
        return void 0 === e && (e = null), ft(this, void 0, void 0, (function() {
            var n, a, r, i, o, u, c, s, l, f, p, h, v, g, m, y, b, k, O, E, T, _, N, M, x, I, D, R, A, Y, j, X, L, W, z, H;
            return pt(this, (function(q) {
                switch (n = e || d(), a = [n, t], t) {
                    case 13:
                    case 14:
                    case 12:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 19:
                    case 20:
                        for (r = 0, i = he; r < i.length; r++) W = i[r], (o = Er(W.data.target, W.event)).id > 0 && ((a = [W.time, W.event]).push(o.id), a.push(W.data.x), a.push(W.data.y), void 0 !== W.data.id && (a.push(W.data.id), void 0 !== W.data.isPrimary && a.push(W.data.isPrimary.toString())), $r(a), (void 0 === W.data.isPrimary || W.data.isPrimary) && C(W.event, W.data.x, W.data.y, W.time));
                        Oe();
                        break;
                    case 9:
                    case 48:
                        for (u = 0, c = te; u < c.length; u++) W = c[u], s = Er(W.data.target, W.event, W.data.text), a = [W.time, W.event], l = s.hash ? s.hash.join(".") : "", a.push(s.id), a.push(W.data.x), a.push(W.data.y), a.push(W.data.eX), a.push(W.data.eY), a.push(W.data.button), a.push(W.data.reaction), a.push(W.data.context), a.push(w(W.data.text, "click", s.privacy)), a.push(S(W.data.link)), a.push(l), a.push(W.data.trust), a.push(W.data.isFullText), $r(a), xr(W.time, W.event, l, W.data.x, W.data.y, W.data.reaction, W.data.context);
                        re();
                        break;
                    case 38:
                        for (f = 0, p = ie; f < p.length; f++) W = p[f], a = [W.time, W.event], (j = Er(W.data.target, W.event)).id > 0 && (a.push(j.id), a.push(W.data.action), $r(a));
                        ue();
                        break;
                    case 11:
                        h = pe, a.push(h.width), a.push(h.height), C(t, h.width, h.height), Ie(), $r(a);
                        break;
                    case 26:
                        v = Ve, a.push(v.name), a.push(v.persisted), $e(), $r(a);
                        break;
                    case 27:
                        for (g = 0, m = se; g < m.length; g++) W = m[g], y = Er(W.data.target, W.event, W.data.value), (a = [W.time, W.event]).push(y.id), a.push(w(W.data.value, "input", y.privacy, !1, W.data.type)), a.push(W.data.trust), $r(a);
                        fe();
                        break;
                    case 21:
                        (b = We) && (k = Er(b.start, t), O = Er(b.end, t), a.push(k.id), a.push(b.startOffset), a.push(O.id), a.push(b.endOffset), Fe(), $r(a));
                        break;
                    case 10:
                        for (E = 0, T = Ce; E < T.length; E++) W = T[E], _ = Er(W.data.target, W.event), N = Er(W.data.top, W.event), M = Er(W.data.bottom, W.event), x = (null == N ? void 0 : N.hash) ? N.hash.join(".") : "", I = (null == M ? void 0 : M.hash) ? M.hash.join(".") : "", _.id > 0 && ((a = [W.time, W.event]).push(_.id), a.push(W.data.x), a.push(W.data.y), a.push(x), a.push(I), $r(a), C(W.event, W.data.x, W.data.y, W.time));
                        Ce = [], De = null, Pe = null;
                        break;
                    case 42:
                        for (D = 0, R = Gt; D < R.length; D++) W = R[D], a = [W.time, W.event], (j = Er(W.data.target, W.event)).id > 0 && ((a = [W.time, W.event]).push(j.id), a.push(W.data.type), a.push(w(W.data.value, "change", j.privacy)), a.push(w(W.data.checksum, "checksum", j.privacy)), $r(a));
                        Zt();
                        break;
                    case 39:
                        for (A = 0, Y = Ge; A < Y.length; A++) W = Y[A], a = [W.time, W.event], (j = Er(W.data.target, W.event)).id > 0 && (a.push(j.id), $r(a));
                        Ze();
                        break;
                    case 22:
                        for (X = 0, L = Nr; X < L.length; X++) W = L[X], (a = [W.time, W.event]).push(W.data.type), a.push(W.data.hash), a.push(W.data.x), a.push(W.data.y), a.push(W.data.reaction), a.push(W.data.context), $r(a, !1);
                        Mr();
                        break;
                    case 28:
                        z = Be, a.push(z.visible), $r(a), P(n, z.visible), en();
                        break;
                    case 50:
                        H = Je, a.push(H.focused), $r(a, !1), nn()
                }
                return [2]
            }))
        }))
    }
    var _r = [],
        Nr = [];

    function Mr() {
        Nr = []
    }

    function xr(t, e, n, a, r, i, o) {
        void 0 === i && (i = 1), void 0 === o && (o = 0), _r.push({
            time: t,
            event: 22,
            data: {
                type: e,
                hash: n,
                x: a,
                y: r,
                reaction: i,
                context: o
            }
        }), C(e, a, r, t)
    }

    function Ir(t, e, n) {
        return "".concat(t, "=").concat(w(e, 0 === t.indexOf("data-") ? "data-" : t, n))
    }
    var Cr = [],
        Dr = 1,
        Pr = null;

    function Rr() {
        Cr = [],
            function(t) {
                var e = [t];
                for (; e.length > 0;) {
                    for (var n = null, a = null, r = null, i = e.shift(), o = i.firstChild, u = i.parentElement ? i.parentElement : i.parentNode ? i.parentNode : null; o;) e.push(o), o = o.nextSibling;
                    switch (i.nodeType) {
                        case Node.DOCUMENT_TYPE_NODE:
                            var c = i;
                            a = "*D", n = {
                                name: c.name,
                                publicId: c.publicId,
                                systemId: c.systemId
                            };
                            break;
                        case Node.TEXT_NODE:
                            r = i.nodeValue, a = Pr.get(u) ? "*T" : a;
                            break;
                        case Node.ELEMENT_NODE:
                            var s = i;
                            n = Ar(s), a = ["NOSCRIPT", "SCRIPT", "STYLE"].indexOf(s.tagName) < 0 ? s.tagName : a
                    }
                    Yr(i, u, {
                        tag: a,
                        attributes: n,
                        value: r
                    })
                }
            }(document),
            function(t) {
                ft(this, void 0, void 0, (function() {
                    var e, n, a, r, i, o, u, c, s, l, f, p, h;
                    return pt(this, (function(v) {
                        switch (e = d(), n = [e, t], t) {
                            case 8:
                                a = Rn, n.push(a.width), n.push(a.height), C(t, a.width, a.height), $r(n);
                                break;
                            case 43:
                                if ((r = Cr).length > 0) {
                                    for (i = 0, o = r; i < o.length; i++)
                                        for (u = o[i], c = u.metadata.privacy, s = u.data, l = 0, f = ["tag", "attributes", "value"]; l < f.length; l++)
                                            if (s[p = f[l]]) switch (p) {
                                                case "tag":
                                                    n.push(u.id), u.parent && n.push(u.parent), u.previous && n.push(u.previous), n.push(s[p]);
                                                    break;
                                                case "attributes":
                                                    for (h in s[p]) void 0 !== s[p][h] && n.push(Ir(h, s[p][h], c));
                                                    break;
                                                case "value":
                                                    n.push(w(s[p], s.tag, c))
                                            }
                                    $r(un(n), !0)
                                }
                        }
                        return [2]
                    }))
                }))
            }(43)
    }

    function Ar(t) {
        var e = {},
            n = t.attributes;
        if (n && n.length > 0)
            for (var a = 0; a < n.length; a++) e[n[a].name] = n[a].value;
        return e
    }

    function Yr(t, e, n) {
        if (t && n && n.tag) {
            var a = function(t) {
                    return null === t ? null : Pr.has(t) ? Pr.get(t) : (Pr.set(t, Dr), Dr++)
                }(t),
                r = e ? Pr.get(e) : null,
                i = t.previousSibling ? Pr.get(t.previousSibling) : null;
            Cr.push({
                id: a,
                parent: r,
                previous: i,
                children: [],
                data: n,
                selector: null,
                hash: null,
                region: null,
                metadata: {
                    active: !0,
                    suspend: !1,
                    privacy: 5,
                    position: null,
                    fraud: null,
                    size: null
                }
            })
        }
    }
    var jr = [],
        Xr = !1;

    function Lr(t) {
        Xr && "function" == typeof t && jr.push(t)
    }

    function Wr(t) {
        ! function(t) {
            if (!Xr) return;
            try {
                var e = document.createElement("script");
                e.src = t, e.async = !0, document.head.appendChild(e)
            } catch (t) {}
        }(t)
    }
    var zr, Hr, qr, Ur, Fr, Vr = Object.freeze({
            __proto__: null,
            dynamicEvent: Wr,
            register: Lr,
            start: function() {
                Xr = !0
            },
            stop: function() {
                jr.reverse().forEach((function(t) {
                    try {
                        t()
                    } catch (t) {}
                })), jr = [], Xr = !1
            }
        }),
        Br = 0,
        Jr = 0,
        Gr = null,
        Kr = 0,
        Zr = !1;

    function Qr() {
        Ur = !0, Br = 0, Jr = 0, Zr = !1, Kr = 0, zr = [], Hr = [], qr = {}, Fr = null
    }

    function $r(t, e) {
        if (void 0 === e && (e = !0), Ur) {
            var n = d(),
                a = t.length > 1 ? t[1] : null,
                r = JSON.stringify(t);
            switch (u.lean ? !Zr && Jr + r.length > 10485760 && (di(10, 0), Zr = !0) : Zr = !1, a) {
                case 5:
                    if (Zr) break;
                    Br += r.length;
                case 37:
                case 6:
                case 43:
                case 45:
                case 46:
                case 44:
                case 51:
                    if (Zr) break;
                    Jr += r.length, zr.push(r);
                    break;
                default:
                    Hr.push(r)
            }
            K(25);
            var i = function() {
                var t = !1 === u.lean && Br > 0 ? 100 : ko.sequence * u.delay;
                return "string" == typeof u.upload ? Math.max(Math.min(t, 3e4), 100) : u.delay
            }();
            n - Kr > 2 * i && (tt(Gr), Gr = null), e && null === Gr && (25 !== a && rt(), Gr = $(ei, i), Kr = n, ji(Jr))
        }
    }

    function ti() {
        tt(Gr), ei(!0), Br = 0, Jr = 0, Zr = !1, Kr = 0, zr = [], Hr = [], qr = {}, Fr = null, Ur = !1
    }

    function ei(t) {
        return void 0 === t && (t = !1), ft(this, void 0, void 0, (function() {
            var e, n, a, r, i, o, c, s;
            return pt(this, (function(l) {
                switch (l.label) {
                    case 0:
                        return Ur ? (Gr = null, (e = !1 === u.lean && Jr > 0 && (Jr < 1048576 || ko.sequence > 0)) && Q(1, 1), yr(), function() {
                            if (ko) {
                                var t = [];
                                Nr = [];
                                for (var e = (ko.start || 0) + (ko.duration || 0), n = Math.max(e - 2e3, 0), a = 0, r = _r; a < r.length; a++) {
                                    var i = r[a];
                                    i.time >= n && (i.time <= e && Nr.push(i), t.push(i))
                                }
                                _r = t, Tr(22)
                            }
                        }(), Ft(), function() {
                            for (var t = 0, e = pn; t < e.length; t++) {
                                var n = e[t],
                                    a = n == document ? -1 : Fa(n);
                                mn(n, a in fn ? fn[a] : null)
                            }
                        }(), n = !0 === t, ko ? (a = JSON.stringify(To(n)), r = "[".concat(Hr.join(), "]"), i = e ? "[".concat(zr.join(), "]") : "", n && i.length > 0 && a.length + r.length + i.length > 65536 && (i = ""), o = function(t) {
                            return t.p.length > 0 ? '{"e":'.concat(t.e, ',"a":').concat(t.a, ',"p":').concat(t.p, "}") : '{"e":'.concat(t.e, ',"a":').concat(t.a, "}")
                        }({
                            e: a,
                            a: r,
                            p: i
                        }), n ? (s = null, [3, 3]) : [3, 1]) : [2]) : [2];
                    case 1:
                        return [4, vt(o)];
                    case 2:
                        s = l.sent(), l.label = 3;
                    case 3:
                        return Z(2, (c = s) ? c.length : o.length), ni(o, c, ko.sequence, n), Hr = [], e && (zr = [], Jr = 0, Br = 0, Zr = !1), [2]
                }
            }))
        }))
    }

    function ni(t, e, n, a) {
        if (void 0 === a && (a = !1), "string" == typeof u.upload) {
            var r = u.upload,
                i = !1;
            if (a && navigator && navigator.sendBeacon) try {
                (i = navigator.sendBeacon.bind(navigator)(r, t)) && ri(n)
            } catch (t) {}
            if (!1 === i) {
                n in qr ? qr[n].attempts++ : qr[n] = {
                    data: t,
                    attempts: 1
                };
                var o = new XMLHttpRequest;
                o.open("POST", r, !0), o.timeout = 15e3, o.ontimeout = function() {
                    No(new Error("".concat("Timeout", " : ").concat(r)))
                }, null !== n && (o.onreadystatechange = function() {
                    Mo(ai)(o, n)
                }), o.withCredentials = !0, e ? (o.setRequestHeader("Accept", "application/x-clarity-gzip"), o.send(e)) : o.send(t)
            }
        } else if (u.upload) {
            (0, u.upload)(t), ri(n)
        }
    }

    function ai(t, e) {
        var n = qr[e];
        t && 4 === t.readyState && n && ((t.status < 200 || t.status > 208) && n.attempts <= 1 ? t.status >= 400 && t.status < 500 ? Xi(6) : (0 === t.status && (u.upload = u.fallback ? u.fallback : u.upload), Fr = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, Ai(2), ni(n.data, null, e)) : (Fr = {
            sequence: e,
            attempts: n.attempts,
            status: t.status
        }, n.attempts > 1 && Ai(2), 200 === t.status && t.responseText && function(t) {
            for (var e = t && t.length > 0 ? t.split("\n") : [], n = 0, a = e; n < a.length; n++) {
                var r = a[n],
                    i = r && r.length > 0 ? r.split(/ (.*)/) : [""];
                switch (i[0]) {
                    case "END":
                        Xi(6);
                        break;
                    case "UPGRADE":
                        Pi("Auto");
                        break;
                    case "ACTION":
                        u.action && i.length > 1 && u.action(i[1]);
                        break;
                    case "EXTRACT":
                        i.length > 1 && Dt(i[1]);
                        break;
                    case "SIGNAL":
                        i.length > 1 && zt(i[1]);
                        break;
                    case "MODULE":
                        i.length > 1 && Wr(i[1]);
                        break;
                    case "SNAPSHOT":
                        u.lean = !1, Rr()
                }
            }
        }(t.responseText), 0 === t.status && (ni(n.data, null, e, !0), Xi(3)), t.status >= 200 && t.status <= 208 && ri(e), delete qr[e]))
    }

    function ri(t) {
        1 === t && (fo(), lo())
    }
    var ii, oi = {};

    function ui(t) {
        var e = t.error || t;
        return e.message in oi || (oi[e.message] = 0), oi[e.message]++ >= 5 || e && e.message && (ii = {
            message: e.message,
            line: t.lineno,
            column: t.colno,
            stack: e.stack,
            source: t.filename
        }, ci(31)), !0
    }

    function ci(t) {
        return ft(this, void 0, void 0, (function() {
            var e;
            return pt(this, (function(n) {
                switch (e = [d(), t], t) {
                    case 31:
                        e.push(ii.message), e.push(ii.line), e.push(ii.column), e.push(ii.stack), e.push(S(ii.source)), $r(e);
                        break;
                    case 33:
                        si && (e.push(si.code), e.push(si.name), e.push(si.message), e.push(si.stack), e.push(si.severity), $r(e, !1));
                        break;
                    case 41:
                        Vt && (e.push(Vt.id), e.push(Vt.target), e.push(Vt.checksum), $r(e, !1))
                }
                return [2]
            }))
        }))
    }
    var si, li = {};

    function di(t, e, n, a, r) {
        void 0 === n && (n = null), void 0 === a && (a = null), void 0 === r && (r = null);
        var i = n ? "".concat(n, "|").concat(a) : "";
        t in li && li[t].indexOf(i) >= 0 || (si = {
            code: t,
            name: n,
            message: a,
            stack: r,
            severity: e
        }, t in li ? li[t].push(i) : li[t] = [i], ci(33))
    }
    var fi = 5e3,
        pi = {},
        hi = [],
        vi = null,
        gi = null,
        mi = null;

    function yi() {
        pi = {}, hi = [], vi = null, gi = null
    }

    function bi(t, e) {
        return void 0 === e && (e = 0), ft(this, void 0, void 0, (function() {
            var n, a, r;
            return pt(this, (function(i) {
                for (n = 0, a = hi; n < a.length; n++)
                    if (a[n].task === t) return [2];
                return r = new Promise((function(n) {
                    hi[1 === e ? "unshift" : "push"]({
                        task: t,
                        resolve: n,
                        id: ro()
                    })
                })), null === vi && null === gi && wi(), [2, r]
            }))
        }))
    }

    function wi() {
        var t = hi.shift();
        t && (vi = t, t.task().then((function() {
            t.id === ro() && (t.resolve(), vi = null, wi())
        })).catch((function(e) {
            t.id === ro() && (e && di(0, 1, e.name, e.message, e.stack), vi = null, wi())
        })))
    }

    function Si(t) {
        var e = Ti(t);
        return e in pi ? performance.now() - pi[e].start > pi[e].yield ? 0 : 1 : 2
    }

    function ki(t) {
        pi[Ti(t)] = {
            start: performance.now(),
            calls: 0,
            yield: 30
        }
    }

    function Oi(t) {
        var e = performance.now(),
            n = Ti(t),
            a = e - pi[n].start;
        Z(t.cost, a), K(5), pi[n].calls > 0 && Z(4, a)
    }

    function Ei(t) {
        var e;
        return ft(this, void 0, void 0, (function() {
            var n, a;
            return pt(this, (function(r) {
                switch (r.label) {
                    case 0:
                        return (n = Ti(t)) in pi ? (Oi(t), a = pi[n], [4, _i()]) : [3, 2];
                    case 1:
                        a.yield = (null === (e = r.sent()) || void 0 === e ? void 0 : e.timeRemaining()) || 30,
                            function(t) {
                                var e = Ti(t);
                                if (pi && pi[e]) {
                                    var n = pi[e].calls,
                                        a = pi[e].yield;
                                    ki(t), pi[e].calls = n + 1, pi[e].yield = a
                                }
                            }(t), r.label = 2;
                    case 2:
                        return [2, n in pi ? 1 : 2]
                }
            }))
        }))
    }

    function Ti(t) {
        return "".concat(t.id, ".").concat(t.cost)
    }

    function _i() {
        return ft(this, void 0, void 0, (function() {
            return pt(this, (function(t) {
                switch (t.label) {
                    case 0:
                        return gi ? [4, gi] : [3, 2];
                    case 1:
                        t.sent(), t.label = 2;
                    case 2:
                        return [2, new Promise((function(t) {
                            Ni(t, {
                                timeout: fi
                            })
                        }))]
                }
            }))
        }))
    }
    var Ni = window.requestIdleCallback || function(t, e) {
        var n = performance.now(),
            a = new MessageChannel,
            r = a.port1,
            i = a.port2;
        r.onmessage = function(a) {
            var r = performance.now(),
                o = r - n,
                u = r - a.data;
            if (u > 30 && o < e.timeout) requestAnimationFrame((function() {
                i.postMessage(r)
            }));
            else {
                var c = o > e.timeout;
                t({
                    didTimeout: c,
                    timeRemaining: function() {
                        return c ? 30 : Math.max(0, 30 - u)
                    }
                })
            }
        }, requestAnimationFrame((function() {
            i.postMessage(performance.now())
        }))
    };

    function Mi() {
        bi(xi, 1).then((function() {
            Mo(Un)(), Mo(yr)(), Mo(Le)()
        }))
    }

    function xi() {
        return ft(this, void 0, void 0, (function() {
            var t, e;
            return pt(this, (function(n) {
                switch (n.label) {
                    case 0:
                        return t = d(), ki(e = {
                            id: ro(),
                            cost: 3
                        }), [4, Fn(document, e, 0, t)];
                    case 1:
                        return n.sent(), mn(document, t), [4, Ln(5, e, t)];
                    case 2:
                        return n.sent(), Oi(e), [2]
                }
            }))
        }))
    }
    var Ii, Ci = null;

    function Di() {
        !u.lean && u.upgrade && u.upgrade("Config"), Ci = null
    }

    function Pi(t) {
        Vo() && u.lean && (u.lean = !1, Ci = {
            key: t
        }, lo(), fo(), u.upgrade && u.upgrade(t), Ai(3), u.lite && (Mi(), gn()))
    }

    function Ri() {
        Ci = null
    }

    function Ai(t) {
        var e = [d(), t];
        switch (t) {
            case 4:
                var n = N;
                n && n.data && ((e = [n.time, n.event]).push(n.data.visible), e.push(n.data.docWidth), e.push(n.data.docHeight), e.push(n.data.screenWidth), e.push(n.data.screenHeight), e.push(n.data.scrollX), e.push(n.data.scrollY), e.push(n.data.pointerX), e.push(n.data.pointerY), e.push(n.data.activityTime), e.push(n.data.scrollTime), e.push(n.data.pointerTime), e.push(n.data.moveX), e.push(n.data.moveY), e.push(n.data.moveTime), e.push(n.data.downX), e.push(n.data.downY), e.push(n.data.downTime), e.push(n.data.upX), e.push(n.data.upY), e.push(n.data.upTime), e.push(n.data.pointerPrevX), e.push(n.data.pointerPrevY), e.push(n.data.pointerPrevTime), $r(e, !1)), I();
                break;
            case 25:
                e.push(B.gap), $r(e);
                break;
            case 35:
                e.push(Ii.check), $r(e, !1);
                break;
            case 3:
                e.push(Ci.key), $r(e);
                break;
            case 2:
                e.push(Fr.sequence), e.push(Fr.attempts), e.push(Fr.status), $r(e, !1);
                break;
            case 24:
                F.key && e.push(F.key), e.push(F.value), $r(e);
                break;
            case 34:
                var a = Object.keys(mt);
                if (a.length > 0) {
                    for (var r = 0, i = a; r < i.length; r++) {
                        var o = i[r];
                        e.push(o), e.push(mt[o])
                    }
                    kt(), $r(e, !1)
                }
                break;
            case 0:
                var u = Object.keys(G);
                if (u.length > 0) {
                    for (var c = 0, s = u; c < s.length; c++) {
                        var l = s[c],
                            f = parseInt(l, 10);
                        e.push(f), e.push(Math.round(G[l]))
                    }
                    G = {}, $r(e, !1)
                }
                break;
            case 1:
                var p = Object.keys(Hi);
                if (p.length > 0) {
                    for (var h = 0, v = p; h < v.length; h++) {
                        var g = v[h];
                        f = parseInt(g, 10);
                        e.push(f), e.push(Hi[g])
                    }
                    Ji(), $r(e, !1)
                }
                break;
            case 36:
                var m = Object.keys(ut);
                if (m.length > 0) {
                    for (var y = 0, b = m; y < b.length; y++) {
                        var w = b[y];
                        f = parseInt(w, 10);
                        e.push(f), e.push([].concat.apply([], ut[w]))
                    }
                    lt(), $r(e, !1)
                }
                break;
            case 40:
                Nt.forEach((function(t) {
                    e.push(t);
                    var n = [];
                    for (var a in _t[t]) {
                        var r = parseInt(a, 10);
                        n.push(r), n.push(_t[t][a])
                    }
                    e.push(n)
                })), At(), $r(e, !1);
                break;
            case 47:
                e.push(Y.source), e.push(Y.ad_Storage), e.push(Y.analytics_Storage), $r(e, !1)
        }
    }

    function Yi() {
        Ii = {
            check: 0
        }
    }

    function ji(t) {
        if (0 === Ii.check) {
            var e = Ii.check;
            e = ko.sequence >= 128 ? 1 : e, e = ko.pageNum >= 128 ? 7 : e, e = d() > 72e5 ? 2 : e, (e = t > 10485760 ? 2 : e) !== Ii.check && Xi(e)
        }
    }

    function Xi(t) {
        Ii.check = t, 5 !== t && (so(), mu())
    }

    function Li() {
        0 !== Ii.check && Ai(35)
    }

    function Wi() {
        Ii = null
    }
    var zi = null,
        Hi = null,
        qi = !1;

    function Ui() {
        zi = {}, Hi = {}, qi = !1
    }

    function Fi() {
        zi = {}, Hi = {}, qi = !1
    }

    function Vi(t, e) {
        if (e && (e = "".concat(e), t in zi || (zi[t] = []), zi[t].indexOf(e) < 0)) {
            if (zi[t].length > 128) return void(qi || (qi = !0, Xi(5)));
            zi[t].push(e), t in Hi || (Hi[t] = []), Hi[t].push(e)
        }
    }

    function Bi() {
        Ai(1)
    }

    function Ji() {
        Hi = {}, qi = !1
    }
    var Gi = null,
        Ki = [],
        Zi = 0,
        Qi = null,
        $i = null,
        to = {
            ad_Storage: "denied",
            analytics_Storage: "denied"
        };

    function eo() {
        var t, e, n;
        Qi = null;
        var a = navigator && "userAgent" in navigator ? navigator.userAgent : "",
            r = null !== (n = "undefined" != typeof Intl && (null === (e = null === (t = null === Intl || void 0 === Intl ? void 0 : Intl.DateTimeFormat()) || void 0 === t ? void 0 : t.resolvedOptions()) || void 0 === e ? void 0 : e.timeZone)) && void 0 !== n ? n : "",
            i = (new Date).getTimezoneOffset().toString(),
            o = window.location.ancestorOrigins ? Array.from(window.location.ancestorOrigins).toString() : "",
            c = document && document.title ? document.title : "";
        Zi = a.indexOf("Electron") > 0 ? 1 : 0;
        var s = function() {
                var t = {
                        session: vo(),
                        ts: Math.round(Date.now()),
                        count: 1,
                        upgrade: null,
                        upload: ""
                    },
                    e = yo("_clsk", !u.includeSubdomains);
                if (e) {
                    var n = e.includes("^") ? e.split("^") : e.split("|");
                    n.length >= 5 && t.ts - go(n[1]) < 18e5 && (t.session = n[0], t.count = go(n[2]) + 1, t.upgrade = go(n[3]), t.upload = n.length >= 6 ? "".concat("https://").concat(n[5], "/").concat(n[4]) : "".concat("https://").concat(n[4]))
                }
                return t
            }(),
            l = mo(),
            d = u.projectId || p(location.host);
        Gi = {
            projectId: d,
            userId: l.id,
            sessionId: s.session,
            pageNum: s.count
        }, u.lean = u.track && null !== s.upgrade ? 0 === s.upgrade : u.lean, u.upload = u.track && "string" == typeof u.upload && s.upload && s.upload.length > "https://".length ? s.upload : u.upload, Vi(0, a), Vi(3, c), Vi(1, S(location.href, !!Zi)), Vi(2, document.referrer), Vi(15, function() {
            var t = vo();
            if (u.track && po(window, "sessionStorage")) {
                var e = sessionStorage.getItem("_cltk");
                t = e || t, sessionStorage.setItem("_cltk", t)
            }
            return t
        }()), Vi(16, document.documentElement.lang), Vi(17, document.dir), Vi(26, "".concat(window.devicePixelRatio)), Vi(28, l.dob.toString()), Vi(29, l.version.toString()), Vi(33, o), Vi(34, r), Vi(35, i), Q(0, s.ts), Q(1, 0), Q(35, Zi);
        var f, h = null === window || void 0 === window ? void 0 : window.Zone;
        h && "__symbol__" in h && Q(39, 1), navigator && (Vi(9, navigator.language), Q(33, navigator.hardwareConcurrency), Q(32, navigator.maxTouchPoints), Q(34, Math.round(navigator.deviceMemory)), (f = navigator.userAgentData) && f.getHighEntropyValues ? f.getHighEntropyValues(["model", "platform", "platformVersion", "uaFullVersion"]).then((function(t) {
            var e;
            Vi(22, t.platform), Vi(23, t.platformVersion), null === (e = t.brands) || void 0 === e || e.forEach((function(t) {
                Vi(24, t.name + "~" + t.version)
            })), Vi(25, t.model), Q(27, t.mobile ? 1 : 0)
        })) : Vi(22, navigator.platform)), screen && (Q(14, Math.round(screen.width)), Q(15, Math.round(screen.height)), Q(16, Math.round(screen.colorDepth)));
        for (var v = 0, g = u.cookies; v < g.length; v++) {
            var m = g[v],
                y = yo(m);
            y && yt(m, y)
        }
        L(uo($i = {
            ad_Storage: u.track ? "granted" : "denied",
            analytics_Storage: u.track ? "granted" : "denied"
        }, 0)), ho(l)
    }

    function no() {
        Qi = null, Gi = null, $i = null, Ki.forEach((function(t) {
            t.called = !1
        }))
    }

    function ao(t, e, n, a) {
        void 0 === e && (e = !0), void 0 === n && (n = !1), void 0 === a && (a = !1);
        var r = u.lean ? 0 : 1,
            i = !1;
        Gi && (r || !1 === e) && (t(Gi, !u.lean, a ? $i : void 0), i = !0), !n && i || Ki.push({
            callback: t,
            wait: e,
            recall: n,
            called: i,
            consentInfo: a
        })
    }

    function ro() {
        return Gi ? [Gi.userId, Gi.sessionId, Gi.pageNum].join(".") : ""
    }

    function io(t) {
        void 0 === t && (t = !0), t ? (oo({
            ad_Storage: "granted",
            analytics_Storage: "granted"
        }), W()) : oo()
    }

    function oo(t, e) {
        void 0 === t && (t = to), void 0 === e && (e = 1), $i = {
            ad_Storage: co(t.ad_Storage),
            analytics_Storage: co(t.analytics_Storage)
        }, lo(!0);
        var n = uo($i, e);
        if (!n.analytics_Storage) return u.track = !1, wo("_clsk", "", -Number.MAX_VALUE), wo("_clck", "", -Number.MAX_VALUE), mu(), void window.setTimeout(gu, 250);
        Vo() && (u.track = !0, ho(mo(), 1), fo(), H(n), W())
    }

    function uo(t, e) {
        return {
            source: e,
            ad_Storage: "granted" === t.ad_Storage ? 1 : 0,
            analytics_Storage: "granted" === t.analytics_Storage ? 1 : 0
        }
    }

    function co(t) {
        return "string" == typeof t ? t.toLowerCase() : "denied"
    }

    function so() {
        wo("_clsk", "", 0)
    }

    function lo(t) {
        void 0 === t && (t = !1),
            function(t, e) {
                void 0 === e && (e = !1);
                if (Ki.length > 0)
                    for (var n = 0; n < Ki.length; n++) {
                        var a = Ki[n];
                        a.callback && (!a.called && !e || a.consentInfo && e) && (!a.wait || t) && (a.callback(Gi, !u.lean, a.consentInfo ? $i : void 0), a.called = !0, a.recall || (Ki.splice(n, 1), n--))
                    }
            }(u.lean ? 0 : 1, t)
    }

    function fo() {
        if (Gi && u.track) {
            var t = Math.round(Date.now()),
                e = u.upload && "string" == typeof u.upload ? u.upload.replace("https://", "") : "",
                n = u.lean ? 0 : 1;
            wo("_clsk", [Gi.sessionId, t, Gi.pageNum, n, e].join("^"), 1)
        }
    }

    function po(t, e) {
        try {
            return !!t[e]
        } catch (t) {
            return !1
        }
    }

    function ho(t, e) {
        void 0 === e && (e = null), e = null === e ? t.consent : e;
        var n = Math.ceil((Date.now() + 31536e6) / 864e5),
            a = 0 === t.dob ? null === u.dob ? 0 : u.dob : t.dob;
        (null === t.expiry || Math.abs(n - t.expiry) >= 1 || t.consent !== e || t.dob !== a) && wo("_clck", [Gi.userId, 2, n.toString(36), e, a].join("^"), 365)
    }

    function vo() {
        var t = Math.floor(Math.random() * Math.pow(2, 32));
        return window && window.crypto && window.crypto.getRandomValues && Uint32Array && (t = window.crypto.getRandomValues(new Uint32Array(1))[0]), t.toString(36)
    }

    function go(t, e) {
        return void 0 === e && (e = 10), parseInt(t, e)
    }

    function mo() {
        var t = {
                id: vo(),
                version: 0,
                expiry: null,
                consent: 0,
                dob: 0
            },
            e = yo("_clck", !u.includeSubdomains);
        if (e && e.length > 0) {
            var n = e.includes("^") ? e.split("^") : e.split("|");
            n.length > 1 && (t.version = go(n[1])), n.length > 2 && (t.expiry = go(n[2], 36)), n.length > 3 && 1 === go(n[3]) && (t.consent = 1), n.length > 4 && go(n[1]) > 1 && (t.dob = go(n[4])), u.track = u.track || 1 === t.consent, t.id = u.track ? n[0] : t.id
        }
        return t
    }

    function yo(t, e) {
        var n;
        if (void 0 === e && (e = !1), po(document, "cookie")) {
            var a = document.cookie.split(";");
            if (a)
                for (var r = 0; r < a.length; r++) {
                    var i = a[r].split("=");
                    if (i.length > 1 && i[0] && i[0].trim() === t) {
                        for (var o = bo(i[1]), u = o[0], c = o[1]; u;) u = (n = bo(c))[0], c = n[1];
                        return e ? c.endsWith("".concat("~", "1")) ? c.substring(0, c.length - 2) : null : c
                    }
                }
        }
        return null
    }

    function bo(t) {
        try {
            var e = decodeURIComponent(t);
            return [e != t, e]
        } catch (t) {}
        return [!1, t]
    }

    function wo(t, e, n) {
        if ((u.track || "" == e) && (navigator && navigator.cookieEnabled || po(document, "cookie"))) {
            var a = function(t) {
                    return encodeURIComponent(t)
                }(e),
                r = new Date;
            r.setDate(r.getDate() + n);
            var i = r ? "expires=" + r.toUTCString() : "",
                o = "".concat(t, "=").concat(a).concat(";").concat(i).concat(";path=/");
            try {
                if (null === Qi) {
                    for (var c = location.hostname ? location.hostname.split(".") : [], s = c.length - 1; s >= 0; s--)
                        if (Qi = ".".concat(c[s]).concat(Qi || ""), s < c.length - 1 && (document.cookie = "".concat(o).concat(";").concat("domain=").concat(Qi), yo(t) === e)) return;
                    Qi = ""
                }
            } catch (t) {
                Qi = ""
            }
            document.cookie = Qi ? "".concat(o).concat(";").concat("domain=").concat(Qi) : o
        }
    }
    var So, ko = null;

    function Oo() {
        var t = Gi;
        ko = {
            version: f,
            sequence: 0,
            start: 0,
            duration: 0,
            projectId: t.projectId,
            userId: t.userId,
            sessionId: t.sessionId,
            pageNum: t.pageNum,
            upload: 0,
            end: 0,
            applicationPlatform: 0,
            url: ""
        }
    }

    function Eo() {
        ko = null
    }

    function To(t) {
        return ko.start = ko.start + ko.duration, ko.duration = d() - ko.start, ko.sequence++, ko.upload = t && "sendBeacon" in navigator ? 1 : 0, ko.end = t ? 1 : 0, ko.applicationPlatform = 0, ko.url = S(location.href, !1, !0), [ko.version, ko.sequence, ko.start, ko.duration, ko.projectId, ko.userId, ko.sessionId, ko.pageNum, ko.upload, ko.end, ko.applicationPlatform, ko.url]
    }

    function _o() {
        So = []
    }

    function No(t) {
        if (So && -1 === So.indexOf(t.message)) {
            var e = u.report;
            if (e && e.length > 0 && ko) {
                var n = {
                    v: ko.version,
                    p: ko.projectId,
                    u: ko.userId,
                    s: ko.sessionId,
                    n: ko.pageNum
                };
                t.message && (n.m = t.message), t.stack && (n.e = t.stack);
                var a = new XMLHttpRequest;
                a.open("POST", e, !0), a.send(JSON.stringify(n)), So.push(t.message)
            }
        }
        return t
    }

    function Mo(t) {
        return function() {
            var e = performance.now();
            try {
                t.apply(this, arguments)
            } catch (t) {
                throw No(t)
            }
            var n = performance.now() - e;
            Z(4, n), n > 30 && (K(7), Q(6, n), t.dn && di(9, 0, "".concat(t.dn, "-").concat(n)))
        }
    }
    var xo = new Map;

    function Io(t, e, n, a, r) {
        void 0 === a && (a = !1), void 0 === r && (r = !0), n = Mo(n);
        try {
            t[c("addEventListener")](e, n, {
                capture: a,
                passive: r
            }), Po(t) || xo.set(t, []), xo.get(t).push({
                event: e,
                listener: n,
                options: {
                    capture: a,
                    passive: r
                }
            })
        } catch (t) {}
    }

    function Co() {
        xo.forEach((function(t, e) {
            Ro(t, e)
        })), xo = new Map
    }

    function Do(t) {
        Po(t) && Ro(xo.get(t), t)
    }

    function Po(t) {
        return xo.has(t)
    }

    function Ro(t, e) {
        t.forEach((function(t) {
            try {
                e[c("removeEventListener")](t.event, t.listener, {
                    capture: t.options.capture,
                    passive: t.options.passive
                })
            } catch (t) {}
        })), xo.delete(e)
    }
    var Ao = null,
        Yo = null,
        jo = null,
        Xo = 0;

    function Lo() {
        return !(Xo++ > 20) || (di(4, 0), !1)
    }

    function Wo() {
        Xo = 0, jo !== Ho() && (mu(), window.setTimeout(zo, 250))
    }

    function zo() {
        gu(), Q(29, 1)
    }

    function Ho() {
        return location.href ? location.href.replace(location.hash, "") : location.href
    }
    var qo = !1;

    function Uo() {
        qo = !0, s = l(), yi(), Co(), _o(), jo = Ho(), Xo = 0, Io(window, "popstate", Wo), null === Ao && (Ao = history.pushState, history.pushState = function() {
            Ao.apply(this, arguments), Vo() && Lo() && Wo()
        }), null === Yo && (Yo = history.replaceState, history.replaceState = function() {
            Yo.apply(this, arguments), Vo() && Lo() && Wo()
        })
    }

    function Fo() {
        jo = null, Xo = 0, _o(), Co(), yi(), s = 0, qo = !1
    }

    function Vo() {
        return qo
    }

    function Bo() {
        gu(), V("clarity", "restart")
    }
    var Jo = Object.freeze({
        __proto__: null,
        start: function() {
            ! function() {
                Bt = [], Q(26, navigator.webdriver ? 1 : 0);
                try {
                    Q(31, window.top == window.self || window.top == window ? 1 : 2)
                } catch (t) {
                    Q(31, 0)
                }
            }(), Io(window, "error", ui), oi = {}, li = {}
        },
        stop: function() {
            li = {}
        }
    });
    var Go = Object.freeze({
        __proto__: null,
        hashText: tr,
        start: function() {
            var t;
            qn(), Un(), kr(), vr = null, dr = new WeakMap, fr = {}, pr = [], hr = !!window.IntersectionObserver, za(), u.delayDom ? Io(window, "load", (function() {
                    na()
                })) : na(), Mi(), gn(),
                function() {
                    if (window.Animation && window.Animation.prototype && window.KeyframeEffect && window.KeyframeEffect.prototype && window.KeyframeEffect.prototype.getKeyframes && window.KeyframeEffect.prototype.getTiming && (In(), Dn(kn, "play"), Dn(On, "pause"), Dn(En, "commitStyles"), Dn(Tn, "cancel"), Dn(_n, "finish"), null === Sn && (Sn = Element.prototype.animate, Element.prototype.animate = function() {
                            var t = Sn.apply(this, arguments);
                            return Pn(t, "play"), t
                        }), document.getAnimations))
                        for (var t = 0, e = document.getAnimations(); t < e.length; t++) {
                            var n = e[t];
                            "finished" === n.playState ? Pn(n, "finish") : "paused" === n.playState || "idle" === n.playState ? Pn(n, "pause") : "running" === n.playState && Pn(n, "play")
                        }
                }(), window.clarityOverrides = window.clarityOverrides || {}, (null === (t = window.customElements) || void 0 === t ? void 0 : t.define) && !window.clarityOverrides.define && (window.clarityOverrides.define = window.customElements.define, window.customElements.define = function() {
                    return Vo() && jn(arguments[0]), window.clarityOverrides.define.apply(this, arguments)
                })
        },
        stop: function() {
            kr(), dr = null, fr = {}, pr = [], vr && (vr.disconnect(), vr = null), hr = !1, Ha(),
                function() {
                    for (var t = 0, e = Array.from(Vn); t < e.length; t++) {
                        var n = e[t];
                        n && n.disconnect()
                    }
                    Vn = new Set, $n = {}, Bn = [], Jn = {}, Gn = [], Qn = 0, Kn = null, ta = new WeakMap
                }(), qn(), dn = {}, fn = {}, pn = [], hn = [], yn(), In(), Xn(), Yn.clear()
        }
    });
    var Ko = null;

    function Zo() {
        Ko = null
    }

    function Qo(t) {
        Ko = {
                fetchStart: Math.round(t.fetchStart),
                connectStart: Math.round(t.connectStart),
                connectEnd: Math.round(t.connectEnd),
                requestStart: Math.round(t.requestStart),
                responseStart: Math.round(t.responseStart),
                responseEnd: Math.round(t.responseEnd),
                domInteractive: Math.round(t.domInteractive),
                domComplete: Math.round(t.domComplete),
                loadEventStart: Math.round(t.loadEventStart),
                loadEventEnd: Math.round(t.loadEventEnd),
                redirectCount: Math.round(t.redirectCount),
                size: t.transferSize ? t.transferSize : 0,
                type: t.type,
                protocol: t.nextHopProtocol,
                encodedSize: t.encodedBodySize ? t.encodedBodySize : 0,
                decodedSize: t.decodedBodySize ? t.decodedBodySize : 0
            },
            function(t) {
                ft(this, void 0, void 0, (function() {
                    var e, n;
                    return pt(this, (function(a) {
                        return e = d(), n = [e, t], 29 === t && (n.push(Ko.fetchStart), n.push(Ko.connectStart), n.push(Ko.connectEnd), n.push(Ko.requestStart), n.push(Ko.responseStart), n.push(Ko.responseEnd), n.push(Ko.domInteractive), n.push(Ko.domComplete), n.push(Ko.loadEventStart), n.push(Ko.loadEventEnd), n.push(Ko.redirectCount), n.push(Ko.size), n.push(Ko.type), n.push(Ko.protocol), n.push(Ko.encodedSize), n.push(Ko.decodedSize), Zo(), $r(n)), [2]
                    }))
                }))
            }(29)
    }
    var $o, tu = 0,
        eu = 1 / 0,
        nu = 0,
        au = 0,
        ru = [],
        iu = new Map,
        ou = function() {
            return tu || 0
        },
        uu = function() {
            if (!ru.length) return -1;
            var t = Math.min(ru.length - 1, Math.floor((ou() - au) / 50));
            return ru[t].latency
        },
        cu = function() {
            au = ou(), ru.length = 0, iu.clear()
        },
        su = function(t) {
            if (t.interactionId && !(t.duration < 40)) {
                ! function(t) {
                    "interactionCount" in performance ? tu = performance.interactionCount : t.interactionId && (eu = Math.min(eu, t.interactionId), nu = Math.max(nu, t.interactionId), tu = nu ? (nu - eu) / 7 + 1 : 0)
                }(t);
                var e = ru[ru.length - 1],
                    n = iu.get(t.interactionId);
                if (n || ru.length < 10 || t.duration > (null == e ? void 0 : e.latency)) {
                    if (n) t.duration > n.latency && (n.latency = t.duration);
                    else {
                        var a = {
                            id: t.interactionId,
                            latency: t.duration
                        };
                        iu.set(a.id, a), ru.push(a)
                    }
                    ru.sort((function(t, e) {
                        return e.latency - t.latency
                    })), ru.length > 10 && ru.splice(10).forEach((function(t) {
                        return iu.delete(t.id)
                    }))
                }
            }
        },
        lu = ["navigation", "resource", "longtask", "first-input", "layout-shift", "largest-contentful-paint", "event"];

    function du() {
        try {
            $o && $o.disconnect(), $o = new PerformanceObserver(Mo(fu));
            for (var t = 0, e = lu; t < e.length; t++) {
                var n = e[t];
                PerformanceObserver.supportedEntryTypes.indexOf(n) >= 0 && ("layout-shift" === n && Z(9, 0), $o.observe({
                    type: n,
                    buffered: !0
                }))
            }
        } catch (t) {
            di(3, 1)
        }
    }

    function fu(t) {
        ! function(t) {
            for (var e = (!("visibilityState" in document) || "visible" === document.visibilityState), n = 0; n < t.length; n++) {
                var a = t[n];
                switch (a.entryType) {
                    case "navigation":
                        Qo(a);
                        break;
                    case "resource":
                        var r = a.name;
                        Vi(4, hu(r)), r !== u.upload && r !== u.fallback || Q(28, a.duration);
                        break;
                    case "longtask":
                        K(7);
                        break;
                    case "first-input":
                        e && Q(10, a.processingStart - a.startTime);
                        break;
                    case "event":
                        e && "PerformanceEventTiming" in window && "interactionId" in PerformanceEventTiming.prototype && (su(a), Vi(37, uu().toString()));
                        break;
                    case "layout-shift":
                        e && !a.hadRecentInput && Z(9, 1e3 * a.value);
                        break;
                    case "largest-contentful-paint":
                        e && Q(8, a.startTime)
                }
            }
        }(t.getEntries())
    }
    var pu = null;

    function hu(t) {
        return pu || (pu = document.createElement("a")), pu.href = t, pu.host
    }
    var vu = [Jo, Go, on, Object.freeze({
        __proto__: null,
        start: function() {
            Zo(),
                function() {
                    navigator && navigator.connection && Vi(27, navigator.connection.effectiveType), window.PerformanceObserver && PerformanceObserver.supportedEntryTypes ? "complete" !== document.readyState ? Io(window, "load", $.bind(this, du, 0)) : du() : di(3, 0)
                }()
        },
        stop: function() {
            $o && $o.disconnect(), $o = null, cu(), pu = null, Zo()
        }
    }), Vr];

    function gu(t) {
        void 0 === t && (t = null),
            function() {
                try {
                    var t = navigator && "globalPrivacyControl" in navigator && 1 == navigator.globalPrivacyControl;
                    return !1 === qo && "undefined" != typeof Promise && window.MutationObserver && document.createTreeWalker && "now" in Date && "now" in performance && "undefined" != typeof WeakMap && !t
                } catch (t) {
                    return !1
                }
            }() && (! function(t) {
                if (null === t || qo) return !1;
                for (var e in t) e in u && (u[e] = t[e])
            }(t), Uo(), qt(), vu.forEach((function(t) {
                return Mo(t.start)()
            })), null === t && Su())
    }

    function mu() {
        Vo() && (vu.slice().reverse().forEach((function(t) {
            return Mo(t.stop)()
        })), Ut(), Fo(), void 0 !== bu && (bu[wu] = function() {
            (bu[wu].q = bu[wu].q || []).push(arguments), "start" === arguments[0] && bu[wu].q.unshift(bu[wu].q.pop()) && Su()
        }))
    }
    var yu = Object.freeze({
            __proto__: null,
            consent: io,
            consentv2: oo,
            dlog: Vi,
            event: V,
            hashText: tr,
            identify: bt,
            maxMetric: Q,
            measure: Mo,
            metadata: ao,
            pause: function() {
                Vo() && (V("clarity", "pause"), null === gi && (gi = new Promise((function(t) {
                    mi = t
                }))))
            },
            queue: $r,
            register: Lr,
            resume: function() {
                Vo() && (gi && (mi(), gi = null, null === vi && wi()), V("clarity", "resume"))
            },
            schedule: bi,
            set: yt,
            signal: function(t) {
                Wt = t
            },
            start: gu,
            stop: mu,
            time: d,
            upgrade: Pi,
            version: f
        }),
        bu = window,
        wu = "clarity";

    function Su() {
        if (void 0 !== bu) {
            if (bu[wu] && bu[wu].v) return console.warn("Error CL001: Multiple Clarity tags detected.");
            var t = bu[wu] && bu[wu].q || [];
            for (bu[wu] = function(t) {
                    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
                    return yu[t].apply(yu, e)
                }, bu[wu].v = f; t.length > 0;) bu[wu].apply(bu, t.shift())
        }
    }
    Su()
}();